/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/
function MetalBuildingDesigner(background, groundTextureName)
{
	BuildingDesigner.call(this, background, groundTextureName);

	this.buildingType = BUILDING_CARPORT;

	this.CreateBuilding = async function (buildingID, sizeData, rafter)
	{
		if (this.building)
			this.building.Destroy();

		this.buildingButtonData = GuiDataUtilities.GetButtonData(buildingDesigner.buildingID);
		this.building = new MetalBuilding(buildingID, rafter, sizeData);

		await this.building.Initialize();

		ElementsMenu.ElementsListPricingUpdate();
	};

	this.MouseOver = function (mousepos)
	{
		if (this.building)
		{
			this.building.walls.SetMouseOverTransparency(0.0);
			let wallAndPosOnWall = this.building.GetWallMouseOver({
				x: mousepos.x,
				y: mousepos.y
			});

			if (wallAndPosOnWall)
				wallAndPosOnWall.wall.SetMouseOverTransparency(0.5);

			buildingDesigner.Draw();
		}
	};

	this.OnLeftMouseDownOrTouchDelayed = async function ()
	{
		if (!GUIInput.touchStart)
		{						
			if (Elements.draggableElement)
			{
				GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.IDLE;

				GUIInput.EndDraggingElement();
			}
			else
				switch (GUIInput.currentDesignEditorMode)
				{
				case GUIInput.DESIGN_EDIT_MODE.ADD_ELEMENT:

					break;

				case GUIInput.DESIGN_EDIT_MODE.IDLE:
					let vecDelta = new THREE.Vector2().subVectors(GUIInput.vecCurrentMousePos, GUIInput.vecLastMousePos);
					let regenerate = false;

					if (buildingDesigner.building)
						buildingDesigner.building.ClearSelections();

					let selectedObject = Elements.GetSelectedElement();

					if (vecDelta.length() < 4)
					{
						let elementAndPos = buildingDesigner.building.GetSelectedElement({
							x: GUIInput.vecCurrentMousePos.x,
							y: GUIInput.vecCurrentMousePos.y
						});

						if (elementAndPos != null && elementAndPos.element != null)
						{
							selectedObject = elementAndPos;

							//don't set regenerate = true here since a dragging element function will be called that will regenerate
						}
						else
						{
							if (selectedObject)
							{
								regenerate = true;
								selectedObject.SetSelected(false);
							}

							selectedObject = null;
						}

						let buildingSelectedDistance = buildingDesigner.building.IsBuildingSelected({
							x: GUIInput.vecCurrentMousePos.x,
							y: GUIInput.vecCurrentMousePos.y
						});

						if ((!selectedObject && buildingSelectedDistance >= 0) || (buildingSelectedDistance >= 0 && (selectedObject.distance - buildingSelectedDistance) > Wall.WALLTHICKNESS))
						{
							buildingDesigner.building.SetSelected(true);
							selectedObject = buildingDesigner.building;

							let wallAndPosOnWall = this.building.GetWallMouseOver({
								x: GUIInput.vecCurrentMousePos.x,
								y: GUIInput.vecCurrentMousePos.y
							});

							if (wallAndPosOnWall)
								wallAndPosOnWall.wall.SetSelected(true);

							regenerate = true;
						}
						else
						if (selectedObject)
						{
							selectedObject.element.SetSelected(true);

							Elements.StartDraggingElement(elementAndPos.element);

							GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT;

							regenerate = true;
						}

						if (regenerate && buildingDesigner.building)
						{
							buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
							buildingDesigner.Draw();

							ElementsMenu.ElementsListPricingUpdate();
						}
					}

					if (!selectedObject)
						GUIInput.OnRotateMouseOrTouch({
							clientX: GUIInput.vecCurrentMousePos.x,
							clientY: GUIInput.vecCurrentMousePos.y
						});

					break;

				case GUIInput.DESIGN_EDIT_MODE.SET_WALL:
					if (Wall.SelectedWallButtonData)
					{
						let wallAndPosOnWall = this.building.GetWallMouseOver({
							x: GUIInput.vecCurrentMousePos.x,
							y: GUIInput.vecCurrentMousePos.y
						});

						if (wallAndPosOnWall)
						{
							if (Elements.GetElementsOnWall(wallAndPosOnWall.wall.eWall).length == 0)
							{
								if (Wall.SelectedSidingButtonData)
									wallAndPosOnWall.wall.SetWallSidingData(Wall.SelectedSidingButtonData);

								wallAndPosOnWall.wall.SetWallData(Wall.SelectedWallButtonData);

								await wallAndPosOnWall.wall.GetAndSetDimensionWallPrice();

								ElementsMenu.ElementsListPricingUpdate();
							}
							else
								alert(ErrorText.WALL_HAS_ELEMENTS);
						}
					}
					break;

				case GUIInput.DESIGN_EDIT_MODE.SET_SIDING:
					if (Wall.SelectedSidingButtonData)
					{
						let wallAndPosOnWall = this.building.GetWallMouseOver({
							x: GUIInput.vecCurrentMousePos.x,
							y: GUIInput.vecCurrentMousePos.y
						});

						if (wallAndPosOnWall)
						{
							wallAndPosOnWall.wall.SetWallSidingData(Wall.SelectedSidingButtonData);

							await wallAndPosOnWall.wall.GetAndSetDimensionWallPrice();

							buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

							buildingDesigner.building.Draw();

							ElementsMenu.ElementsListPricingUpdate();

							buildingDesigner.building.SetBuildingModified();
						}
					}
					break;
				}

			GUIInput.touchStart = true;
		}
	};

	this.DeleteSelectedElement = function ()
	{
		Elements.DeleteSelectedElement();

		buildingDesigner.building.SetRegenerateElementMeshes(true);

		this.building.SetBuildingModified();
	};

	this.LaunchCreateBuildingCode = async function (buildingID, sizeIndex, savedDesign)
	{
		if (savedDesign)
		{
			BuildingDesigner.buildingLoadedFromDesign = true;
		}
		else
		{
			BuildingDesigner.buildingLoadedFromDesign = false;
		}

		if (BuildingDesigner.buildingChangedbyUser && buildingDesigner.building)
		{
			BuildingDesigner.previousWidth = buildingDesigner.building.sizeData.width_display;
			BuildingDesigner.previousLength = buildingDesigner.building.sizeData.length_display;
			BuildingDesigner.previousSiding = buildingDesigner.building.walls.sidingColorData.siding_id;
			BuildingDesigner.previousSidingCategory = buildingDesigner.building.walls.sidingCategoryData.category_id;
			BuildingDesigner.previousTrim = buildingDesigner.building.roof.cornerTrimColorID;
			BuildingDesigner.previousRoofing = buildingDesigner.building.roof.data.roofing_id;
			BuildingDesigner.previousRoofingCategory = buildingDesigner.building.roof.categoryID;
		}
		else
		{
			BuildingDesigner.buildingChangedbyUser = false;
		}

		buildingDesigner.buildingID = buildingID;
		buildingDesigner.selectedBuildingSizeIndex = sizeIndex;

		if (BuildingDesigner.buildingLoadedFromDesign)
		{
			if (savedDesign.localName)
			{
				buildingDesigner.xmlDesignDoc = savedDesign;
			}
			else
			{
				buildingDesigner.savedDesignObject = savedDesign;
			}
		}

		await MetalBuildingDesigner.CreateBuildingThread();

		ElementsMenu.DestroyContextMenu();
	};

	this.OnClickChangeBuildingSize = async function (event)
	{
		if (BuildingDesigner.buildingType != BUILDING_CARPORT)
		{
			buildingDesigner.selectedBuildingSizeIndex = event.currentTarget.iSizeIndex;

			Rafters.rafterData = GuiDataUtilities.LoadRafterData(buildingDesigner.buildingID, MathUtilities.Round(buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].width, 0));

			let rafter = null;

			if (Rafters.rafterData.length > 0)
			{
				rafter = new Rafter(Rafters.rafterData[0]);
				rafter.Process();
			}

			await buildingDesigner.CreateBuilding(buildingDesigner.buildingID, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex], rafter);

			buildingDesigner.camera.SetInitialPositionAndOrientation();

			buildingDesigner.InitializeCameraAndRender();

			if (event.currentTarget)
			{
				ElementsMenu.SetBuildingSizeChecked(event.currentTarget.iSizeIndex);
			}
			else if (event.target)
			{
				ElementsMenu.SetBuildingSizeChecked(event.target.iSizeIndex);
			}
		}
		else
		{
			let elem = document.getElementById("widthSelection");
			let selectedWidth = elem[elem.selectedIndex].value;

			elem = document.getElementById("lengthSelection");
			let selectedLength = elem[elem.selectedIndex].value;

			elem = document.getElementById("heightSelection");
			let selectedHeight = elem[elem.selectedIndex].value;

			let checkWidthAvailable = false;
			let checkLengthAvailable = false;
			let checkHeightAvailable = false;

			if (selectedWidth.indexOf("*") > -1)
			{
				if (confirm("That selection is unavailable based on your other selections. If you want that specific value then your other selections will be reset if they're unavailable."))
				{
					selectedWidth = TextDataUtilities.RemoveCharacterAndTrimString(selectedWidth, "*");

					selectedLength = "-";
					selectedHeight = "-";

					checkLengthAvailable = true;
					checkHeightAvailable = true;
				}
				else
				{
					elem = document.getElementById("widthSelection");
					elem.selectedIndex = this.prevGUISelectedWidthIndex;

					this.prevGUISelectedWidthIndex = elem.selectedIndex;
				}
			}
			else
			if (selectedLength.indexOf("*") > -1)
			{
				if (confirm("That selection is unavailable based on your other selections. If you wnat that specific value then your other selections will be reset."))
				{
					selectedLength = TextDataUtilities.RemoveCharacterAndTrimString(selectedLength, "*");

					selectedWidth = "-";
					selectedHeight = "-";

					checkWidthAvailable = true;
					checkHeightAvailable = true;
				}
				else
				{
					elem = document.getElementById("lengthSelection");
					elem.selectedIndex = this.prevGUISelectedLengthIndex;

					this.prevGUISelectedLengthIndex = elem.selectedIndex;
				}
			}
			else
			if (selectedHeight.indexOf("*") > -1)
			{
				if (confirm("That selection is unavailable based on your other selections. If you wnat that specific value then your other selections will be reset."))
				{
					selectedHeight = TextDataUtilities.RemoveCharacterAndTrimString(selectedHeight, "*");

					selectedWidth = "-";
					selectedLength = "-";

					checkWidthAvailable = true;
					checkLengthAvailable = true;
				}
				else
				{
					elem = document.getElementById("heightSelection");
					elem.selectedIndex = this.prevGUISelectedHeightIndex;

					this.prevGUISelectedHeightIndex = elem.selectedIndex;
				}
			}

			if (selectedWidth.indexOf("*") == -1 && selectedLength.indexOf("*") == -1 && selectedHeight.indexOf("*") == -1)
			{
				ElementsMenu.CreateAllSizesMenu(buildingDesigner.buildingSizes, selectedWidth, selectedLength, selectedHeight);

				if (selectedWidth != "-" && selectedLength != "-" && selectedHeight != "-")
				{
					buildingDesigner.selectedBuildingSizeIndex = buildingDesigner.GetBuildingIndexForWidthLengthHeightDisplay(selectedWidth, selectedLength, selectedHeight);

					Rafters.rafterData = await GuiDataUtilities.LoadRafterData(buildingDesigner.buildingID, MathUtilities.Round(buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].width, 0));

					let rafter = null;

					if (Rafters.rafterData.length > 0)
					{
						rafter = new Rafter(Rafters.rafterData[0]);
						rafter.Process();
					}

					await buildingDesigner.building.SetRafterAndSizeData(rafter, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex]);
				}
			}

			if (checkWidthAvailable)
			{
				let elem = document.getElementById("widthSelection");

				if (elem[this.prevGUISelectedWidthIndex].value.indexOf("*") == -1)
					elem.selectedIndex = this.prevGUISelectedWidthIndex;
			}

			if (checkLengthAvailable)
			{
				let elem = document.getElementById("lengthSelection");

				if (elem[this.prevGUISelectedLengthIndex].value.indexOf("*") == -1)
					elem.selectedIndex = this.prevGUISelectedLengthIndex;
			}

			if (checkHeightAvailable)
			{
				let elem = document.getElementById("heightSelection");

				if (elem[this.prevGUISelectedHeightIndex].value.indexOf("*") == -1)
					elem.selectedIndex = this.prevGUISelectedHeightIndex;
			}

			elem = document.getElementById("widthSelection");
			this.prevGUISelectedWidthIndex = elem.selectedIndex;

			elem = document.getElementById("lengthSelection");
			this.prevGUISelectedLengthIndex = elem.selectedIndex;

			elem = document.getElementById("heightSelection");
			this.prevGUISelectedHeightIndex = elem.selectedIndex;
		}

		buildingDesigner.InitializeCameraAndRender();
	};

	this.IsValidBuilding = function (buildingID)
	{
		if (buildingID.indexOf("CARPORT") > -1)
			return true;

		return false;
	};
}

MetalBuildingDesigner.prototype = Object.create(BuildingDesigner.prototype);
MetalBuildingDesigner.prototype.constructor = MetalBuildingDesigner;

MetalBuildingDesigner.CreateBuildingThread = async function ()
{
	clearTimeout(this.createBuildingThreadHandle);

	buildingDesigner.buildingSizes = await GuiDataUtilities.LoadBuildingSizes(buildingDesigner.buildingID);

	if (buildingDesigner.buildingSizes)
	{
		if (buildingDesigner.selectedBuildingSizeIndex == -1)
			buildingDesigner.selectedBuildingSizeIndex = buildingDesigner.buildingSizes.length - 1;

		Rafters.rafterData = await GuiDataUtilities.LoadRafterData(buildingDesigner.buildingID, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].width);

		let rafter = null;

		rafter = new Rafter(Rafters.rafterData[0]);
		rafter.Process();

		await buildingDesigner.CreateBuilding(buildingDesigner.buildingID, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex], rafter);

		if (buildingDesigner.xmlDesignDoc != undefined && buildingDesigner.xmlDesignDoc != null)
		{
			await buildingDesigner.building.LoadTDFDesignerFileVersion10(buildingDesigner.xmlDesignDoc);
		}
		else if (buildingDesigner.savedDesignObject && buildingDesigner.savedDesignObject.TDFDESIGN)
		{
			await buildingDesigner.building.LoadTDFDesignerObject(buildingDesigner.savedDesignObject);
		}

		ElementsMenu.UpdateAvailableSizes(buildingDesigner.buildingSizes, buildingDesigner.selectedBuildingSizeIndex, ElementsMenu.SHOW_AVAILABLE_SIZES_MODE_ALL);

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

		buildingDesigner.InitializeCameraAndRender();
	}

	buildingDesigner.xmlDesignDoc = null;

};

MetalBuildingDesigner.LoadDataForGUIRequiredForStartingTheBuildingProcess = async function ()
{
	let buttonParams = {
		subscriber_id: SubscriberDataUtilities.subscriber,
		series_code: SubscriberDataUtilities.series_code,
		building_type: BUILDING_STRING[BuildingDesigner.buildingType]
	};
	[GuiDataUtilities.buildingsButtonData, GuiDataUtilities.sidingCategoryButtonData, GuiDataUtilities.sidingColorButtonData, GuiDataUtilities.roofingButtonData, GuiDataUtilities.trimColorButtonData, GuiDataUtilities.wallsButtonData, TexturesDataUtilities.dataLoaded] = await Promise.all([
		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Buildings", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("SidingCategories", buttonParams),
		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("SidingColors", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Roofing", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("TrimColors", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Walls", buttonParams),

		TexturesDataUtilities.GetTextureDataFromServer()
	]);
};

MetalBuildingDesigner.LoadDataForGUI = async function ()
{
	let buttonParams = {
		subscriber_id: SubscriberDataUtilities.subscriber,
		series_code: SubscriberDataUtilities.series_code,
		building_type: BUILDING_STRING[BuildingDesigner.buildingType]
	};
	[GuiDataUtilities.doorsButtonData, GuiDataUtilities.hingesButtonData, GuiDataUtilities.windowsButtonData, GuiDataUtilities.optionsButtonData] = await Promise.all([
		GuiDataUtilities.currentGuiDataUtilities.LoadElementAndCategoryButtons("Doors"),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Hinges", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Windows", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Options", buttonParams)
	]);
};

/**
 * Initialize the building designer object, set the camera and render, this is called by the IndexDB
 */
MetalBuildingDesigner.Initialize = async function ()
{
	if (BuildingDesigner.cachedVersion != BuildingDesigner.serverVersion)
	{
		location.reload(true);
		return;
	}

	$(".collapse").on("show.bs.collapse", function ()
	{
		$("#infobar-html").hide();
	});

	$(".collapse").on("hide.bs.collapse", function ()
	{
		$("#infobar-html").show();
	});

	if (SubscriberDataUtilities.subscriber.length == 0)
	{
		SubscriberDataUtilities.subscriber = AuxUtilities.GetURLParameter("sc");
	}
	DEBUG = await BuildingDesigner.IsDebugVersion();

	BuildingDesigner.buildingType = BUILDING_CARPORT;

	await SubscriberDataUtilities.LoadData();

	await GuiDataUtilities.currentGuiDataUtilities.ProcessParametersCreateAdditionalHTMLAndConfigurePage("Carport Designer");



	let background = await GuiDataUtilities.GetBackground();

	if (background && background.length > 0)
	{
		background = background[0];
	}
	else
	{
		background = new Object();

		background.texture = "carportdesigner_background";

		background.color = "rgb(255, 255, 255, 255)";
	}


	buildingDesigner = new MetalBuildingDesigner(background, tdf.groundTextureName);

	BuildingDesigner.OnWindowResize();

	if (!await UserDataUtilities.IsSessionZipCodeSet())
	{
		window.location.href = "#zipCodeFormDiv";
		if3CloseLeftMenu();
	}

	if (SubscriberDataUtilities.subscriber)
	{
		let loader = new THREE.FontLoader();

		loader.load(Ruler.RULER_TEXT_FONT, function (font)
		{
			Ruler.rulerFont = font;
		});

		await ColorsDataUtilities.GetColorsDataFromServer();

		await MetalBuildingDesigner.LoadDataForGUIRequiredForStartingTheBuildingProcess();

		//add siding textures data
		TexturesDataUtilities.AddToData(GuiDataUtilities.sidingColorButtonData);

		//add roofing textures data
		TexturesDataUtilities.AddToData(GuiDataUtilities.roofingButtonData);
		await BuildingDesigner.CreateOrLoadBuilding();

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		buildingDesigner.Draw();


		await MetalBuildingDesigner.LoadDataForGUI();

		ObjectDataUtilities.LoadData();

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		buildingDesigner.building.SetBuildingModified();

		ElementsMenu.SetAvailableSiding();
		ElementsMenu.SetAvailableRoofing();
		ElementsMenu.SetAvailableElements();
	}
	else
	{
		window.location.href = "https://sheddesigner2.3dfish.net/";
	}
};

BuildingDesigner.Initialize = MetalBuildingDesigner.Initialize;
