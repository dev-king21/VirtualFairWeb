/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function PorchCeiling(parent)
{
	this.parent = parent;

	this.ceilingTextureFileName = "";
	this.ceilingTexture = null;
	this.ceilingColor = 0xFFFFFF;

	this.regenerate = true;

	this.SetCeilingColor = function (color)
	{
		this.ceilingColor = color;
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.GetTextures = function ()
	{
		if (this.ceilingTextureFileName != "")
		{
			this.ceilingTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.ceilingTextureFileName, buildingDesigner.building.porch.length, buildingDesigner.building.porch.width);
		}
		else
			this.ceilingTexture = null;
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			this.GetTextures();

			this.mesh = new THREE.Mesh();

			let ceilingMater = new THREE.MeshStandardMaterial({
				color: this.ceilingColor,
				metalness: METALNESS
			});


			let ceilingPoints = [];

			for (let i=0; i<this.parent.shape.length;i++)
			{
				ceilingPoints.push({x: this.parent.shape[i].x, y: -this.parent.shape[i].z});
			}

			let shape = new THREE.Shape(ceilingPoints);

			let ceilingGeometry = new THREE.ExtrudeGeometry(shape, {
				depth:  buildingDesigner.building.roofRafter.data.soffit_board_width,
				bevelEnabled: false
			});

			this.mesh = new THREE.Mesh(ceilingGeometry, ceilingMater);

			this.mesh.matrixAutoUpdate = false;
			this.mesh.applyMatrix4(new THREE.Matrix4().makeRotationX(-Math.PI/2));

			if (this.parent.rightSide)
			{
				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(new THREE.Matrix4().makeTranslation((buildingDesigner.building.porch.length>=0 ? 1 * buildingDesigner.building.roofRafter.wallWidth/2 : -1 * buildingDesigner.building.roofRafter.wallWidth/2), buildingDesigner.building.height, -buildingDesigner.building.length/2 + Wall.WALLTHICKNESS + (buildingDesigner.building.porch.length>0 ? this.parent.backWallLength : this.parent.frontWallLength)));
			}
			else
			{
				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(new THREE.Matrix4().makeTranslation((buildingDesigner.building.porch.length>=0 ? 1 * buildingDesigner.building.roofRafter.wallWidth/2 : -1 * buildingDesigner.building.roofRafter.wallWidth/2), buildingDesigner.building.height, buildingDesigner.building.length/2 - Wall.WALLTHICKNESS - (buildingDesigner.building.porch.length>0 ? this.parent.backWallLength : this.parent.frontWallLength)));
			}

			buildingMeshes.push(this.mesh);

			this.regenerate = false;
		}
	};
}

PorchCeiling.CEILING_THICKNESS = 0.1;
