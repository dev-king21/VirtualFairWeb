/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function ProfileUtilities()
{}

ProfileUtilities.Increaselength = function (profile, newLength, reverse, xOffset)
{
	let newProfilePoints = [];

	if (profile)
	{
		let originalLength = profile[profile.length - 1][0];

		let segmentXOffset = 0;

		let exit = false;
		let i;

		while (segmentXOffset < newLength)
		{
			// i from the for loop is used below
			for (i = 0; i < profile.length - 1; i++)
			{
				if (segmentXOffset + profile[i][0] <= newLength)
					newProfilePoints.push([segmentXOffset + profile[i][0], profile[i][1]]);
				else
				{
					////let intersect = GeometryUtilities.LinesIntersectPoint(new THREE.Vector2(segmentXOffset + profile[i-1][0], profile[i-1][1]), new THREE.Vector2(segmentXOffset + profile[i][0], profile[i][1]), new THREE.Vector2(newLength, 0), new THREE.Vector2(newLength, 10));
					////newProfilePoints.push([newLength, profile[i][1]]);

					//exit = true;

					break;
				}
			}

			//if (exit)
			//break;

			segmentXOffset += originalLength;
		}


		if (segmentXOffset >= newLength)
		{
			segmentXOffset -= originalLength;
			// i from the above for loop used here
			let intersect = GeometryUtilities.LinesIntersectPoint(new THREE.Vector2(segmentXOffset + profile[i - 1][0], profile[i - 1][1]), new THREE.Vector2(segmentXOffset + profile[i][0], profile[i][1]), new THREE.Vector2(newLength, 0), new THREE.Vector2(newLength, 10));
			newProfilePoints.push([newLength, profile[i][1]]);

		}
	}
	else
	{
		newProfilePoints.push([0, ProfileUtilities.METALPROFILETHICKNESS]);
		newProfilePoints.push([newLength, ProfileUtilities.METALPROFILETHICKNESS]);
	}


	if (reverse) // != undefined && reverse)
	{
		newProfilePoints = AuxUtilities.ReverseArray(newProfilePoints);

		for (let i = 0; i < newProfilePoints.length; i++)
		{
			newProfilePoints[i][0] = newLength - newProfilePoints[i][0];
		}
	}

	if (xOffset != undefined && xOffset != null && xOffset != 0)
	{
		for (let i = 0; i < newProfilePoints.length; i++)
		{
			newProfilePoints[i][0] = xOffset + newProfilePoints[i][0];
		}
	}


	return newProfilePoints;
};

ProfileUtilities.AddTextureCoordinates = function (profile, profile_texture_coordinates)
{
	let newProfilePts = [];

	let u1 = 0;
	let v1 = 0;
	let v2 = 1;

	let j = 0;

	for (let i = 0; i < profile.length; i++)
	{
		v1 = profile_texture_coordinates[j][1];
		v2 = profile_texture_coordinates[j][2];

		if (v1 == -1)
		{
			v1 = RANDOM_NUMBERS[i];

			if (i % 2)
				v1 = 1 - v1;

			v2 = v1 + v2;


			newProfilePts.push([profile[i][0], profile[i][1], profile_texture_coordinates[j][0], profile_texture_coordinates[j][0], v1, v2]);

			j++;
			j = j % (profile_texture_coordinates.length - 1);

			i++;

			if (i < profile.length)
				newProfilePts.push([profile[i][0], profile[i][1], profile_texture_coordinates[j][0], profile_texture_coordinates[j][0], v1, v2]);
		}
		else
		{
			newProfilePts.push([profile[i][0], profile[i][1], profile_texture_coordinates[j][0], profile_texture_coordinates[j][0], v1, v2]);
		}

		j++;

		j = j % (profile_texture_coordinates.length - 1);


		////newProfilePts.push([profile[i][0], profile[i][1], u1, u1, v1, v2]);

		////u1+=0.1;

	}

	return newProfilePts;
};

ProfileUtilities.IncreaseResolutionForSurface = function (profile, surface)
{
	let newProfilePoints = [];

	let surfaceToProfileX = 0;

	let currentProfilePointIndex = 0;

	let previousProfilePointIndex = currentProfilePointIndex;

	let intersect;

	let pt1, pt2;

	for (let i = 0; i < surface.length - 1; i++)
	{
		pt1 = new THREE.Vector2(surface[i][0], surface[i][1]);
		pt2 = new THREE.Vector2(surface[i + 1][0], surface[i + 1][1]);

		surfaceToProfileX = pt2.sub(pt1).length() + surfaceToProfileX;


		while (currentProfilePointIndex < profile.length && surfaceToProfileX >= profile[currentProfilePointIndex][0])
		{
			currentProfilePointIndex++;
		}


		if (currentProfilePointIndex - previousProfilePointIndex > 1)
		{
			for (let j = previousProfilePointIndex; j < currentProfilePointIndex; j++)
			{
				newProfilePoints.push([profile[j][0], profile[j][1]]);
			}
		}

		if (currentProfilePointIndex < profile.length)
		{
			intersect = GeometryUtilities.LinesIntersectPoint(new THREE.Vector2(profile[currentProfilePointIndex - 1][0], profile[currentProfilePointIndex - 1][1]), new THREE.Vector2(profile[currentProfilePointIndex][0], profile[currentProfilePointIndex][1]), new THREE.Vector2(surfaceToProfileX, 0), new THREE.Vector2(surfaceToProfileX, 1));

			newProfilePoints.push([intersect.x, intersect.y]);
		}

		previousProfilePointIndex = currentProfilePointIndex;
	}

	return newProfilePoints;
};

ProfileUtilities.METALPROFILETHICKNESS = 0.001;
