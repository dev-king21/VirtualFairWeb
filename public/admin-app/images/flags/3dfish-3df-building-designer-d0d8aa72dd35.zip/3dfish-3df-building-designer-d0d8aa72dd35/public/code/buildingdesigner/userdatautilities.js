/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/
function UserDataUtilities()
{

}

UserDataUtilities.SetUserDisplay = function ()
{
	if (UserDataUtilities.usertype == "master")
	{
			if (!DEBUG) {
				$("#statstoggle").hide();
			}
				$(".driverui").show();
				$(".staffui").show();
				$(".adminui").show();
				$(".sadminui").show();
				$(".masterui").show();
	}
	else if (UserDataUtilities.usertype == "admin")
	{
			$(".driverui").show();
			$(".staffui").show();
			$(".adminui").show();
			$(".sadminui").hide();
			$(".masterui").hide();
			if (UserDataUtilities.userData.data && UserDataUtilities.userData.data.acl && UserDataUtilities.userData.data.acl.adminview)
			{
				$(".uiacl_adminview").show();
			}
	}
	else if (UserDataUtilities.usertype == "sadmin")
	{
			$(".driverui").show();
			$(".staffui").show();
			$(".adminui").show();
			$(".sadminui").show();
			$(".masterui").hide();
			if (UserDataUtilities.userData.data && UserDataUtilities.userData.data.acl && UserDataUtilities.userData.data.acl.adminview)
			{
				$(".uiacl_adminview").show();
			}
	}
	else if (UserDataUtilities.usertype == "staff")
	{
			$(".driverui").show();
			$(".staffui").show();
			$(".adminui").hide();
			$(".sadminui").hide();
			$(".masterui").hide();
			if (UserDataUtilities.userData.data && UserDataUtilities.userData.data.acl && UserDataUtilities.userData.data.acl.adminview)
			{
				$(".uiacl_adminview").show();
			}
	}
	else if (UserDataUtilities.usertype == "driver")
	{
			$(".driverui").show();
			$(".staffui").hide();
			$(".adminui").hide();
			$(".sadminui").hide();
			$(".masterui").hide();
			if (UserDataUtilities.userData.data && UserDataUtilities.userData.data.acl && UserDataUtilities.userData.data.acl.adminview)
			{
				$(".uiacl_adminview").show();
			}
	}
	else
	{
			$("#saveAsDefaultConfiguration").hide();
			$("#editObjects").hide();
			$(".driverui").hide();
			$(".staffui").hide();
			$(".adminui").hide();
			$(".sadminui").hide();
			$(".masterui").hide();
	}
	if (UserDataUtilities.userData && UserDataUtilities.userData.data && UserDataUtilities.userData.data.custom_printout) {
		$("#customprintoutoption").show();
	}
	$(".unavailable").hide();
};

UserDataUtilities.GetUserData = async function ()
{
	let userData;
	if (UserDataUtilities.userData && UserDataUtilities.userData.subscriber_id)
	{
		userData = UserDataUtilities.userData;
	}
	else
	{
		let err;
		[err, userData] = await to(NodeJSUtilities.UQuery("userDataRequest",{request: "getUserData", username: UserDataUtilities.userID}));
		if (err) {
			throw err;
		}
	}

	if (userData.userid)
	{
		$("#profileuserid").text(userData.userid);
		$("#profileusername").text(userData.firstname + " " + userData.lastname);
		$("#profileuseraddress").text(userData.address);
		$("#profileuseremail").text(userData.email);
		$("#profileuserphone").text(userData.phone1);

		UserDataUtilities.userData = userData;
		UserDataUtilities.userID = userData.userid;
		UserDataUtilities.username = userData.firstname + " " + userData.lastname;
		UserDataUtilities.address = userData.address;
		UserDataUtilities.email = userData.email;
		UserDataUtilities.phone1 = userData.phone1;
		UserDataUtilities.zipcode = userData.zip;
		UserDataUtilities.usertype = userData.usertype;
	}

	let saveAsDefaultConfiguration = document.getElementById("saveAsDefaultConfiguration");

	let editObjects = document.getElementById("editObjects");

	UserDataUtilities.SetUserDisplay();
};


UserDataUtilities.AddFormHandler = function ()
{
	let zipCodeForm = document.getElementById("zipCodeForm");

	zipCodeForm.addEventListener("keyup", function (event)
	{
		event.preventDefault();

		if (event.keyCode == 13)
		{
			document.getElementById("zipCodeButton").click();
		}
	});
};

UserDataUtilities.ValidateZipCode = async function (form)
{
	let zipCode = form.elements.zipCode.value;

	if (zipCode.length == 0)
	{
		document.getElementById("zipCodeResult").innerHTML = "<font size='2' color='red'>Zip code not entered</font>";
	}
	else
	{
		let err, zipcodeResult;
		if (zipCode !== window.invalidZip) {
			[err, zipcodeResult] = await to(NodeJSUtilities.UQuery("userAction",{request: "setZipCode", subscriber_id: SubscriberDataUtilities.subscriber, zipCode: zipCode}));
			if (err)
			{
				zipcodeResult.error = err;
			}
		} else {
			zipcodeResult = {validzip: false};
		}
		if (!zipcodeResult.validzip) {
			if (zipcodeResult.error) {
				document.getElementById("zipCodeResult").innerHTML = "<font size='2' color='red'>Sorry, error when looking up zipcode.</font>";
			} else {
				document.getElementById("zipCodeResult").innerHTML = "<font size='2' color='red'>Sorry, zip code not found</font>";
				window.invalidZip = zipCode;
			}
		} else if (!zipcodeResult.inrange) {
			switch (BuildingDesigner.buildingType)
			{
			case BUILDING_CARPORT:
				document.getElementById("zipCodeResult").innerHTML = "<font size='2' color='red'>Sorry, 3d carport designer is unavailable in your area</font>";
				break;
			case BUILDING_SHED:
				document.getElementById("zipCodeResult").innerHTML = "<font size='2' color='red'>Sorry, 3d shed designer is unavailable in your area</font>";
				break;
			case BUILDING_HORSEBARN:
				document.getElementById("zipCodeResult").innerHTML = "<font size='2' color='red'>Sorry, 3d horse barn designer is unavailable in your area</font>";
				break;
			default:
				document.getElementById("zipCodeResult").innerHTML = "<font size='2' color='red'>Sorry, the 3d building designer is unavailable in your area</font>";
				break;
			}
		}
		else
		{
			UserDataUtilities.zipcode = zipCode;
			if (zipcodeResult.postal_code_data)
			{
				UserDataUtilities.postal_code_data = zipcodeResult.postal_code_data;
			}
			$("#contact_zipcode").val(zipCode).prev("label").addClass("show");
			SubscriberDataUtilities.SetLocation(zipcodeResult.closest_location);

			form.elements.sc = SubscriberDataUtilities.subscriber;
			window.location.href = "#";
			if (featureData && featureData.interface && featureData.interface.guide_popup)
			{
				$("#GuideModal").foundation("open");
			}
		}
	}
};

UserDataUtilities.AutoFillCheckPostalCode = async function (element)
{
	if ($(element).is(":focus"))
	{
		return;
	}
	else
	{
		await UserDataUtilities.ValidatePostalCode(element);
	}
}

UserDataUtilities.ValidatePostalCode = async function (element, cb)
{
	if (UserDataUtilities.postal_code_data && UserDataUtilities.postal_code_data.zipcode == element.value)
	{
		element.form.postal_code_data = UserDataUtilities.postal_code_data;
		if (UserDataUtilities.postal_code_data.country_code === "US")
		{
			if (element.labels[0])
			{
				element.labels[0].innerHTML = element.placeholder + ": " + UserDataUtilities.postal_code_data.city + ", " + UserDataUtilities.postal_code_data.state;
				element.isvalid = true;
				element.validitychecked = true;
				if (typeof cb === "function")
				{
					cb(element);
				}
			}
		}
	}
	else
	{
		let [err, postalcodeResult] = await to(NodeJSUtilities.UQuery("userAction",{request:"checkPostalCode", subscriber_id: SubscriberDataUtilities.subscriber, postalCode: element.value}));
		if (err) {
			element.isvalid = false;
			element.form.postal_code_data = null;
			element.validitychecked = true;
			element.labels[0].innerHTML = element.placeholder + ": " + "<font color='red'>Error contacting server</font>";
			return;
		}
		if (postalcodeResult.validzip)
		{
			element.form.postal_code_data = postalcodeResult.postal_code_data;
			if (postalcodeResult.postal_code_data.country_code === "US")
			{
				if (element.labels[0])
				{
					element.labels[0].innerHTML = element.placeholder + ": " + postalcodeResult.postal_code_data.city + ", " + postalcodeResult.postal_code_data.state;
					element.isvalid = true;
					element.validitychecked = true;
					if (typeof cb === "function")
					{
						cb(element);
					}
				}
			}
		}
		else
		{
			element.isvalid = false;
			element.form.postal_code_data = null;
			element.validitychecked = true;
			element.labels[0].innerHTML = element.placeholder + ": " + "<font color='red'>Invalid zip code</font>";
		}
	}
}

UserDataUtilities.IsSessionZipCodeSet = async function ()
{
	let err;
	let zipcodeResult = {};
	[err,zipcodeResult] = await to(NodeJSUtilities.UQuery("userDataRequest",{request: "getZipCode", subscriber_id: SubscriberDataUtilities.subscriber}));

	if (typeof zipcodeResult === "undefined" || !zipcodeResult.validzip)
		return false;
	else
	{
		UserDataUtilities.zipcode = zipcodeResult.zipCode;
		if (UserDataUtilities.userData && UserDataUtilities.userData.location_number > 0)
		{
			SubscriberDataUtilities.location_number = UserDataUtilities.userData.location_number;
		}
		else
		{
			SubscriberDataUtilities.location_number = zipcodeResult.closest_location;
		}
		if (zipcodeResult.postal_code_data)
		{
			UserDataUtilities.postal_code_data = zipcodeResult.postal_code_data;
		}
		if (UserDataUtilities.userData && !UserDataUtilities.userData.zip > 0)
		{
			UserDataUtilities.zip = zipcodeResult.zipCode;
			let [err, setResult] = await to(NodeJSUtilities.UQuery("userAction",{request: "setZipCode", subscriber_id: SubscriberDataUtilities.subscriber, zipCode: zipcodeResult.zipCode}));
		}
		if (interfaceCode === "if3")
		{
			$("#contact_zipcode").val(zipcodeResult.zipCode).prev("label").addClass("show");
			//$("#contact_zipcode").prev('label').addClass(showClass);
			if (featureData && featureData.interface && featureData.interface.guide_popup)
			{
				$("#GuideModal").foundation("open");
			}
		}
		return true;
	}
};

ifvisible.activeNow = true;

UserDataUtilities.updateAppStatus = async function () {
	if (DEBUG) {
		console.log("UDU.updateAppStatus");
	}
	if (UserDataUtilities.updatingAppStatus) {
		if (DEBUG) { console.log("...not updating")};
		return;
	}
	if ((!window.socket) || (!socket.connected)) {
		return;
	}
	UserDataUtilities.updatingAppStatus = true;
	await AuxUtilities.sleep(2000);
	//socket.emit("userInfo",{info: "appStatus", visible: ifvisible.now(), active: ifvisible.activeNow});
	socket.emit("userInfo",{info: "appStatus", visible: document.visibilityState === "visible", active: ifvisible.activeNow});
	UserDataUtilities.updatingAppStatus = false;
	if (DEBUG) {
		console.log(`update sent. visible: ${ifvisible.now()}, active: ${ifvisible.activeNow}`);
	}
}

ifvisible.on("blur", function(){
	//socket.emit("userInfo",{info: "appStatus", visible: false, active: false});
	ifvisible.activeNow = false;
	if (document.visibilityState === "hidden") {
		UserDataUtilities.updateAppStatus();
	}
	if (DEBUG) {
		console.log("ifvisible:on blur");
	}
});

ifvisible.on("focus", function(){
	//socket.emit("userInfo",{info: "appStatus", visible: true});
	UserDataUtilities.updateAppStatus();
	if (DEBUG) {
		console.log("ifvisible:on focus");
	}
})

ifvisible.on("idle", function(){
	//socket.emit("userInfo",{info: "appStatus", visible: ifvisible.now(), active: false});
	ifvisible.activeNow = false;
	UserDataUtilities.updateAppStatus();
	if (DEBUG) {
		console.log("ifvisible:on idle");
	}
})

ifvisible.on("wakeup", function(){
	//socket.emit("userInfo",{info: "appStatus", visible: ifvisible.now(), active: true});
	ifvisible.activeNow = true;
	UserDataUtilities.updateAppStatus();
	if (DEBUG) {
		console.log("on wakeup");
	}
})

if (window.socket) {
	socket.on("notification",(data) =>
	{
		if (data.msg)
		{
			GuiDataUtilities.Alert(data.msg);
		}
	});
}

UserDataUtilities.loggedIn = false;
UserDataUtilities.userID = "";
UserDataUtilities.fQUserID = "";
UserDataUtilities.zipcode = "";
UserDataUtilities.usertype = "";
UserDataUtilities.userData = {};
