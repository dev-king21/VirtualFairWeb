/*eslint-env jquery, browser, es6*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/
function HorseBarnBuildingDesigner(background, groundTextureName)
{
	BuildingDesigner.call(this, background, groundTextureName);

	this.buildingType = BUILDING_HORSEBARN;

	this.CreateBuilding = async function(buildingID, sizeData, rafter)
	{
		if (this.building)
			this.building.Destroy();

		this.buildingButtonData = GuiDataUtilities.GetButtonData(buildingDesigner.buildingID);
		let stallCountData = sizeData.stall_count.split(",");

		let stallCount = -1;

		if (this.building && this.building.stallCount == +stallCountData[buildingDesigner.selectedStallCountIndex]) //+ changes string into number
		{
			for (let i = 0; i < stallCountData.length; i++)
			{
				if (this.building.stallCount == +stallCountData[i])
				{
					stallCount = this.building.stallCount;

					buildingDesigner.selectedStallCountIndex = i;

					break;
				}
			}
		}

		if (stallCount == -1)
		{
			if (buildingDesigner.selectedStallCountIndex == -1)
				buildingDesigner.selectedStallCountIndex = stallCountData.length - 1;
			else
			if (buildingDesigner.selectedStallCountIndex > stallCountData.length - 1)
				buildingDesigner.selectedStallCountIndex = stallCountData.length - 1;

			stallCount = +stallCountData[buildingDesigner.selectedStallCountIndex];
		}

		if (stallCount == 0)
			stallCount = 1;

		this.building = new HorseBarnBuilding(buildingID, rafter, sizeData, stallCount);

		await this.building.Initialize();

		ElementsMenu.ElementsListPricingUpdate();

	};

	this.CreateBuildingAndDefaultElements = async function(buildingID, sizeData, rafter)
	{
		await this.CreateBuilding(buildingID, sizeData, rafter);

		this.building.AddDefaultElements();

		this.building.SetBuildingModified();

		Elements.draggableElement = null;

	};

	this.MouseOver = function(mousepos)
	{};

	this.OnLeftMouseDownOrTouchDelayed = async function()
	{
		if (!GUIInput.touchStart)
		{
			if (Elements.draggableElement)
			{
				GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.IDLE;

				GUIInput.EndDraggingElement();
			}
			else
				switch (GUIInput.currentDesignEditorMode)
				{
				case GUIInput.DESIGN_EDIT_MODE.ADD_ELEMENT:

					break;

				case GUIInput.DESIGN_EDIT_MODE.IDLE:
				case GUIInput.DESIGN_EDIT_MODE.SET_PARTITION:
					let vecDelta = new THREE.Vector2().subVectors(GUIInput.vecCurrentMousePos, GUIInput.vecLastMousePos);

					////buildingDesigner.building.ClearSelections();

					let regenerate = false;
					////let selectedObject = null;
					let selectedObject = Elements.GetSelectedElement();

					if (vecDelta.length() < 4)
					{
						let elementAndPos = buildingDesigner.building.GetSelectedElement({
							x: GUIInput.vecCurrentMousePos.x,
							y: GUIInput.vecCurrentMousePos.y
						});

						let partition = buildingDesigner.building.GetSelectedPartitionAtMouseCoord({
							x: GUIInput.vecCurrentMousePos.x,
							y: GUIInput.vecCurrentMousePos.y
						});



						if (elementAndPos != null && elementAndPos.element != null)
						{
							if (!partition || elementAndPos.distance < partition.distance)
							{
								selectedObject = elementAndPos;

								partition = null;
							}
							else if (partition)
							{
								selectedObject = partition;
							}
						}
						else if (partition)
						{
							selectedObject = partition;
						}
						else
						{
							if (selectedObject)
							{
								regenerate = true;
								selectedObject.SetSelected(false);
							}

							selectedObject = null;
						}

						let buildingSelectedDistance = buildingDesigner.building.IsBuildingSelected({
							x: GUIInput.vecCurrentMousePos.x,
							y: GUIInput.vecCurrentMousePos.y
						});

						if ((!selectedObject && buildingSelectedDistance >= 0) || (buildingSelectedDistance >= 0 && buildingSelectedDistance < selectedObject.distance))
						{
							if (!buildingDesigner.building.selected)
							{
								buildingDesigner.building.SetSelected(true);
								selectedObject = buildingDesigner.building;
							}
							else
								buildingDesigner.building.SetSelected(false);

							regenerate = true;
						}
						else if (selectedObject)
						{
							selectedObject.element.SetSelected(true);

							if (!partition)
							{
								Elements.StartDraggingElement(elementAndPos.element);

								GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT;

								regenerate = true;
							}
						}

						if (regenerate && buildingDesigner.building)
						{
							buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
							buildingDesigner.Draw();
						}
					}

					if (!selectedObject)
						GUIInput.OnRotateMouseOrTouch({
							clientX: GUIInput.vecCurrentMousePos.x,
							clientY: GUIInput.vecCurrentMousePos.y
						});

					////buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
					////buildingDesigner.Draw();

					break;
				}

			GUIInput.touchStart = true;
		}
	};

	this.DeleteSelectedElement = function()
	{
		Elements.DeleteSelectedElement();

		let partition = buildingDesigner.building.stalls.GetSelectedPartition();

		if (partition)
		{
			partition.SetStyle(Partition.NO_PARTITION);
			partition.price = 0;

			partition.SetSelected(false);

			buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		}
		else
			buildingDesigner.building.SetRegenerateElementMeshes(true);

		this.building.SetBuildingModified();
	};

	this.LaunchCreateBuildingCode = async function(buildingID, sizeIndex, savedDesign)
	{
		if (savedDesign)
		{
			BuildingDesigner.buildingLoadedFromDesign = true;
		}
		else
		{
			BuildingDesigner.buildingLoadedFromDesign = false;
		}
		buildingDesigner.buildingID = buildingID;
		buildingDesigner.selectedBuildingSizeIndex = sizeIndex;

		if (BuildingDesigner.buildingLoadedFromDesign)
		{
			if (savedDesign.localName)
			{
				buildingDesigner.xmlDesignDoc = savedDesign;
			}
			else
			{
				buildingDesigner.savedDesignObject = savedDesign;
			}
		}

		await HorseBarnBuildingDesigner.CreateBuildingThread();

		////buildingDesigner.createBuildingThreadHandle = setTimeout(HorseBarnBuildingDesigner.CreateBuildingThread, 1000);

		ElementsMenu.DestroyContextMenu();
	};

	this.OnClickChangeBuildingSize = async function(event)
	{
		buildingDesigner.selectedBuildingSizeIndex = event.currentTarget.iSizeIndex;

		Rafters.rafterData = await GuiDataUtilities.LoadRafterData(buildingDesigner.buildingID, MathUtilities.Round(buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].width, 0));

		let rafter = null;

		if (Rafters.rafterData.length > 0)
		{
			let previousSelectedLeanToWidth = buildingDesigner.leanToSizes[buildingDesigner.selectedLeanToSizeIndex].width;

			buildingDesigner.selectedLeanToSizeIndex = 0;
			if (Rafters.rafterData.length > 1) // more than one rafter for a specified width indicates lean to's with different widths are also available
			{
				buildingDesigner.leanToSizes = GuiDataUtilities.LoadLeanToSizes(Rafters.rafterData);

				for (let i = 0; i < buildingDesigner.leanToSizes.length; i++)
				{
					if (buildingDesigner.leanToSizes[i].width == previousSelectedLeanToWidth)
					{
						buildingDesigner.selectedLeanToSizeIndex = i;
						ElementsMenu.SetBuildingLeanToSizeChecked(buildingDesigner.selectedLeanToSizeIndex);
						break;
					}
				}
			}

			rafter = new Rafter(Rafters.rafterData[buildingDesigner.selectedLeanToSizeIndex]);
			rafter.Process();
		}

		GuiDataUtilities.LoadStallCount(buildingDesigner.buildingSizes, buildingDesigner.selectedBuildingSizeIndex);

		await buildingDesigner.CreateBuildingAndDefaultElements(buildingDesigner.buildingID, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex], rafter);

		////buildingDesigner.camera.SetInitialPositionAndOrientation();

		ElementsMenu.SetStallCountChecked(buildingDesigner.selectedStallCountIndex);

		if (event.currentTarget)
		{
			ElementsMenu.SetBuildingSizeChecked(event.currentTarget.iSizeIndex);
		}
		else if (event.target)
		{
			ElementsMenu.SetBuildingSizeChecked(event.target.iSizeIndex);
		}

        buildingDesigner.building.InitializeRulersAndLogo();
        buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		buildingDesigner.InitializeCameraAndRender();
	};

	this.IsValidBuilding = function(buildingID)
	{
		if (buildingID == "STALL_BARN_WITH_LEANTTO" || buildingID == "STALL_BARN")
			return true;

		return false;
	};
}

HorseBarnBuildingDesigner.prototype = Object.create(BuildingDesigner.prototype);
HorseBarnBuildingDesigner.prototype.constructor = HorseBarnBuildingDesigner;

HorseBarnBuildingDesigner.CreateBuildingThread = async function()
{
	////if (GeometryUtilities.objectsLoaded)
	{
		clearTimeout(this.createBuildingThreadHandle);

		BuildingDesigner.creatingBuilding = true;
		buildingDesigner.buildingSizes = await GuiDataUtilities.LoadBuildingSizes(buildingDesigner.buildingID);

		if (buildingDesigner.buildingSizes)
		{

			if (buildingDesigner.selectedBuildingSizeIndex === -1)
			{
				buildingDesigner.defaultSettings = await buildingDesigner.GetDefaultSettings(buildingDesigner.buildingID, 0);
				if (buildingDesigner.defaultSettings)
				{
					if (buildingDesigner.defaultSettings.options && buildingDesigner.defaultSettings.options.default_width)
					{
						buildingDesigner.selectedBuildingSizeIndex = buildingDesigner.GetBuildingIndexForWidthLengthHeightDisplay(buildingDesigner.defaultSettings.options.default_width,buildingDesigner.defaultSettings.default_length,buildingDesigner.buildingSizes[0].height_display);
					}
					else
					{
						buildingDesigner.selectedBuildingSizeIndex = buildingDesigner.GetBuildingIndexForWidthLengthHeightDisplay(buildingDesigner.buildingSizes[0].width_display,buildingDesigner.defaultSettings.default_length,buildingDesigner.buildingSizes[0].height_display);
					}
				}
				else
				{
					buildingDesigner.selectedBuildingSizeIndex = 0;
				}
				// buildingDesigner.selectedBuildingSizeIndex = buildingDesigner.buildingSizes.length - 1;
			}

			GuiDataUtilities.LoadStallCount(buildingDesigner.buildingSizes, buildingDesigner.selectedBuildingSizeIndex);

			Rafters.rafterData = await GuiDataUtilities.LoadRafterData(buildingDesigner.buildingID, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].width);

			let rafter = null;

			if (Rafters.rafterData.length > 0)
			{
				rafter = new Rafter(Rafters.rafterData[0]);
				rafter.Process();

				buildingDesigner.leanToSizes = GuiDataUtilities.LoadLeanToSizes(Rafters.rafterData);
			}

			await buildingDesigner.CreateBuilding(buildingDesigner.buildingID, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex], rafter);

			if (buildingDesigner.xmlDesignDoc != undefined && buildingDesigner.xmlDesignDoc != null)
			{
				await buildingDesigner.building.LoadTDFDesignerFileVersion10(buildingDesigner.xmlDesignDoc);
			}
			else if (buildingDesigner.savedDesignObject && buildingDesigner.savedDesignObject.TDFDESIGN)
			{
				await buildingDesigner.building.LoadTDFDesignerObject(buildingDesigner.savedDesignObject);
			}
			else
			{
				buildingDesigner.building.AddDefaultElements();
			}


			ElementsMenu.UpdateAvailableSizes(buildingDesigner.buildingSizes, buildingDesigner.selectedBuildingSizeIndex);

			ElementsMenu.SetBuildingSizeChecked(buildingDesigner.selectedBuildingSizeIndex);

			buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
			buildingDesigner.Draw();

			let element = document.getElementById("tabPartitionsButton");

			if (element.className == "selected")
				ElementsMenu.TabPartitions();

			BuildingDesigner.creatingBuilding = false;
		}

		buildingDesigner.xmlDesignDoc = null;

		buildingDesigner.InitializeCameraAndRender();
	}
};

HorseBarnBuildingDesigner.LoadDataForGUIRequiredForStartingTheBuildingProcess = async function()
{
	let buttonParams = {
		subscriber_id: SubscriberDataUtilities.subscriber,
		series_code: SubscriberDataUtilities.series_code,
		building_type: BUILDING_STRING[BuildingDesigner.buildingType]
	};
	let result1, result2;
	[GuiDataUtilities.buildingsButtonData, GuiDataUtilities.partitionsButtonData, GuiDataUtilities.sidingCategoryButtonData, GuiDataUtilities.sidingColorButtonData, GuiDataUtilities.roofingButtonData, GuiDataUtilities.trimColorButtonData, GuiDataUtilities.doorsButtonData, GuiDataUtilities.hingesButtonData, GuiDataUtilities.windowsButtonData, TexturesDataUtilities.dataLoaded, result1, result2] = await Promise.all([
		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Buildings", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Partitions", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("SidingCategories", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("SidingColors", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Roofing", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("TrimColors", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadElementAndCategoryButtons("Doors"),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Hinges", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Windows", buttonParams),

		TexturesDataUtilities.GetTextureDataFromServer(),

		ObjectDataUtilities.LoadData(),

		KickBoard.GetKickBoardData(),
	]);
};

HorseBarnBuildingDesigner.LoadDataForGUI = async function()
{};

//Initialize the building designer object, set the camera and render
HorseBarnBuildingDesigner.Initialize = async function()
{
	let t = [];
	let ct = 0;
	t[0] = performance.now();
	if (BuildingDesigner.cachedVersion != BuildingDesigner.serverVersion)
	{
		location.reload(true);
		return;
	}
	if (SubscriberDataUtilities.subscriber.length == 0)
	{
		SubscriberDataUtilities.subscriber = AuxUtilities.GetURLParameter("sc");
	}
	DEBUG = await BuildingDesigner.IsDebugVersion();
	if (DEBUG)
	{
		ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
	}//1
	await AuxUtilities.sleep(5);

	BuildingDesigner.buildingType = BUILDING_HORSEBARN;

	await GuiDataUtilities.currentGuiDataUtilities.ProcessParametersCreateAdditionalHTMLAndConfigurePage("Horse Barn Designer");
	if (DEBUG)
	{
		ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
	}//2
	await AuxUtilities.sleep(5);

	let background = await GuiDataUtilities.GetBackground();
	if (DEBUG)
	{
		ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
	}//3
	await AuxUtilities.sleep(5);

	if (background && background.length > 0)
	{
		background = background[0];
	}
	else
	{
		background = new Object();

		background.texture = "horsebarndesigner_background";

		background.color = "rgb(255, 255, 255, 255)";
	}

	buildingDesigner = new HorseBarnBuildingDesigner(background, tdf.groundTextureName);
	if (DEBUG)
	{
		ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
	}//4
	await AuxUtilities.sleep(5);

	BuildingDesigner.OnWindowResize();
	if (DEBUG)
	{
		ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
	}//5

	await AuxUtilities.sleep(5);

	if (!await UserDataUtilities.IsSessionZipCodeSet())
	{
		window.location.href = "#zipCodeFormDiv";
		if3CloseLeftMenu();
	}

	if (SubscriberDataUtilities.subscriber)
	{
		let loader = new THREE.FontLoader();

		loader.load(Ruler.RULER_TEXT_FONT, function(font)
		{
			Ruler.rulerFont = font;
		});
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//7
		await AuxUtilities.sleep(5);

		await ColorsDataUtilities.GetColorsDataFromServer();
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//8
		await AuxUtilities.sleep(5);

		await HorseBarnBuildingDesigner.LoadDataForGUIRequiredForStartingTheBuildingProcess();
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//9
		await AuxUtilities.sleep(5);

		//add siding textures data
		TexturesDataUtilities.AddToData(GuiDataUtilities.sidingColorButtonData);
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//10
		await AuxUtilities.sleep(5);

		//add roofing textures data
		TexturesDataUtilities.AddToData(GuiDataUtilities.roofingButtonData);
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//11
		await AuxUtilities.sleep(5);

		await BuildingDesigner.CreateOrLoadBuilding();
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//12
		await AuxUtilities.sleep(5);

		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//13
		await AuxUtilities.sleep(5);
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//14
		await AuxUtilities.sleep(5);

		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//15
		await AuxUtilities.sleep(5);

		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//16
		await AuxUtilities.sleep(5);

		await HorseBarnBuildingDesigner.LoadDataForGUI();
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//17
		await AuxUtilities.sleep(5);


		await SubscriberDataUtilities.LoadData();
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//18
		await AuxUtilities.sleep(5);

		await ColorsDataUtilities.GetDoorColorsDataFromServer();
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//19
		await AuxUtilities.sleep(5);

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//20
		await AuxUtilities.sleep(5);
		buildingDesigner.building.SetBuildingModified();
		if (DEBUG)
		{
			ct++;t[ct] = performance.now();console.log("HBDI - ",ct,t[ct]-t[ct-1]);
		}//21
		await AuxUtilities.sleep(5);
		Elements.draggableElement = null;

		ElementsMenu.SetAvailableSiding();
		ElementsMenu.SetAvailableRoofing();
		ElementsMenu.SetAvailableElements();
	}
	else
	{
		// alert("No Subscriber Detected");
		window.location.href = "https://mybuilding.3dfish.net/";
	}
};

HorseBarnBuildingDesigner.leanToSizes = [];

BuildingDesigner.Initialize = HorseBarnBuildingDesigner.Initialize;
