/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/

if (typeof tdf ==="undefined")
{
	window.tdf = {};
}

if (tdf.groundTextureName === undefined)
{
	tdf.groundTextureName = "grasslight-big";
}

tdf = {...tdf,
	isMobile: false,
	printingPage: false,
	buttonData: [],
	displayRoof: true,
	displayRafters: true,
	elementHorizRulerVisible: false,
	elementVertRulerVisible: false,
	placementAlert: true
}
var buildingDesigner = null;

var threeRenderer = null;
var threeScene = null;

var canvasMain = null;
var canvasSpin = null;
var contextSpin = null;

// Color constants
var COLOR_SKY = 0xACDFFC;
//var COLOR_GROUND = 0x00FF00;
var COLOR_GROUND = 0x3E6123;

// UI constants
var SCROLLBAR_WIDTH_ADJ = 20; // pixels

var CLICKORTOUCHDELAY = 0;

// Three JS Material Constants
const METALNESS = 0.5;

// 3D Object constants
const INCHTOFEET = 0.08333333;
const BACKGROUND_HEIGHT = 85;
const BACKGROUND_CURVE_SEGMENTS = 10;
const GRASS_RADIUS = 130;
const BOARD_2x4_WIDTH = 0.292;
const BOARD_2x4_THICKNESS = 0.125;
const LEAN_TO_POST_WIDTH = 0.5;
const DRAGGING_Z_SHIFT = 0.16;

//3D Object Configuration Mode
const OBJECT_CONFIGURATION1 = 1;
const OBJECT_CONFIGURATION2 = 2;
const OBJECT_CONFIGURATION3 = 3;

// Textures
var texturesList = null;

// Folders
var DIR_RESOURCES = "resources/";
var DIR_OBJECTS = "objects/";
var DIR_IMAGES = DIR_RESOURCES + "images/";
var DIR_TEXTURES = DIR_RESOURCES + "textures/";
var DIR_GUI_BUTTONS = DIR_RESOURCES + "buttons/";
var DIR_BACKGROUNDS = DIR_TEXTURES + "backgrounds/";
var DIR_BUILDINGS = "buildings/";
var DIR_DOORS = "doors/";
var DIR_DOOR_CATEGORIES = DIR_DOORS + "categories/";

var DIR_HINGES = "hinges/";

var DIR_WINDOWS = "windows/";
var DIR_OPTIONS = "options/";
var DIR_SHELVES = "shelves/";
var DIR_WALLS = "walls/";
var DIR_SIDING = "siding/";
var DIR_ROOFING = "roofing/";
var DIR_DORMERS = "dormers/";
var DIR_PARTITIONS = "partitions/";
var DIR_MISC = DIR_TEXTURES + "misc/";

// Building Types
var BUILDING_SHED = 0;
var BUILDING_HORSEBARN = 1;
var BUILDING_CARPORT = 2;

var BUILDING_STRING = ["SHED",
	"HORSE_BARN",
	"CARPORT"
];

// Enum - element type
const ELEM_UNDEFINED = -1;
const ELEM_BUILDING = 0;
const ELEM_FLOORING = 1;
const ELEM_WALL = 2;
const ELEM_SIDING = 3;
const ELEM_ROOFING = 4;
const ELEM_DOOR = 5;
const ELEM_WINDOW = 6;
const ELEM_RUN_IN = 7;
const ELEM_WALL_RAFTER = 8;
const ELEM_ROOF_RAFTER = 9;
const ELEM_STALL = 10;
const ELEM_PARTITION = 11;
const ELEM_TRIMCOLORS = 12;
const ELEM_DORMER = 13;
const ELEM_OPTION = 14;
const ELEM_DOOR_CATEGORY = 15;
const ELEM_SHELF = 16;
const ELEM_FRAMING = 17;
const ELEM_RIDGEVENT = 18;
const ELEM_RAMP = 19;
const ELEM_ANCHORS = 20;
const ELEM_ARMORTHANE_FLOOR = 21;
const ELEM_COATED_FLOOR = 21;
const ELEM_HIP_ROOF = 22;
const ELEM_KICKBOARD = 23;
const ELEM_WALL_TRANSPARENCY = 24;
const ELEM_LEG_BRACES = 25;
const ELEM_RAILING = 26;
const ELEM_HINGE = 27;
const ELEM_DOORKNOB = 28;
const ELEM_CUPOLA = 29;
const ELEM_WALL_EXTENSION = 30;

const ELEM_STRING = ["Building",
	"Flooring",
	"Wall",
	"Siding",
	"Roofing",
	"Door",
	"Window",
	"Run-In",
	"Wall Rafter",
	"Roof Rafter",
	"Stall",
	"Partition",
	"Trim Colors Button",
	"Dormer",
	"Option",
	"Door Category",
	"Shelf",
	"Framing",
	"Ridge Vent",
	"Ramp",
	"Anchors",
	"Coated Floor",
	"Hip Roof",
	"Kickboard",
	"Wall Transparency",
	"Leg Braces",
	"Porch Railing",
	"Hinge",
	"Doorknob",
	"Cupola",
	"Wall Extension"
];

// Walls enum
var WALL_UNDEFINED = -1;
var WALL_FRONT = 0;
var WALL_BACK = 1;
var WALL_LEFT = 2;
var WALL_RIGHT = 3;

var WALL_STRING = ["Front",
	"Back",
	"Left",
	"Right"
];

var DEBUG = false;
var RAYCASTER_DEBUG = false;

var RUN_IN_OPTIMISED = true;

var MAX_ITEMS_PER_COLUMN = 5;
var MAX_ITEMS_PER_ROW = 5;

// Selection box constants
var SEL_BOX_SIZE = 0.2;
var SEL_BOX_SIZE_LARGE = SEL_BOX_SIZE * 1.5;
var SEL_BOX_COLOR = 0x0000C8;

// orientation constants
var FRONT = 0;
var BACK = 2;
var LEFT = 3;
var RIGHT = 4;

var RANDOM_NUMBERS = [];

for (let i = 0; i < 1000; i++)
{
	RANDOM_NUMBERS.push(Math.random());
}

// vars
var features = new String(" ");

if (typeof featureData !== "object")
{
	window.featureData = {};
}

var Price_Blurb = 0;

var cache = {};

var allCodeLoaded = false;

var stats;

var showRoof = true;

var admin_settings = {
	admin_user: false,
	pricing_override: false
};

// definition of global functions

const threeDFishBuildingDesigner = () => {
	return buildingDesigner;
};

const threeDFishBuildingDesignerCamera = () => {
	return buildingDesigner.camera;
};

