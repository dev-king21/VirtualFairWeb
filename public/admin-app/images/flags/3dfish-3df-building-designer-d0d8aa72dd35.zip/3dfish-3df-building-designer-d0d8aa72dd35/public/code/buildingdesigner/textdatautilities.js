/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef, no-useless-escape */

function TextDataUtilities()
{}

TextDataUtilities.GetParameterByName = function (name, url)
{
	if (!url)
	{
		url = window.location.href;
	}

	if (typeof url === "string")
	{
		name = name.replace(/[\[\]]/g, "\\$&");

		let regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)");

		let results = regex.exec(url);

		if (!results)
		{
			return null;
		}

		if (!results[2])
		{
			return "";
		}

		return decodeURIComponent(results[2].replace(/\+/g, " "));
	}
	else
	{
		return url[name];
	}
};

TextDataUtilities.EscapeRegExp = function (str)
{
	return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
};

TextDataUtilities.ReplaceAll = function (str, find, replace)
{
	let result = str.replace(new RegExp(TextDataUtilities.EscapeRegExp(find), "g"), replace);

	return result;
};

TextDataUtilities.RemoveCharacterAndTrimString = function (stringArray, character)
{
	let index = stringArray.indexOf(character);

	if (index > -1)
	{
		stringArray = stringArray.substr(0, index);

		stringArray = stringArray.trim();
	}

	return stringArray;
};

TextDataUtilities.PLUS_CODE = "PLUS_C@";

TextDataUtilities.INVERTED_COMMA_CODE = "I_C_C@";
TextDataUtilities.AMPERSAND_CODE = "A_C@";
TextDataUtilities.NEWLINE_CODE = "N_C@";

TextDataUtilities.LEFT_BRACKET_CODE = "L_B_C@";

TextDataUtilities.RIGHT_BRACKET_CODE = "R_B_C@";

TextDataUtilities.SPACE_CODE = " ";
