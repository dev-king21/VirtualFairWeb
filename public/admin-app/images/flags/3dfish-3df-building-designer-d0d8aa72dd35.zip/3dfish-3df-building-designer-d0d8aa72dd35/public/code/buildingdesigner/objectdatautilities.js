/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function ObjectDataUtilities()
{

}

ObjectDataUtilities.objectData = [];

ObjectDataUtilities.LoadData = async function ()
{
	ObjectDataUtilities.objectData = await NodeJSUtilities.UQuery("dataRequest", {request: "get3DObjects", subscriber_id: SubscriberDataUtilities.subscriber, series_code: SubscriberDataUtilities.series_code});

	for (let k = 0; k < ObjectDataUtilities.objectData.length; k++)
	{
		await AuxUtilities.sleep(5);
		if (ObjectDataUtilities.objectData[k].objectFile.indexOf(".") > -1)
			GeometryUtilities.AddFilenameToBeLoaded(RESOURCE_HOST + DIR_RESOURCES + DIR_OBJECTS + ObjectDataUtilities.objectData[k].objectType + "/" + ObjectDataUtilities.objectData[k].objectFile);
		else
		{
			let err;
			[err, componentObjectData] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getComponent3DObjectData", object_name: ObjectDataUtilities.objectData[k].objectFile}));

			if (err)
			{
				// **TODO: Handle Error
			}
			GeometryUtilities.AddFilenameToBeLoaded(DIR_RESOURCES + DIR_OBJECTS + ObjectDataUtilities.objectData[k].objectType + "/" + componentObjectData[0].objectFile);

			for (let j = k + 1; j < ObjectDataUtilities.objectData.length; j++)
			{
				if (ObjectDataUtilities.objectData[j].objectFile == ObjectDataUtilities.objectData[k].objectFile)
					ObjectDataUtilities.objectData[j].objectFile = componentObjectData[0].objectFile;
			}

			ObjectDataUtilities.objectData[k].objectFile = componentObjectData[0].objectFile;
		}
	}

	GeometryUtilities.StartLoadingGeomtry();
};
