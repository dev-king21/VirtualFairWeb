/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function ScriptLoader()
{}

ScriptLoader.GetServerVersion = async function ()
{
	return await NodeJSUtilities.UQuery("dataRequest",{request: "getServerVersion"});
};

ScriptLoader.OnAllCodeLoaded = async function ()
{

	if (tdf.allCodeLoaded)
	{
		return;
	}
	tdf.allCodeLoaded = true;

	//feature check
	if (!feature.webGL)
	{
		window.location.href = "https://mybuilding.3dfish.net/nowebgl.html";
		return;
	}

	tdf.isMobile = AuxUtilities.IsMobile();
	tdf.isMobileOrTablet = AuxUtilities.IsMobileOrTablet();

	if (!tdf.dashboard_only)
	{
		ProgressBar.StartProgressBar();

		if (tdf.isMobile)
		{
			BuildingDesigner.Initialize();
		}
		else
		{
			IndexDB.InitializeIndexDB(BuildingDesigner.Initialize);
		}


		if (!tdf.isMobile)
		{
			if (document.fullscreenEnabled)
			{
				$("#fullscreen").show();
				if (document.fullscreenElement)
				{
					$(".fullscreen-on").show();
					console.log("show fullscreen icon");
				}
				else
				{
					$(".fullscreen-off").show();
					console.log("show shrink icon");
				}
				document.addEventListener("fullscreenchange", function (event)
				{
					if (document.fullscreenElement)
					{
						$(".fullscreen-on").show();
						$(".fullscreen-off").hide();
					}
					else
					{
						$(".fullscreen-off").show();
						$(".fullscreen-on").hide();
					}
				})
			}
		}
	}
	else
	{
		await Login.isLoggedIn();
		AdminUtilities.DisplayAdminView();
	}
	allCodeLoaded = true;
};

ScriptLoader.codeToBeLoadedArray = [];

ScriptLoader.scriptsLoaded = 0;

ScriptLoader.currentScriptToBeLoadedIndex = 0;

if (window.socket)
{
	socket.on("version", (data) =>
	{
		console.log("Connected: server version: ", data.version, " client version: ", tdf_version);
		tdf.server_version = data.version;
		if (data.version.substring(0, data.version.lastIndexOf(".")) !== tdf_version.substring(0, tdf_version.lastIndexOf(".")))
		{
			let msg = "The building designer has been updated. Please refresh this page as soon as possible.";
			GuiDataUtilities.Alert(msg);
		}
	});
}
