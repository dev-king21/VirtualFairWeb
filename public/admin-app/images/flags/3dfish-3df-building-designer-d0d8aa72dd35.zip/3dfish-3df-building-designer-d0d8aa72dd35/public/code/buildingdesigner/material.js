/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Material()
{

}

Material.CreateMaterial = function (color, map)
{
	let alpha = 1.0;
	if (typeof color === "string")
	{
		color = color.toLowerCase();

		if (/^rgb\((\d+), ?(\d+), ?(\d+), ?(\d+)\)$/i.test(color))
		{
			let colorArray = /^rgb\((\d+), ?(\d+), ?(\d+), ?(\d+)\)$/i.exec(color);

			this.r = colorArray[1];
			this.g = colorArray[2];
			this.b = colorArray[3];

			alpha = Math.min(255, parseInt(colorArray[4], 10)) / 255;

			color = "rgb(" + this.r + ", " + this.g + ", " + this.b + ")";
		}
	}

	let matter = new THREE.MeshStandardMaterial({
		color: color,
		map: TexturesDataUtilities.TextureLoaded(map),
		roughness: 1.0,
		metalness: METALNESS
	});

	////matter = new THREE.MeshLambertMaterial( { color: color, map: map, roughness: 1.0 } );

	matter.side = THREE.DoubleSide;

	if (alpha < 1.0)
	{
		matter.transparent = true;
		matter.opacity = alpha;
	}

	return matter;
};


Material.SetMaterialOpacity = function (material, opacity)
{
	if (material.length > 0)
	{
		for (let i = 0; i < material.length; i++)
		{
			Material.SetMaterialOpacity(material[i], opacity);
		}
	}

	if (material.opacity && material.opacity != opacity)
	{
		material.prevOpacity = material.opacity;

		material.opacity = opacity;

		if (material.opacity < 1)
			material.transparent = true;
		else
			material.transparent = false;

		material.needsUpdate = true;
	}
};

Material.RevertMaterialOpacity = function (material)
{
	if (material.length > 0)
	{
		for (let i = 0; i < material.length; i++)
		{
			Material.RevertMaterialOpacity(material[i]);
		}
	}

	if (material.opacity && material.prevOpacity && material.prevOpacity != material.opacity)
	{
		material.opacity = material.prevOpacity;

		if (material.opacity < 1)
			material.transparent = true;
		else
			material.transparent = false;

		material.needsUpdate = true;
	}
};
