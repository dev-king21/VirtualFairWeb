/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Component3DObject(parentObject, geometryFilename, objectData)
{
	this.parentObject = parentObject;
	if (RESOURCE_HOST && (geometryFilename.indexOf(RESOURCE_HOST) === -1))
	{
		this.geometryFilename = RESOURCE_HOST + geometryFilename;
	}
	else
	{
		this.geometryFilename = geometryFilename;
	}
	//this.geometryFilename = RESOURCE_HOST + geometryFilename;

	this.selected = false;

	this.mesh = null;

	this.objectData = objectData;

	this.texture = null;


	if (objectData.rot_x == undefined)
	{
		objectData.rot_x = objectData.xRot;
		objectData.rot_y = objectData.yRot;
		objectData.rot_z = objectData.zRot;

		objectData.pos_x = objectData.xPos;
		objectData.pos_y = objectData.yPos;
		objectData.pos_z = objectData.zPos;

		objectData.scale_x = objectData.xScale;
		objectData.scale_y = objectData.yScale;
		objectData.scale_z = objectData.zScale;
	}

	this.axis = new Axis();

	this.axis = this.axis.rotateAxis(0, 0, 1, objectData.rot_z * MathUtilities.RADIAN);
	this.axis = this.axis.rotateAxis(1, 0, 0, objectData.rot_x * MathUtilities.RADIAN);
	this.axis = this.axis.rotateAxis(0, 1, 0, objectData.rot_y * MathUtilities.RADIAN);

	this.pos = new THREE.Vector3(objectData.pos_x, objectData.pos_y, objectData.pos_z);
	this.scale = new THREE.Vector3(objectData.scale_x, objectData.scale_y, objectData.scale_z);

	this.visible = true;

	this.modified = false;

	this.regenerate = true;

	if (!GeometryUtilities.GetGeometry(this.geometryFilename))
	{
		GeometryUtilities.geometry[this.geometryFilename] = "required";
	}
	else if (!this.objectData.sizedTextureCoordinates)
	{
		////if (GeometryUtilities.GetGeometry(this.geometryFilename) && !this.objectData.sizedTextureCoordinates)
		TexturesDataUtilities.AssignUVsToGeometryXY(GeometryUtilities.geometry[this.geometryFilename]);
	}

	this.DetermineRotationAndRoundValues = function ()
	{
		this.pos.x = MathUtilities.Round(this.pos.x, 3);
		this.pos.y = MathUtilities.Round(this.pos.y, 3);
		this.pos.z = MathUtilities.Round(this.pos.z, 3);

		let vector = this.axis.DetermineAxisRotation();

		this.rot = new THREE.Vector3(MathUtilities.Round(vector.x / MathUtilities.RADIAN, 3), MathUtilities.Round(vector.y / MathUtilities.RADIAN, 3), MathUtilities.Round(vector.z / MathUtilities.RADIAN, 3));

		this.scale.x = MathUtilities.Round(this.scale.x, 3);
		this.scale.y = MathUtilities.Round(this.scale.y, 3);
		this.scale.z = MathUtilities.Round(this.scale.z, 3);
	};

	this.UpdateModified3DObject = async function ()
	{
		if (this.modified)
		{
			this.DetermineRotationAndRoundValues();

			let params = {
				subscriber_id: SubscriberDataUtilities.subscriber,
				id: objectData.id,
				pos_x: this.pos.x,
				pos_y: this.pos.y,
				pos_z: this.pos.z,
				rot_x: this.rot.x,
				rot_y: this.rot.y,
				rot_z: this.rot.z,
				scale_x: this.scale.x,
				scale_y: this.scale.y,
				scale_z: this.scale.z
		};

			let resultStr = await NodeJSUtilities.UQuery("masterAction",{request: "update3DObject", ...params});

			if (resultStr == "Success!")
			{
				this.modified = false;
			}
		}
	};

	this.SetGuiDefinedColor = function (color)
	{
		if (objectData.guiDefinedColorEnabled == 1)
		{
			this.objectData.color = color;
		}
	};

	this.GetTextures = function (scale)
	{
		if (objectData.textureName && objectData.textureName != "")
		{
			if (this.objectData.sizedTextureCoordinates)
				this.texture = TexturesDataUtilities.GetRealWorldSizedTexture(objectData.textureName, 1, 1);
			else
			{
				if (!GeometryUtilities.geometry[this.geometryFilename].boundingBox)
				{
					GeometryUtilities.geometry[this.geometryFilename].computeBoundingBox();
				}

				////let size = GeometryUtilities.geometry[this.geometryFilename].boundingBox.getSize();

				let size = new THREE.Vector3();

				size = GeometryUtilities.geometry[this.geometryFilename].boundingBox.getSize(size);



				this.texture = TexturesDataUtilities.GetRealWorldSizedTexture(objectData.textureName, size.x * scale.x, size.y * scale.y);
			}
		}
	};

	this.SetCameraAndConfigurationModeVisibility = function (modeCamera, configurationMode)
	{
		if (this.mesh)
		{
			if (modeCamera == Camera.CAM_MODE_INTERIOR)
			{
				if (this.objectData.interiorVisibility == 1)
					this.mesh.material.visible = true;
				else
					this.mesh.material.visible = false;
			}
			else
				this.mesh.material.visible = true;


			if (this.objectData.configurationMode != configurationMode && this.objectData.configurationMode != OBJECT_CONFIGURATION1)
				if (this.mesh.material.visible)
					this.mesh.material.visible = false;
		}
	};

	this.Generate = function (buildingMeshes, scale)
	{
		if (!GeometryUtilities.GetGeometry(this.geometryFilename))
			GeometryUtilities.geometry[this.geometryFilename] = "required";

		if (this.visible && this.regenerate && GeometryUtilities.GetGeometry(this.geometryFilename))
		{
			this.GetTextures(scale);

			////if (TexturesDataUtilities.TextureLoaded(this.texture) || objectData.textureName==null || objectData.textureName=="null" || objectData.textureName=="")
			{
				if (!GeometryUtilities.geometry[this.geometryFilename].boundingBox)
					GeometryUtilities.geometry[this.geometryFilename].computeBoundingBox();

				let strColor;

				if (this.selected)
					strColor = "rgb(0, 0, 255)";
				else
				if (objectData.trimColorFromBarnEnabled == 1 && !this.parentObject.parentObject.trimColor)
					strColor = buildingDesigner.building.roof.cornerTrimColor;
				else
				if (this.parentObject.parentObject.buttonData.user_specifiable_trim_color && this.parentObject.parentObject.trimColor && objectData.trimColorFromBarnEnabled)
				{
					strColor = this.parentObject.parentObject.trimColor;
				}
				else
				if (this.parentObject.parentObject.colorFromBarn && objectData.colorFromBarnEnabled) // && shedGraphics.sidingColor != undefined && shedGraphics.sidingColor != null)
				{
					let colorsArray = ColorsDataUtilities.GetAvailableDoorColors(this.parentObject.parentObject.buttonData.available_colors_elem_id);

					let colorIndex = ColorsDataUtilities.GetColorMatch(colorsArray, this.parentObject.parentObject.wall.colorID);

					if (colorIndex > -1)
					{
						strColor = colorsArray[colorIndex].color;

						this.parentObject.parentObject.SetColorID(colorsArray[colorIndex].color_id);
					}
					else
					{
						if (this.parentObject.parentObject.wall.colorID && this.parentObject.parentObject.wall.colorID != "null")
						{
							let colorData = ColorsDataUtilities.FindColor(this.parentObject.parentObject.wall.colorID);
							if (colorData)
								colorIndex = ColorsDataUtilities.GetClosestColor(colorsArray, colorData.color);
						}

						if (colorIndex > -1)
						{
							strColor = colorsArray[colorIndex].color;
							this.parentObject.parentObject.SetColorID(colorsArray[colorIndex].color_id);
						}
						else
							strColor = this.objectData.color;
					}
				}
				else
					strColor = this.objectData.color;

				let mater = Material.CreateMaterial(strColor, this.texture);

				this.mesh = new THREE.Mesh(GeometryUtilities.geometry[this.geometryFilename], mater);

				let vector = this.axis.DetermineAxisRotation();

				let matrix = new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z);
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(vector.x, vector.y, vector.z), "ZXY"));
				matrix = matrix.scale(this.scale);

				this.mesh.matrix = matrix;

				////this.mesh.geometry.matrixAutoUpdate = false;
				////this.mesh.geometry.applyMatrix4(matrix);

				this.mesh.matrixAutoUpdate = false;

				if (mater.opacity == 0)
				{
					this.mesh.castShadow = false;
					this.mesh.receiveShadow = false;
				}
				else
				{
					this.mesh.castShadow = true;
					this.mesh.receiveShadow = true;
				}

				this.mesh.component3DObject = this;

				//this.regenerate = false;
				this.mesh.visible = this.visible;

				if (this.eWall != null && this.eWall != undefined)
					this.mesh.eWall = this.eWall;
			}
		}

		return this.mesh;
	};

	this.SetVisibility = function (visible)
	{
		this.visible = visible;
	};

	this.SetTextureName = function (textureName)
	{
		objectData.textureName = textureName;
	};

	this.SetColor = function (color)
	{
		this.objectData.color = color;
	};

	this.Rotate = function (xRot, yRot, zRot, angle)
	{
		this.axis = this.axis.rotateAxis(xRot, yRot, zRot, angle);

		this.modified = true;
	};

	this.Translate = function (x, y, z)
	{
		/*////this.objectData.pos_x += x;
		this.objectData.pos_y += y;
		this.objectData.pos_z += z;
		*/

		this.pos.x += x;
		this.pos.y += y;
		this.pos.z += z;

		this.modified = true;
	};

	this.Scale = function (x, y, z)
	{
		this.scale.x += x;
		this.scale.y += y;
		this.scale.z += z;

		this.modified = true;
	};

}
