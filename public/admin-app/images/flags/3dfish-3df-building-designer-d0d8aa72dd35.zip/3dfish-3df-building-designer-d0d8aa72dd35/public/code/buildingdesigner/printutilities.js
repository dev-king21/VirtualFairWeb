/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function PrintUtilities()
{

}

function PrintToCanvas(zoom, camHorizAngle, camVertAngle, camMode, canvasName)
{	
	let printCanvas = document.getElementById(canvasName);
	let ctx = printCanvas.getContext("2d");

    if (camMode == Camera.CAM_MODE_INTERIOR)
	    buildingDesigner.camera.CalculateInteriorViewPosition(camHorizAngle, camVertAngle, zoom);
	else		    	
        buildingDesigner.camera.CalculateExteriorViewPosition(camHorizAngle, camVertAngle, zoom);

	$("#building_designer_canvas").height(printCanvas.height);
	$("#building_designer_canvas").width(printCanvas.width);
	buildingDesigner.camera.SetCanvasDimensions(printCanvas.width, printCanvas.height, true);

    buildingDesigner.camera.SetView(camMode, false);
    buildingDesigner.camera.Update();

    buildingDesigner.SetRegenerate(true);				
    buildingDesigner.Draw();

	ctx.drawImage(threeRenderer.domElement, 0, 0, printCanvas.clientWidth, printCanvas.clientHeight);	
}

PrintUtilities.GeneratePrintPageAndPrint = async function ()
{
	location.href = "#printDialog";

	let elem = document.getElementById("printDialog");
	elem.style.visibility = "visible";

	elem.style.opacity = 1;

	if (!SubscriberDataUtilities.printPage2) {
		$("#printpage2").remove();
	}
	/* elem = document.getElementById("printpage2");
	if (elem.innerHTML!="")
	{
		elem.style.display = "block";
		elem.style.visibility = "visible";

		elem.style.opacity = 1;
	} */

	let original_ground = buildingDesigner.environment.ground.textureName;
	let original_background = buildingDesigner.environment.backGround.background.texture;

	let currentPrintout = false;
	if (SubscriberDataUtilities.custom_printout && SubscriberDataUtilities.featureData && SubscriberDataUtilities.featureData.customprintout) {
		currentPrintout = SubscriberDataUtilities.featureData.customprintout;
	} else {
		if (SubscriberDataUtilities.featureData && SubscriberDataUtilities.featureData.defaultprintout) {
			currentPrintout = SubscriberDataUtilities.featureData.defaultprintout;
		}
	}

	switch (PrintUtilities.printPageGenerationStage)
	{
	case (0): {
		let camera_angle = Camera.CAM_HORIZ_INITIAL_ANGLE_DEG;
		let customerData = {};
		PrintUtilities.dealerData = SubscriberDataUtilities.subscriberData;
		let dealerData = PrintUtilities.dealerData;
		let userData = UserDataUtilities.userData || {};
		if (!["user", "customer"].includes(userData.usertype)) {
			if (buildingDesigner.building.designID && ((buildingDesigner.building.designID === LoadingSavingUtilities.designMetaData.design_id) || (SubscriberDataUtilities.design_prefix + "_" + buildingDesigner.building.designID === LoadingSavingUtilities.designMetaData.design_id))) {
				let params = {
					design_id: LoadingSavingUtilities.designMetaData.design_id,
					subscriber_id: SubscriberDataUtilities.subscriber_id,
					design_prefix: SubscriberDataUtilities.design_prefix
				};
				let [err,result] = await to(NodeJSUtilities.UQuery("adminDataRequest", {request:"getDesignUserInfo", ...params}));
				if (err) {
					customerData = {
						firstname: SubscriberDataUtilities.print_salesperson ? "Salesperson:":"",
						lastname: SubscriberDataUtilities.print_salesperson ? userData.firstname + " " + userData.lastname:"",
						address: "",
						state: "",
						zip: "",
						phone1: "",
						email: ""
					};
				} else {
					customerData = result;
				}
				dealerData = SubscriberDataUtilities.locationData.find(element => element.location_number === LoadingSavingUtilities.designMetaData.location_number) || SubscriberDataUtilities.subscriberData;
				PrintUtilities.dealerData = dealerData;

			}
		} else {
			customerData = userData;
		}
		//let usertype = userData.usertype || [];
		let customer_name = customerData.firstname ? customerData.firstname + " ":"";
		customer_name += customerData.lastname ? customerData.lastname:"";
		let customer_address = customerData.address || "";
		let customer_city = customerData.city || "";
		let customer_region = customerData.state || "";
		let customer_postalcode = customerData.zip || "";
		let customer_phone = customerData.phone1 || "";
		let customer_email = customerData.email || "";

		if (currentPrintout) {
			$("#printpage1").html(currentPrintout.html);
			// depricated - to be rereplaced by setMapField
			let setField = function(data_map) {
				if (buildingDesigner.building.sizeData.size_options && buildingDesigner.building.sizeData.size_options.data && buildingDesigner.building.sizeData.size_options.data[data_map[0]]) {
					$("#" + data_map[1]).text(buildingDesigner.building.sizeData.size_options.data[data_map[0]]);
				}
			};
			// depricated
			if (currentPrintout.size_options_data_map) {
				currentPrintout.size_options_data_map.forEach(setField);
			}
			// data_maps: [{"base":"baseobjectname", "path":"path.to.mapped.objects", "map":[["object1","elementid"],["object2","elementid"]]}]
			if (currentPrintout.data_maps) {
				for (mapObj of currentPrintout.data_maps) {
					let setMapField = function(data_map) {
						$("#" + data_map[1]).text(nestedObj(window[mapObj.base],mapObj.path ? mapObj.path+"."+data_map[0]:data_map[0]));
					}
					mapObj.map.forEach(setMapField);
				}
			}
		}
		tdf.printingPage = true;
		$("#dealername").text(dealerData.name);

		$("#dealeraddress").text(dealerData.address);

		$("#dealerregion").text(dealerData.city + ", " + dealerData.region + ", " + dealerData.postalcode);

		$("#dealerphone").text("Phone: " + dealerData.phone);

		$("#dealerfax").text("Fax: " + dealerData.fax);

		$("#dealeremail").text("Email: " + dealerData.email);
		$("#customeraddress").text(customer_address);
		$("#customercity").text(customer_city);
		$("#customerregion").text(customer_region);
		$("#customerpostalcode").text(customer_postalcode);
		$("#customerphone").text(customer_phone);
		$("#customername").text(customer_name);
		$("#customeremail").text(customer_email);
		$("#print_linked_product_id").text(buildingDesigner.building.sizeData.linked_product_id);

		{
		let pdate = new Date();
		$("#printdate").text(pdate.toLocaleDateString("short"));
		}

		if (buildingDesigner.building.designID) {
			$("#prn_designid").text(GuiDataUtilities.formatDesignID(buildingDesigner.building.designID));
			if (nestedObj(LoadingSavingUtilities,"designMetaData.create_date")) {
				let orderDate = new Date(LoadingSavingUtilities.designMetaData.create_date);
				//$("#print_order_date").text(LoadingSavingUtilities.designMetaData.create_date.substring(0,10));
				$("#print_order_date").text(orderDate.toLocaleDateString("short"));
				$("#print_create_date").text(orderDate.toLocaleDateString("short"));
			} else {
				let today = new Date;
				$("#print_order_date").text(today.toLocaleDateString("short"));
			}
		} else {
			let today = new Date;
			$("#print_order_date").text(today.toLocaleDateString("short"));
			$("#print_create_date").text(today.toLocaleDateString("short"));
			$("#prn_designid").text("");
		}

		$("#printPagePricing").html(PrintUtilities.printPagePricing);
		if (currentPrintout) {
			let baseprice = building.detailList[0].price;
			let basecost = building.detailList[0].cost;
			let pd = currentPrintout.fields || {};
			let cpo = currentPrintout;
			if (cpo.camera_angle) {
				camera_angle = cpo.camera_angle[0];
			}
			if (cpo.ground_texture) {
				buildingDesigner.environment.ground.textureName = cpo.ground_texture;
				let texture = TexturesDataUtilities.FindTexture(cpo.ground_texture);
				if (texture == null) {
					let OnTextureLoaded = new TexturesDataUtilities_OnTextureLoaded(cpo.ground_texture);
					TexturesDataUtilities.LoadTextureFromName(cpo.ground_texture, OnTextureLoaded.TextureLoaded);
					await AuxUtilities.sleep(1000);
				}
			}
			if (cpo.background) {
				buildingDesigner.environment.backGround.background.texture = cpo.background;
				let texture = TexturesDataUtilities.FindTexture(cpo.background);
				if (texture == null) {
					let OnTextureLoaded = new TexturesDataUtilities_OnTextureLoaded(cpo.background);
					TexturesDataUtilities.LoadTextureFromName(cpo.background, OnTextureLoaded.TextureLoaded);
					await AuxUtilities.sleep(1000);
				}
			}
			if (pd.style) {
				$("#" + pd.style).text(building.detailList[0].style);
			}
			if (pd.size) {
				$("#" + pd.size).text(building.detailList[0].size);
			}
			if (pd.baseprice) {
				$("#" + pd.baseprice).text(building.detailList[0].price);
			}
			if (pd.basecost) {
				$("#" + pd.basecost).text(building.detailList[0].cost);
			}
			if (pd.height_display) {
				$("#" + pd.height_display).text(building.detailList[0].height_display);
			}
			if (pd.dealeraddress) {
				$("#" + pd.dealeraddress).text(dealerData.address);
			}
			if (pd.dealercity) {
				$("#" + pd.dealercity).text(dealerData.city);
			}
			if (pd.dealerregion) {
				$("#" + pd.dealerregion).text(dealerData.region);
			}
			if (pd.dealerpostalcode) {
				$("#" + pd.dealerpostalcode).text(dealerData.postalcode);
			}
			let itemList = [];
			let itemQty = [];
			let addItem = function (item, itemList, ItemQty, itemClass) {
				let itemNum = itemList.indexOf(item.item);
				if (itemNum > -1) {
					itemQty[itemNum]++;
					$(`#item${itemNum} .print_qty`).text(itemQty[itemNum])
				} else {
					itemList.push(item.item);
					itemQty.push(1);
					$("#print_" + itemClass).append(fillTemplate(cpo.item_template, {
						id: "item" + (itemList.length - 1),
						qty: "1",
						item: item.item
					}));
				}
			}
			for (let item of building.detailList) {
				switch (item.class) {
					case "roofing": {
						console.log("roofing");
						if (pd.roofing) {
							$("#" + pd.roofing).text(item.material);
						}
						if (pd.roof_color) {
							$("#" + pd.roof_color).text(item.color);
						}
						break;
					}
					case "siding": {
						console.log("siding");
						if (pd.siding) {
							$("#" + pd.siding).text(item.material);
						}
						if (pd.siding_color) {
							$("#" + pd.siding_color).text(item.color);
						}
						break;
					}
					case "trim_color": {
						console.log("trim");
						if (pd.trim_color) {
							$("#" + pd.trim_color).text(item.color);
						}
						break;
					}
					case "door": {
						console.log("door");
						/*if (itemList.indexOf(item.item) > -1) {
							itemQty[itemList.indexOf(item.item)]++;
							$("#item"+itemList.indexOf(item.item)+" .print_qty").text(itemQty[itemList.indexOf(item.item)])
						} else {
							itemList.push(item.item);
							itemQty.push(1);
							$("#print_doors").append(fillTemplate(cpo.item_template,{id: "item"+itemList.length-1,qty:"1",item: item.item}));
						}*/
						addItem(item, itemList, itemQty, "doors");
						break;
					}
					case "window": {
						console.log("window");
						//$("#print_windows").append(fillTemplate(cpo.item_template,{id: "",qty:"1",item: item.item}));
						addItem(item, itemList, itemQty, "windows");
						break;
					}
					case "shelf": {
						console.log("shelf");
						//$("#print_shelves").append(fillTemplate(cpo.item_template,{id: "",qty:"1",item: item.item}));
						addItem(item, itemList, itemQty, "shelves");
						break;
					}
					case "option": {
						console.log("option");
						//$("#print_other").append(fillTemplate(cpo.item_template,{id: "",qty:"1",item: item.item}));
						addItem(item, itemList, itemQty, "other");
						break;
					}
					case "subtotal1": {
						let optionsPrice = currency(item.price).subtract(baseprice);
						let optionsCost = currency(item.cost).subtract(basecost);
						let discount = currency(0);
						if (cpo.discount_calc && cpo.discount_data) {
							switch (cpo.discount_data.type) {
								case "msrp": {
									if (pd.baseprice) {
										let msrp = currency(buildingDesigner.building.sizeData.size_options.data[cpo.discount_data.price_field]);
										$("#" + pd.baseprice).text(msrp);
										discount = currency(msrp).subtract(baseprice);
									}
									break;
								}
							}
						}
						if (pd.optionsprice) {
							$("#" + pd.optionsprice).text(optionsPrice);
						}
						if (pd.optionscost) {
							$("#" + pd.optionscost).text(optionsCost);
						}
						if (pd.subtotal1) {
							$("#" + pd.subtotal1).text(currency(item.price).add(discount));
						}
						if (pd.costsubtotal1) {
							$("#" + pd.costsubtotal1).text(currency(item.cost));
						}
						if (pd.discount) {
							$("#" + pd.discount).text("-"+discount);
						}
						if (pd.subtotal2) {
							$("#" + pd.subtotal2).text(item.price);
						}
						if (pd.costsubtotal2) {
							$("#" + pd.costsubtotal2).text(currency(item.cost));
						}
						break;
					}
				}
			}
		}

		PrintToCanvas(0.6, THREE.Math.degToRad(camera_angle), 0.0, Camera.CAM_MODE_EXTERIOR, "printcanvas_MainViewRenderer");
		buildingDesigner.environment.ground.textureName = original_ground;
		buildingDesigner.environment.backGround.background.texture = original_background;
		break;
	}

	case (1): {
		let camera_angle = 200;		
		if (currentPrintout) {
			let cpo = currentPrintout;
			if (cpo.camera_angle) {
				camera_angle = cpo.camera_angle[1];
			}
			if (cpo.ground_texture) {
				buildingDesigner.environment.ground.textureName = cpo.ground_texture;
			}
			if (cpo.background) {
				buildingDesigner.environment.backGround.background.texture = cpo.background;
			}
		}
		PrintToCanvas(0.6, THREE.Math.degToRad(camera_angle), 0.0, Camera.CAM_MODE_EXTERIOR, "printcanvas_LeftViewRenderer");
		buildingDesigner.environment.ground.textureName = original_ground;
		buildingDesigner.environment.backGround.background.texture = original_background;
		break;
	}

	case (2): {
		let camera_angle = -20;		
		if (currentPrintout) {
			let cpo = currentPrintout;
			if (cpo.camera_angle) {
				camera_angle = cpo.camera_angle[2];
			}
			if (cpo.ground_texture) {
				buildingDesigner.environment.ground.textureName = cpo.ground_texture;
			}
			if (cpo.background) {
				buildingDesigner.environment.backGround.background.texture = cpo.background;
			}
		}
		PrintToCanvas(0.6, THREE.Math.degToRad(camera_angle), 0.0, Camera.CAM_MODE_EXTERIOR, "printcanvas_RightViewRenderer");
		buildingDesigner.environment.ground.textureName = original_ground;
		buildingDesigner.environment.backGround.background.texture = original_background;
		break;
	}

	case (3): {
		let camera_angle = 120;
		if (currentPrintout) {
			let cpo = currentPrintout;
			if (cpo.camera_angle) {
				camera_angle = cpo.camera_angle[3];
			}
			if (cpo.ground_texture) {
				buildingDesigner.environment.ground.textureName = cpo.ground_texture;
			}
			if (cpo.background) {
				buildingDesigner.environment.backGround.background.texture = cpo.background;
			}
		}
		PrintToCanvas(0.6, THREE.Math.degToRad(camera_angle), 0.0, Camera.CAM_MODE_EXTERIOR, "printcanvas_RearViewRenderer");
		buildingDesigner.environment.ground.textureName = original_ground;
		buildingDesigner.environment.backGround.background.texture = original_background;
		break;
	}

	case (4): {
		PrintToCanvas(0.15, 0, 0.0, Camera.CAM_MODE_INTERIOR, "printcanvas_InteriorLeftViewRenderer");
		break;
	}

	case (5): {
		PrintToCanvas(0.15, THREE.Math.degToRad(180.0), 0.0, Camera.CAM_MODE_INTERIOR, "printcanvas_InteriorRightViewRenderer");
		break;
	}

	case (6): {
		buildingDesigner.camera.SetCanvasDimensions(canvasMain.clientWidth, canvasMain.clientHeight, true);

		buildingDesigner.SetRegenerate(true);

		buildingDesigner.InitializeCameraAndRender();

		if (typeof (interfaceCode) !== "undefined")
		{
			if (interfaceCode == "if2")
			{
				//
			}
			if (interfaceCode == "if1")
			{
				let printingText = document.getElementById("printingText");
				printingText.innerHTML = "";
			}
		}
		else
		{
			let printingText = document.getElementById("printingText");
			printingText.innerHTML = "";
		}

		tdf.printingPage = false;
		window.print();
		break;
	}
	}

	if (PrintUtilities.printPageGenerationStage < 7)
	{
		setTimeout(PrintUtilities.GeneratePrintPageAndPrint, 400);
		PrintUtilities.printPageGenerationStage++;
	}
	else
		PrintUtilities.printPageGenerationStage = 0;
};

PrintUtilities.Print = function ()
{
	if (typeof (interfaceCode) !== "undefined")
	{
		if (interfaceCode == "if2")
		{
			//
		}
		if (interfaceCode == "if1")
		{
			let printingText = document.getElementById("printingText");
			printingText.innerHTML = "<font size='3' color='#707070'>Preparing to Print... </font>";
		}
	}
	else
	{
		let printingText = document.getElementById("printingText");
		printingText.innerHTML = "<font size='3' color='#707070'>Preparing to Print... </font>";
	}

	buildingDesigner.building.ClearSelections();

	PrintUtilities.printPageGenerationStage = 0;

	setTimeout(PrintUtilities.GeneratePrintPageAndPrint, 1000);
};

PrintUtilities.PrintClose = function ()
{
	let elem = document.getElementById("printDialog");
	elem.style.visibility = "hidden";

	elem.style.opacity = 0;

	/* elem = document.getElementById("printpage2");
	elem.style.display = "none";
	elem.style.visibility = "hidden";

	elem.style.opacity = 0; */

	BuildingDesigner.OnWindowResize();
	buildingDesigner.InitializeCameraAndRender();
};

PrintUtilities.printPageGenerationStage = 0;

PrintUtilities.printPagePricing = {};
