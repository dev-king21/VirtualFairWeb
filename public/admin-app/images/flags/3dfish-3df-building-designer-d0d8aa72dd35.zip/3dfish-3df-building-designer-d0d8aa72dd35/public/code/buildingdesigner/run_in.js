/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function RunIn(buttonData)
{
	Element.call(this, buttonData);

	this.length = BOARD_2x4_WIDTH + KickBoard.THICKNESS;

	this.buttonData.type = ELEM_RUN_IN;

	this.component3DObjects.geometryCenter.x = 0;
	this.component3DObjects.geometryCenter.y = 0;
	this.component3DObjects.geometryCenter.z = 0;

	this.subtractMesh = null;

	this.SetPos = function (x, y, z)
	{
		this.pos.x = x;
		this.pos.y = Floor.FLOOR_THICKNESS + buttonData.height / 2;
		this.pos.z = z;

		this.UpdateMatrix();
	};

	this.GetMatrix = function ()
	{
		return this.mesh.matrix;
	};

	this.CreateRunInMesh = function (pts, thickness, color, transparent, opacity)
	{
		let shapeRunIn = new THREE.Shape(pts);

		let runInGeom = new THREE.ExtrudeGeometry(shapeRunIn, {
			depth: thickness,
			bevelEnabled: false
		});

		TexturesDataUtilities.AssignUVsToGeometryXY(runInGeom);

		let mater = new THREE.MeshStandardMaterial({
			color: color,
			map: this.texture,
			roughness: 1.0,
			metalness: METALNESS
		});

		mater.transparent = transparent;
		mater.opacity = opacity;

		runInGeom.matrixAutoUpdate = false;
		runInGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(-buttonData.width / 2, -buttonData.height / 2, -thickness * 0.9));

		let mesh = new THREE.Mesh(runInGeom, mater);

		return mesh;
	};


	this.Generate = function (buildingMeshes, elementMeshes)
	{
		if (this.regenerate && this.wall)
		{
			if (this.component3DObjects.boundingBox == null)
			{
				this.component3DObjects.CalculateGeometryScale(this.buttonData.width, this.buttonData.height, this.buttonData.height);
				this.component3DObjects.CalculateGeometryCenter();
			}

			let roofAngle = 45;

			let h1 = 0.87 * buttonData.height;
			let h2 = 0.13 * buttonData.height;

			let w1 = h2 * Math.tan((90 - roofAngle) * MathUtilities.RADIAN);
			let w2 = buttonData.width - w1;


			let angleHeightAdj = BOARD_2x4_WIDTH * Math.tan(((90 - roofAngle) / 2) * MathUtilities.RADIAN);
			let angleWidthAdj = BOARD_2x4_WIDTH * Math.tan((roofAngle / 2) * MathUtilities.RADIAN);

			let h1_2 = h1 - angleHeightAdj;


			this.runInPts = [{
				x: 0,
				y: 0
			},
			{
				x: 0,
				y: h1
			},
			{
				x: w1,
				y: buttonData.height
			},
			{
				x: w2,
				y: buttonData.height
			},
			{
				x: buttonData.width,
				y: h1
			},
			{
				x: buttonData.width,
				y: 0
			}
			];


			this.runInSubtractPts = [{
				x: BOARD_2x4_WIDTH,
				y: 0
			},
			{
				x: BOARD_2x4_WIDTH,
				y: h1_2
			},
			{
				x: w1 + angleWidthAdj,
				y: buttonData.height - BOARD_2x4_WIDTH
			},
			{
				x: w2 - angleWidthAdj,
				y: buttonData.height - BOARD_2x4_WIDTH
			},
			{
				x: buttonData.width - BOARD_2x4_WIDTH,
				y: h1_2
			},
			{
				x: buttonData.width - BOARD_2x4_WIDTH,
				y: 0
			}
			];

			this.subtractMesh = this.CreateRunInMesh(this.runInPts, this.length * 2, 0x000000, true, 0);

			this.runInPts = [{
				x: 0,
				y: 0
			},
			{
				x: 0,
				y: h1
			},
			{
				x: w1,
				y: buttonData.height
			},
			{
				x: w2,
				y: buttonData.height
			},
			{
				x: buttonData.width,
				y: h1
			},
			{
				x: buttonData.width,
				y: 0
			}
			];

			this.runInPts.push({
				x: buttonData.width - BOARD_2x4_WIDTH,
				y: 0
			});
			this.runInPts.push({
				x: buttonData.width - BOARD_2x4_WIDTH,
				y: h1_2
			});
			this.runInPts.push({
				x: w2 - angleWidthAdj,
				y: buttonData.height - BOARD_2x4_WIDTH
			});
			this.runInPts.push({
				x: w1 + angleWidthAdj,
				y: buttonData.height - BOARD_2x4_WIDTH
			});
			this.runInPts.push({
				x: BOARD_2x4_WIDTH,
				y: h1_2
			});
			this.runInPts.push({
				x: BOARD_2x4_WIDTH,
				y: 0
			});

			this.runInMesh = this.CreateRunInMesh(this.runInPts, this.length, buildingDesigner.building.roof.cornerTrimColor, false, 1.0);

			this.regenerate = false;

			this.mesh = new THREE.Mesh();

			this.mesh.add(this.subtractMesh);
			this.mesh.add(this.runInMesh);

			if (this.selected)
				this.GenerateSelectedBoxes(this.mesh, this.mesh.matrix);

			this.mesh.type = ELEM_RUN_IN;

			this.mesh.element = this;

			this.mesh.castShadow = false;

			this.mesh.visible = true;

			this.UpdateMatrix();

			if (!this.dragging)
			{
				this.subtractMesh.matrix = new THREE.Matrix4();
				this.subtractMesh.matrixAutoUpdate = false;
				this.subtractMesh.applyMatrix4(this.mesh.matrix);

				MeshUtilities.SubtractMeshFromMeshes(buildingMeshes, this.subtractMesh, this.wall.eWall);
				MeshUtilities.SubtractMeshFromMeshes(buildingMeshes, this.runInMesh, this.wall.eWall);


				MeshUtilities.SubtractMeshFromMeshes(buildingMeshes, this.subtractMesh, -1, ELEM_KICKBOARD);


				this.subtractMesh.matrix = new THREE.Matrix4();
				this.subtractMesh.matrixAutoUpdate = false;
				this.subtractMesh.applyMatrix4(new THREE.Matrix4());
			}
		}

		return this.mesh;
	};

	this.UpdateMatrix = function ()
	{
		if (this.mesh)
			if (this.wall.matrix)
			{
				let matrix = new THREE.Matrix4();

				matrix = new THREE.Matrix4().multiplyMatrices(this.wall.matrix, matrix);

				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z));

				if (this.wall.eWall == WALL_LEFT || this.wall.eWall == WALL_BACK)
					matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationY(-MathUtilities.PI));

				if (this.dragging)
				{
					if (buildingDesigner.camera.modeCamera == Camera.CAM_MODE_EXTERIOR)
						matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, 0, DRAGGING_Z_SHIFT));
					else
						matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, 0, -DRAGGING_Z_SHIFT));
				}

				this.mesh.matrix = new THREE.Matrix4();
				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(matrix);

				if (this.selected)
				{
					this.horizRuler.SetRegenerate(true);
					this.vertRuler.SetRegenerate(true);

					this.GenerateRulers();
				}
			}
			else
			{
				let matrix = new THREE.Matrix4();
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, 9999, 0));

				this.mesh.matrix = new THREE.Matrix4();
				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(matrix);
			}
	};

	this.DraggingElement = function (wall, facetIndex, vectorPos)
	{
		this.SetWall(wall, facetIndex);

		let distToCenter;

		if (this.wall.eWall == WALL_FRONT || this.wall.eWall == WALL_BACK)
		{
			centerPos = -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length / 2;

			distToCenter = Math.abs(vectorPos.x - (-buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length / 2));
		}
		else
		{
			centerPos = 0;

			distToCenter = Math.abs(vectorPos.x);
		}

		if (distToCenter < LineGuide.SNAP_TO_CENTER_RANGE)
			vectorPos.x = centerPos;

		if (Math.abs(vectorPos.y - this.wall.height / 2) < LineGuide.SNAP_TO_CENTER_RANGE)
			vectorPos.y = this.wall.height / 2;

		this.SetPos(vectorPos.x, vectorPos.y, vectorPos.z);

		if (distToCenter < LineGuide.CENTER_RANGE)
		{
			this.wall.vertLineGuide.SetVisibility(true);
			this.wall.vertLineGuide.UpdateMatrix();
		}
		else
			this.wall.vertLineGuide.SetVisibility(false);


		if (Math.abs(vectorPos.y - this.wall.height / 2) < LineGuide.CENTER_RANGE)
		{
			this.wall.horizLineGuide.SetVisibility(true);
			this.wall.horizLineGuide.UpdateMatrix();
		}
		else
			this.wall.horizLineGuide.SetVisibility(false);
	};
}
