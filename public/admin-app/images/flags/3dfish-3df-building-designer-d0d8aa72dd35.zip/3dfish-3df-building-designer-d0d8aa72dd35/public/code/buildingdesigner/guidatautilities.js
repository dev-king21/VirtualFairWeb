/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2 */
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef*/
function GuiDataUtilities()
{
	// UI constants
	this.COMPONENTS_BAR_HEIGHT = -20; // pixels

	this.version = "NewInterface";

	this.GetComponentsBarHeight = function ()
	{
		return this.COMPONENTS_BAR_HEIGHT;
	};

	this.ProcessParametersCreateAdditionalHTMLAndConfigurePage = async function (designerStr)
	{
		if (SubscriberDataUtilities.subscriber.length == 0)
		{
			SubscriberDataUtilities.subscriber = AuxUtilities.GetURLParameter("sc");
		}
		if (SubscriberDataUtilities.series_code.length == 0)
		{
			let series_code;
			series_code = AuxUtilities.GetURLParameter("series");
			if (!series_code)
				series_code = "Standard";
			SubscriberDataUtilities.series_code = series_code;
		}

		let designID;
		designID = AuxUtilities.GetURLHashParameter("designID");

		if (!designID)
			designID = AuxUtilities.GetURLParameter("designID");

		if (designID)
			LoadingSavingUtilities.designID = designID;

		if (await Login.isLoggedIn())
		{
			Login.ShowLoggedInHMTL();
		}
		else
		{
			Login.ShowNotLoggedInHMTL();
		}


		/*////if (AuxUtilities.IsMobileOrTablet())
		{
			$("#zoomin").hide();
			$("#zoomout").hide();
		}*/


		/*////if (screenfull.enabled) $("#fullscreen").show();
        else $("#fullscreen").hide();
        */
	};

	this.LoadButtons = async function (buttonTypeStr, params, buttonData, category)
	{
		let folderStr;
		let btnFileName;

		folderStr = DIR_GUI_BUTTONS;

		let containerStr = "tab" + buttonTypeStr;
		let buttonContainer = document.getElementById(containerStr);

		let buttons = [];

		let buttonType;
		let elemButton;
		let elemSubContainer;

		let gridTable = false;

		let buttonFormat = "image";

		switch (buttonTypeStr)
		{
		case ("Buildings"): {
			folderStr += DIR_BUILDINGS;

			buttonType = ELEM_BUILDING;

			break;
		}
		case ("Doors"): {
			folderStr += DIR_DOORS;
			buttonType = ELEM_DOOR;
			break;
		} // case Doors

		case ("Hinges"): {
			folderStr += DIR_HINGES;

			buttonType = ELEM_HINGE;
			break;
		} // case Hinges
		case ("Windows"):
			folderStr += DIR_WINDOWS;

			buttonType = ELEM_WINDOW;
			break;

		case ("Options"):
			folderStr += DIR_OPTIONS;

			buttonType = ELEM_OPTION;
			break;

		case ("Shelves"):
			folderStr += DIR_SHELVES;

			buttonType = ELEM_SHELF;
			break;

		case ("Dormers"):
			folderStr += DIR_DORMERS;

			buttonType = ELEM_DORMER;
			break;

		case ("Walls"):
			folderStr += DIR_WALLS;

			buttonType = ELEM_WALL;
			break;

		case ("SidingCategories"):
			folderStr += DIR_SIDING;

			params = {
				subscriber_id: SubscriberDataUtilities.subscriber,
				button: 1,
				series_code: SubscriberDataUtilities.series_code
			};

			containerStr = "sidingCategories";
			buttonContainer = document.getElementById(containerStr);

			buttonType = ELEM_SIDING;
			break;

		case ("Roofing"):
			folderStr += DIR_ROOFING;

			params = {
				subscriber_id: SubscriberDataUtilities.subscriber,
				button: 1,
				series_code: SubscriberDataUtilities.series_code
			};

			containerStr = "roofingCategories";
			buttonContainer = document.getElementById(containerStr);

			buttonType = ELEM_ROOFING;
			break;

		case ("TrimColors"): {
			buttonType = ELEM_TRIMCOLORS;
			buttonFormat = "color";
			containerStr = "trimColorsContainer";
			$("#trimColorsContainer").empty();
			break;
		} // case TrimColors

		case ("Partitions"): {
			folderStr += DIR_PARTITIONS;

			buttonType = ELEM_PARTITION;
			break;
		} // case Partitions
		} // switch buttonTypeStr

		if (buttonData == undefined || buttonData == null)
		{
			let err;
			[err,buttonData] = await to(NodeJSUtilities.UQuery("dataRequest",{request: `get${buttonTypeStr}`, ...params}));
			if (err) {
				if (DEBUG) {
					console.log("Error Loading Data:",err);
				}
			}
			tdf.buttonData[buttonType] = buttonData;
		}

		/* moved to loop below
		for (let i = 0; i < buttonData.length; i++) {
			buttonData[i].type = buttonType;
		} */

		if (buttonTypeStr == "Siding")
		{
			for (let i = 0; i < buttonData.length; i++)
			{

				buttonData[i].textureName = buttonData[i].textureFile;
				buttonData[i].textureFile = DIR_SIDING + buttonData[i].textureFile;


				buttonData[i].textureNameInterior = buttonData[i].textureFileInterior;
				buttonData[i].textureFileInterior = DIR_SIDING + buttonData[i].textureFileInterior;
			}
		}

		if (buttonTypeStr == "Roofing")
		{
			for (let i = 0; i < buttonData.length; i++)
			{
				buttonData[i].textureFile = DIR_ROOFING + buttonData[i].textureFile;
				buttonData[i].textureName = buttonData[i].textureFile;
			}
		}

		let createButton;

		let colorsCountPerColumn = 0;

		let elemTr, elemTd;

		let first = true;

		for (let i = 0; i < buttonData.length; i++)
		{
			buttonData[i].type = buttonType;
			if (category == undefined || category == null || buttonData[i].belongs_to_category == category)
			{
				createButton = false;

				if (gridTable)
				{
					if (colorsCountPerColumn == MAX_ITEMS_PER_ROW)
						colorsCountPerColumn = 0;

					if (colorsCountPerColumn == 0)
					{
						//
					}
				}

					elemButton = document.createElement("img");
					elemSubContainer = document.createElement("div")
					if (buttonData[i].category_id) {
						elemSubContainer.setAttribute("id",`bt${buttonData[i].type}_${buttonData[i].category_id}`);
					}
					if (buttonData[i].elem_id) {
						elemSubContainer.setAttribute("id",`bt${buttonData[i].type}_${buttonData[i].elem_id}`);
					}
					if (buttonData[i].admin_only)
					{
						elemButton.setAttribute("class", "objbutton");
						elemSubContainer.setAttribute("class", "objbuttondiv adminui btntype"+buttonData[i].type);
					}
					else
					{
						elemButton.setAttribute("class", "objbutton");
						elemSubContainer.setAttribute("class", "objbuttondiv btntype"+buttonData[i].type);
					}




				if (buttonData[i].button_file != null && buttonData[i].button_file != "null" && buttonData[i].button_file != "")
				{
					if (buttons.indexOf(buttonData[i].button_file) == -1)
					{
						buttons.push(buttonData[i].button_file);

						let subfolder = "";
						if ((buttonTypeStr === "Doors") && (buttonData[i].belongs_to_category) && (!buttonData[i].category))
							{
								subfolder = buttonData[i].belongs_to_category.toLowerCase() + "/";
							}
						btnFileName = RESOURCE_HOST + folderStr + subfolder + buttonData[i].button_file;
						elemButton.setAttribute("src", btnFileName);

						createButton = true;
					}
				}
				else
				if (buttonTypeStr != "SidingColors" && buttonTypeStr != "Roofing" && buttonData[i].color_id != null && buttonData[i].color_id != undefined)
				{
					colorData = ColorsDataUtilities.FindColor(buttonData[i].color_id);

					if (colorData)
					{
						if (interfaceNumber > 2)
						{
							if (buttonFormat === "color")
							{
								let prefix = "";
								let groupName = "sidingSelection";
								let colorClass = "";
								if (buttonType === ELEM_TRIMCOLORS)
								{
									prefix = "trim_";
									groupName = "trimSelection";
									colorClass = "trimcolor trimset_" + buttonData[i].trim_set_id;

								}
								let colorHTMLTemplate = "<div class=\"box ${colorClass}\" title=\"${colorData.color_name}\"><input type=\"radio\" id=\"${prefix}${colorData.color_id}\" name=\"${groupName}\" ${first ? \"checked\" : \"\"}><label for=\"${prefix}${colorData.color_id}\"><span class=\"box_color\" style=\"background-color: ${colorData.color}\"></span><span class=\"box_text\">${colorData.color_name}</span></label></div>";
								$("#"+containerStr).append(fillTemplate(colorHTMLTemplate,{first: first, colorData: colorData, prefix: prefix, groupName: groupName, colorClass: colorClass }));
								let currentButton = $(`#${prefix}${colorData.color_id}`);
								if (buttonType === ELEM_TRIMCOLORS)
								{
									$(`#${prefix}${colorData.color_id}`).click(ElementsMenu.OnClickChangeColor);
									$("#trimColorsModalContainer").append(fillTemplate(colorHTMLTemplate,{first: false, colorData: colorData, prefix: "mtrim_", groupName: "mtrimSelection", colorClass: colorClass + " mtrimcolor" }));
									let currentmButton = $(`#mtrim_${colorData.color_id}`);
									currentmButton[0].btnIndex = i;
									currentmButton[0].color_id = colorData.color_id;
									currentmButton[0].buttonType = buttonType;
									currentmButton[0].forElement = true;
									$(`#mtrim_${colorData.color_id}`).click(ElementsMenu.AddElementClick);
								}
								else
								{
									$(`#${prefix}${colorData.color_id}`).click(ElementsMenu.OnClickChangeSidingColor);
								}
								currentButton[0].btnIndex = i;
								currentButton[0].color_id = colorData.color_id;
								currentButton[0].buttonType = buttonType;
								createButton = false;
								first = false;
							}
						}

					}
					else
					{
						createButton = false;
					}
				}

				if (createButton)
				{
					elemButton.btnIndex = i;

					elemButton.categoryName = buttonData[i].category;

					elemButton.buttonType = buttonType;

					if (buttonTypeStr == "Siding" || buttonTypeStr == "Roofing") {
						elemButton.category = true;
					}

					elemButton.onclick = ElementsMenu.AddElementClick;

					if (gridTable)
					{
						//
					}
					else
					{
							// don't display category buttons
							elemSubContainer.appendChild(elemButton);
							if ((buttonTypeStr === "Doors") && (buttonData[i].category))
							{
								//$(`#${containerStr}`).append(elemSubContainer);
								if (DEBUG) {
									console.log("Skipping Door Category...");
								}
							}
							else
							{
								if (buttonData[i].admin_only) {
									$(elemSubContainer).append(`<i class="fas fa-exclamation-triangle adminonlyflag" title="Admin Only option."></i>`);
								}
								if (buttonData[i].options && buttonData[i].options.infoButton)
								{
									$(elemSubContainer).append(`<i class="fas fa-info-circle infobutton" id="${buttonData[i].elem_ID}_infobox_link" data-open="${buttonData[i].elem_ID}_infobox" title="Click here to learn more."></i>`);
									if (buttonData[i].options.info)
									{
										$("body").append(`
	<div class="reveal" id="${buttonData[i].elem_ID}_infobox" data-reveal>
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-close aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">
				${buttonData[i].options.info}
				</div>
				<div class="modal-footer">
					<button type="button" id="${buttonData[i].elem_ID}_infoboxCloseButton" class="success button" data-close>Close</button>
				</div>
			</div>
		</div>
	</div>`);
									}
									$(`#${buttonData[i].elem_ID}_infobox`).foundation();
									$(`#${buttonData[i].elem_ID}_infobox_link`).foundation();
								}
								$(`#${containerStr}`).append(elemSubContainer);

								if (nestedObj(buttonData[i].options,"alternateButton")) {
									$(buttonData[i].options.alternateButton.addto).append(buttonData[i].options.alternateButton.html);
									$(`#alt_${buttonData[i].elem_id}`).prop({btnIndex:i,categoryName: buttonData[i].category, buttonType: buttonType}).click(ElementsMenu.AddElementClick);
								}
							}
					}
				}

				colorsCountPerColumn++;
			}
		}

		if (buttonType === ELEM_TRIMCOLORS) {
			$(".trimcolor").hide();
		}

		UserDataUtilities.SetUserDisplay();
		if ((buttons.length <= 1) && (["Roofing","SidingCategories"].includes(buttonTypeStr))) {
			// hide menu if only 1 selection
			switch (buttonTypeStr) {
				case "Roofing": {
					$("#tabRoofingButton").hide();
					break;
				}
				case "SidingCategories": {
					$("#tabSidingButton").hide();
					break;
				}
			}

		}
		return buttonData;
	};

	this.LoadElementAndCategoryButtons = async function (buttonTypeStr)
	{
		let buttonData = await GuiDataUtilities.LoadButtonData(buttonTypeStr, {subscriber_id: SubscriberDataUtilities.subscriber, series_code: SubscriberDataUtilities.series_code, building_type: BUILDING_STRING[BuildingDesigner.buildingType]});

		let categories = new Set();

		for (const data of buttonData)
		{
			categories.add(data.belongs_to_category);
		}

		if (nestedObj(featureData.interface,"categories_off."+buttonTypeStr)) {
			this.LoadButtons(buttonTypeStr, {subscriber_id: SubscriberDataUtilities.subscriber, series_code: SubscriberDataUtilities.series_code, category: null, building_type: BUILDING_STRING[BuildingDesigner.buildingType]}, buttonData, null);
		} else {
			for (const category of categories)
			{
				// May need to add await -- not sure if we need to wait for this or let it continue in the background
				this.LoadButtons(buttonTypeStr, {subscriber_id: SubscriberDataUtilities.subscriber, series_code: SubscriberDataUtilities.series_code, category: category, building_type: BUILDING_STRING[BuildingDesigner.buildingType]}, buttonData, category);
			}
		}

		return buttonData;
	};

}

GuiDataUtilities.buildingsButtonData = [];
GuiDataUtilities.doorsButtonData = [];
GuiDataUtilities.windowsButtonData = [];
GuiDataUtilities.optionsButtonData = [];
GuiDataUtilities.shelvesButtonData = [];
GuiDataUtilities.dormersButtonData = [];
GuiDataUtilities.wallsButtonData = [];
GuiDataUtilities.sidingCategoryButtonData = [];
GuiDataUtilities.sidingColorButtonData = [];
GuiDataUtilities.roofingButtonData = [];
GuiDataUtilities.partitionsButtonData = [];
GuiDataUtilities.trimColorButtonData = [];
GuiDataUtilities.rampsData = [];


GuiDataUtilities.LoadButtonData = async function (buttonTypeStr, params)
{
	let [err,buttonData] = await to(NodeJSUtilities.UQuery("dataRequest",{request: `get${buttonTypeStr}`, ...params}));
	if (err) {
		// TODO: handle error
	}
	return buttonData;
};

/*GuiDataUtilities.LoadButtonCategory = function(buttonTypeStr, params)
    {
        GuiDataUtilities.LoadButtons = function(buttonTypeStr, params);
    }*/

GuiDataUtilities.GetButtonData = function (elem_ID)
{
	let buttonData;

	buttonData = GuiDataUtilities.GetBuildingButtonData(elem_ID);

	if (buttonData)
		return buttonData;

	buttonData = GuiDataUtilities.GetDoorButtonData(elem_ID);

	if (buttonData)
		return buttonData;

	buttonData = GuiDataUtilities.GetHingeButtonData(elem_ID);

	if (buttonData)
		return buttonData;

	buttonData = GuiDataUtilities.GetWindowButtonData(elem_ID);

	if (buttonData)
		return buttonData;

	buttonData = GuiDataUtilities.GetOptionButtonData(elem_ID);

	if (buttonData)
		return buttonData;

	buttonData = GuiDataUtilities.GetShelfButtonData(elem_ID);

	if (buttonData)
		return buttonData;

	buttonData = GuiDataUtilities.GetDormerButtonData(elem_ID);

	if (buttonData)
		return buttonData;


	buttonData = GuiDataUtilities.GetSidingCategoryButtonData(elem_ID);

	if (buttonData)
		return buttonData;

	buttonData = GuiDataUtilities.GetWallButtonData(elem_ID);

	if (buttonData)
		return buttonData;

	buttonData = GuiDataUtilities.GetSidingColorButtonData(elem_ID);

	if (buttonData)
		return buttonData;

	buttonData = GuiDataUtilities.GetRoofingButtonData(elem_ID);

	/*if (buttonData)
            return buttonData;

        buttonData = GuiDataUtilities.GetTrimButtonData(elem_ID);
        */

	return buttonData;
};

GuiDataUtilities.GetBuildingButtonData = function (building_ID)
{
	for (let i = 0; i < GuiDataUtilities.buildingsButtonData.length; i++)
	{
		if (GuiDataUtilities.buildingsButtonData[i].building_id == building_ID)
		{
			return GuiDataUtilities.buildingsButtonData[i];
		}
	}

	return null;
};

GuiDataUtilities.GetDoorButtonData = function (elem_ID)
{
	for (let i = 0; i < GuiDataUtilities.doorsButtonData.length; i++)
	{
		if (GuiDataUtilities.doorsButtonData[i].elem_id == elem_ID)
		{
			return GuiDataUtilities.doorsButtonData[i];
		}
	}

	return null;
};

GuiDataUtilities.GetHingeButtonData = function (elem_ID)
{
	if (GuiDataUtilities.hingesButtonData)
	{
		for (let i = 0; i < GuiDataUtilities.hingesButtonData.length; i++)
		{
			if (GuiDataUtilities.hingesButtonData[i].elem_ID == elem_ID)
			{
				return GuiDataUtilities.hingesButtonData[i];
			}
		}
	}

	return null;
};

GuiDataUtilities.GetWindowButtonData = function (elem_ID)
{
	for (let i = 0; i < GuiDataUtilities.windowsButtonData.length; i++)
	{
		if (GuiDataUtilities.windowsButtonData[i].elem_ID == elem_ID)
		{
			return GuiDataUtilities.windowsButtonData[i];
		}
	}

	return null;
};

GuiDataUtilities.GetOptionButtonData = function (elem_ID)
{
	for (let i = 0; i < GuiDataUtilities.optionsButtonData.length; i++)
	{
		if (GuiDataUtilities.optionsButtonData[i].elem_ID == elem_ID)
		{
			return GuiDataUtilities.optionsButtonData[i];
		}
	}

	return null;
};

GuiDataUtilities.GetShelfButtonData = function (elem_ID)
{
	for (let i = 0; i < GuiDataUtilities.shelvesButtonData.length; i++)
	{
		if (GuiDataUtilities.shelvesButtonData[i].elem_ID == elem_ID)
		{
			return GuiDataUtilities.shelvesButtonData[i];
		}
	}

	return null;
};

GuiDataUtilities.GetDormerButtonData = function (elem_ID)
{
	if (elem_ID && elem_ID.indexOf("DEFAULT_WIDTH_")>-1)
	{
		let width = elem_ID.slice(14);
		if (width.length === 1)
		{
			width = "0" + width;
		}
		for (let i = 0; i < GuiDataUtilities.dormersButtonData.length; i++)
		{
			let teid = GuiDataUtilities.dormersButtonData[i].elem_ID;
			if (teid.slice(teid.lastIndexOf("_")+1) == width)
			{
				return GuiDataUtilities.dormersButtonData[i];
			}
		}
	}
	else
	{
		for (let i = 0; i < GuiDataUtilities.dormersButtonData.length; i++)
		{
			if (GuiDataUtilities.dormersButtonData[i].elem_ID == elem_ID)
			{
				return GuiDataUtilities.dormersButtonData[i];
			}
		}
	}
	return null;
};

GuiDataUtilities.GetSidingCategoryIndex = function (sidingCategoryID)
{
	for (let i=0; i < GuiDataUtilities.sidingCategoryButtonData.length; i++)
	{
		if (GuiDataUtilities.sidingCategoryButtonData[i].category_id == sidingCategoryID)
		{
			return i;
		}
	}
	// may change this at some point to -1 and add not found handling, but currently returning 0 to prevent errors
	//return -1;
	return 0;
}

GuiDataUtilities.GetSidingCategoryButtonData = function (sidingCategoryID)
{
	for (let i = 0; i < GuiDataUtilities.sidingCategoryButtonData.length; i++)
	{
		if (GuiDataUtilities.sidingCategoryButtonData[i].category_id == sidingCategoryID)
		{
			return GuiDataUtilities.sidingCategoryButtonData[i];
		}
	}

	if (DEBUG) {
		console.error("Cannot find siding category data for: ",sidingCategoryID);
	}
	return null;
};

/**
 * @function GuiDataUtilities.GetWallButtonData
 * @param {string} wallID
 */
GuiDataUtilities.GetWallButtonData = function (wallID)
{
	for (let i = 0; i < GuiDataUtilities.wallsButtonData.length; i++)
	{
		if (GuiDataUtilities.wallsButtonData[i].wallID == wallID)
		{
			return GuiDataUtilities.wallsButtonData[i];
		}
	}

	return null;
};

GuiDataUtilities.GetSidingColorButtonData = function (sidingID)
{
	for (let i = 0; i < GuiDataUtilities.sidingColorButtonData.length; i++)
	{
		if (GuiDataUtilities.sidingColorButtonData[i].siding_id == sidingID)
		{
			return GuiDataUtilities.sidingColorButtonData[i];
		}
	}

	if (DEBUG) {
		console.error("Cannot find siding color data for: ",sidingID);
	}
	return null;
};

GuiDataUtilities.GetRoofingCategoryIndex = function (roofingCategoryID)
{
	for (let i = 0; i < GuiDataUtilities.roofingButtonData.length; i++)
	{
		if (GuiDataUtilities.roofingButtonData[i].category_id == roofingCategoryID)
		{
			return i;
		}
	}

	// may change this at some point to -1 and add not found handling, but currently returning 0 to prevent errors
	//return -1;
	return 0;
}

GuiDataUtilities.GetRoofingButtonData = function (roofingID)
{
	for (let i = 0; i < GuiDataUtilities.roofingButtonData.length; i++)
	{
		if (GuiDataUtilities.roofingButtonData[i].roofing_id == roofingID)
		{
			return GuiDataUtilities.roofingButtonData[i];
		}
	}

	if (DEBUG) {
		console.error("Cannot find roofing data for: ",roofingID);
	}
	return null;
};




GuiDataUtilities.LoadStallCount = function (sizeData, index)
{
	let stallsTab = document.getElementById("tabStalls");

	while (stallsTab.childNodes.length > 0)
		stallsTab.removeChild(stallsTab.childNodes[0]);

	let elemTable = document.createElement("TABLE");
	let elemTr = document.createElement("TR");
	let elemTd;

	elemTable.appendChild(elemTr);

	let stallCountData = sizeData[index].stall_count.split(",");

	let colorsCountPerColumn = 0;
	for (let i = 0; i < stallCountData.length; i++)
	{
		if (colorsCountPerColumn == MAX_ITEMS_PER_COLUMN)
			colorsCountPerColumn = 0;

		if (colorsCountPerColumn == 0)
		{
			elemTd = document.createElement("TD");

			elemTd.setAttribute("vAlign", "top");
			elemTr.appendChild(elemTd);
		}

		let elemRadio = document.createElement("INPUT");
		elemRadio.setAttribute("type", "radio");
		elemRadio.setAttribute("id", "stallCountID" + i);
		elemRadio.setAttribute("name", "stallCountID" + i);

		elemRadio.iStallsCountIndex = i;

		if (i == stallCountData.length - 1)
		{
			elemRadio.setAttribute("checked", "1");
		}

		elemRadio.onchange = ElementsMenu.OnClickChangeStallCount;

		let sizeLabel = document.createElement("LABEL");

		let textNode;

		if (stallCountData[i] == 1)
			textNode = document.createTextNode(stallCountData[i] + " stall");
		else
			textNode = document.createTextNode(stallCountData[i] + " stalls");


		sizeLabel.appendChild(textNode);

		sizeLabel.iStallsCountIndex = i;
		sizeLabel.onclick = ElementsMenu.OnClickChangeStallCount;

		elemTd.appendChild(elemRadio);
		elemTd.appendChild(sizeLabel);
		elemTd.appendChild(document.createElement("BR"));

		colorsCountPerColumn++;
	}

	stallsTab.appendChild(elemTable);

	return this.sizeData;
};

/**
 * @function
 * @async
 * @param {string} buildingID
 * @returns {Promise} sizeData if exists otherwise null
 */
GuiDataUtilities.LoadBuildingSizes = async function (buildingID)
{
	if (cache.lastbuildingsizes !== undefined)
	{
		if ((cache.lastbuildingsizes.buildingID === buildingID))
			return cache.lastbuildingsizes.sizeData;
	}

	let err;
	[err, this.sizeData] = await to(NodeJSUtilities.UQuery("dataRequest", {request: "getBuildingSizes", subscriber_id: SubscriberDataUtilities.subscriber, buildingID: buildingID, series_code: SubscriberDataUtilities.series_code}));
	if (err) {
		// ** TODO: handle error
	}

	try
	{
		// this.sizeData = JSON.parse(sizeDataStr);
		cache.lastbuildingsizes = {
			"buildingID": buildingID,
			"sizeData": this.sizeData
		};
		return this.sizeData;
	}
	catch (ex)
	{
		//
	}

	return null;
};

GuiDataUtilities.GetRamps = async function ()
{
	let err;
	[err, GuiDataUtilities.rampsData] = await to(NodeJSUtilities.UQuery("dataRequest", {request: "getRamps", subscriber_id: SubscriberDataUtilities.subscriber, series_code: SubscriberDataUtilities.series_code}));
	if (err) {
		// TODO: handle error
	}
	return GuiDataUtilities.rampsData;
};

GuiDataUtilities.GetClosestRampToDoor = function (door)
{
	let minWidthDiff = -999;

	let index = -1;

	let widthDiff;

	let rampType = door.ramp.buttonData.elem_id + "_";
	rampType = rampType.toUpperCase();

	for (let i = 0; i < GuiDataUtilities.rampsData.length; i++)
	{
		if (GuiDataUtilities.rampsData[i].ramp_id.toUpperCase().indexOf(rampType) === 0) {
			widthDiff = GuiDataUtilities.rampsData[i].width - door.doorWidth;
			if (widthDiff <= 0 && widthDiff > minWidthDiff)
			{
				minWidthDiff = widthDiff;
				index = i;
			}
		}
	}

	if (index == -1) {
		index = 0;
	}

	return GuiDataUtilities.rampsData[index];
};



GuiDataUtilities.LoadLeanToSizes = function (rafterData)
{
	let leanToSizes = [];

	let sizesPerColumn = 0;

	let leanToTab = document.getElementById("tabLeanTo");

	while (leanToTab.childNodes.length > 0)
		leanToTab.removeChild(leanToTab.childNodes[0]);

	let elemTable = document.createElement("TABLE");

	elemTable.style.borderCollapse = "separate";
	elemTable.style.borderSpacing = "20px 20px";

	let elemTr = document.createElement("TR");
	let elemTd;

	elemTable.appendChild(elemTr);

	let prevWidth = -1;

	for (let i = 0; i < rafterData.length; i++)
	{
		leanToSizes[i] = {
			width: rafterData[i].lean_to_width,
			width_display: rafterData[i].lean_to_width_display
		};

		if (rafterData[i].width_display != prevWidth || sizesPerColumn == MAX_ITEMS_PER_COLUMN)
			sizesPerColumn = 0;

		if (sizesPerColumn == 0)
		{
			elemTd = document.createElement("TD");

			elemTd.setAttribute("vAlign", "top");
			elemTr.appendChild(elemTd);
		}

		let elemRadio = document.createElement("INPUT");
		elemRadio.setAttribute("type", "radio");
		elemRadio.setAttribute("id", "leanToSizeID" + i);
		elemRadio.setAttribute("name", "leanToSizeID" + i);

		elemRadio.iSizeIndex = i;

		if (i == 0)
		{
			elemRadio.setAttribute("checked", "1");
		}

		elemRadio.onchange = ElementsMenu.OnClickChangeLeanToSize;

		let sizeLabel = document.createElement("LABEL");

		let textNode = document.createTextNode(rafterData[i].lean_to_width_display);

		sizeLabel.appendChild(textNode);

		sizeLabel.iSizeIndex = i;
		sizeLabel.onclick = ElementsMenu.OnClickChangeLeanToSize;

		elemTd.appendChild(elemRadio);
		elemTd.appendChild(sizeLabel);
		elemTd.appendChild(document.createElement("BR"));

		prevWidth = rafterData[i].lean_to_width_display;

		sizesPerColumn++;
	}

	leanToTab.appendChild(elemTable);


	return leanToSizes;
};

GuiDataUtilities.GetBackground = async function ()
{
	let err, backgroundData;
		[err, backgroundData] = await to(NodeJSUtilities.UQuery("dataRequest", {request: "getBackground", subscriber_id: SubscriberDataUtilities.subscriber, building_type: BUILDING_STRING[BuildingDesigner.buildingType], series_code: SubscriberDataUtilities.series_code}));

	if (window.backgroundOverride)
	{
		backgroundData[0].texture = window.backgroundOverride;
	}
	return backgroundData;
};

/**
 * This has been depricated and is being replaced by GuiDataUtilities.LoadRafterDataE which has error handling.
 * @function
 * @async
 * @param {string} buildingID
 * @param {number} width
*/
GuiDataUtilities.LoadRafterData = async function (buildingID, width)
{
	let [err, rafterData] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getRafter", subscriber_id: SubscriberDataUtilities.subscriber, buildingID: buildingID, width: width, series_code: SubscriberDataUtilities.series_code}));
	if (err) {
		// TODO: handle error
	}

	if ((typeof MetalRafters !== "undefined") && MetalRafters && rafterData[0] && rafterData[0].options && rafterData[0].options.BentBowRafterCurveRadius)
	{
		MetalRafters.BentBowRafterCurveRadius = rafterData[0].options.BentBowRafterCurveRadius;
	}

	return rafterData;
};

/**
 * This loads rafter data when a building size has been selected. This replaces GuiDataUtilities.LoadRafterData which does not have error handling.
 * @function
 * @async
 * @param {string} buildingID
 * @param {number} width
*/
GuiDataUtilities.LoadRafterDataE = async function (buildingID, width)
{
	let [err, rafterData] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getRafter", subscriber_id: SubscriberDataUtilities.subscriber, buildingID: buildingID, width: width, series_code: SubscriberDataUtilities.series_code}));

	if (err)
	{
		throw (err);
	}
	if ((typeof MetalRafters !== "undefined") && MetalRafters && rafterData[0] && rafterData[0].options && rafterData[0].options.BentBowRafterCurveRadius)
	{
		MetalRafters.BentBowRafterCurveRadius = rafterData[0].options.BentBowRafterCurveRadius;
	}

	return rafterData;
};

/**
 * @function
 * @async
 * @param {string} rafterID
 * @param {number} length
*/
GuiDataUtilities.GetLeanToPrice = async function (rafterID, length)
{
	let [err, leanToData] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getLeanToPrice", subscriber_id: SubscriberDataUtilities.subscriber, rafterID: rafterID, length: length, series_code: SubscriberDataUtilities.series_code}));

	if (leanToData.length > 0)
		return leanToData[0].price;
	else
		return 0;
};

/**
 * GuiDataUtilities.Alert
 * @function
 * @async
 * @param {(string|Object)} data String with message to display or Object with msg property
*/
GuiDataUtilities.Alert = async function (data)
{
		if (typeof data === "string")
		{
			$("#alert_content").html(data);
			$("#alert_infobox").foundation("open");
		}
		else
		{
			$("#alert_content").html(data.msg);
			$("#alert_infobox").foundation("open");
			if (data.datatable) {
				$(`#${data.datatable.id}`).DataTable(data.datatable.config);
			}
		}
};

GuiDataUtilities.formatDesignID = function(design_id) {
	if (SubscriberDataUtilities.design_prefix && design_id.includes(SubscriberDataUtilities.design_prefix + "_")) {
		return design_id.substr(SubscriberDataUtilities.design_prefix.length+1);
	} else {
		return design_id;
	}
}

GuiDataUtilities.displayDesignID = function(design_id) {
	if (design_id) {
		$("#design_id_display").text("Design ID:"+GuiDataUtilities.formatDesignID(design_id));
		$(".design_id_display").show();
	} else {
		$("#design_id_display").text("");
		$(".design_id_display").hide();
	}
}
GuiDataUtilities.currentGuiDataUtilities = new GuiDataUtilities();
