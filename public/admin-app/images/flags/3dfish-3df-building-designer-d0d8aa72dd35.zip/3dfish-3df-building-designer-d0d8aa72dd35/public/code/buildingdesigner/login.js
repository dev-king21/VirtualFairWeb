/*eslint-env jquery, browser*/
/*eslint no-unused-vars:1, quotes: ["warn", "double", { "allowTemplateLiterals":true}] */
/*eslint-disable no-console, no-unused-vars, no-undef*/
function Login()
{}

Login.Login = async function (social_login, loginData)
{
	if (!social_login)
	{
		if (Login.sendingLoginRequest)
		{
			return;
		}
		Login.sendingLoginRequest = true;
		let loginForm = document.getElementById("loginForm");

		let err;
		[err, loginData] = await to(NodeJSUtilities.UQuery("userAction", {
			request: "login",
			username: loginForm.loginUsername.value,
			password: md5(loginForm.loginPassword.value),
			subscriber_id: SubscriberDataUtilities.subscriber
		}));
		if (err)
		{
			console.log(err);
			Login.sendingLoginRequest = false;
			return;
		}
	}
	if (loginData.success)
	{
		UserDataUtilities.userID = loginForm.loginUsername.value;

		if (loginData.userData)
		{
			UserDataUtilities.userData = loginData.userData;
			if (loginData.userData.location_number)
			{
				SubscriberDataUtilities.SetLocation(loginData.userData.location_number);
			}
			if (loginData.userData.with_prefix)
			{
				UserDataUtilities.fQUserID = SubscriberDataUtilities.design_prefix+"_"+loginData.userData.userid;
			}
			else
			{
				UserDataUtilities.fQUserID = loginData.userData.userid;
			}
		}
		Login.SetLoginError("");
		$("#password_reset_link").hide();
		Login.ShowLoggedInHMTL();

		window.location = ("" + window.location).replace(/#[A-Za-z0-9_]*$/, "") + "#closeButton";
		$("#loginFormDiv").foundation("close");
		Login.sendingLoginRequest = false;
	}
	else
	{
		Login.SetLoginError("Incorrect username or password!");
		$("#password_reset_link").show();

		loginForm.loginUsername.value = "";
		loginForm.loginPassword.value = "";
		Login.sendingLoginRequest = false;
	}
};

Login.Logout = async function ()
{
	let logoutData;
	[err,logoutData] = await to(NodeJSUtilities.UQuery("userAction",{request: "logout"}));

	if (logoutData.success)
	{
		UserDataUtilities.usertype = "guest";
		UserDataUtilities.userID = null;
		UserDataUtilities.fQUserID = null;
		UserDataUtilities.userData = null;
		Login.ShowNotLoggedInHMTL();
		UserDataUtilities.SetUserDisplay();
	}
};

Login.PasswordReset = async function ()
{
	if (Login.sendingPasswordResetRequest)
	{
		return;
	}
	Login.sendingPasswordResetRequest = true;
	let resetID = $("#resetUsername").val();
	if (!resetID)
	{
		Login.sendingPasswordResetRequest = false;
		return;
	}
	$("#passwordResetStatus").html(`<font color="green">Sending request.</font>`);
	let [err,resetData] = await to(NodeJSUtilities.UQuery("userAction",{request: "pwrst", userid: resetID, subscriber_id: SubscriberDataUtilities.subscriber}));
	if (err)
	{
		console.error("Error requesting password reset.");
		$("#passwordResetStatus").html(`<font color="red">Request failed. Please try again.</font>`);
		Login.sendingPasswordResetRequest = false;
	}
	if (resetData && resetData.success)
	{
		$("#passwordResetStatus").html(`<font color="green">Password Reset / User ID lookup successful. Check your email.<br>Email will come from sheddesigner@3dfish.net<br>Password reset links expire after 1 hour.</font>`);
		await AuxUtilities.sleep(8000);
		$("#passwordResetFormDiv").foundation("close");
		$("#passwordResetStatus").html("");
		$("#resetUsername").val("");
		Login.sendingPasswordResetRequest = false;
	}
	else
	{
		if (resetData.err_code && resetData.err_code === 1)
		{
			$("#passwordResetStatus").html(`<font color="red">No matching user id or email address found.</font>`);
			Login.sendingPasswordResetRequest = false;
		}
		else
		{
			$("#passwordResetStatus").html(`<font color="red">Request failed. Please try again.</font>`);
			Login.sendingPasswordResetRequest = false;
		}
	}
}

Login.OnShowLoginForm = function ()
{
	Login.SetLoginError("");

	let loginForm = document.getElementById("loginForm");

	loginForm.loginUsername.value = "";
	loginForm.loginPassword.value = "";
};

Login.isLoggedIn = async function ()
{
	let [err, loginData] = await to(NodeJSUtilities.UQuery("userDataRequest",{request: "isLoggedIn"}));

	if (loginData)
	{
		UserDataUtilities.userID = loginData.userid;
		if (loginData.subscriber_id)
		{
			UserDataUtilities.userData = loginData;
			SubscriberDataUtilities.SetLocation(loginData.location_number);
		}

		return true;
	}
	else
	{
		return false;
	}
};

Login.ShowLoginBtn = function ()
{
	if (interfaceCode && (interfaceCode === "if2"))
	{
		let loginButton = document.getElementById("loginButton");
		loginButton.style.display = "block";

		let logoutButton = document.getElementById("logoutButton");
		logoutButton.style.display = "none";

		logoutButton = document.getElementById("userprofileButton");
		logoutButton.style.display = "none";
	}
	if (interfaceCode && (interfaceCode === "if3"))
	{
		$("#loginButton").show();
		$("#logoutButton").hide();
	}
};

Login.ShowLogoutBtn = function ()
{
	if (interfaceCode && (interfaceCode === "if2"))
	{
		let loginButton = document.getElementById("loginButton");
		loginButton.style.display = "none";

		let logoutButton = document.getElementById("logoutButton");
		logoutButton.style.display = "block";

		let userprofileButton = document.getElementById("userprofileButton");
		userprofileButton.style.display = "block";
	}
	if (interfaceCode && (interfaceCode === "if3"))
	{
		$("#loginButton").hide();
		$("#logoutButton").show();
	}
	UserDataUtilities.GetUserData();
};

Login.ShowLoginOrRegisterHref = function ()
{
	$("#loginOrRegisterHref").show();
};

Login.HideLoginOrRegisterHref = function ()
{
	$("#loginOrRegisterHref").hide();
	if (interfaceCode === "if3")
	{
		$("#loginCloseButton").click();
	}
};

Login.ShowSaveWebDesignsForm = function ()
{
	$("#savedesign-html").show();
};

Login.HideSaveWebDesignsForm = function ()
{
	$("#savedesign-html").hide();
	$("#design_id").val("");
};

Login.ShowSaveWebDesignsList = function ()
{
	$("#webDesigns").show();
};

Login.HideSaveWebDesignsList = function ()
{
	$("#webDesigns").hide();
};


Login.Hide3DObjectEditorButtons = function ()
{
	if (interfaceCode && (interfaceCode !== "if3"))
	{
		let editObjects = document.getElementById("editObjects");

		saveAsDefaultConfiguration.style.display = "none";
	}
	if ((typeof (interfaceCode) !== "undefined") && ((interfaceCode === "if2") || (interfaceCode === "if3")))
	{
		if (interfaceCode === "if2")
		{
			$(".adminui").css("display", "none");
			$(".sadminui").css("display", "none");
			$(".masterui").css("display", "none");
		}
		else
		{
			$(".adminui").hide();
			$(".sadminui").hide();
			$(".masterui").hide();
			//changeCss(".adminui","display: none;");
			//changeCss(".sadminui","display: none;");
			//changeCss(".masterui","display: none;");
		}
	}
	else
	{
		if (interfaceCode && (interfaceCode === "if2"))
		{
			//editObjects.style.display = "none";
			$("#editObjects").hide();
		}
	}
};

Login.ArchiveDesign = async function (design_id, design_name, fq_design_id)
{
	let err, result;
	if (confirm("Are you sure you want to archive " + design_id + " - " + design_name))
	{
		[err, result] = await to($.ajax({
			url: "/updateDesign",
			type: "POST",
			data: {
				subscriber_id: SubscriberDataUtilities.subscriber,
				series_code: SubscriberDataUtilities.series_code,
				userid: UserDataUtilities.userID,
				design_id: fq_design_id,
				request: "archive"
			}
		}));
		if (err)
		{
			alert("Archiving operation failed.");
		}
		else
		{
			if (result.success)
			{
				Login.LoadWebDesignsList();
			}
			else
			{
				alert("Archiving operation failed.");
			}
		}
	}
};

Login.ActivateDesign = async function (design_id, design_name, fq_design_id)
{
	let err, result;
	if (confirm("Are you sure you want to activate " + design_id + " - " + design_name))
	{
		[err, result] = await to($.ajax({
			url: "/updateDesign",
			type: "POST",
			data: {
				subscriber_id: SubscriberDataUtilities.subscriber,
				series_code: SubscriberDataUtilities.series_code,
				userid: UserDataUtilities.userID,
				design_id: fq_design_id,
				request: "activate"
			}
		}));
		if (err)
		{
			alert("Activating operation failed.");
		}
		else
		{
			if (result.success)
			{
				Login.LoadWebDesignsList();
			}
			else
			{
				alert("Activating operation failed.");
			}
		}
	}
};

Login.RenameDesign = async function (design_id, design_name)
{
	let err, result;
	let newName = prompt("Rename Design ID: " + design_id, design_name);
	if ((newName != null) && (newName != design_name))
	{
		[err, result] = await to($.ajax({
			url: "/updateDesign",
			type: "POST",
			data: {
				subscriber_id: SubscriberDataUtilities.subscriber,
				series_code: SubscriberDataUtilities.series_code,
				userid: UserDataUtilities.userID,
				design_id: design_id,
				new_design_id: design_id,
				design_name: newName,
				request: "rename"
			}
		}));
		if (err)
		{
			alert("Rename operation failed.");
		}
		else
		{
			if (result.success)
			{
				$("#designlink_" + design_id + " font:first-child").text(design_id + " - " + newName);
			}
			else
			{
				alert("Rename operation failed.");
			}
		}
	}
};

Login.DeleteDesign = async function (design_id, design_name, fq_design_id)
{
	if (!fq_design_id)
	{
		fq_design_id = design_id;
	}
	let err, result;
	if (confirm("Are you sure you want to delete design id: " + design_id + " - " + design_name))
	{
		[err, result] = await to($.ajax({
			url: "/updateDesign",
			type: "POST",
			data: {
				subscriber_id: SubscriberDataUtilities.subscriber,
				series_code: SubscriberDataUtilities.series_code,
				userid: UserDataUtilities.userID,
				design_id: fq_design_id,
				request: "delete"
			}
		}));
		if (err)
		{
			alert("Delete operation failed.");
		}
		else
		{
			if (result.success)
			{
				$("#designlink_" + design_id).parent().remove();
			}
			else
			{
				alert("Delete operation failed.");
			}
		}
	}
};

Login.EditDesignUserInfo = async function ()
{
	let err, result;
	alert("Edit feature coming soon...");
};

/**
 * @function
 * @async
 */
Login.LoadWebDesignsList = async function ()
{
	let delivered_icon = `<i class="fas fa-check" data-fa-transform="shrink-10 left-4 up-2" data-fa-mask="fas fa-truck" title="Delivered"></i>&nbsp;`;
	let ordered_icon = `<i class="fas fa-file-upload" title="Ordered"></i>&nbsp;`;
	let locked_icon = `<i class="fas fa-lock" title="Design Locked"></i>&nbsp;`;
	let built_icon = `<i class="fas fa-clock" data-fa-transform="shrink-10 left-4 up-2" data-fa-mask="fas fa-truck" title="Built">&nbsp;`;

	let [err,designsData] = await to(LoadingSavingUtilities.GetSavedWebDesigns(UserDataUtilities.userID, SubscriberDataUtilities.subscriber));
	if (err)
	{
		//TODO: additional handling of error condition
		console.error("Error retrieving saved designs.");
		return;
	}
	let webDesignsDiv = document.getElementById("webDesigns");

	let webDesignsLabel = document.getElementById("webDesignsLabel");
	if (interfaceNumber > 2)
	{
		webDesignsLabel.innerHTML = `Your (${UserDataUtilities.userID}'s) designs on the web:<span id="archiveLink" style="display:none"><br><a href="#ShowArchives" data-open="ArchivesModal" onclick="event.preventDefault();">View archived designs.</a></span>`;
	}
	else
	{
		webDesignsLabel.innerHTML = `Your (${UserDataUtilities.userID}'s) designs on the web:<span id="archiveLink" style="display:none"><br><a href="#ShowArchives" data-target="#ArchivesModal" data-toggle="modal" onclick="event.preventDefault();">View archived designs.</a></span>`;
	}

	let webDesignsTable = document.getElementById("webDesignsTable");
	webDesignsTable.parentNode.removeChild(webDesignsTable);
	$("#archiveList").empty();

	let tr, td, i, tr2, td2;

	let maxRows = 3;
	let designData;

	let newTable = document.createElement("TABLE");
	newTable.setAttribute("id", "webDesignsTable");
	newTable.setAttribute("cellspacing", "20px");

	/*newTable.setAttribute("border-collapse", "separate");

	newTable.setAttribute("border-spacing", "10px 10px");
    */

	newTable.style.borderCollapse = "separate";

	newTable.style.borderSpacing = "20px 20px";

	tr = newTable.insertRow(newTable.rows.length);
	td = tr.insertCell(tr.cells.length);

	td.setAttribute("valign", "top");
	if ((typeof (interfaceCode) !== "undefined") && (interfaceNumber > 1))
	{
		let archiveTable = document.getElementById("archiveList");
		tr2 = archiveTable.insertRow(0);
		td2 = tr2.insertCell(tr2.cells.length);

		td2.setAttribute("valign", "top");
	}

	for (i = 0; i < designsData.length; i++)
	{
		let flags = "";
		if (designsData[i].design_locked)
		{
			flags += locked_icon;
		}
		if (designsData[i].design_delivered)
		{
			flags += delivered_icon;
		}
		else if (designsData[i].design_built)
		{
			flags += built_icon;
		}
		else if (designsData[i].design_ordered)
		{
			flags += ordered_icon;
		}
		if ((typeof (interfaceCode) !== "undefined") && (interfaceNumber === 2))
		{
			if (!designsData[i].design_archived)
			{
				td.innerHTML += `<div class="dropdown" id="designlink_${designsData[i].design_id}"><i class="fas fa-ellipsis-v" data-toggle="dropdown"></i>
	<ul class="dropdown-menu">
		<li><a href="#" onclick="Login.RenameDesign('${designsData[i].fq_design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}');">Rename</a></li>
		<li><a href="#" class="archivedesign" onclick="Login.ArchiveDesign('${designsData[i].fq_design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}');">Archive</a></li>
		<li>
				<a href="#" class="activatedesign" style="display:none;" onclick="Login.ActivateDesign('${designsData[i].design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}','${designsData[i].fq_design_id}');">Activate</a>
			</li>
		<li class="adminui"><a href="#">Edit User Info</a></li>
		<li><a href="#" onclick="Login.DeleteDesign('${designsData[i].design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}','${designsData[i].fq_design_id}');">Delete</a></li>
	</ul>&nbsp;${flags}<a href="#?designID=${designsData[i].design_id}" onclick="LoadingSavingUtilities.LoadWebDesign(&apos;${designsData[i].design_id}&apos;,&apos;${designsData[i].software_version}&apos;);">
		<font size=2 color="#0000FF">${designsData[i].design_id} - ${designsData[i].shedName}</font>
	</a>
</div>`;
			}
			else
			{
				$("#archiveLink").show();
				td2.innerHTML += `<div class="dropdown" id="designlink_${designsData[i].design_id}">
	<i class="fas fa-ellipsis-v" data-toggle="dropdown"></i>
	<ul class="dropdown-menu">
		<li>
			<a href="#" onclick="Login.RenameDesign('${designsData[i].fq_design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}');">Rename</a>
		</li>
		<li><a href="#" class="archivedesign" style="display:none" onclick="Login.ArchiveDesign('${designsData[i].design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}','${designsData[i].fq_design_id}');">Archive</a></li>
		<li>
			<a href="#" class="activatedesign" onclick="Login.ActivateDesign('${designsData[i].design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}','${designsData[i].fq_design_id}');">Activate</a>
		</li>
		<li class="adminui">
			<a href="#">Edit User Info</a>
		</li>
		<li>
			<a href="#" onclick="Login.DeleteDesign('${designsData[i].design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}','${designsData[i].fq_design_id}');">Delete</a>
		</li>
	</ul>
	&nbsp;${flags}<a href="#?designID=${designsData[i].design_id}" onclick="LoadingSavingUtilities.LoadWebDesign(&apos;${designsData[i].design_id}&apos;,&apos;${designsData[i].software_version}&apos;);">
		<font size=2 color="#0000FF">${designsData[i].design_id} - ${designsData[i].shedName}</font>
	</a>
</div>`;
			}
		}
		else if (interfaceNumber > 2)
		{
			if (!designsData[i].design_archived)
			{
				td.innerHTML += `<ul class="dropdown menu" data-dropdown-menu>
				<li id="designlink_${designsData[i].design_id}"><i class="fas fa-ellipsis-v design_menu_icon"></i>
	<ul class="menu" id="dropdown_${designsData[i].design_id}">
		<li><a href="#" onclick="Login.RenameDesign('${designsData[i].fq_design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}');">Rename</a></li>
		<li><a href="#" class="archivedesign" onclick="Login.ArchiveDesign('${designsData[i].design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}','${designsData[i].fq_design_id}');">Archive</a></li>
		<li>
				<a class="activatedesign" style="display:none;" href="#" onclick="Login.ActivateDesign('${designsData[i].design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}','${designsData[i].fq_design_id}');">Activate</a>
			</li>
		<li class="adminui"><a href="#">Edit User Info</a></li>
		<li><a href="#" onclick="Login.DeleteDesign('${designsData[i].design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}','${designsData[i].fq_design_id}');">Delete</a></li>
	</ul><li id="link_${designsData[i].design_id}"><a href="#?designID=${designsData[i].design_id}" onclick="LoadingSavingUtilities.LoadWebDesign(&apos;${designsData[i].design_id}&apos;,&apos;${designsData[i].software_version}&apos;);">${flags}
		<font size=2 color="#0000FF">${designsData[i].design_id} - ${designsData[i].shedName}</font>
	</a></li>
</ul>`;
			}
			else
			{
				$("#archiveLink").show();
				td2.innerHTML += `<ul class="dropdown menu" data-dropdown-menu><li id="designlink_${designsData[i].design_id}">
	<i class="fas fa-ellipsis-v design_menu_icon"></i>
	<ul class="menu" id="dropdown_${designsData[i].design_id}">
		<li>
			<a href="#" onclick="Login.RenameDesign('${designsData[i].fq_design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}');">Rename</a>
		</li>
		<li><a href="#" class="archivedesign" style="display:none" onclick="Login.ArchiveDesign('${designsData[i].design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}','${designsData[i].fq_design_id}');">Archive</a></li>
		<li class="activatedesign" onclick="Login.ActivateDesign('${designsData[i].design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}','${designsData[i].fq_design_id}');">
			<a href="#">Activate</a>
		</li>
		<li class="adminui">
			<a href="#">Edit User Info</a>
		</li>
		<li>
			<a href="#" onclick="Login.DeleteDesign('${designsData[i].design_id}','${AuxUtilities.escapeSQuote(designsData[i].shedName)}','${designsData[i].fq_design_id}');">Delete</a>
		</li>
	</ul></li>
	<li id="link_${designsData[i].design_id}"><a href="#?designID=${designsData[i].design_id}" onclick="LoadingSavingUtilities.LoadWebDesign(&apos;${designsData[i].design_id}&apos;,&apos;${designsData[i].software_version}&apos;);">${flags}
		<font size=2 color="#0000FF">${designsData[i].design_id} - ${designsData[i].shedName}</font>
	</a></li>
</ul>`;
			}
		}
		else
		{
			if (!designsData[i].design_archived)
			{
				td.innerHTML += "<a href=\"#?designID=" + designsData[i].design_id + "\" onclick=\"LoadingSavingUtilities.LoadWebDesign(&apos;" + designsData[i].design_id + "&apos;,&apos;" + designsData[i].software_version + "&apos;);\"><font size=2 color=\"#0000FF\">" + designsData[i].design_id + " - " + designsData[i].shedName + "</font></a>";
			}
		}

		/* if ((i + 1) % maxRows != 0) {
			// td.innerHTML += "<br><br>";
		} else {
			td.innerHTML += "<br><br>";
			td = tr.insertCell(tr.cells.length);
			td.setAttribute("valign", "top");
		} */
	}

	td.innerHTML += "<br><br>";

	webDesignsDiv.appendChild(newTable);
	if (interfaceNumber > 2)
	{
		$("#webDesignsTable").foundation();
		$("#archiveList").foundation();
	}
};

Login.SetLoginError = function (text)
{
	let loginResult = document.getElementById("loginResult");
	loginResult.innerHTML = "<font size='2' color='red'>" + text + "</font>";
};

Login.ShowLoggedInHMTL = function ()
{
	Login.ShowLogoutBtn();
	Login.HideLoginOrRegisterHref();
	Login.ShowSaveWebDesignsForm();
	Login.LoadWebDesignsList();
	Login.ShowSaveWebDesignsList();
	$("#logoutButton").attr("title",`3D Builder Account
${UserDataUtilities.userData.userid}
${UserDataUtilities.userData.firstname} ${UserDataUtilities.userData.lastname}
${UserDataUtilities.userData.email}`);
};

Login.ShowNotLoggedInHMTL = function ()
{
	Login.ShowLoginBtn();
	Login.ShowLoginOrRegisterHref();
	Login.HideSaveWebDesignsForm();
	Login.HideSaveWebDesignsList();
	Login.Hide3DObjectEditorButtons();
};

/**
 * Processes form for user to contact the subscriber
 * @function Login.contactForm
 */
Login.contactForm = async function ()
{
	// User contact form
	if (Login.sendingContactRequest)
	{
		return;
	}
	Login.sendingContactRequest = true;
	let err, result;
	let formData = $("form#contactForm").serializeObject();
	formData.first_name = AuxUtilities.properName(formData.first_name);
	formData.last_name = AuxUtilities.properName(formData.last_name);
	let contactForm = $("#contactForm")[0];
	if (contactForm.postal_code_data)
	{
		formData.postal_code_data = contactForm.postal_code_data;
	}
	$("#contactRequestStatus").html(`<font color="blue">Sending your request...</font>`);
	[err, result] = await to(NodeJSUtilities.UQuery("userAction", {
		request: "contactRequest",
		subscriber_id: SubscriberDataUtilities.subscriber,
		location_number: SubscriberDataUtilities.location_number,
		series_code: SubscriberDataUtilities.series_code,
		user_id: UserDataUtilities.userID,
		form_data: formData
	}));
	if (err)
	{
		$("#contactRequestStatus").html(`<font color="red">Error sending request. Please try again.</font>`);
		Login.sendingContactRequest = false;
		return;
	}
	if (result.success)
	{
		$("#contactRequestStatus").html(`<font color="green">Your request has been sent.</font>`);
		await AuxUtilities.sleep(5000);
		$("#contactFormCloseButton").click();
		$("#contactForm")[0].reset();
		$("#contactRequestStatus").empty();
		Login.sendingContactRequest = false;
	}
	else
	{
		$("#contactRequestStatus").html(`<font color="red">Error sending request. Please call us if this error persists.</font>`);
		Login.sendingContactRequest = false;
	}
};

Login.myDesignsLoginCheck = async function ()
{
	if (!UserDataUtilities.userID)
	{
		await AuxUtilities.sleep(500);
		$("#MyBuildingModal").foundation("close");
		$("#registrationFormDiv").foundation("open");
	}
}

Login.finalQuoteForm = async function ()
{
	let err, result;
	if (Login.sendingFinalQuoteRequest)
	{
		return;
	}
	Login.sendingFinalQuoteRequest = true;
	let formData = $("form#finalQuoteForm").serializeObject();
	let finalQuoteForm = $("#finalQuoteForm")[0];
	if (finalQuoteForm.postal_code_data)
	{
		formData.postal_code_data = finalQuoteForm.postal_code_data;
	}
	formData.product_id = buildingDesigner.building.sizeData.product_id;
	formData.linked_product_id = buildingDesigner.building.sizeData.linked_product_id;
	formData.detailListText = building.detailListText;
	formData.subTotal = building.subTotal;
	formData.shortDescription = building.baseDescription;
	formData.txDateYear2 = new Date().toLocaleDateString(undefined,{year: "2-digit"});
	formData.txDateYear4 = new Date().toLocaleDateString(undefined,{year: "numeric"});
	formData.txDateMonth = new Date().toLocaleDateString(undefined,{month: "2-digit"});
	formData.txDateDay = new Date().toLocaleDateString(undefined,{day: "2-digit"});
	formData.txDateHour = new Date().toLocaleTimeString(undefined,{hour: "2-digit",hour12: false});
	formData.txDateMinute = new Date().toLocaleTimeString(undefined,{minute: "2-digit"});
	formData.detailListHTML = building.detailListHTML;
	formData.detailList = JSON.parse(JSON.stringify(building.detailList));
	if (!formData.register_customer)
	{
		formData.fq_user_id = UserDataUtilities.fQUserID;
	}
	if ((!UserDataUtilities.userID) || formData.register_customer)
	{
		$("#quoteRequestStatus").html(`<font color="blue">Checking for User ID...</font>`);

		[err, result] = await to(NodeJSUtilities.UQuery("userAction", {
			request: "getUserIDbyEmail",
			subscriber_id: SubscriberDataUtilities.subscriber,
			location_number: SubscriberDataUtilities.location_number,
			series_code: SubscriberDataUtilities.series_code,
			email: formData.email}));
		if (err)
		{
			$("#quoteRequestStatus").html(`<font color="red">Error checking for User ID.</font>`);
			result = {success: false, user_list: []};
			Login.sendingFinalQuoteRequest = false;
			return;
		}
		if (result.success)
		{
			if (result.user_list.length === 1)
			{
				$("#quoteRequestStatus").html(`<font color="blue">User ID found</font>`);
				if (!formData.register_customer)
				{
					UserDataUtilities.userID = result.user_list[0].userid;
				}
				formData.fq_user_id = result.user_list[0].userid;
			}
			else if (result.user_list.length === 0)
			{
				$("#quoteRequestStatus").html(`<font color="blue">Creating User ID...</font>`);
				formData.first_name = AuxUtilities.properName(formData.first_name);
				formData.last_name = AuxUtilities.properName(formData.last_name);
				[err, result] = await to(NodeJSUtilities.UQuery("userAction", {
					request: "autoRegister",
					subscriber_id: SubscriberDataUtilities.subscriber,
					location_number: SubscriberDataUtilities.location_number,
					series_code: SubscriberDataUtilities.series_code,
					formData: formData
				}));
				if (err)
				{
					$("#quoteRequestStatus").html(`<font color="red">User creation failed.</font>`);
					Login.sendingFinalQuoteRequest = false;
					return;
				}
				if (result.success)
				{
					if (!formData.register_customer)
					{
						UserDataUtilities.userID = result.userid;
						if (result.userData) {
							UserDataUtilities.userData = result.userData;
						}
						Login.ShowLoggedInHMTL();
					}
					formData.fq_user_id = result.userid;
				}
				else
				{
					$("#quoteRequestStatus").html(`<font color="red">User creation failed.</font>`);
					Login.sendingFinalQuoteRequest = false;
					return;
				}
			}
			else
			{
				$("#quoteRequestStatus").html(`<font color="red">Multiple users found. You must log in first.</font>`);
				Login.sendingFinalQuoteRequest = false;
				return;
			}
		}
		else
		{
			$("#quoteRequestStatus").html(`<font color="red">Error checking for User ID.</font>`);
			Login.sendingFinalQuoteRequest = false;
			return;
		}

	}
	formData.submitted_by = UserDataUtilities.userID;
	$("#quoteRequestStatus").html(`<font color="blue">Saving your design...</font>`);
	if (formData.register_customer)
	{
		[err,result] = await to(LoadingSavingUtilities.SaveToServer("","Design for Order",formData.fq_user_id));
	}
	else
	{
		[err,result] = await to(LoadingSavingUtilities.SaveToServer("","Design for Order"));
	}
	if (err)
	{
		$("#quoteRequestStatus").html(`<font color="red">Saving failed.</font>`);
		Login.sendingFinalQuoteRequest = false;
		return;
	}
	formData.design_id = result.design_id;
	formData.subscriber_id = SubscriberDataUtilities.subscriber;
	$("#quoteRequestStatus").html(`<font color="blue">Sending your order...</font>`);
	[err, result] = await to(NodeJSUtilities.UQuery("userAction", {
		request: "quoteRequest",
		subscriber_id: SubscriberDataUtilities.subscriber,
		location_number: SubscriberDataUtilities.location_number,
		series_code: SubscriberDataUtilities.series_code,
		user_id: UserDataUtilities.userID,
		form_data: formData
	}));
	if (err)
	{
		$("#quoteRequestStatus").html(`<font color="red">Error sending order. Please try again.</font>`);
		Login.sendingFinalQuoteRequest = false;
		return;
	}
	if (result.success)
	{
		$("#quoteRequestStatus").html(`<font color="green">Your order has been sent.</font>`);
		await AuxUtilities.sleep(5000);
		$("#finalQuoteFormCloseButton").click();
		$("#finalQuoteForm")[0].reset();
		$("quoteRequestStatus").empty();
		Login.LoadWebDesignsList();
		Login.sendingFinalQuoteRequest = false;
	}
	else
	{
		$("#contactRequestStatus").html(`<font color="red">Error sending request. Please call us if this error persists.</font>`);
		Login.sendingFinalQuoteRequest = false;
	}
};

Login.purchaseForm = async function ()
{
	return;
}

Login.purchaseBillingForm = async function ()
{
	return;
}

Login.leasePurchaseForm = async function ()
{
	return;
}

Login.sendingContactRequest = false;
Login.sendingFinalQuoteRequest = false;
Login.sendingPasswordResetRequest = false;
Login.sendingLoginRequest = false;

if (window.socket)
{
	socket.on("social_login",(data) =>
	{
		Login.Login(true,data);
	});
}
