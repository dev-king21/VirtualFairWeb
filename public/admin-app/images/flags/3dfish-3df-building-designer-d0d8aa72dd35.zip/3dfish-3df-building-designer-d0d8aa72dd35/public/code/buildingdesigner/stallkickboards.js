/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function StallKickBoards(stall)
{
	this.stall = stall;

	this.width = this.stall.width;
	this.length = this.stall.length;

	this.kickBoards = [];

	this.selected = false;

	this.regenerate = true;

	////let kickBoardLength = this.width - KickBoard.THICKNESS*2;

	let kickBoardLength = this.width;

	if (this.stall.stallIndex > 0 && this.stall.partition && this.stall.partition.style != Partition.NO_PARTITION)
		kickBoardLength -= Partition.PARTITION_THICKNESS * 2;
	else
	if (this.stall.stallIndex == 0 && !this.stall.partition)
		kickBoardLength -= (Wall.WALLTHICKNESS * 2 + buildingDesigner.building.roofRafter.data.width * 2);
	else
	if (this.stall.stallIndex == 0 || this.stall.stallIndex == buildingDesigner.building.stalls.stallsList.length - 1)
		kickBoardLength -= (Wall.WALLTHICKNESS + buildingDesigner.building.roofRafter.data.width);


	let zOff = 0;

	if (this.stall.stallIndex == 0 && this.stall.partition)
	{
		zOff = Wall.WALLTHICKNESS + buildingDesigner.building.roofRafter.data.width - Partition.PARTITION_THICKNESS;
	}
	else
	if (this.stall.stallIndex > 0 && !this.stall.partition)
		zOff = Partition.PARTITION_THICKNESS - Wall.WALLTHICKNESS - buildingDesigner.building.roofRafter.data.width;


	this.kickBoards[0] = new KickBoard(kickBoardLength, this.length / 2 - KickBoard.THICKNESS / 2 - buildingDesigner.building.roofRafter.data.width, 0, zOff, MathUtilities.PI / 2);

	this.kickBoards[1] = new KickBoard(kickBoardLength, -this.length / 2 + KickBoard.THICKNESS / 2 + buildingDesigner.building.roofRafter.data.width, 0, zOff, MathUtilities.PI / 2);


	kickBoardLength = this.length - Wall.WALLTHICKNESS;

	let xOff = 0;

	////if (this.stall.stallIndex == buildingDesigner.building.stalls.stallsList.length-1 || (this.stall.partition && this.stall.partition.style != Partition.NO_PARTITION))
	{
		this.kickBoards[2] = new KickBoard(kickBoardLength, xOff, 0, this.width / 2 - KickBoard.THICKNESS / 2 - (this.stall.partition ? Partition.PARTITION_THICKNESS / 2 : buildingDesigner.building.roofRafter.data.width + Wall.WALLTHICKNESS), 0);

		if (this.stall.partition)
			this.kickBoards[2].mesh.element = this.stall.partition;
	}


	////if (this.stall.stallIndex == 0 || (buildingDesigner.building.stalls.stallsList[this.stall.stallIndex-1].partition && buildingDesigner.building.stalls.stallsList[this.stall.stallIndex-1].partition.style != Partition.NO_PARTITION))
	{
		this.kickBoards[3] = new KickBoard(kickBoardLength, xOff, 0, -this.width / 2 + KickBoard.THICKNESS / 2 + (this.stall.stallIndex > 0 ? Partition.PARTITION_THICKNESS / 2 : buildingDesigner.building.roofRafter.data.width + Wall.WALLTHICKNESS), 0);

		if (this.stall.stallIndex > 0 && buildingDesigner.building.stalls.stallsList[this.stall.stallIndex - 1].partition)
			this.kickBoards[3].mesh.element = buildingDesigner.building.stalls.stallsList[this.stall.stallIndex - 1].partition;
	}




	this.SetSelected = function (selected)
	{
		this.selected = selected;
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;

		for (let i = 0; i < this.kickBoards.length; i++)
		{
			if (this.kickBoards[i])
				this.kickBoards[i].SetRegenerate(regenerate);
		}
	};

	this.GenerateSelectedBoxes = function (parentMesh, matrix)
	{
		let fSelBoxSize = SEL_BOX_SIZE * 2;
		let box_size2 = fSelBoxSize / 2.0;

		let box_offs_x = this.width - fSelBoxSize - box_size2;
		let box_offs_y = this.height + box_size2;


		let box_offs_z = 0;

		let vecOffs = [{
			x: box_size2,
			y: fSelBoxSize,
			z: box_offs_z
		},
		{
			x: box_size2,
			y: box_offs_y / 2,
			z: box_offs_z
		},
		{
			x: box_size2,
			y: box_offs_y,
			z: box_offs_z
		},
		{
			x: box_offs_x,
			y: fSelBoxSize,
			z: box_offs_z
		},
		{
			x: box_offs_x,
			y: box_offs_y / 2,
			z: box_offs_z
		},
		{
			x: box_offs_x,
			y: box_offs_y,
			z: box_offs_z
		},
		{
			x: box_offs_x / 2,
			y: box_offs_y,
			z: box_offs_z
		},
		{
			x: box_offs_x / 2,
			y: fSelBoxSize,
			z: box_offs_z
		}
		];


		let materSelBox = Material.CreateMaterial(SEL_BOX_COLOR, null);

		let totalGeometry = new THREE.Geometry();

		for (let i = 0; i < 8; i++)
		{
			let geomSelBox = new THREE.BoxGeometry(fSelBoxSize, fSelBoxSize, fSelBoxSize);

			let boxMatrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(vecOffs[i].x - this.width / 2, vecOffs[i].y, vecOffs[i].z));

			totalGeometry.merge(geomSelBox, boxMatrix);
		}

		let meshSelBox = new THREE.Mesh(totalGeometry, materSelBox);
		parentMesh.add(meshSelBox);
	};

	this.Generate = function (stallMeshes)
	{
		if (this.regenerate)
		{
			let kickBoardMeshes = [];

			for (let i = 0; i < this.kickBoards.length; i++)
			{
				if (this.kickBoards[i] && (!this.kickBoards[i].mesh.element || (this.kickBoards[i].mesh.element && this.kickBoards[i].mesh.element.style != Partition.NO_PARTITION)))
				{
					this.kickBoards[i].Generate(kickBoardMeshes);
				}
			}



			for (let i = 0; i < kickBoardMeshes.length; i++)
			{
				kickBoardMeshes[i].geometry.matrixAutoUpdate = false;
				kickBoardMeshes[i].geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, this.stall.zStart + this.stall.width / 2));
				kickBoardMeshes[i].type = ELEM_KICKBOARD;
				stallMeshes.add(kickBoardMeshes[i]);
			}

			////let kickBoardsMesh = MeshUtilities.MergeMeshes(kickBoardMeshes);
			////kickBoardsMesh.geometry..matrixAutoUpdate = false;
			////kickBoardsMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, this.stall.zStart+this.stall.width/2));

			/*if (kickBoardMeshes.length>0)
            {
			let kickBoardsMesh = kickBoardMeshes;
			kickBoardsMesh..matrixAutoUpdate = false;
            kickBoardsMesh.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, this.stall.zStart+this.stall.width/2));

            kickBoardsMesh.type = ELEM_KICKBOARD;

            stallMeshes.add(kickBoardsMesh);

            /*
            if (this.selected)
                this.GenerateSelectedBoxes(this.mesh, new THREE.Matrix4());
            */
			//}
		}
	};

}
