/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function LineGuide(wall, type)
{
	this.wall = wall;
	this.type = type;

	this.length = 0;

	this.matrix = null;

	this.pos = new THREE.Vector3(0, 0, 0);

	this.mesh = null;

	this.guideColor = 0x000000;

	this.visible = false;

	this.regenerate = true;

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.SetVisibility = function (visibility)
	{
		this.visible = visibility;

		if (this.mesh)
		{
			this.mesh.visible = this.visible;

			////this.UpdateMatrix();
		}
	};

	this.CreateDashedLine = function (vecEnd1, vecEnd2, dashSize, slotSize)
	{
		/*let fPixelDensity = g_fCanvasHeight / canvasMain.height;
        let fDashSize = fDashSizePix * fPixelDensity;
        let fSlotSize = fSlotSizePix * fPixelDensity;
        let fPeriodSize = fDashSize + fSlotSize;
        */

		let periodSize = dashSize + slotSize;

		let vecDir = new THREE.Vector3().subVectors(vecEnd2, vecEnd1);

		let lineLen = vecDir.length();

		let vecDash = vecDir.clone();
		let vecSlot = vecDir.clone();

		vecDash.setLength(dashSize);
		vecSlot.setLength(slotSize);


		let currLen = 0.0;
		let vecPnt = vecEnd1.clone();
		let vecPoints = [];

		while (currLen < lineLen)
		{
			vecPoints.push(vecPnt.clone());

			if (currLen + dashSize > lineLen)
				vecPnt.add(vecDash.setLength(lineLen - currLen));
			else
				vecPnt.add(vecDash);

			vecPoints.push(vecPnt.clone());
			vecPnt.add(vecSlot);

			currLen += periodSize;
		}

		return vecPoints;
	};

	this.Generate = function ()
	{
		if (this.regenerate)
		{
			this.Destroy();

			let vecEnd1;
			let vecEnd2;

			if (this.type == LineGuide.HORIZ_GUIDE)
			{
				this.length = this.wall.length;

				vecEnd1 = new THREE.Vector3(-this.length / 2, 0, 0);
				vecEnd2 = new THREE.Vector3(this.length / 2, 0, 0);
			}
			else
			{
				this.length = this.wall.height;

				vecEnd1 = new THREE.Vector3(0, -this.length / 2, 0);
				vecEnd2 = new THREE.Vector3(0, this.length / 2, 0);
			}



			let geomLine = new THREE.Geometry();
			geomLine.vertices = this.CreateDashedLine(vecEnd1, vecEnd2, LineGuide.LINE_DASH_SIZE, LineGuide.LINE_SLOT_SIZE);

			let material = new THREE.LineBasicMaterial({
				color: 0x000000
			});

			this.mesh = new THREE.LineSegments(geomLine, material);

			threeScene.add(this.mesh);
			threeRenderer.shadowMap.needsUpdate = true;


			/*let material = new THREE.LineBasicMaterial({color: 0x000000});

              let geometry = new THREE.Geometry();
              ////geometry.vertices.push(new THREE.Vector3(-10, 0, 1), new THREE.Vector3(10, 10, 1));

              geometry.vertices.push(new THREE.Vector3(-10, 10, 1), new THREE.Vector3(10, 10, 1));

              this.mesh = new THREE.Line(geometry, material);

              threeScene.add(this.mesh);
              */


			this.mesh.visible = this.visible;

			this.UpdateMatrix();

			////buildingMeshes.push(this.mesh);

			this.regenerate = false;

			return this.mesh;
		}
	};

	this.UpdateMatrix = function ()
	{
		if (this.wall && this.wall.matrix)
		{
			let matrix = new THREE.Matrix4();

			matrix = new THREE.Matrix4().multiplyMatrices(this.wall.matrix, matrix);

			let inFrontAdj = LineGuide.GUIDE_IN_FRONT_WALL_DISTANCE;

			switch (this.wall.eWall)
			{
			case (WALL_LEFT):
				inFrontAdj = -LineGuide.GUIDE_IN_FRONT_WALL_DISTANCE;
				break;

			case (WALL_BACK):
				inFrontAdj = -LineGuide.GUIDE_IN_FRONT_WALL_DISTANCE;
				break;
			}

			if (buildingDesigner.camera.modeCamera == Camera.CAM_MODE_INTERIOR)
				inFrontAdj *= -1;

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, inFrontAdj));


			/*if (this.type==LineGuide.HORIZ_GUIDE)
                {
                    matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0,this.wall.height/2,0));
                    ////matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationZ( MathUtilities.PI/2 ));
                    ////matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0,this.wall.height,0));
                    ////matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0,-this.wall.height/2,0));
                }
                else*/
			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.floorHeight + this.wall.height / 2, 0));

			this.mesh.matrix = new THREE.Matrix4();
			this.mesh.matrixAutoUpdate = false;
			this.mesh.applyMatrix4(matrix);
		}
	};


	this.SetWall = function (wall)
	{
		if (this.wall != wall)
		{
			this.wall = wall;

			return 1;
		}
	};

	this.SetPos = function (x, y, z)
	{
		this.pos.x = x;
		this.pos.y = y;
		this.pos.z = z;
	};

	this.SetPos = function (vector)
	{
		this.pos.x = vector.x;
		this.pos.y = vector.y;
		this.pos.z = vector.z;
	};

	this.Destroy = function ()
	{
		if (this.mesh != null)
		{
			threeScene.remove(this.mesh);
			threeRenderer.shadowMap.needsUpdate = true;

			this.mesh = null;
		}
	};
}

LineGuide.HORIZ_GUIDE = 1;
LineGuide.VERT_GUIDE = 2;

LineGuide.WIDTH = 1.0;
LineGuide.THICKNESS = 0.1;
LineGuide.LINE_DASH_SIZE = 0.3;
LineGuide.LINE_SLOT_SIZE = 0.1;

LineGuide.GUIDE_IN_FRONT_WALL_DISTANCE = 1.5;
//LineGuide.GUIDE_IN_FRONT_WALL_DISTANCE = 0.1;

LineGuide.CENTER_RANGE = 1;

LineGuide.SNAP_TO_CENTER_RANGE = 0.3;
