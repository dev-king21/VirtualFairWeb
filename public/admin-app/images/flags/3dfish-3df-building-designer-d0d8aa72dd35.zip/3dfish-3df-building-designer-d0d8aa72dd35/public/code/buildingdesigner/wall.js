/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/

/**
 *
 * @constructor
 * @param {*} parent
 * @param {*} eWall
 */
function Wall(parent, eWall)
{
	this.parent = parent;

	this.price = 0;

	this.length = null;
	this.height = null;

	this.eWall = eWall;

	this.matrix = null;
	this.pos = null;

	this.mesh = null;
	this.innerWallMesh = null;

	this.wallColor = null;
	this.wallColorTexture = null;
	this.wallColorTextureFileName = null;

	this.wallTextureFileName = "";
	this.wallTexture = null;
	this.wallMater = null;

	this.innerWallTextureFileName = "";
	this.innerWallTexture = null;
	this.innerWallMater = null;

	this.selected = false;

	this.type = ELEM_WALL;

	this.horizLineGuide = new LineGuide(this, LineGuide.HORIZ_GUIDE);

	this.vertLineGuide = new LineGuide(this, LineGuide.VERT_GUIDE);

	this.style = Wall.CLOSED;

	this.sidingColorData = null;

	this.regenerate = true;

	this.Initialize = function ()
	{
		this.SetDimensions();
	};

	/**
	 * @method Wall.GetDesignXMLString
	 * @returns {string} XML string with wall object data
	 */
	this.GetDesignXMLString = function ()
	{
		let strXml = "<WALL wallID=\"WALL_CLOSED\"";

		let str = "";

		if (this.sidingCategoryData)
			str = AuxUtilities.JSONStringifyAndEncode(this.sidingCategoryData);

		strXml += " sidingCategoryData=\"" + str + "\"";

		if (this.sidingColorData)
			str = AuxUtilities.JSONStringifyAndEncode(this.sidingColorData);
		else
			str = "";

		strXml += " sidingColorData=\"" + str + "\"";

		strXml += "/>";

		return strXml;
	};

	/**
	 * Returns wall object for storage
	 * @method Wall.GetDesignObject
	 * @returns {Object} wall object
	 */
	this.GetDesignObject = function ()
	{
		let wall = {};
		wall.wallID = "WALL_CLOSED";
		wall.sidingCategoryData = this.sidingCategoryData;
		wall.sidingColorData = this.sidingColorData;
		return wall;
	};

	this.SetDimensions = function ()
	{
		switch (this.eWall)
		{
		case (WALL_FRONT):
			this.length = buildingDesigner.building.length;
			this.height = buildingDesigner.building.height;
			break;

		case (WALL_BACK):
			this.length = buildingDesigner.building.length;
			this.height = buildingDesigner.building.backWallHeight;
			break;

		case (WALL_LEFT):
		case (WALL_RIGHT):
			this.length = buildingDesigner.building.roofRafter.wallWidth + buildingDesigner.building.roofRafter.frontVisorWidth + buildingDesigner.building.roofRafter.rearVisorWidth;

			let hipRoof = Elements.GetElementsOfType(ELEM_HIP_ROOF);

			if (hipRoof)
				this.height = buildingDesigner.building.height;
			else
				this.height = buildingDesigner.building.height + buildingDesigner.building.roofRafter.roofHeight;
			break;
		}
	};

	this.SetStyle = function (style)
	{
		this.style = style;
	};

	this.SetWallSidingData = async function (data, sidingCategoryData, renderNow)
	{
		if (typeof renderNow === "undefined")
		{
			renderNow = true;
		}
		/* This was incorrect, it was setting each wall to the total building siding price -- moved this to walls.js -- to set the price on the walls object instead of each walls object
		if (BuildingDesigner.buildingType != BUILDING_CARPORT)
		{
			let sidingPrice = await Walls.GetSidingPrice(buildingDesigner.building.sizeData.product_id, data.category_id);
			this.SetPrice(sidingPrice);
		}
		*/
		if (!sidingCategoryData)
			sidingCategoryData = GuiDataUtilities.GetSidingCategoryButtonData(data.category_id);

		if (sidingCategoryData.profile_points[0] == "[")
			sidingCategoryData.profile_points = JSON.parse(sidingCategoryData.profile_points);

		if (sidingCategoryData.profile_texture_coordinates[0] == "[")
			sidingCategoryData.profile_texture_coordinates = JSON.parse(sidingCategoryData.profile_texture_coordinates);

		this.SetSidingCategoryData(sidingCategoryData);

		await this.SetSidingColorData(data, renderNow);

		if (this.eWall == WALL_FRONT && buildingDesigner.building.dormer)
		{
			buildingDesigner.building.dormer.SetSidingCategoryData(sidingCategoryData);
			buildingDesigner.building.dormer.SetSidingColorData(data);
		}

		GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.IDLE;

		if (buildingDesigner.building.initialized && renderNow)
		{
			buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
			buildingDesigner.building.SetBuildingModified();
		}

		return true;
	};

	this.SetSidingCategoryData = function (data)
	{
		this.sidingCategoryData = data;
	};

	this.SetSidingColorData = async function (data, renderNow)
	{
		if (typeof renderNow === "undefined")
		{
			renderNow = true;
		}
		this.sidingColorData = data;
		buildingDesigner.building.walls.sidingColorData = data;

		this.SetCategoryID(this.sidingColorData.category_id);

		if (BuildingDesigner.buildingType != BUILDING_CARPORT)
		{
			let sidingPrice = await Walls.GetSidingPrice(buildingDesigner.building.sizeData.product_id, this.sidingColorData.category_id);
			this.SetPrice(sidingPrice);
		}

		this.SetColorID(this.sidingColorData.color_id);

		if (buildingDesigner.building.initialized && renderNow)
		{
			buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
			buildingDesigner.building.SetBuildingModified();
		}
	};

	this.SetPrice = function (price)
	{
		this.price = price;
	};

	this.SetSidingPrice = function (price)
	{
		this.sidingPrice = price;
	};

	this.SetCategoryID = function (categoryID)
	{
		this.categoryID = categoryID;
	};

	this.SetColorID = function (colorID)
	{
		this.colorID = colorID;

		let colorData = ColorsDataUtilities.FindColor(this.colorID);

		if (colorData)
		{
			if (colorData.color_texture_file)
			{
				this.wallColorTextureFileName = colorData.color_texture_file;
				this.wallColor = null;
			}
			else
			{
				this.wallColor = colorData.color;
				this.wallColorTextureFileName = null;
			}
		}
		else
		{
			this.wallColor = null;
		}
	};

	this.SetSelected = function (selected)
	{
		this.selected = selected;
	};

	this.GetTextures = function ()
	{
		if (this.sidingCategoryData && this.sidingCategoryData.texture_name != "")
		{
			if (this.wallColorTextureFileName)
			{
				this.wallTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.wallColorTextureFileName, -1, -1);
			}
			else
			{
				this.wallTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.sidingCategoryData.texture_name, -1, -1);
			}
		}

		if (this.sidingCategoryData && this.sidingCategoryData.texture_name_interior != "")
		{
			this.innerWallTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.sidingCategoryData.texture_name_interior, this.length, this.height);
		}
	};

	this.SetWallTextureName = function (fileName)
	{
		this.sidingCategoryData.texture_name = fileName;
	};

	this.SetInnerWallTextureName = function (fileName)
	{
		this.innerWallTextureName = fileName;
	};

	this.SetMouseOverTransparency = function (opacity)
	{};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.CreateCrossSectionFromProfile = function (useSurfaceAsBase)
	{
		let referencePoints = [];

		referencePoints.push([0, 0]);
		referencePoints.push([this.sidingCategoryData.vertical_siding ? this.length * 2 : this.height * 2, 0]);

		let newProfilePts = ProfileUtilities.Increaselength(this.sidingCategoryData.profile_points, this.sidingCategoryData.vertical_siding ? this.length * 2 : this.height * 2);

		newProfilePts = ProfileUtilities.AddTextureCoordinates(newProfilePts, this.sidingCategoryData.profile_texture_coordinates);

		let frontTilePoints = GeometryUtilities.GetSurfacePointsUsingProfile(referencePoints, 0, referencePoints.length - 1, 0.0001, Roof.ANGLED_TRIM, false, newProfilePts, this.sidingCategoryData.flat_base, Wall.METALTHICKNESS);

		return frontTilePoints;
	};

	this.CreateSidingFromProfile = function (material)
	{
		let points = this.CreateCrossSectionFromProfile(true);

		let extrudeSettings = {
			depth: this.sidingCategoryData.vertical_siding ? this.height * 2 : this.length * 2,
			steps: 1,
			material: 1,
			extrudeMaterial: 0,
			bevelEnabled: false,
		};

		let mesh = MeshUtilities.CreateMeshFromCrossSectionPoints(points, points, material, extrudeSettings, 0, 0, 0, false);

		if (this.sidingCategoryData.vertical_siding)
			mesh = this.VerticallyOrientateMesh(mesh, this.eWall, Wall.OUTER_WALLTHICKNESS);
		else
			mesh = this.HorizontallyOrientateMesh(mesh, this.eWall, Wall.OUTER_WALLTHICKNESS);

		return mesh;
	};

	this.HorizontallyOrientateMesh = function (mesh, eWall, thickness)
	{
		switch (eWall)
		{
		case (WALL_FRONT):
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(MathUtilities.PI2));
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationZ(MathUtilities.PI2));

			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-this.wallCenter, 0, 0));
			break;

		case (WALL_BACK):
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(MathUtilities.PI2));
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationZ(MathUtilities.PI2));
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(-MathUtilities.PI));

			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(this.length - this.wallCenter, 0, 0));
			break;

		case (WALL_LEFT):
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(MathUtilities.PI2));
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationZ(MathUtilities.PI2));
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(-MathUtilities.PI));

			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(this.length - this.wallCenter, 0, 0));
			break;

		case (WALL_RIGHT):
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(MathUtilities.PI2));

			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationZ(MathUtilities.PI2));

			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-this.wallCenter, 0, 0));
			break;
		}

		return mesh;
	};

	this.VerticallyOrientateMesh = function (mesh, eWall, thickness)
	{
		switch (eWall)
		{
		case (WALL_FRONT):
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(-MathUtilities.PI2));
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(-MathUtilities.PI));

			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(this.length - this.wallCenter, 0, 0));
			break;

		case (WALL_BACK):
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(-MathUtilities.PI2));

			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-this.wallCenter, 0, 0));
			break;

		case (WALL_LEFT):
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(-MathUtilities.PI2));

			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-this.wallCenter, 0, 0));
			break;

		case (WALL_RIGHT):
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(-MathUtilities.PI2));
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(MathUtilities.PI));

			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(this.length - this.wallCenter, 0, 0));
			break;
		}

		return mesh;
	};

	this.GetTransformationMatrixForWallPositionAndAngle = function(eWall, coord, angle)
	{
		this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(coord.x, coord.y, coord.z), new THREE.Matrix4().makeRotationY(-angle));

		switch (this.eWall)
		{
		case (WALL_FRONT):
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - innerWallThickness, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2)), this.matrix);
			break;

		case (WALL_BACK):
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + innerWallThickness, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2)), this.matrix);
			break;

		case (WALL_LEFT):
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0.0, 0.0, -buildingDesigner.building.length / 2 + outerWallThickness), this.matrix);
			break;

		case (WALL_RIGHT):
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0.0, 0.0, buildingDesigner.building.length / 2 - outerWallThickness), this.matrix);
			break;
		}

		return this.matrix;
	}


	this.CreateWallFacet = function (wallsPts, wallsPtsForElements, outerWallThickness, innerWallThickness, coord = new THREE.Vector3(0, 0, 0), angle = 0)
	{
		if (!coord)
			coord = new THREE.Vector3(0, 0, 0);

		let wallFacet = new Object();

		let shapeWall = new THREE.Shape(wallsPts);

		let wallContainerThickness = outerWallThickness * 20;

		let wallGeom = new THREE.ExtrudeGeometry(shapeWall, {
			depth: outerWallThickness * 20,
			bevelEnabled: false
		});

		wallGeom.scale(1.0005, 1, 1);

		TexturesDataUtilities.AssignUVsToGeometryXY(wallGeom);

		wallGeom.matrixAutoUpdate = false;
		wallGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -wallContainerThickness / 2));

		this.mesh = new THREE.Mesh(wallGeom, this.wallMater);

		let siding = this.CreateSidingFromProfile(this.wallMater);

		this.mesh = MeshUtilities.IntersectMesh(this.mesh, siding);

		wallGeom = this.mesh.geometry;


		if (buildingDesigner.building.metalFraming)
		{
			if (this.wallMater.length > 1)
			{
				for (i = 0; i < wallGeom.faces.length; i++)
				{
					if (wallGeom.faces[i].normal.z > 0)
					{
						if (this.eWall == WALL_FRONT || this.eWall == WALL_RIGHT)
							wallGeom.faces[i].materialIndex = 0;
						else
							wallGeom.faces[i].materialIndex = 1;
					}
					else
					{
						if (this.eWall == WALL_FRONT || this.eWall == WALL_RIGHT)
							wallGeom.faces[i].materialIndex = 1;
						else
							wallGeom.faces[i].materialIndex = 0;
					}
				}
			}
		}


		switch (this.eWall)
		{
		case (WALL_FRONT):
			break;

		case (WALL_BACK):
			coord.z *= -1;
			break;

		case (WALL_LEFT):
			coord.z *= -1;
			break;

		case (WALL_RIGHT):
			break;
		}

		this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(coord.x, coord.y, coord.z), new THREE.Matrix4().makeRotationY(-angle));

		switch (this.eWall)
		{
		case (WALL_FRONT):
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - innerWallThickness, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2)), this.matrix);
			break;

		case (WALL_BACK):
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + innerWallThickness, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2)), this.matrix);
			break;

		case (WALL_LEFT):
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0.0, 0.0, -buildingDesigner.building.length / 2 + outerWallThickness), this.matrix);
			break;

		case (WALL_RIGHT):
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0.0, 0.0, buildingDesigner.building.length / 2 - outerWallThickness), this.matrix);
			break;
		}

		wallGeom.matrixAutoUpdate = false;
		wallGeom.applyMatrix4(this.matrix);


		this.mesh = new THREE.Mesh(wallGeom, this.wallMater);

		this.mesh.type = ELEM_WALL;
		this.mesh.wallFacetIndex = this.wallFacets.length;

		MeshUtilities.SetElement(this.mesh, this);

		this.mesh.castShadow = true;
		this.mesh.receiveShadow = true;

		this.mesh.minUV = GeometryUtilities.GetMinUVs(wallGeom);
		this.mesh.maxUV = GeometryUtilities.GetMaxUVs(wallGeom);

		this.mesh.castShadow = true;
		this.mesh.receiveShadow = true;

		wallFacet.outerMesh = this.mesh;

		if (!buildingDesigner.building.metalFraming)
		{
			//inner wall
			wallGeom = new THREE.ExtrudeGeometry(shapeWall, {
				depth: innerWallThickness,
				bevelEnabled: false
			});

			TexturesDataUtilities.AssignUVsToGeometryXY(wallGeom);

			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(coord.x, coord.y, coord.z), new THREE.Matrix4().makeRotationY(-angle));

			switch (this.eWall)
			{
			case (WALL_FRONT):
				this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2)), this.matrix);
				break;

			case (WALL_BACK):
				this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + innerWallThickness, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2)), this.matrix);
				break;

			case (WALL_LEFT):
				this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0.0, 0.0, -buildingDesigner.building.length / 2 + outerWallThickness), this.matrix);
				break;

			case (WALL_RIGHT):
				this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0.0, 0.0, buildingDesigner.building.length / 2 - Wall.WALLTHICKNESS), this.matrix);
				break;
			}

			wallGeom.matrixAutoUpdate = false;
			wallGeom.applyMatrix4(this.matrix);

			this.innerWallMater = new THREE.MeshStandardMaterial({
				color: 0xFFFFFF,
				map: TexturesDataUtilities.TextureLoaded(this.innerWallTexture),
				roughness: 1.0,
				metalness: METALNESS
			});

			this.innerWallMesh = new THREE.Mesh(wallGeom, this.innerWallMater);

			this.innerWallMesh.wallFacetIndex = this.wallFacets.length;

			MeshUtilities.SetElement(this.innerWallMesh, this);

			wallFacet.innerMesh = this.innerWallMesh;
		}
		else
		{
			wallFacet.innerMesh = null;
		}

		wallFacet.wallsPtsForElements = wallsPtsForElements;

		wallFacet.zOffset = 0;
		wallFacet.coord = coord;

		wallFacet.matrix = this.matrix;

		return wallFacet;
	};

	this.Generate = function(buildingMeshes)
	{
		if (this.regenerate)
		{
			let outerWallThickness = Wall.OUTER_WALLTHICKNESS;
			let innerWallThickness = Wall.INNER_WALLTHICKNESS;

			let hipRoof = Elements.GetElementsOfType(ELEM_HIP_ROOF);

			this.GetTextures();

			if (this.wallColor == null)
				this.SetColorID(this.colorID);


			this.wallFacets = [];

			this.wallFraming = [];

			if (buildingDesigner.building.metalFraming)
			{
				let materials = [];

				materials.push(new THREE.MeshPhongMaterial({
					color: this.wallColor,
					specular: 0x080808,
					shininess: 100,
					map: this.wallTexture
				}));

				materials.push(new THREE.MeshPhongMaterial({
					color: Wall.METAL_WALL_INTERIOR_COLOR,
					specular: 0x080808,
					shininess: 100,
					map: null
				}));

				this.wallMater = materials;
			}
			else
			{
				// This is the outside siding panel texture
				this.wallMater = new THREE.MeshStandardMaterial({
					color: this.wallColor,
					map: TexturesDataUtilities.TextureLoaded(this.wallTexture),
					roughness: 1.0,
					metalness: METALNESS
				});
			}

			let tw2 = buildingDesigner.building.roofRafter.wallWidth / 2 + Wall.WALLTHICKNESS;
			let tl2 = buildingDesigner.building.length / 2 - Wall.WALLTHICKNESS;

			let roofRafterSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[1][1] - buildingDesigner.building.roofRafter.data.rafter_spec[0][1];

			let roofRafterFrontSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[0][1]][1] - buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[0][0]][1];
			let roofRafterBackSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[1][1]][1] - buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[1][0]][1];

			let connectionHeight = Math.tan(buildingDesigner.building.roofRafter.data.wall_roof_connection_angle * MathUtilities.RADIAN) * buildingDesigner.building.roofRafter.frontVisorWidth;

			if (connectionHeight > 0 && buildingDesigner.building.roofRafter.data.curved_wall_roof_connection)
				this.connectionCurvePoints = GeometryUtilities.GenerateCurve(buildingDesigner.building.roofRafter.frontVisorWidth, connectionHeight);

			switch (this.eWall)
			{
			case (WALL_FRONT):
				if (!buildingDesigner.building.dormer || !buildingDesigner.building.dormer.wall || !buildingDesigner.building.dormer.wall.mesh || (buildingDesigner.building.dormer.buttonData.elem_ID.toLowerCase().indexOf("shed") > -1))
				{
					this.wallsPts = [{
						x: buildingDesigner.building.walls.leftFrontWallCoord,
						y: 0
					},
					{
						x: buildingDesigner.building.walls.leftFrontWallCoord,
						y: buildingDesigner.building.height
					},
					{
						x: buildingDesigner.building.walls.rightFrontWallCoord,
						y: buildingDesigner.building.height
					},
					{
						x: buildingDesigner.building.walls.rightFrontWallCoord,
						y: 0
					},
					];
				}
				else
				{
					if (!buildingDesigner.building.dormer.wall.mesh.geometry.boundingBox)
						buildingDesigner.building.dormer.wall.mesh.geometry.computeBoundingBox();


					let size = new THREE.Vector3();

					size = buildingDesigner.building.dormer.wall.mesh.geometry.boundingBox.getSize(size);

					let dormerXOffset = buildingDesigner.building.rafters.thickness/size.y * (size.x/2);

					size.y -= buildingDesigner.building.rafters.thickness;

					this.wallsPts = [{
						x: buildingDesigner.building.walls.leftFrontWallCoord,
						y: 0
					},
					{
						x: buildingDesigner.building.walls.leftFrontWallCoord,
						y: buildingDesigner.building.height
					},
					{
						x: -size.x / 2 + dormerXOffset,
						y: buildingDesigner.building.height
					},
					{
						x: 0,
						y: buildingDesigner.building.height + size.y
					},
					{
						x: size.x / 2 - dormerXOffset,
						y: buildingDesigner.building.height
					},
					{
						x: buildingDesigner.building.walls.rightFrontWallCoord,
						y: buildingDesigner.building.height
					},
					{
						x: buildingDesigner.building.walls.rightFrontWallCoord,
						y: 0
					},
					];
				}

				this.wallCenter = this.length / 2;

				this.wallsPtsForElements = this.wallsPts;

				this.vecWallExts = [{
					x: -tl2,
					y: 0.0
				}, {
					x: tl2,
					y: this.height
				}];
				break;

			case (WALL_BACK):
				this.wallsPts = [{
					x: buildingDesigner.building.walls.leftBackWallCoord,
					y: 0
				},
				{
					x: buildingDesigner.building.walls.leftBackWallCoord,
					y: buildingDesigner.building.backWallHeight
				},
				{
					x: buildingDesigner.building.walls.rightBackWallCoord,
					y: buildingDesigner.building.backWallHeight
				},
				{
					x: buildingDesigner.building.walls.rightBackWallCoord,
					y: 0
				},
				];

				this.wallCenter = this.length / 2;

				this.wallsPtsForElements = this.wallsPts;

				this.vecWallExts = [{
					x: tl2,
					y: 0.0
				}, {
					x: -tl2,
					y: this.height
				}];
				break;

			case (WALL_LEFT):
			case (WALL_RIGHT):
				if (buildingDesigner.building.roofRafter.data.front_wall_attach_coord != "")
				{
					if (!buildingDesigner.building.roofRafter.leanToRafter)
						frontRafteroffsetx = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0];
					else
						frontRafteroffsetx = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0] - buildingDesigner.building.roofRafter.data.width;
				}

				if (hipRoof)
				{
					this.wallsPts = [{
						x: -tw2,
						y: 0
					},
					{
						x: -tw2,
						y: buildingDesigner.building.height
					},
					{
						x: tw2,
						y: buildingDesigner.building.height
					},
					{
						x: tw2,
						y: 0
					},
					];

					this.wallsPtsForElements = this.wallsPts;

					this.vecWallExts = [{
						x: -this.length / 2,
						y: 0.0
					}, {
						x: this.length / 2,
						y: this.height
					}];
				}
				else
				{
					let offsetY;

					if (buildingDesigner.building.roofRafter.data.bent_bow)
						offsetY = buildingDesigner.building.roof.frontVisorHeightFromFloor - buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1];
					else
						offsetY = buildingDesigner.building.roof.frontVisorHeightFromFloor;

					let wallRoofPoints = Wall.GetWallRoofPoints(buildingDesigner.building.roofRafter.data.rafter_spec, buildingDesigner.building.roofRafter.sideCoordsIndices[0][0], buildingDesigner.building.roofRafter.sideCoordsIndices[1][0], -buildingDesigner.building.roofRafter.wallWidth / 2 - frontRafteroffsetx, offsetY);

					this.wallsPts = [];
					this.wallsPtsForElements = [];

					tw2 -= (outerWallThickness - 0.02);

					if (buildingDesigner.building.porch && ((this.eWall == WALL_RIGHT && buildingDesigner.building.porch.rightSide) || (this.eWall == WALL_LEFT && !buildingDesigner.building.porch.rightSide)))
					{
						if ((this.eWall == WALL_RIGHT || this.eWall == WALL_LEFT) && buildingDesigner.building.porch.fullLength)
						{
							//
						}
						else
						if (buildingDesigner.building.porch.length < 0)
							this.wallsPts.push({
								x: -tw2 - buildingDesigner.building.porch.length + Wall.WALLTHICKNESS,
								y: 0
							});
						else
							this.wallsPts.push({
								x: -tw2,
								y: 0
							});
					}
					else
						this.wallsPts.push({
							x: -tw2,
							y: 0
						});

					if (buildingDesigner.building.porch)
						this.wallsPtsForElements.push({
							x: -tw2,
							y: 0
						});
					else
						this.wallsPtsForElements.push(this.wallsPts[this.wallsPts.length - 1]);

					if (!buildingDesigner.building.roofRafter.leanToRafter)
					{
						if (buildingDesigner.building.porch && this.eWall == WALL_RIGHT && buildingDesigner.building.porch.fullLength)
						{
							this.wallsPtsForElements.push({
								x: -tw2,
								y: buildingDesigner.building.height
							});
						}
						else
						if (buildingDesigner.building.porch && ((this.eWall == WALL_RIGHT && buildingDesigner.building.porch.rightSide) || (this.eWall == WALL_LEFT && !buildingDesigner.building.porch.rightSide)))
						{
							if (buildingDesigner.building.porch.length < 0)
							{
								this.wallsPtsForElements.push({
									x: -tw2,
									y: buildingDesigner.building.roof.frontVisorHeightFromFloor
								});
							}
							else
								this.wallsPtsForElements.push({
									x: -tw2,
									y: buildingDesigner.building.roof.frontVisorHeightFromFloor
								});
						}
						else
							this.wallsPtsForElements.push({
								x: -tw2,
								y: buildingDesigner.building.roof.frontVisorHeightFromFloor
							});
					}
					else
						this.wallsPtsForElements.push({
							x: -tw2,
							y: buildingDesigner.building.height
						});


					if (connectionHeight > 0 && buildingDesigner.building.roofRafter.data.curved_wall_roof_connection)
					{
						this.connectionCurvePoints = GeometryUtilities.TranslatePoints(this.connectionCurvePoints, -tw2 - buildingDesigner.building.roofRafter.frontVisorWidth, buildingDesigner.building.roof.frontVisorHeightFromFloor - connectionHeight);

						for (let i = 0; i < this.connectionCurvePoints.length; i++)
						{
							this.wallsPts.push({
								x: this.connectionCurvePoints[i][0],
								y: this.connectionCurvePoints[i][1]
							});
						}
					}
					else
					{
						if (!buildingDesigner.building.roofRafter.leanToRafter)
						{
							if (buildingDesigner.building.porch && ((this.eWall == WALL_RIGHT && buildingDesigner.building.porch.rightSide) || (this.eWall == WALL_LEFT && !buildingDesigner.building.porch.rightSide)) && buildingDesigner.building.porch.fullLength)
							{
								//
							}
							else
							if (buildingDesigner.building.porch && ((this.eWall == WALL_RIGHT && buildingDesigner.building.porch.rightSide) || (this.eWall == WALL_LEFT && !buildingDesigner.building.porch.rightSide)))
							{
								if (buildingDesigner.building.porch.length < 0)
									this.wallsPts.push({
										x: -tw2 - buildingDesigner.building.porch.length + Wall.WALLTHICKNESS,
										y: buildingDesigner.building.roof.frontVisorHeightFromFloor - connectionHeight
									});
								else
									this.wallsPts.push({
										x: -tw2,
										y: buildingDesigner.building.roof.frontVisorHeightFromFloor - connectionHeight
									});
							}
							else
								this.wallsPts.push({
									x: -tw2,
									y: buildingDesigner.building.roof.frontVisorHeightFromFloor - connectionHeight
								});
						}
						else
							this.wallsPts.push({
								x: -tw2,
								y: buildingDesigner.building.height - connectionHeight
							});
					}

					for (let i = 0; i < wallRoofPoints.length; i++)
					{
						this.wallsPts.push({
							x: wallRoofPoints[i][0],
							y: wallRoofPoints[i][1]
						});

						if (wallRoofPoints[i][0] > -tw2 && wallRoofPoints[i][0] < tw2)
							this.wallsPtsForElements.push({
								x: wallRoofPoints[i][0],
								y: wallRoofPoints[i][1]
							});
					}

					if (buildingDesigner.building.porch && ((this.eWall == WALL_RIGHT && buildingDesigner.building.porch.rightSide) || (this.eWall == WALL_LEFT && !buildingDesigner.building.porch.rightSide)))
					{
						if (buildingDesigner.building.porch.length > 0 && (!buildingDesigner.building.porch.fullLength))
							this.wallsPts.push({
								x: tw2 - buildingDesigner.building.porch.length - Wall.WALLTHICKNESS,
								y: buildingDesigner.building.backWallHeight < buildingDesigner.building.roof.rearVisorHeightFromFloor ? buildingDesigner.building.backWallHeight : buildingDesigner.building.roof.rearVisorHeightFromFloor
							});
						else
							this.wallsPts.push({
								x: tw2,
								y: buildingDesigner.building.backWallHeight < buildingDesigner.building.roof.rearVisorHeightFromFloor ? buildingDesigner.building.backWallHeight : buildingDesigner.building.roof.rearVisorHeightFromFloor
							});
					}
					else
						this.wallsPts.push({
							x: tw2,
							y: buildingDesigner.building.backWallHeight < buildingDesigner.building.roof.rearVisorHeightFromFloor ? buildingDesigner.building.backWallHeight : buildingDesigner.building.roof.rearVisorHeightFromFloor
						});


					this.wallsPtsForElements.push({
						x: tw2,
						y: buildingDesigner.building.backWallHeight
					});

					if (buildingDesigner.building.porch && ((this.eWall == WALL_RIGHT && buildingDesigner.building.porch.rightSide) || (this.eWall == WALL_LEFT && !buildingDesigner.building.porch.rightSide)))
					{
						if (buildingDesigner.building.porch.fullLength)
						{
							//
						}
						else
						if (buildingDesigner.building.porch.length > 0 && (!buildingDesigner.building.porch.fullLength))
							this.wallsPts.push({
								x: tw2 - buildingDesigner.building.porch.length - Wall.WALLTHICKNESS,
								y: 0
							});
						else
							this.wallsPts.push({
								x: tw2,
								y: 0
							});
					}
					else
						this.wallsPts.push({
							x: tw2,
							y: 0
						});

					this.wallsPtsForElements.push(this.wallsPts[this.wallsPts.length - 1]);

					if (this.eWall == WALL_RIGHT)
						this.vecWallExts = [{
							x: -tw2,
							y: 0.0
						}, {
							x: tw2,
							y: buildingDesigner.building.height + buildingDesigner.building.roofRafter.roofHeight
						}];
					else
						this.vecWallExts = [{
							x: tw2,
							y: 0.0
						}, {
							x: -tw2,
							y: buildingDesigner.building.height + buildingDesigner.building.roofRafter.roofHeight
						}];
				}

				this.wallCenter = buildingDesigner.building.roofRafter.frontVisorWidth + buildingDesigner.building.roofRafter.wallWidth / 2;

				break;
			}

			this.wallFacets.push(this.CreateWallFacet(this.wallsPts, this.wallsPtsForElements, outerWallThickness, innerWallThickness));////, new THREE.Vector3(0, 0, 0)));

			if (buildingDesigner.building.porch)
			{
				for (let i = 0; i<buildingDesigner.building.porch.porchWallSpecifications.length; i++)
				{
					if (this.eWall == buildingDesigner.building.porch.porchWallSpecifications[i].eWall)
					{
						this.wallsPts =
								[
									{
										x: -buildingDesigner.building.porch.porchWallSpecifications[i].width/2,
										y: 0
									},
									{
										x: -buildingDesigner.building.porch.porchWallSpecifications[i].width/2,
										y: buildingDesigner.building.height
									},
									{
										x: buildingDesigner.building.porch.porchWallSpecifications[i].width/2,
										y: buildingDesigner.building.height
									},
									{
										x: buildingDesigner.building.porch.porchWallSpecifications[i].width/2,
										y: 0
									},
								];

						this.wallFacets.push(this.CreateWallFacet(this.wallsPts, this.wallsPts, outerWallThickness, innerWallThickness, buildingDesigner.building.porch.porchWallSpecifications[i].coord.clone(), buildingDesigner.building.porch.porchWallSpecifications[i].angle));
					}
				}
			}

			for (let i = 0; i < this.wallFacets.length; i++)
			{
				if (this.wallFacets[i].innerMesh)
				{
					// Interior surface of siding
					buildingMeshes.push(this.wallFacets[i].innerMesh);
				}

				// Exterior surface of siding
				buildingMeshes.push(this.wallFacets[i].outerMesh);
			}


			if (!buildingDesigner.building.lineGuides[this.eWall])
			{
				buildingDesigner.building.lineGuides[this.eWall] = {
					horiz: null,
					vert: null
				};

				buildingDesigner.building.lineGuides[this.eWall].horiz = this.horizLineGuide.Generate();
				buildingDesigner.building.lineGuides[this.eWall].vert = this.vertLineGuide.Generate();
			}

			this.regenerate = false;
		}
	};
}

Wall.GetWallRoofPoints = function (array, start, end, x, y)
{
	let surfacePoints = [];

	if (end > start)
	{
		for (let i = start; i <= end; i++)
			surfacePoints.push([array[i][0] + x, array[i][1] + y]);
	}
	else
	{
		for (let i = start; i >= end; i--)
			surfacePoints.push([array[i][0] + x, array[i][1] + y]);
	}

	return surfacePoints;
};

Wall.METAL_PROFILE_PTS = [
	[0, 0.01],
	[0.07421875, 0.01],
	[0.08203125, 0.015625],
	[0.08984375, 0.015625],
	[0.09765625, 0.01],
	[0.265625, 0.01],
	[0.3046875, 0.0625],
	[0.34375, 0.0625],
	[0.3828125, 0.01],
	[0.5546875, 0.01],
	[0.5625, 0.015625],
	[0.5703125, 0.015625],
	[0.578125, 0.01],
	[0.65234375, 0.01]
];

Wall.WALLTHICKNESS = 0.1;

Wall.OUTER_WALLTHICKNESS = Wall.WALLTHICKNESS * 0.95;
Wall.INNER_WALLTHICKNESS = Wall.WALLTHICKNESS * 0.05;

Wall.SelectedWallButtonData = null;

Wall.BB_BATTENWIDTH = 0.1458333;
Wall.BB_BOARDWIDTH = 0.625 + Wall.BB_BATTENWIDTH;
Wall.BB_BATTENTHICKNESS = 0.065416667;

Wall.LPSMARTSIDEPANELSECTIONWIDTH = 0.67;
Wall.LPSMARTSIDELAPSECTIONWIDTH = 0.57;
Wall.DUTCHVINYLSECTIONWIDTH = 0.34;

Wall.METALSIDINGSECTIONWIDTH = 0.75;

Wall.METALTHICKNESS = 0.01;

Wall.CLOSED = 0;

Wall.METAL_WALL_INTERIOR_COLOR = "rgb(255, 255, 255)";
