// admin-manageseriesobjects.js
/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1*/
/*eslint-disable no-console, no-unused-vars*/

function changeObjectSeries(clickedObject, sub_id, series_code) {
	if(DEBUG) console.log("fn: changeObjectSeries");
	//$(clickedObject).css("color","red");
	let rowID = $(clickedObject).parent().parent().prop("id");
	let objectID = $("#"+rowID).data("objectid");
	let objectType = $("#"+rowID).data("objecttype");
	let objectChecked = $(clickedObject).prop("checked");
	if(objectChecked) {
		objectAction = "add";
	} else {
		objectAction = "deactivate";
	}
	// alert("Retrieved ID: " + rowID + " - ObjectID: " + objectID + " - objectType: " + objectType + " - series_code: " + series_code + " - objectChecked: " + objectChecked);
	$.post("adminui?q=updateseriesobj&type="+objectType, {action: "updateseriesobject", subscriber_id: sub_id, objectaction: objectAction, objecttype: objectType, series_code: series_code, objectid: objectID}, function(data, status)
	{
		if(DEBUG) console.log(data);
		//$(clickedObject).css("color","green");
	});
}

function manageSeriesObjects(sub_id,seriesArray) {
	if(DEBUG) console.log("fn: manageSeriesObjects");
	$("#profile").hide();
	$("#subprofile").html("");
	$("#subprofile").show();
	$("#subprofile").append(`<div class='header'><i class='fas fa-arrow-alt-circle-left' onclick='ReturntoProfile()'></i><h1>${sub_id} Series Objects</h1></div>`);
	// object info
	let table_row = "";
	let seriesHeaderHTML = "";
	let seriesRow = "";
	for(let i=0;i<seriesArray.length; i++){
		seriesHeaderHTML += `<th>&nbsp;${seriesArray[i]}&nbsp;</th>`;
		seriesRow += `<td class="${seriesArray[i]}" style="text-align: center; color: blue;"><input type="checkbox" class="css-checkbox" onchange="changeObjectSeries(this,'${sub_id}','${seriesArray[i]}');"></td>`;
	}
	let subprofile_html = `
	Siding<br>
	<table border='2' id="seriesSidingList">
	<tr><th>ID</th>${seriesHeaderHTML}</tr>
	</table>
	<br>
	Roofing<br>
	<table border='2' id="seriesRoofingList">
	<tr><th> ID </th>${seriesHeaderHTML}</tr>
	</table>
	<br>
	Doors<br>
	<table border='2' id="seriesDoorList">
	<tr><th> ID </th>${seriesHeaderHTML}</tr>
	</table>
	<br>
	Hinges<br>
	<table border='2' id="seriesHingeList">
	<tr><th> ID </th>${seriesHeaderHTML}</tr>
	</table>
	<br>
	Windows<br>
	<table border='2' id="seriesWindowList">
	<tr><th> ID </th>${seriesHeaderHTML}</tr>
	</table>
	<br>
	Options<br>
	<table border='2' id="seriesOptionsList">
	<tr><th> ID </th>${seriesHeaderHTML}</tr>
	</table>
	<br>
	Shelves<br>
	<table border='2' id="seriesShelfList">
	<tr><th> ID </th>${seriesHeaderHTML}</tr>
	</table>
	<br>
	Siding Colors<br>
	<table border='2' id="seriesSidingColorList">
	<tr><th> ID </th>${seriesHeaderHTML}</tr>
	</table>
	<br>
	Roofing Colors<br>
	<table border='2' id="seriesRoofingColorList">
	<tr><th> ID </th>${seriesHeaderHTML}</tr>
	</table>
	<br>
	Trim Colors<br>
	<table border='2' id="seriesTrimColorList">
	<tr><th> ID </th>${seriesHeaderHTML}</tr>
	</table>
	<br>
	Door Colors<br>
	<table border='2' id="seriesDoorColorList">
	<tr><th> ID </th>${seriesHeaderHTML}</tr>
	</table>
	`;
	$("#subprofile").append(subprofile_html);

	$.post("adminui?q=siding", {loaddata: "getsubsiding", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_siding = JSON.parse(data);
		for (let i=0; i<sub_siding.length; i++)
		{
			let sdata = sub_siding[i];
			if($("#SM_"+sdata.category_id).length == 0) {
				$("#seriesSidingList").append(`<tr id="SM_${sdata.category_id}" data-objectid="${sdata.category_id}" data-objecttype="sidingtype" title="${sdata.display_name}"><td>&nbsp;${sdata.category_id}&nbsp;</td>${seriesRow}</tr>`);
				$("#SM_"+sdata.category_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
			else {
				$("#SM_"+sdata.category_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
		}
	});

	$.post("adminui?q=roofingcat", {loaddata: "getsubroofingcat", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_roofing = JSON.parse(data);
		for (let i=0; i<sub_roofing.length; i++)
		{
			let sdata = sub_roofing[i];
			if($("#SM_"+sdata.category_id).length == 0) {
				$("#seriesRoofingList").append(`<tr id="SM_${sdata.category_id}" data-objectid="${sdata.category_id}" data-objecttype="roofingtype" title="${sdata.category_name}"><td>&nbsp;${sdata.category_id}&nbsp;</td>${seriesRow}</tr>`);
				$("#SM_"+sdata.category_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
			else {
				$("#SM_"+sdata.category_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
		}
	});

	$.post("adminui?q=doors", {loaddata: "getsubdoors", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_doors = JSON.parse(data);
		for (let i=0; i<sub_doors.length; i++)
		{
			let sdata = sub_doors[i];
			if($("#SM_"+sdata.elem_id).length == 0) {
				$("#seriesDoorList").append(`<tr id="SM_${sdata.elem_id}" data-objectid="${sdata.elem_id}" data-objecttype="door" title="${sdata.element_name}"><td>&nbsp;${sdata.elem_id}&nbsp;</td>${seriesRow}</tr>`);
				$("#SM_"+sdata.elem_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
			else {
				$("#SM_"+sdata.elem_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
		}
	});

	$.post("adminui?q=hinges", {loaddata: "getsubhinges", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_hinges = JSON.parse(data);
		for (let i=0; i<sub_hinges.length; i++)
		{
			let sdata = sub_hinges[i];
			if($("#SM_"+sdata.elem_id).length == 0) {
				$("#seriesHingeList").append(`<tr id="SM_${sdata.elem_id}" data-objectid="${sdata.elem_id}" data-objecttype="hinge" title="${sdata.element_name}"><td>&nbsp;${sdata.elem_id}&nbsp;</td>${seriesRow}</tr>`);
				$("#SM_"+sdata.elem_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
			else {
				$("#SM_"+sdata.elem_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
		}
	});

	$.post("adminui?q=windows", {loaddata: "getsubwindows", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_windows = JSON.parse(data);
		for (let i=0; i<sub_windows.length; i++)
		{
			let sdata = sub_windows[i];
			if(sdata.active) {
				if($("#SM_"+sdata.elem_id).length == 0) {
					$("#seriesWindowList").append(`<tr id="SM_${sdata.elem_id}" data-objectid="${sdata.elem_id}" data-objecttype="window" title="${sdata.element_name}"><td>&nbsp;${sdata.elem_id}&nbsp;</td>${seriesRow}</tr>`);
					$("#SM_"+sdata.elem_id+" ."+sdata.series_code + " input").prop('checked', true);
				}
				else {
					$("#SM_"+sdata.elem_id+" ."+sdata.series_code + " input").prop('checked', true);
				}
			}
		}
	});

	$.post("adminui?q=options", {loaddata: "getsuboptions", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_options = JSON.parse(data);
		for (let i=0; i<sub_options.length; i++)
		{
			let sdata = sub_options[i];
			if($("#SM_"+sdata.elem_id).length == 0) {
				$("#seriesOptionsList").append(`<tr id="SM_${sdata.elem_id}" data-objectid="${sdata.elem_id}" data-objecttype="option" title="${sdata.element_name}"><td>&nbsp;${sdata.elem_id}&nbsp;</td>${seriesRow}</tr>`);
				$("#SM_"+sdata.elem_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
			else {
				$("#SM_"+sdata.elem_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
		}
	});

	$.post("adminui?q=shelves", {loaddata: "getsubshelves", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_shelves = JSON.parse(data);
		for (let i=0; i<sub_shelves.length; i++)
		{
			let sdata = sub_shelves[i];
			if($("#SM_"+sdata.elem_id).length == 0) {
				$("#seriesShelfList").append(`<tr id="SM_${sdata.elem_id}" data-objectid="${sdata.elem_id}" data-objecttype="shelf" title="${sdata.element_name}"><td>&nbsp;${sdata.elem_id}&nbsp;</td>${seriesRow}</tr>`);
				$("#SM_"+sdata.elem_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
			else {
				$("#SM_"+sdata.elem_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
		}
	});

	$.post("adminui?q=roofing", {loaddata: "getsubroofing", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_roofing = JSON.parse(data);
		for (let i=0; i<sub_roofing.length; i++)
		{
			let sdata = sub_roofing[i];
			if($("#SM_"+sdata.roofing_id).length == 0) {
				$("#seriesRoofingColorList").append(`<tr id="SM_${sdata.roofing_id}" data-objectid="${sdata.roofing_id}" data-objecttype="roofingcolor" title="${sdata.display_name}"><td>&nbsp;${sdata.roofing_id}&nbsp;</td>${seriesRow}</tr>`);
				$("#SM_"+sdata.roofing_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
			else {
				$("#SM_"+sdata.roofing_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
		}
	});

	$.post("adminui?q=sidingcolor", {loaddata: "getsubsidingcolors", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_siding = JSON.parse(data);
		for (let i=0; i<sub_siding.length; i++)
		{
			let sdata = sub_siding[i];
			if($("#SM_"+sdata.siding_id).length == 0) {
				$("#seriesSidingColorList").append(`<tr id="SM_${sdata.siding_id}" data-objectid="${sdata.siding_id}" data-objecttype="sidingcolor" title="${sdata.display_name}"><td>&nbsp;${sdata.siding_id}&nbsp;</td>${seriesRow}</tr>`);
				$("#SM_"+sdata.siding_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
			else {
				$("#SM_"+sdata.siding_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
		}
	});

	$.post("adminui?q=trimcolors", {loaddata: "getsubtrimcolors", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_trimcolors = JSON.parse(data);
		for (let i=0; i<sub_trimcolors.length; i++)
		{
			let sdata = sub_trimcolors[i];
			if($("#SM_"+sdata.color_id).length == 0) {
				$("#seriesTrimColorList").append(`<tr id="SM_${sdata.color_id}" data-objectid="${sdata.color_id}" data-objecttype="trimcolor" title="${sdata.color_name}"><td>&nbsp;${sdata.color_id}&nbsp;</td>${seriesRow}</tr>`);
				$("#SM_"+sdata.color_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
			else {
				$("#SM_"+sdata.color_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
		}
	});

	$.post("adminui?q=doorcolors", {loaddata: "getsubdoorcolors", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_doorcolors = JSON.parse(data);
		for (let i=0; i<sub_doorcolors.length; i++)
		{
			let sdata = sub_doorcolors[i];
			if($("#SM_"+sdata.color_id+"_"+sdata.color_id).length == 0) {
				$("#seriesDoorColorList").append(`<tr id="SM_${sdata.door_id}_${sdata.color_id}" data-objectid="${sdata.door_id}:${sdata.color_id}" data-objecttype="doorcolor" title="${sdata.color_name}"><td>&nbsp;${sdata.door_id} - ${sdata.color_id}&nbsp;</td>${seriesRow}</tr>`);
				$("#SM_"+sdata.door_id+"_"+sdata.color_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
			else {
				$("#SM_"+sdata.door_id+"_"+sdata.color_id+" ."+sdata.series_code + " input").prop('checked', true);
			}
		}
	});

}