/*eslint-env browser, es6, jquery*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape */
/* global Foundation, Login */

function checkForPostalCodeValid(element,required,parent) {
	if(!required) return true;
	if(!element[0].validitychecked) return true;
	if (UserDataUtilities.postal_code_data.country_code === "US") {
		if (element[0].value == UserDataUtilities.postal_code_data.zipcode) {
			return true;
		} else {
			if (element[0].isvalid) {
				return true;
			} else {
				return false;
			}
		}
	} else {
		if (element[0].value == UserDataUtilities.postal_code_data.postal_code) {
			return true;
		} else {
			if (element[0].isvalid) {
				return true;
			} else {
				return false;
			}
		}
	}

}

function linkMenuTabs() {
	$(".addclick").click(function () {
		if ($(".closeLeftMenu").is(":visible") && (window.tdf.if3MenuOpen === this.id))
		{
			if3CloseLeftMenu();
			window.tdf.if3MenuOpen = "";
		} else {
			window.tdf.if3MenuOpen = this.id;
			$(".leftSideMenu").css({
				"background-color": "#ffffff",
				"z-index": "3"
			});
			$(".leftSideMenu .nav_content").css({
				"transform": "translateX(0px)",
				"-webkit-transform": "translateX(0px)"
			});
			$(".closeLeftMenu").show();
			$(".frame_links").css({
				"position": "relative",
				"z-index": "1"
			});
		}
	}).removeClass("addclick");
}

Foundation.Abide.defaults.patterns['dashes_only'] = /^[0-9-]*$/;
Foundation.Abide.defaults.patterns['phone_number'] = /^\D?(\d{3})\D?\D?(\d{3})\D?(\d{4})$/;
Foundation.Abide.defaults.patterns['user_name'] = /[A-Za-z0-9]{5,}/;
Foundation.Abide.defaults.validators['postal_code'] = checkForPostalCodeValid;

$(document).foundation();

if (typeof tdf === "undefined") {
	window.tdf = {};
}
window.tdf.if3MenuOpen = "";

/*
$("#myTabs").on("toggled", function (event, tab) {
	//console.log(tab);
});
*/

/* Hide/Show Lefside Bar Menu */
$(".leftSideMenu .nav_content").css({
	"transform": "translateX(-100vw)",
	"-webkit-transform": "translateX(-100vw)"
});
$(".frame_links").css({
	"position": "relative",
	"z-index": "10"
});
/* $(".setting_gear .gear_btn").click(function(){
$('.leftSideMenu').show();
$('.leftSideMenu').css({"transform": "translateX(0%)", "-webkit-transform": "translateX(0%)"});
}); */

$(".closeLeftMenu").hide();
linkMenuTabs();

function if3CloseLeftMenu () {
	$(".leftSideMenu .nav_content").css({
		"transform": "translateX(-100vw)",
		"-webkit-transform": "translateX(-100vw)"
	});
	$(".leftSideMenu").css({
		"background-color": "transparent",
		"z-index": "1"
	});
	$(".closeLeftMenu").hide();
	$(".frame_links").css({
		"position": "relative",
		"z-index": "10"
	});
}

$(".closepopup").click(function() { if3CloseLeftMenu(); });

/* End Hide/Show Lefside Bar Menu */

/* */

function initForms() {
	let showClass = 'show';

	$('.flinput').off('checkval').off('keyup').on('checkval', function () {
		var label = $(this).prev('label');
		if(this.value !== '') {
			label.addClass(showClass);
		} else {
			label.removeClass(showClass);
		}
	}).on('keyup', function () {
		$(this).trigger('checkval');
	});
}

$(initForms());

/*$(function () {
	let showClass = 'show';

	$('.flinput').on('checkval', function () {
		var label = $(this).prev('label');
		if(this.value !== '') {
			label.addClass(showClass);
		} else {
			label.removeClass(showClass);
		}
	}).on('keyup', function () {
		$(this).trigger('checkval');
	});
}); */

// form validation failed
/* $(document).on("forminvalid.zf.abide", function(ev,frm) {
	console.log("Form id "+ev.target.id+" is invalid");
}); */

// to prevent form from submitting upon successful validation
$(document).on("submit", function(ev) {
	if (ev.target.id === "contactForm") {
		ev.preventDefault();
		Login.contactForm();
		return;
	}
	if (ev.target.id === "finalQuoteForm") {
		ev.preventDefault();
		Login.finalQuoteForm();
		return;
	}
	if (ev.target.id === "purchaseForm") {
		ev.preventDefault();
		Login.purchaseForm();
		return;
	}
	if (ev.target.id === "purchaseBillingForm") {
		ev.preventDefault();
		Login.purchaseBillingForm();
		return;
	}
	if (ev.target.id === "leaseBillingForm") {
		ev.preventDefault();
		Login.leaseBillingForm();
		return;
	}
	if (ev.target.id === "registrationForm") {
		ev.preventDefault();
		Register.Register();
		return;
	}
	if (ev.target.id.substr(0,5) === "admin") {
		ev.preventDefault();
		AdminUtilities.ProcessForm(ev.target.id);
		return;
	}

	// console.log("Submit for form id "+ev.target.id+" intercepted");
});
/*
$(document).ready(function() {
	$('#elementsList').select2();
}); */

function switchSeries(element) {
	let sc = AuxUtilities.GetURLParameter("sc");
	if (sc) {
		window.location.href = window.location.origin + "/?sc=" + SubscriberDataUtilities.subscriber + "&series=" + element.value;
	} else {
		window.location.href = window.location.origin + "/?series=" + element.value;
	}
}

function startDictation(element) {

	if (window.hasOwnProperty('webkitSpeechRecognition')) {

		var recognition = new webkitSpeechRecognition();

		recognition.continuous = false;
		recognition.interimResults = false;

		recognition.lang = "en-US";
		$(element).addClass("activemic");
		recognition.start();

		recognition.onresult = function (e) {
			let transcript = e.results[0][0].transcript;
			let current_text = $(".activemic").siblings(".flinput").val();
			if (current_text.length > 0) {
				let element = $(".activemic").siblings(".flinput")[0];
				let sStart = element.selectionStart;
				let sEnd = element.selectionEnd;
				let before = current_text.substring(0, sStart);
				let after = current_text.substring(sEnd, current_text.length);
				$(".activemic").siblings(".flinput").val(before + transcript + after);
			} else {
				$(".activemic").siblings(".flinput").val(transcript);
			}
			recognition.stop();
			$(".activemic").removeClass("activemic");
		};

		recognition.onerror = function (e) {
			recognition.stop();
			$(".activemic").removeClass("activemic");
		}

	}
}

if ((!(window.hasOwnProperty('webkitSpeechRecognition'))) || AuxUtilities.IsMobile()) {
	$(".letstalk").hide();
}
