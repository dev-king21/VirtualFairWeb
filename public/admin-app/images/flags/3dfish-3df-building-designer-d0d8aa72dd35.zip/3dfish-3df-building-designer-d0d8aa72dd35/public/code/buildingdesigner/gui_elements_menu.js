/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/
function ElementsMenu()
{}

ElementsMenu.ShowRoofing = function ()
{
	if (BuildingDesigner.buildingType == BUILDING_HORSEBARN)
	{
		buildingDesigner.building.SetShowRoof(true);

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		buildingDesigner.Draw();
	}
};

ElementsMenu.TabHowto = function (event)
{

};

ElementsMenu.TabBuildings = function (event)
{};

ElementsMenu.TabWalls = function (event)
{};

ElementsMenu.TabDoors = function (event)
{};

ElementsMenu.TabHinges = function (event)
{};

ElementsMenu.TabDoorColors = function (event)
{
	////ElementsMenu.GenerateDoorColorsTab();
};

ElementsMenu.TabDoorCategories = function (event)
{};

ElementsMenu.TabWindows = function (event)
{};

ElementsMenu.TabOptions = function (event)
{};

ElementsMenu.TabShelves = function (event)
{};

ElementsMenu.TabSiding = function (event)
{};

ElementsMenu.TabRoofing = function (event)
{
	ElementsMenu.ShowRoofing();
};

ElementsMenu.TabDormers = function (event)
{};

ElementsMenu.TabTrimColors = function (event)
{

};

ElementsMenu.TabPartitions = function (event)
{
	GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.SET_PARTITION;

	buildingDesigner.building.SetShowRoof(false);

	buildingDesigner.camera.SetPartitionsPositionAndOrientation();

	buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
	buildingDesigner.InitializeCameraAndRender();
};

ElementsMenu.TabStalls = function (event)
{};

ElementsMenu.TabSizesButton = function (event)
{};

ElementsMenu.TabMyShed = function (event)
{};

ElementsMenu.TabPricing = function (event)
{};

ElementsMenu.TabOrder = function (event)
{};

ElementsMenu.TabFiles = function (event)
{
	let buildingDescription = document.getElementById("buildingDescription");

	buildingDescription.innerHTML = buildingDesigner.building.ID + " buildings" + " of " + buildingDesigner.building.sizeData.width_display + " foot width and for the " + SubscriberDataUtilities.subscriber + " Subscriber";
};

ElementsMenu.SetAvailableSiding = function (buildingData)
{
	if (!buildingData)
	{
		buildingData = buildingDesigner.building;
	}
	$(".btntype3").show().removeClass("unavailable");
	if (nestedObj(buildingData.options,"siding.unavailable"))
	{
		for (siding of buildingData.options.siding.unavailable)
		{
			$(`#bt3_${siding}`).hide().addClass("unavailable");
		}
		if (buildingData.options.siding.unavailable.includes(buildingDesigner.building.walls.sidingCategoryData.category_id))
		{
			for (let i=0;i < GuiDataUtilities.sidingCategoryButtonData.length;i++)
			{
				if (!buildingData.options.siding.unavailable.includes(GuiDataUtilities.sidingCategoryButtonData[i].category_id))
				{
					ElementsMenu.OnClickShowSidingColorsForCategory(i);
					break;
				}
			}
		}
	}
}

ElementsMenu.SetAvailableRoofing = function (buildingData)
{
	if (!buildingData)
	{
		buildingData = buildingDesigner.building;
	}
	$(".btntype4").show().removeClass("unavailable");
	if (nestedObj(buildingData.options,"roofing.unavailable"))
	{
		for (roofing of buildingData.options.roofing.unavailable)
		{
			$(`#bt4_${roofing}`).hide().addClass("unavailable");
		}
		if (buildingData.options.roofing.unavailable.includes(buildingDesigner.building.roof.categoryID))
		{
			//for (let i=0;i < GuiDataUtilities.sidingCategoryButtonData.length;i++) {
			//if (!buildingData.options.roofing.unavailable.includes(GuiDataUtilities.sidingCategoryButtonData[i].category_id)) {
			//ElementsMenu.OnClickShowSidingColorsForCategory(i);
			//break;
			//}
			//}
		}
	}
}

ElementsMenu.SetAvailableElements = function (buildingData)
{
	if (!buildingData)
	{
		buildingData = buildingDesigner.building;
	}
	let elemTypes = [ELEM_DOOR, ELEM_OPTION, ELEM_WINDOW, ELEM_SHELF];
	for (elemType of elemTypes)
	{
		$(`.btntype${elemType}`).show().removeClass("unavailable");
		if (nestedObj(buildingData.options,`${ELEM_STRING[elemType].toLowerCase()}.unavailable`))
		{
			for (option of buildingData.options[ELEM_STRING[elemType].toLowerCase()].unavailable)
			{
				$(`#bt${elemType}_${option}`).hide().addClass("unavailable");
				$(`.bt${elemType}_${option}`).hide().addClass("unavailable");
			}
		}
	}
}

ElementsMenu.SetAvailableTrim = function ()
{
	let trim_set = buildingDesigner.building.walls.sidingCategoryData.trim_set_id;
	$(".trimcolor").hide();
	$(".trimset_"+trim_set).show();
}

ElementsMenu.BuildingElementClick = async function (elementButton, vecPos)
{
	let buildingData = GuiDataUtilities.buildingsButtonData[elementButton.btnIndex];

	if (interfaceNumber < 3)
	{
		console.warn("Interfaces prior to 3 no longer supported.")
	}
	{
		if (buildingData.building_id !== nestedObj(buildingDesigner,"building.ID"))
		{
			BuildingDesigner.buildingChangedbyUser = true;
			BuildingDesigner.buildingLoadedFromDesign = false;
			buildingDesigner.buildingSizes = await GuiDataUtilities.LoadBuildingSizes(buildingData.building_id, -1);
			let sizeData = buildingDesigner.buildingSizes[0];
			await BuildingDesigner.CreateOrLoadBuilding(buildingData.building_id, sizeData.width_display, sizeData.height_display,  SubscriberDataUtilities.subscriber, false, true, false);
			ElementsMenu.SetAvailableSiding();
			ElementsMenu.SetAvailableRoofing();
			ElementsMenu.SetAvailableElements();
			UserDataUtilities.SetUserDisplay();
			buildingDesigner.building.ElementsListPricingUpdate();
			//ElementsMenu.CreateContextMenu(buildingData.building_id, vecPos);
		}
	}
};

ElementsMenu.OnOpenModal = function (event)
{
	ElementsMenu.currentOpenModal = event.dataset.target.substring(1);

	switch (ElementsMenu.currentOpenModal)
	{
	case ("RoofingModal"):
		ElementsMenu.ShowRoofing();
		break;

	case ("PartitionsModal"):
		ElementsMenu.TabPartitions();
		break;
	}

	////$("#" + ElementsMenu.currentOpenModal).modal("show");
};

ElementsMenu.HideCurrentModal = function ()
{
	if (ElementsMenu.currentOpenModal)
	{
		$("#" + ElementsMenu.currentOpenModal).foundation("close");
	}

};

ElementsMenu.AddDoor = function (event)
{
	ElementsMenu.HideCurrentModal();

	let elementButton;

	if (ElementsMenu.currentButtonClicked)
		elementButton = ElementsMenu.currentButtonClicked;


	configuration = Door.newDoorConfiguration;

	let doorButtonData = GuiDataUtilities.doorsButtonData[elementButton.btnIndex];

	if (doorButtonData.max_number == -1 || Elements.GetElementCount(doorButtonData.elem_ID) < doorButtonData.max_number)
	{
		let element = Door.AddDoor(doorButtonData, configuration);

		if (event)
		{
			////let elementButton = event.currentTarget;

			if (event.currentTarget.btnIndex == -1)
			{
				element.colorFromBarn = true;
			}
			else
			{
				let colorData = ColorsDataUtilities.FindColor(ColorsDataUtilities.doorColorsData[event.currentTarget.btnIndex].color_id);

				element.SetColorID(colorData.color_id);
			}
		}
		else
		{
			if (doorButtonData.options && doorButtonData.options.default_color)
			{
				element.SetColorID(doorButtonData.options.default_color);
			}
			else
			{
				element.colorFromBarn = true;
			}
		}

		Elements.StartDraggingElement(element);

		GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT;
	}

};


ElementsMenu.AddHinge = function (elementButton)
{
	ElementsMenu.HideCurrentModal();

	let hingeButtonData = GuiDataUtilities.hingesButtonData[elementButton.btnIndex];

	let hingesContainerRightClickMenu = document.getElementById("hinges-container");

	if (hingesContainerRightClickMenu.style.display == "block" || ElementsMenu.currentOpenModal === "HingesModal")
	{
		let selectedElement = Elements.GetSelectedElement();

		if (elementButton.btnIndex != -1 && selectedElement && selectedElement.buttonData.type == ELEM_DOOR)
		{
			////let element = new Hinge(hingeButtonData);

			////selectedElement.SetCurrentHinge(element);

			selectedElement.CreateHinges(hingeButtonData);
		}

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

		buildingDesigner.building.SetBuildingModified();

		ElementsMenu.GenerateAndActivateTabHingesTable();
	}
	else
	{
		let element = Hinge.AddHinge(hingeButtonData);

		Elements.StartDraggingElement(element);

		GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT;
	}
};

ElementsMenu.ChangeElementColor = function (event)
{
	let selectedElement = Elements.GetSelectedElement();

	if (selectedElement)
	{
		let elementButton;

		if (event)
			elementButton = event.currentTarget;
		else
			elementButton = ElementsMenu.currentButtonClicked;

		if (elementButton.btnIndex == -1)
		{
			selectedElement.colorFromBarn = true;
		}
		else
		{
			//let colorData = ColorsDataUtilities.FindColor(ColorsDataUtilities.doorColorsData[elementButton.btnIndex].color_id);
			let colorData = ColorsDataUtilities.FindColor(elementButton.color_id);

			selectedElement.SetColorID(colorData.color_id);

			selectedElement.colorFromBarn = false;
		}

		buildingDesigner.building.SetBuildingModified();

		buildingDesigner.building.SetRegenerateElementMeshes(true);
		buildingDesigner.Draw();
	}

	let container = document.getElementById("colors-container");

	$("#DoorColorsModal").foundation("close");

};

ElementsMenu.AddWindow = function (elementButton)
{
	ElementsMenu.HideCurrentModal();

	let element = null;

	let windowButtonData = GuiDataUtilities.windowsButtonData[elementButton.btnIndex];

	if (windowButtonData.max_number == -1 || Elements.GetElementCount(windowButtonData.elem_ID) < windowButtonData.max_number)
	{
		element = Window.AddWindow(windowButtonData);

		Elements.StartDraggingElement(element);

		GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT;
	}
};

ElementsMenu.AddOption = async function (elementButton)
{
	ElementsMenu.HideCurrentModal();

	buildingDesigner.building.ClearSelections();

	let optionButtonData = GuiDataUtilities.optionsButtonData[elementButton.btnIndex];

	if (optionButtonData.max_number == -1 || Elements.GetElementCount(optionButtonData.elem_ID) < optionButtonData.max_number || optionButtonData.elem_ID == "LegBraces")
	{
		switch (optionButtonData.elem_type)
		{
		case ("RidgeVent"): {
			let ridgeVent = RidgeVent.AddRidgeVent(optionButtonData);
			ridgeVent.SetSelected(true);
			Elements.draggableElement = null;

			buildingDesigner.building.SetDesignModified();
			buildingDesigner.building.SetBuildingModified();
			break;
		}

		case ("LegBracesCorners"): {
			if (Elements.GetElementCountOfType(ELEM_LEG_BRACES) == 0)
			{
				let legBraces = LegBraces.AddLegBraces(optionButtonData);
				legBraces.SetSelected(true);
				Elements.draggableElement = null;

				buildingDesigner.building.SetDesignModified();
				buildingDesigner.building.SetBuildingModified();
			}
			break;
		}

		case ("LegBraces2FootCorners"): {
			if (Elements.GetElementCountOfType(ELEM_LEG_BRACES) == 0)
			{
				let legBraces = LegBraces.AddLegBraces(optionButtonData);
				legBraces.SetSelected(true);
				Elements.draggableElement = null;

				buildingDesigner.building.SetDesignModified();
				buildingDesigner.building.SetBuildingModified();
			}
			break;
		}


		case ("LegBraces2FootAllLegs"): {
			if (Elements.GetElementCountOfType(ELEM_LEG_BRACES) == 0)
			{
				let legBraces = LegBraces.AddLegBraces(optionButtonData);
				legBraces.SetSelected(true);
				Elements.draggableElement = null;

				buildingDesigner.building.SetDesignModified();
				buildingDesigner.building.SetBuildingModified();
			}
			break;
		}

		case ("LegBraces3FootCorners"): {
			if (Elements.GetElementCountOfType(ELEM_LEG_BRACES) == 0)
			{
				let legBraces = LegBraces.AddLegBraces(optionButtonData);
				legBraces.SetSelected(true);
				Elements.draggableElement = null;

				buildingDesigner.building.SetDesignModified();
				buildingDesigner.building.SetBuildingModified();
			}
			break;
		}


		case ("LegBraces3FootAllLegs"): {
			if (Elements.GetElementCountOfType(ELEM_LEG_BRACES) == 0)
			{
				let legBraces = LegBraces.AddLegBraces(optionButtonData);
				legBraces.SetSelected(true);
				Elements.draggableElement = null;

				buildingDesigner.building.SetDesignModified();
				buildingDesigner.building.SetBuildingModified();
			}
			break;
		}

		case ("LegBracesAllLegs"): {
			if (Elements.GetElementCountOfType(ELEM_LEG_BRACES) == 0)
			{
				let legBraces = LegBraces.AddLegBraces(optionButtonData);
				legBraces.SetSelected(true);
				Elements.draggableElement = null;

				buildingDesigner.building.SetDesignModified();
				buildingDesigner.building.SetBuildingModified();
			}
			break;
		}


		case ("Ramp"): {
			if (GuiDataUtilities.rampsData.length > 0)
			{
				let ramp = Ramp.AddRamp(optionButtonData);
				Elements.StartDraggingElement(ramp);
				GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT;
			}
			break;
		}

		case ("Anchors"): {
			let anchors = Anchors.AddAnchors(optionButtonData);
			anchors.SetSelected(true);
			Elements.draggableElement = null;

			buildingDesigner.building.SetDesignModified();
			buildingDesigner.building.SetBuildingModified();
			break;
		}

		case ("CoatedFloor"):
		case ("ArmorthaneFloor"): {
			let coatedFloor = CoatedFloor.AddCoatedFloor(optionButtonData);
			coatedFloor.SetSelected(true);
			Elements.draggableElement = null;

			buildingDesigner.building.SetDesignModified();
			buildingDesigner.building.SetBuildingModified();
			break;
		}

		case ("WallExtension"): {
			let wallExtension = WallExtension.AddWallExtension(optionButtonData);
			// wallExtension.SetSelected(true);
			Elements.draggableElement = null;
			buildingDesigner.building.SetDesignModified();
			buildingDesigner.building.SetBuildingModified();
			break;
		}

		case ("HipRoof"): {
			let hipRoof = HipRoof.AddHipRoof(optionButtonData);
			hipRoof.SetSelected(true);
			Elements.draggableElement = null;

			buildingDesigner.building.SetDesignModified();
			buildingDesigner.building.SetBuildingModified();
			break;
		}
		case ("hidden"): {
			let element = Option.AddOption(optionButtonData);
			element.SetSelected(true);
			Elements.draggableElement = null;
			buildingDesigner.building.SetDesignModified();
			buildingDesigner.building.SetBuildingModified();
			//alert("element added.");
			$("#AddNotificationName").text(optionButtonData.element_name);
			$("#AddNotificationModal").foundation("open");
			await AuxUtilities.sleep(10000);
			$("#AddNotificationModal").foundation("close");
			break;
		}

		default: {
			let element = Option.AddOption(optionButtonData);
			Elements.StartDraggingElement(element);

			GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT;
			break;
		}
		}
	}
	else
	{
		$("#NotAddedNotificationName").text(optionButtonData.element_name);
		$("#NotAddedNotificationReason").text("the maximum number of this item has already been added.");
		$("#NotAddedNotificationModal").foundation("open");
		await AuxUtilities.sleep(10000);
		$("#NotAddedNotificationModal").foundation("close");
	}
};

ElementsMenu.AddShelf = function (elementButton)
{
	ElementsMenu.HideCurrentModal();

	let shelfButtonData = GuiDataUtilities.shelvesButtonData[elementButton.btnIndex];

	if (shelfButtonData.class === "loft" && buildingDesigner.building.sizeData.size_options && buildingDesigner.building.sizeData.size_options &&buildingDesigner.building.sizeData.size_options.loft_height == -1)
	{
		GuiDataUtilities.Alert("Lofts are not available for this building size and style");
		return;
	}
	if (shelfButtonData.class === "workbench" && buildingDesigner.building.sizeData.size_options && buildingDesigner.building.sizeData.size_options && buildingDesigner.building.sizeData.size_options.workbench_height == -1)
	{
		GuiDataUtilities.Alert("Workbenches are not available for this building size and style");
		return;
	}

	if (shelfButtonData.max_number == -1 || Elements.GetElementCount(shelfButtonData.elem_ID) < shelfButtonData.max_number)
	{
		let element = Shelf.AddShelf(shelfButtonData);

		Elements.StartDraggingElement(element);

		GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT;
	}
};

ElementsMenu.AddDormer = function (elementButton)
{
	ElementsMenu.HideCurrentModal();

	let dormerButtonData = GuiDataUtilities.dormersButtonData[elementButton.btnIndex];

	if (dormerButtonData.max_number == -1 || Elements.GetElementCount(dormerButtonData.elem_ID) < dormerButtonData.max_number)
	{
		let element = Dormer.AddDormer(dormerButtonData);

		buildingDesigner.building.SetDesignModified();
		element.SetSelected(true);
	}
};

ElementsMenu.RoofingElementClick = function (elementButton)
{};

ElementsMenu.OnClickTrimColor = function (elementButton)
{
	ElementsMenu.HideCurrentModal();

	$("#TrimColorsModal").foundation("close");


	let trimColorsContainerRightClickMenu = document.getElementById("colors-container");

	if ((trimColorsContainerRightClickMenu && trimColorsContainerRightClickMenu.style.display == "block") || elementButton.forElement)
	{
		let selectedElement = Elements.GetSelectedElement();

		if (elementButton.btnIndex == -1)
		{
			selectedElement.trimColor = null;
		}
		else
		{
			let trimColor = ColorsDataUtilities.FindColor(elementButton.color || elementButton.color_id);
			selectedElement.trimColor = trimColor.color;
			selectedElement.trimColor_name = trimColor.color_name;
			selectedElement.trimColor_id = trimColor.color_id;
		}

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

		buildingDesigner.building.SetBuildingModified();

		ElementsMenu.GenerateAndActivateTabTrimColorsTable();

		trimColorsContainerRightClickMenu.style.display = "none";
	}
	else
		buildingDesigner.building.OnClickChangeTrimColor(elementButton.color);
};

ElementsMenu.WallsElementClick = function (elementButton)
{
	ElementsMenu.HideCurrentModal();

	Wall.SelectedWallButtonData = GuiDataUtilities.wallsButtonData[elementButton.btnIndex];

	GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.SET_WALL;

	let wall = buildingDesigner.building.GetSelectedWall();

	if (wall != null)
	{
		if (Elements.GetElementsOnWall(wall.eWall).length == 0)
		{
			wall.SetWallData(Wall.SelectedWallButtonData);

			wall.GetAndSetDimensionWallPrice();
		}
		else
			alert(ErrorText.WALL_HAS_ELEMENTS);
	}
};

ElementsMenu.PartitionsElementClick = function (elementButton)
{
	ElementsMenu.HideCurrentModal();

	Partition.SelectedPartitionButtonData = GuiDataUtilities.partitionsButtonData[elementButton.btnIndex];

	GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.SET_PARTITION;

	let partition = buildingDesigner.building.GetSelectedPartition();

	if (partition != null)
	{
		partition.SetPartitionData(Partition.SelectedPartitionButtonData);

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

		buildingDesigner.Draw();

		ElementsMenu.ElementsListPricingUpdate();
	}
};

ElementsMenu.ClearCategoriesContainer = function (categoriesContainer)
{
	for (let i = 0; i < categoriesContainer.children.length; i++)
	{
		categoriesContainer.children[i].style.display = "none";
	}
};

ElementsMenu.ShowElementCategory = function (elementName, newCategoryName)
{
	let categoryContainer = document.getElementById(newCategoryName);

	if (categoryContainer)
	{
		let categoriesContainer = document.getElementById("tab" + elementName);

		ElementsMenu.ClearCategoriesContainer(categoriesContainer);

		categoryContainer.style.display = "inline";
	}
};

ElementsMenu.ShowDoorLeftRightMenu = function ()
{
	let categoriesContainer = document.getElementById("tabDoors");
	ElementsMenu.ClearCategoriesContainer(categoriesContainer);

	let leftRightDoorMenuContainer = document.getElementById("LeftRightDoorMenu");

	for (let i = 0; i < leftRightDoorMenuContainer.children.length; i++)
	{
		leftRightDoorMenuContainer.children[i].checked = false;
	}

	leftRightDoorMenuContainer.style.display = "inline";
};

ElementsMenu.GenerateAndActivateRightClickHingesTable = function ()
{
	if (interfaceNumber > 2)
	{
		let hingesContainer = $("#hinges-container")[0];
		let tabHingesContainer = document.getElementById("tabHinges");
		let selectedElement = Elements.GetSelectedElement();
		while (hingesContainer.children.length > 0)
		{
			hingesContainer.removeChild(hingesContainer.children[0]);
		}

		/*if (tabHingesContainer.firstChild) {
			hingesContainer.appendChild(tabHingesContainer.firstChild.cloneNode(true));
		} */

		/* for (let i = 0; i < hingesContainer.children.length; i++) {
			tabHingesContainer.appendChild(hingesContainer.children[i].cloneNode(true));
		} */
		for (let i = 0; i < tabHingesContainer.children.length; i++)
		{
			//hingesContainer.appendChild($(tabHingesContainer.children[i]).clone(true));
			//$(tabHingesContainer.children[i]).clone(true,true).appendTo(hingesContainer);
			let clone = $(tabHingesContainer.children[i]).clone(true,true);
			$(clone).children(".objbutton").click(ElementsMenu.AddElementClick).prop("buttonType",$(tabHingesContainer.children[i]).children(".objbutton").prop("buttonType")).prop("btnIndex",$(tabHingesContainer.children[i]).children(".objbutton").prop("btnIndex"));
			let btnIndex = $(clone).children(".objbutton").prop("btnIndex");
			if (selectedElement.buttonData.available_hinges.indexOf(tdf.buttonData[ELEM_HINGE][btnIndex].elem_ID) > -1)
			{
				$(hingesContainer).append(clone);
			}
		}
		ElementsMenu.currentOpenModal = "HingesModal";
		$("#HingesModal").foundation("open");
	}

};


ElementsMenu.GenerateAndActivateTabHingesTable = function ()
{
	if (BuildingDesigner.buildingType != BUILDING_CARPORT)
	{
		let hingesContainer = document.getElementById("hinges-container");

	}
};




ElementsMenu.GenerateAndActivateRightClickTrimColorsTable = function ()
{
	$("#TrimColorsModal").foundation("open");
};

ElementsMenu.GenerateAndActivateTabTrimColorsTable = function ()
{
	if (DEBUG)
	{
		console.warn("This function was depricated for interface 3");
	}
};

ElementsMenu.GenerateDoorColorsTable = function (container, onClick, buttonData)
{

	let selectedElement = Elements.GetSelectedElement();
	buttonData = selectedElement.buttonData;

	$("#doorColorsModalContainer").empty();

	let colorHTMLTemplate = "<div class=\"box\" title=\"${colorData.color_name}\"><input type=\"radio\" id=\"${prefix}${colorData.color_id}\" name=\"${groupName}\" ${first ? \"checked\" : \"\"}><label for=\"${prefix}${colorData.color_id}\"><span class=\"box_color\" style=\"background-color: ${colorData.color}\"></span><span class=\"box_text\">${colorData.color_name}</span></label></div>";

	let colorData;
	let colorsData = [];

	if (buttonData.available_colors_elem_id.length > 0)
	{
		for (let i = 0; i < ColorsDataUtilities.doorColorsData.length; i++)
		{
			if (ColorsDataUtilities.doorColorsData[i].door_id == buttonData.available_colors_elem_id)
			{
				colorData = ColorsDataUtilities.FindColor(ColorsDataUtilities.doorColorsData[i].color_id);

				if (colorData)
				{
					colorData.doorsColorIndex = i;
					colorsData.push(colorData);
				}
			}
		}

		if (colorsData.length == 0)
		{
			for (let i = 0; i < ColorsDataUtilities.doorColorsData.length; i++)
			{
				if (ColorsDataUtilities.doorColorsData[i].door_id == buttonData.object3D_name)
				{
					colorData = ColorsDataUtilities.FindColor(ColorsDataUtilities.doorColorsData[i].color_id);

					if (colorData)
					{
						colorData.doorsColorIndex = i;
						colorsData.push(colorData);
					}
				}
			}
		}
	}

	for (let i = 0; i < colorsData.length; i++)
	{
		colorData = colorsData[i];
		$("#doorColorsModalContainer").append(fillTemplate(colorHTMLTemplate,{first: false, colorData: colorData, prefix: "mdoorColor_", groupName: "mdoorColorSelection" }));
		let currentmButton = $(`#mdoorColor_${colorData.color_id}`);
		currentmButton[0].btnIndex = i;
		currentmButton[0].color_id = colorData.color_id;
		currentmButton[0].buttonType = ELEM_DOOR;
		currentmButton[0].forElement = true;
		$(`#mdoorColor_${colorData.color_id}`).click(ElementsMenu.ChangeElementColor);
	}

	$("#DoorColorsModal").foundation("open");

};

ElementsMenu.ShowTabDoorColorsMenu = function ()
{
	let categoriesContainer = document.getElementById("tabDoors");
	ElementsMenu.ClearCategoriesContainer(categoriesContainer);

	categoriesContainer.previousCategory.push(categoriesContainer.currentCategory);

	let elem = document.getElementById("doorColorsMenu");
	elem.style.display = "inline";

	////if (ElementsMenu.\ColorsTable("doorColorsTable"))
	/*////if (ElementsMenu.GenerateDoorColorsTable("colors-container", ElementsMenu.AddDoor)
		ElementsMenu.AddDoor();*/

	let doorButtonData = GuiDataUtilities.doorsButtonData[ElementsMenu.currentButtonClicked.btnIndex];

	if (ElementsMenu.GenerateDoorColorsTable("doorColorsTable", ElementsMenu.AddDoor, doorButtonData) == 0)
		ElementsMenu.AddDoor();

	////ElementsMenu.GenerateDoorColorsTable("colors-container", ElementsMenu.ChangeElementColor);
};

ElementsMenu.HideTabDoorColorsMenu = function ()
{
	let categoriesContainer = document.getElementById("tabDoors");
	ElementsMenu.ClearCategoriesContainer(categoriesContainer);

	categoriesContainer.previousCategory.push(categoriesContainer.currentCategory);

	let elem = document.getElementById("doorColorsMenu");
	elem.style.display = "inline";

	////if (ElementsMenu.\ColorsTable("doorColorsTable"))
	/*////if (ElementsMenu.GenerateDoorColorsTable("colors-container", ElementsMenu.AddDoor)
		ElementsMenu.AddDoor();*/

	let doorButtonData = GuiDataUtilities.doorsButtonData[ElementsMenu.currentButtonClicked.btnIndex];

	if (ElementsMenu.GenerateDoorColorsTable("doorColorsTable", ElementsMenu.AddDoor, doorButtonData) == 0)
		ElementsMenu.AddDoor();

	////ElementsMenu.GenerateDoorColorsTable("colors-container", ElementsMenu.ChangeElementColor);
};

ElementsMenu.ElementBackButtonClick = function (event)
{
	let categoriesContainer;

	let elementButtonData = null;
	let type;

	if (event.currentTarget)
	{
		elementButtonData = event.currentTarget;
		type = elementButtonData.buttonType;
	}
	else
	if (event)
	{
		elementButtonData = event;
		type = elementButtonData.attributes.buttonType.value;
	}

	let elementName = ELEM_STRING[type] + "s";

	containerID = "tab" + elementName;

	categoriesContainer = document.getElementById(containerID);

	categoriesContainer.previousCategory.pop();

	ElementsMenu.ShowElementCategory(elementName, categoriesContainer.previousCategory[categoriesContainer.previousCategory.length - 1]);
};

ElementsMenu.AddElementClick = function (event)
{
	let elementButton = event.currentTarget;
	let vecPos = {
		x: event.clientX,
		y: event.clientY
	};

	if3CloseLeftMenu();

	if (Elements.draggableElement)
		Elements.DeleteElement(Elements.draggableElement);

	if (elementButton.categoryName && elementButton.categoryName.length > 0)
	{
		let elementName = ELEM_STRING[elementButton.buttonType] + "s";
		let category = elementButton.categoryName;

		let categoriesContainer = document.getElementById("tabDoors");

		if (!categoriesContainer.previousCategory)
		{
			categoriesContainer.previousCategory = [];

			categoriesContainer.previousCategory.push(elementName);
		}

		categoriesContainer.previousCategory.push(category);
		ElementsMenu.ShowElementCategory(elementName, category);
	}
	else
	////if (AuxUtilities.IsSet(elementButton.btnIndex))
	{
		switch (elementButton.buttonType)
		{
		case (ELEM_BUILDING): {
			ElementsMenu.BuildingElementClick(elementButton, vecPos);
			break;
		}
		case (ELEM_DOOR):
		{
			ElementsMenu.currentButtonClicked = elementButton;

			let categoriesContainer = document.getElementById("tabDoors");

			let doorButtonData = GuiDataUtilities.doorsButtonData[ElementsMenu.currentButtonClicked.btnIndex];

			if (!categoriesContainer.previousCategory)
			{
				categoriesContainer.previousCategory = [];

				categoriesContainer.previousCategory.push(doorButtonData.belongs_to_category);
			}

			if (doorButtonData.left_right_opening)
			{
				if (doorButtonData.options && doorButtonData.options.ask_left_right)
				{
					categoriesContainer.previousCategory.push("LeftRightDoorMenu");
					ElementsMenu.ShowDoorLeftRightMenu();
				}
				else
				{
					Door.newDoorConfiguration = Door.RIGHT_OPENING;
				}
			} //else {
			if (doorButtonData.options && doorButtonData.options.ask_color && ColorsDataUtilities.GetAvailableDoorColors(doorbuttonData.available_colors_elem_id).length > 1)
			{
				categoriesContainer.previousCategory.push("doorColorsMenu");
				ElementsMenu.ShowTabDoorColorsMenu();
			}
			else
			{
				ElementsMenu.AddDoor(null);
			}
			//}

			break;
		}
		case (ELEM_HINGE):
			ElementsMenu.AddHinge(elementButton);
			break;

		case (ELEM_WINDOW):
			ElementsMenu.AddWindow(elementButton);
			break;

		case (ELEM_OPTION):
			ElementsMenu.AddOption(elementButton);
			break;

		case (ELEM_SHELF):
			ElementsMenu.AddShelf(elementButton);
			break;

		case (ELEM_DORMER):
			ElementsMenu.AddDormer(elementButton);
			break;

		case (ELEM_WALL):
			ElementsMenu.WallsElementClick(elementButton);
			break;

		case (ELEM_SIDING):
			ElementsMenu.OnClickShowSidingColorsForCategory(elementButton.btnIndex);
			break;

		case (ELEM_ROOFING):
			if (elementButton.category)
			{
				ElementsMenu.OnClickShowRoofingColorsForCategory(elementButton.btnIndex);
			}
			break;

		case (ELEM_TRIMCOLORS):
			ElementsMenu.OnClickTrimColor(elementButton);
			break;

		case (ELEM_PARTITION):
			ElementsMenu.PartitionsElementClick(elementButton);
			break;
		}
	}
};

ElementsMenu.OnClickChangeSidingColor = async function (event)
{
	ElementsMenu.HideCurrentModal();

	let elementButton = event.currentTarget;

	buildingDesigner.building.OnClickChangeSidingColor(elementButton);
};

ElementsMenu.OnClickChangeColor = async function (event)
{
	ElementsMenu.HideCurrentModal();

	let elementButton = event.currentTarget;
	switch (elementButton.buttonType)
	{
	case ELEM_TRIMCOLORS: {
		buildingDesigner.building.OnClickChangeTrimColor(elementButton.color_id);
		break;
	}
	case ELEM_SIDING: {
		//
	}
	} //switch buttonType
};

ElementsMenu.OnClickShowSidingCategories = function ()
{
	let element = document.getElementById("sidingColors");
	element.style.display = "none";

	element = document.getElementById("sidingCategories");
	element.style.display = "block";
};

/**
 * @param {number} index siding button index
 * @param {boolean} keepSiding set to true to prevent siding change
 */
ElementsMenu.OnClickShowSidingColorsForCategory = function (index,keepSiding)
{
	let btnFileName;

	$("#sidingColorsContainer").empty();

	let first = true;
	let sidingChange = false;
	if (buildingDesigner.building.walls.sidingCategoryData.category_id !== GuiDataUtilities.sidingCategoryButtonData[index].category_id)
	{
		if (!keepSiding)
		{
			sidingChange = true;
		}
	}
	let selectedColor = buildingDesigner.building.walls.sidingColorData.color_id;
	for (let i = 0; i < GuiDataUtilities.sidingColorButtonData.length; i++)
	{
		if (GuiDataUtilities.sidingColorButtonData[i].category_id == GuiDataUtilities.sidingCategoryButtonData[index].category_id)
		{
			btnFileName = DIR_TEXTURES + GuiDataUtilities.sidingColorButtonData[i].textureFile;
			colorData = ColorsDataUtilities.FindColor(GuiDataUtilities.sidingColorButtonData[i].color_id);
			if (colorData)
			{
				if ($(`#div_${GuiDataUtilities.sidingColorButtonData[i].color_id}`).length)
				{
					$(`#div_${GuiDataUtilities.sidingColorButtonData[i].color_id}`).remove();
				}
				/*$("#sidingColorsContainer").append(`<div class="box" title="${GuiDataUtilities.sidingColorButtonData[i].display_name}">
					<input type="radio" id="${GuiDataUtilities.sidingColorButtonData[i].color_id}" name="sidingSelection" ${first ? "checked" : ""}>*/
				$("#sidingColorsContainer").append(`<div class="box" title="${GuiDataUtilities.sidingColorButtonData[i].display_name}" id="div_${GuiDataUtilities.sidingColorButtonData[i].color_id}">
					<input type="radio" id="${GuiDataUtilities.sidingColorButtonData[i].color_id}" name="sidingSelection" ${GuiDataUtilities.sidingColorButtonData[i].color_id === selectedColor ? "checked" : ""}></input>
					<label for="${GuiDataUtilities.sidingColorButtonData[i].color_id}"><span class="box_color" style="background-color: ${colorData.color}"></span><span class="box_text">${GuiDataUtilities.sidingColorButtonData[i].display_name}</span></label>
					</div>`);
				let currentButton = $(`#${GuiDataUtilities.sidingColorButtonData[i].color_id}`);
				$(`#${GuiDataUtilities.sidingColorButtonData[i].color_id}`).click(ElementsMenu.OnClickChangeSidingColor);
				currentButton[0].btnIndex = i;
				currentButton[0].buttonType = ELEM_SIDING;
				if (first && sidingChange)
				{
					buildingDesigner.building.OnClickChangeSidingColor(currentButton[0]);
				}
				first = false;
			}
		}
	}
	ElementsMenu.SetAvailableTrim();


};

ElementsMenu.OnClickChangeRoofingColor = function (event)
{
	ElementsMenu.HideCurrentModal();

	let elementButton = event.currentTarget;

	buildingDesigner.building.OnClickChangeRoofingColor(elementButton);
};

ElementsMenu.OnClickShowRoofingCategories = function ()
{
	let element = document.getElementById("roofingColors");
	element.style.display = "none";

	element = document.getElementById("roofingCategories");
	element.style.display = "block";
};

/**
 * @function
 * @async
 * @param {number} roofing button index
 * @param {boolean} set to true to prevent roofing change
 */
ElementsMenu.OnClickShowRoofingColorsForCategory = async function (index,keepRoofing)
{
	let btnFileName;

	$("#roofingColorsContainer").empty();
	let first = true;
	let roofingChange = false;
	if (buildingDesigner.building.roof.categoryID !== GuiDataUtilities.roofingButtonData[index].category_id)
	{
		if (!keepRoofing)
		{
			roofingChange = true;
		}
	}
	for (let i = 0; i < GuiDataUtilities.roofingButtonData.length; i++)
	{
		if (GuiDataUtilities.roofingButtonData[i].category_id == GuiDataUtilities.roofingButtonData[index].category_id)
		{
			btnFileName = DIR_TEXTURES + GuiDataUtilities.roofingButtonData[i].textureFile;
			$("#roofingColorsContainer").append(`<div class="box colortexture" title="${GuiDataUtilities.roofingButtonData[i].display_name}">
					<input type="radio" id="${GuiDataUtilities.roofingButtonData[i].roofing_id}" name="roofingSelection" ${first ? "checked" : ""}>
					<label for="${GuiDataUtilities.roofingButtonData[i].roofing_id}"><span class="box_color" style="background-image: url('${btnFileName}'"></span><span class="box_text">${GuiDataUtilities.roofingButtonData[i].display_name}</span></label>
					</div>`);
			let currentButton = $(`#${GuiDataUtilities.roofingButtonData[i].roofing_id}`);
			$(`#${GuiDataUtilities.roofingButtonData[i].roofing_id}`).click(ElementsMenu.OnClickChangeRoofingColor);
			currentButton[0].btnIndex = i;
			currentButton[0].buttonType = ELEM_ROOFING;
			currentButton[0].color_id = GuiDataUtilities.roofingButtonData[i].color_id;
			currentButton[0].roofing_id = GuiDataUtilities.roofingButtonData[i].roofing_id;
			if (first && roofingChange)
			{
				buildingDesigner.building.OnClickChangeRoofingColor(currentButton[0]);
			}
			first = false;
		}
	}



};

ElementsMenu.ElementsListPricingUpdate = function ()
{
	if (buildingDesigner.building && buildingDesigner.building.initialized)
	{
		buildingDesigner.building.ElementsListPricingUpdate();
	}
};

// Depricated -- replaced by OnClickElementsList
ElementsMenu.OnChangeElementsList = function ()
{
	let elementsList = document.getElementById("elementsList");

	buildingDesigner.building.ClearSelections();

	if (elementsList.selectedIndex == 0)
		buildingDesigner.building.SetSelected(true);
	else
	if (elementsList[elementsList.selectedIndex].element != undefined)
	{
		elementsList[elementsList.selectedIndex].element.SetSelected(true);
	}


	buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

	buildingDesigner.Draw();
};

ElementsMenu.OnClickElementsList = function (element)
{
	let elementsList = document.getElementById("elementsList");

	buildingDesigner.building.ClearSelections();
	$(".element_selected").removeClass("element_selected");

	//if (elementsList.selectedIndex === 0)
	//	buildingDesigner.building.SetSelected(true);
	//else
	if (element.element != undefined)
	{
		element.element.SetSelected(true);
		$(element).addClass("element_selected");
	}


	buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

	buildingDesigner.Draw();
};

ElementsMenu.HideBuildingMenu = function ()
{
	if (DEUBG)
	{
		console.warn("This function depricated with interface 3");
	}
};

ElementsMenu.CreateContextMenu = function (buildingID, vecPos)
{
	ElementsMenu.menuContext = document.getElementById("buildingStyleMenu");

	while (ElementsMenu.menuContext.hasChildNodes())
		ElementsMenu.menuContext.removeChild(ElementsMenu.menuContext.childNodes[0]);

	let elemLI, new_a;

	let widthStr;
	let menuWidths = [];

	let sizeData;

	let sizeIndex;

	for (let i = 0; i < buildingDesigner.buildingSizes.length; i++)
	{
		sizeData = buildingDesigner.buildingSizes[i];
		if (sizeData.id == buildingID)
		{
			if (!MathUtilities.ValueInArray(menuWidths, sizeData.width, 0.5))
			{
				menuWidths.push(sizeData.width);

				elemLI = document.createElement("li");
				elemLI.setAttribute("id", buildingID);

				new_a = document.createElement("a");
				new_a.setAttribute("href", "#");

				widthStr = sizeData.width_display;

				textDescription = sizeData.building_display_name + " " + widthStr + "'";

				new_a.setAttribute("onclick", `BuildingDesigner.CreateOrLoadBuilding('${buildingID}', '${sizeData.width_display}', '${sizeData.height_display}', '${SubscriberDataUtilities.subscriber}', false, true, false);ElementsMenu.HideBuildingMenu();`);

				new_a.innerHTML = textDescription;

				elemLI.appendChild(new_a);

				ElementsMenu.menuContext.appendChild(elemLI);
			}
		}
	}

	ElementsMenu.menuContext.style.left = vecPos.x + "px";
	ElementsMenu.menuContext.style.top = vecPos.y + "px";
	ElementsMenu.menuContext.style.display = "block";
};

ElementsMenu.SetDormersTabVisibility = function (visible, widthDisplay)
{
	if (!visible)
	{
		let element = document.getElementById("tabDormersButton");

		if (element)
			element.style.display = "none";
	}
	else
	{
		let element = document.getElementById("tabDormers");

		if (widthDisplay.length == 1)
			widthDisplay = "0" + widthDisplay;

		widthDisplay = "WIDTH_" + widthDisplay;

		let dormerButtonData;

		for (let i = 0; i < element.children.length; i++)
		{
			if (interfaceNumber > 2)
			{
				dormerButtonData = GuiDataUtilities.dormersButtonData[element.children[i].children[0].btnIndex];
			}

			if (dormerButtonData.elem_ID.toLowerCase().indexOf(widthDisplay.toLowerCase()) == -1)
				element.children[i].style.display = "none";
			else
				element.children[i].style.display = "inline";
		}

		element = document.getElementById("tabDormersButton");

		element.style.display = "block";
	}

};

ElementsMenu.DestroyContextMenu = function ()
{
	if (ElementsMenu.menuContext != null)
	{
		ElementsMenu.menuContext.style.display = "none";
		ElementsMenu.menuContext = null;
	}
};

ElementsMenu.CreateFixedSizeMenu = function (sizeData, selectedSizeIndex)
{
	let selectedBuildingWidthDisplay = sizeData[selectedSizeIndex].width_display;
	$("#tabSizes").empty();
	let currentWidth = buildingDesigner.building.width;
	let currentLength = buildingDesigner.building.length;
	for (let i = 0; i < sizeData.length; i++)
	{
		//if (selectedBuildingWidthDisplay == sizeData[i].width_display) {
		let fullSize = `${sizeData[i].width_display}x${sizeData[i].length_display}`;
		let checked = "";
		//if (i===0) checked = "checked"; else checked="";
		if ((sizeData[i].width_display == currentWidth) && (sizeData[i].length_display == currentLength))
		{
			checked = "checked";
		}
		$("#tabSizes").append(`<input type="radio" id="size${fullSize}"${sizeData[i].admin_only ? " class=\"adminui\"":""} name="size" ${checked}><label${sizeData[i].admin_only ? " class=\"adminui\"":""}>${fullSize}</label>`);
		$(`#size${fullSize}`)[0].iSizeIndex = i;
		$(`#size${fullSize}`).click(ElementsMenu.OnClickChangeBuildingSize);
		//}
	}
	UserDataUtilities.SetUserDisplay();
};

ElementsMenu.CreateSizeList = function (label, sizeArray, selectedValue)
{
	let elemTd = document.createElement("TD");

	elemTd.setAttribute("vAlign", "top");

	elemTd.style.paddingLeft = "10px";
	elemTd.style.paddingRight = "10px";


	let sizeList = document.createElement("SELECT");
	sizeList.setAttribute("id", label.toLowerCase() + "Selection");

	sizeList.setAttribute("size", "1");

	sizeList.onchange = ElementsMenu.OnClickChangeBuildingSize;

	let sizeLabel = document.createElement("LABEL");

	let textNode = document.createTextNode(label + ": ");

	sizeLabel.appendChild(textNode);

	elemTd.appendChild(sizeLabel);

	let optNew;

	optNew = new Option("-");
	sizeList.options.add(optNew);

	let selectedIndex = -1;

	for (let i = 0; i < sizeArray.length; i++)
	{
		optNew = new Option(unescape(sizeArray[i].replace(/ /g, "%A0")));
		sizeList.options.add(optNew);


		if (selectedValue != null && sizeArray[i] == selectedValue)
			selectedIndex = i;
	}

	if (selectedIndex > -1)
	{
		sizeList.selectedIndex = selectedIndex;
		sizeList.value = selectedValue;
	}


	elemTd.appendChild(sizeList);

	return elemTd;
};

ElementsMenu.ResetAvailableSizes = function (sizeData)
{
	ElementsMenu.CreateAllSizesMenu(buildingDesigner.buildingSizes);
};

ElementsMenu.CreateAllSizesMenu = function (sizeData, selected_width_display, selected_length_display, selected_height_display)
{
	if (selected_width_display == undefined || selected_width_display == "-")
		selected_width_display = null;
	else
	{
		selected_width_display = TextDataUtilities.RemoveCharacterAndTrimString(selected_width_display, "*");
	}

	if (selected_length_display == undefined || selected_length_display == "-")
		selected_length_display = null;
	else
	{
		selected_length_display = TextDataUtilities.RemoveCharacterAndTrimString(selected_length_display, "*");
	}

	if (selected_height_display == undefined || selected_height_display == "-")
		selected_height_display = null;
	else
	{
		selected_height_display = TextDataUtilities.RemoveCharacterAndTrimString(selected_height_display, "*");
	}


	let sizeTab = document.getElementById("tabSizes");

	while (sizeTab.childNodes.length > 0)
		sizeTab.removeChild(sizeTab.childNodes[0]);

	let elemTable = document.createElement("TABLE");
	let elemTr = document.createElement("TR");

	let widths = AuxUtilities.ExtractDataFromArray(sizeData, function (dataElement)
	{
		if ((dataElement.length_display == selected_length_display || selected_length_display == null) && (dataElement.height_display == selected_height_display || selected_height_display == null))
			return dataElement.width_display;
		else
		{
			if (dataElement.width_display.length == 1)
				return dataElement.width_display + "  *";
			else
				return dataElement.width_display + " *";
		}
	});


	widths = widths.filter(function onlyUnique(value, index, self)
	{
		if (value.indexOf("*") > -1)
			return !(self.indexOf(TextDataUtilities.RemoveCharacterAndTrimString(value, "*")) > -1);
		else
			return true;
	});

	let elemTd = ElementsMenu.CreateSizeList("Width", widths, selected_width_display);
	elemTr.appendChild(elemTd);


	let lengths = AuxUtilities.ExtractDataFromArray(sizeData, function (dataElement)
	{
		if ((dataElement.width_display == selected_width_display || selected_width_display == null) && (dataElement.height_display == selected_height_display || selected_height_display == null))
			return dataElement.length_display;
		else
		{
			if (dataElement.length_display.length == 1)
				return dataElement.length_display + "  *";
			else
				return dataElement.length_display + " *";
		}
	});

	lengths = lengths.filter(function onlyUnique(value, index, self)
	{
		if (value.indexOf("*") > -1)
			return !(self.indexOf(TextDataUtilities.RemoveCharacterAndTrimString(value, "*")) > -1);
		else
			return true;
	});


	elemTd = ElementsMenu.CreateSizeList("Length", lengths, selected_length_display);
	elemTr.appendChild(elemTd);


	let heights = AuxUtilities.ExtractDataFromArray(sizeData, function (dataElement)
	{
		if ((dataElement.width_display == selected_width_display || selected_width_display == null) && (dataElement.length_display == selected_length_display || selected_length_display == null))
			return dataElement.height_display;
		else
		{
			if (dataElement.height_display.length == 1)
				return dataElement.height_display + "   *";
			else
				return dataElement.height_display + " *";
		}
	});


	heights = heights.filter(function onlyUnique(value, index, self)
	{
		if (value.indexOf("*") > -1)
			return !(self.indexOf(TextDataUtilities.RemoveCharacterAndTrimString(value, "*")) > -1);
		else
			return true;
	});


	elemTd = ElementsMenu.CreateSizeList("Height", heights, selected_height_display);
	elemTr.appendChild(elemTd);

	elemTable.appendChild(elemTr);

	sizeTab.appendChild(elemTable);

	elemTable = document.createElement("TABLE");

	elemTable.setAttribute("height", "100");

	elemTr = document.createElement("TR");

	elemTd = document.createElement("TD");

	elemTd.setAttribute("vAlign", "bottom");


	let label = document.createElement("LABEL");
	let text = document.createTextNode("Dimensions with a '*' aren't available based on your other selections.");
	label.appendChild(text);

	label.appendChild(document.createElement("BR"));
	label.appendChild(document.createElement("BR"));

	text = document.createTextNode("You can still choose one of those, although your previous selections will be reset.");
	label.appendChild(text);


	label.appendChild(document.createElement("BR"));
	label.appendChild(document.createElement("BR"));


	elemTd.appendChild(label);

	elemTr.appendChild(elemTd);

	elemTable.appendChild(elemTr);

	sizeTab.appendChild(elemTable);
};

ElementsMenu.UpdateAvailableSizes = function (sizeData, selectedSizeIndex, mode)
{
	if (mode == undefined || mode == null)
		mode = ElementsMenu.SHOW_AVAILABLE_SIZES_MODE_FIXED_WIDTH;

	if (BuildingDesigner.buildingType != BUILDING_CARPORT)
	{
		ElementsMenu.CreateFixedSizeMenu(sizeData, selectedSizeIndex);
	}
	else
	{
		ElementsMenu.CreateAllSizesMenu(sizeData, sizeData[selectedSizeIndex].width_display, sizeData[selectedSizeIndex].length_display, sizeData[selectedSizeIndex].height_display);

		let elem = document.getElementById("widthSelection");
		buildingDesigner.prevGUISelectedWidthIndex = elem.selectedIndex;

		elem = document.getElementById("lengthSelection");
		buildingDesigner.prevGUISelectedLengthIndex = elem.selectedIndex;

		elem = document.getElementById("heightSelection");
		buildingDesigner.prevGUISelectedHeightIndex = elem.selectedIndex;
	}
};

ElementsMenu.SetBuildingSizeChecked = function (iSizeIndex)
{
	let selectedElement;
	for (let i = 0; i < buildingDesigner.buildingSizes.length; i++)
	{
		selectedElement = document.getElementById("sizeID" + i);
		if (selectedElement)
		{
			selectedElement.checked = false;
		}
	}

	let elemSize = document.getElementById("sizeID" + iSizeIndex);
	if (elemSize)
	{
		elemSize.checked = true;
	}
};


ElementsMenu.SetBuildingLeanToSizeChecked = function (iSizeIndex)
{
	let selectedElement;
	for (let i = 0; i < buildingDesigner.leanToSizes.length; i++)
	{
		selectedElement = document.getElementById("leanToSizeID" + i);
		if (selectedElement)
		{
			selectedElement.checked = false;
		}
	}

	let elemSize = document.getElementById("leanToSizeID" + iSizeIndex);
	elemSize.checked = true;
};

ElementsMenu.ShowRightClickMenu = function (selectedElement, x, y)
{
	let menu = document.getElementById("right_click_menu");
	if (nestedObj(selectedElement.buttonData,"options.colorSet"))
	{
		$(".mtrimcolor").hide();
		$(".mtrimcolor.trimset_"+nestedObj(selectedElement.buttonData,"options.colorSet")).show();
	}
	else
	{
		$(".mtrimcolor").hide();
		$(".mtrimcolor.trimset_"+buildingDesigner.building.walls.sidingCategoryData.trim_set_id).show();
	}

	//menu.childNodes[15].style.background = "url('resources/images/ball.png') no-repeat 0px 0px";

	if (selectedElement)
	{
		if (selectedElement.buttonData.type == ELEM_DOOR)
		{
			$("#lodoor").css("background", selectedElement.configurationMode == OBJECT_CONFIGURATION2 ? "url('resources/images/ball.png') no-repeat 0px 0px" : "");
			//menu.children[0].children[0].style.background = selectedElement.configurationMode == OBJECT_CONFIGURATION2 ? "url('resources/images/ball.png') no-repeat 0px 0px" : "";
			$("#rodoor").css("background", selectedElement.configurationMode == OBJECT_CONFIGURATION3 ? "url('resources/images/ball.png') no-repeat 0px 0px" : "");
			//menu.children[0].children[1].style.background = selectedElement.configurationMode == OBJECT_CONFIGURATION3 ? "url('resources/images/ball.png') no-repeat 0px 0px" : "";

			$("#setDoorHingesConfigurationMenuItem").show();
			//menu.childNodes[3].style.display = "block";
			$("#changeDoorColorMenuItem").show();
			if (selectedElement.buttonData.options && selectedElement.buttonData.options.disable_color)
			{
				$("#changeDoorColorMenuItem").hide();
			}
			if (ColorsDataUtilities.GetAvailableDoorColors(selectedElement.buttonData.available_colors_elem_id).length < 2)
			{
				$("#changeDoorColorMenuItem").hide();
			}
			if (selectedElement.buttonData.options && selectedElement.buttonData.options.disable_hinges)
			{
				$("#changeHingesMenuItem").hide();
			}
			else
			{
				$("#changeHingesMenuItem").show();
			}
			if (selectedElement.buttonData.available_hinges.length < 2)
			{
				$("#changeHingesMenuItem").hide();
			}
			if (BuildingDesigner.buildingType == BUILDING_CARPORT)
			{
				$("#changeHingesMenuItem").hide();
			}
		}
		else
		{
			$("#setDoorHingesConfigurationMenuItem").hide();
			$("#changeHingesMenuItem").hide();
			$("#changeDoorColorMenuItem").hide();
		}


		if (selectedElement.buttonData.user_specifiable_trim_color || nestedObj(selectedElement.buttonData,"options.user_specifiable_trim_color"))
		{
			//menu.childNodes[9].style.display = "block";
			$("#changeTrimColorMenuItem").show();
		}
		else
		{
			$("#changeTrimColorMenuItem").hide();
			//menu.childNodes[9].style.display = "none";
		}
	}

	if (tdf.isMobile) {
		menu.style.left = "20px";
		menu.style.top = "20px";
	} else {
		viewHeight = $("#canvascontainer").height();
		viewWidth = $("#canvascontainer").width();
		menuHeight = $(menu).outerHeight();
		menuWidth = $(menu).outerWidth();
		if ((x + 10 + menuWidth) < viewWidth) {
			menu.style.left = (x + 10) + "px";
		} else {
			menu.style.left = (viewWidth - menuWidth) + "px";
		}
		if ((y + menuHeight) < viewHeight) {
			menu.style.top = y + "px";
		} else {
			menu.style.top = (viewHeight - menuHeight) + "px";
		}
	}

	//menu.style.display = "block";
	$("#right_click_menu").show();
};

ElementsMenu.HideRightClickMenu = function ()
{
	let element = document.getElementById("right_click_menu");

	if (element)
	{
		$("#right_click_menu").hide();

		ElementsMenu.GenerateAndActivateTabHingesTable();

		ElementsMenu.GenerateAndActivateTabTrimColorsTable();

		$("#colors-container").hide();
	}
};


ElementsMenu.OnClickChangeStallCount = function (event)
{
	buildingDesigner.selectedStallCountIndex = event.currentTarget.iStallsCountIndex;

	buildingDesigner.CreateBuildingAndDefaultElements(buildingDesigner.buildingID, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex], buildingDesigner.building.roofRafter);

	buildingDesigner.camera.SetInitialPositionAndOrientation();

	buildingDesigner.InitializeCameraAndRender();

	ElementsMenu.SetStallCountChecked(event.currentTarget.iStallsCountIndex);

	Elements.draggableElement = null;
};

ElementsMenu.OnClickChangeBuildingSize = function (event)
{
	buildingDesigner.OnClickChangeBuildingSize(event);
};

ElementsMenu.OnClickChangeLeanToSize = function (event)
{
	buildingDesigner.selectedLeanToSizeIndex = event.currentTarget.iSizeIndex;

	let rafter = new Rafter(Rafters.rafterData[event.currentTarget.iSizeIndex]);
	rafter.Process();

	buildingDesigner.CreateBuildingAndDefaultElements(buildingDesigner.buildingID, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex], rafter);

	buildingDesigner.camera.SetInitialPositionAndOrientation();

	buildingDesigner.InitializeCameraAndRender();

	ElementsMenu.SetBuildingLeanToSizeChecked(event.currentTarget.iSizeIndex);
};

ElementsMenu.SetStallCountChecked = function (iStallsCountIndex)
{
	let selectedElement;

	let stallCountData = buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].stall_count.split(",");

	for (let i = 0; i < stallCountData.length; i++)
	{
		selectedElement = document.getElementById("stallCountID" + i);
		if (selectedElement)
		{
			selectedElement.checked = false;
		}
	}

	let elemSize = document.getElementById("stallCountID" + iStallsCountIndex);
	elemSize.checked = true;
};

ElementsMenu.SetSelectedElementConfiguration = function (configuration)
{
	ElementsMenu.HideRightClickMenu();

	let selectedElement = Elements.GetSelectedElement();

	if (selectedElement)
		selectedElement.SetConfiguration(configuration);

	buildingDesigner.building.SetBuildingModified();

	buildingDesigner.building.SetRegenerateElementMeshes(true);
	buildingDesigner.Draw();
};

ElementsMenu.SHOW_AVAILABLE_SIZES_MODE_ALL = 0;
ElementsMenu.SHOW_AVAILABLE_SIZES_MODE_FIXED_WIDTH = 1;

ElementsMenu.menuContext = null;

ElementsMenu.currentOpenModal = null;
