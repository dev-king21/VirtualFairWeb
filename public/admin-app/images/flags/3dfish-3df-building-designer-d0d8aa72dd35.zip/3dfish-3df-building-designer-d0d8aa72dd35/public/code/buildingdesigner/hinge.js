/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Hinge(buttonData, door)
{
	this.door = door;

	Element.call(this, buttonData);

	this.buttonData.type = ELEM_HINGE;

	this.AddObjects();

	this.SetPos = function (x, y, z)
	{
		if (!this.dragging)
		{
			if (!(typeof this.component3DObjects.objectList[0] === "undefined"))
			{
				this.component3DObjects.objectList[0].pos.x = x;
				this.component3DObjects.objectList[0].pos.y = y;
				this.component3DObjects.objectList[0].pos.z = z;
			}
			else
			{
				console.log("hinge object undefined.");
				return;
			}
		}
		else
		{
			this.pos.x = x;
			this.pos.y = y;
			this.pos.z = z;
		}

		this.UpdateMatrix();
	};

	this.SetHeight = function (y)
	{
		this.component3DObjects.objectList[0].pos.y = y;

		this.UpdateMatrix();
	};

	this.SetZRotation = function (rotation)
	{
		if (!(typeof this.component3DObjects.objectList[0] === "undefined"))
		{
			this.component3DObjects.objectList[0].axis = new Axis();
			this.component3DObjects.objectList[0].axis = this.component3DObjects.objectList[0].axis.rotateAxis(0, 0, 1, rotation);
		}
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.wall && this.wall.matrix)
		{
			if (this.component3DObjects.boundingBox)
			{
				////let size = this.component3DObjects.boundingBox.getSize();

				let size = new THREE.Vector3();

				size = this.component3DObjects.boundingBox.getSize(size);



				this.length = size.z * this.component3DObjects.scale.z;

				this.component3DObjects.Generate(buildingMeshes, this.component3DObjects.scale, true);

				this.component3DObjects.mesh.type = ELEM_OPTION;

				MeshUtilities.SetElement(this.component3DObjects.mesh, this);

				this.component3DObjects.mesh.castShadow = true;

				this.component3DObjects.mesh.visible = true;
			}

			this.UpdateMatrix();

			this.regenerate = false;
		}

		return this.component3DObjects.mesh;
	};

	this.SetCollision = function (collision, collidingObject)
	{
		this.collision = collision;

		this.door = null;

		if (!collision)
		{
			if (this.component3DObjects.mesh)
				MeshUtilities.SetMaterialOpacity(this.component3DObjects.mesh, Element.COLLISION_OPACITY);
		}
		else if (collidingObject && collidingObject.buttonData.type == ELEM_DOOR)
		{
			this.door = collidingObject;

			if (this.component3DObjects.mesh)
				MeshUtilities.SetMaterialOpacity(this.component3DObjects.mesh, 1.0);
		}
	};

	this.AfterDragging = function ()
	{
		if (this.door)
		{
			this.door.CreateHinges(this.buttonData);
		}
	};
}

Hinge.AddHinge = function (hingeButtonData)
{
	let element = new Hinge(hingeButtonData);

	Elements.AddElement(element);

	return element;
};

// The correct place to call parent object is in child class constructor
// as we call it in above Student function code
Hinge.prototype = Object.create(Element.prototype);
// Set the "constructor" property to refer to Student
Hinge.prototype.constructor = Hinge;
