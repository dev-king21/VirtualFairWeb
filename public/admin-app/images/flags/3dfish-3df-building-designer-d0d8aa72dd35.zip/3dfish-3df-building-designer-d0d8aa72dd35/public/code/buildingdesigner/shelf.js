/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Shelf(buttonData)
{
	buttonData.height = buttonData.thickness;

	Element.call(this, buttonData);

	if (this.buttonData.shelves_data_depth && this.buttonData.shelves_data_depth != "null")
	{
		if (typeof this.buttonData.shelves_data_depth == "string")
			this.buttonData.shelves_data_depth = this.buttonData.shelves_data_depth.split(",");
	}
	else
		this.buttonData.shelves_data_depth = null;

	if (this.buttonData.shelves_data_thickness && this.buttonData.shelves_data_thickness != "null")
	{
		if (typeof this.buttonData.shelves_data_thickness == "string")
			this.buttonData.shelves_data_thickness = this.buttonData.shelves_data_thickness.split(",");
	}
	else
		this.buttonData.shelves_data_thickness = null;

	if (this.buttonData.shelves_data_yoffset && this.buttonData.shelves_data_yoffset != "null")
	{
		if (typeof this.buttonData.shelves_data_yoffset == "string")
			this.buttonData.shelves_data_yoffset = this.buttonData.shelves_data_yoffset.split(",");
	}
	else
		this.buttonData.shelves_data_yoffset = null;

	this.buttonData.type = ELEM_SHELF;

	this.SetPos = function (x, y, z)
	{
		this.pos.x = x;
		if (this.buttonData.class === "shelf")
		{
			this.pos.y = y;
		}
		else if (this.buttonData.class === "loft" && buildingDesigner.building.sizeData.size_options && buildingDesigner.building.sizeData.size_options.loft_height && buildingDesigner.building.sizeData.size_options.loft_height != 0)
		{
			this.pos.y = Number(buildingDesigner.building.sizeData.size_options.loft_height);
		}
		else if (this.buttonData.class === "workbench" && buildingDesigner.building.sizeData.size_options && buildingDesigner.building.sizeData.size_options.workbench_height && buildingDesigner.building.sizeData.size_options.workbench_height > 0)
		{
			this.pos.y = Number(buildingDesigner.building.sizeData.size_options.workbench_height);
		}
		else
		{
			this.pos.y = y;
		}
		this.pos.z = z;

		this.UpdateMatrix();
	};

	this.shelfTextureFileName = "Southern_yellowpine_horizontal";
	this.shelfTexture = null;

	this.color = "rgb(252,232,173)";

	this.component3DObjects.geometryCenter.x = 0;
	this.component3DObjects.geometryCenter.y = 0;
	this.component3DObjects.geometryCenter.z = 0;

	this.mesh = null;

	this.GetTextures = function ()
	{
		this.shelfTexture = TexturesDataUtilities.SelectTexture(this.shelfTextureFileName, THREE.RepeatWrapping, THREE.RepeatWrapping);
	};

	this.AddShelfComponent = function (width, height, depth, yOffset)
	{
		this.shelfPoints = [{
			x: 0,
			y: 0
		},
		{
			x: 0,
			y: height
		},
		{
			x: width,
			y: height
		},
		{
			x: width,
			y: 0
		}
		];

		let shelfGeom = new THREE.ExtrudeGeometry(new THREE.Shape(this.shelfPoints), {
			depth: depth,
			bevelEnabled: false
		});

		TexturesDataUtilities.AssignUVsToGeometryXZ(shelfGeom);

		let mater = new THREE.MeshStandardMaterial({
			color: this.color,
			map: TexturesDataUtilities.TextureLoaded(this.shelfTexture),
			roughness: 1.0,
			metalness: METALNESS
		});

		shelfGeom.matrixAutoUpdate = false;
		shelfGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(0, -yOffset, -depth));

		let mesh = new THREE.Mesh(shelfGeom, mater);

		return mesh;
	};

	this.Generate = function ()
	{
		if (this.regenerate && this.wall && this.wall.matrix)
		{
			this.GetTextures();

			////if (TexturesDataUtilities.TextureLoaded(this.shelfTexture))
			{
				if (this.buttonData.shelves_data_yoffset && this.buttonData.shelves_data_yoffset.length)
				{
					this.mesh = new THREE.Mesh();

					let shelfCount = this.buttonData.shelves_data_yoffset.length;

					let shelfThickness, shelfDepth;

					this.buttonData.shelves_data_depth = MathUtilities.ConvertArrayToNumber(this.buttonData.shelves_data_depth);
					this.buttonData.shelves_data_thickness = MathUtilities.ConvertArrayToNumber(this.buttonData.shelves_data_thickness);
					this.buttonData.shelves_data_yoffset = MathUtilities.ConvertArrayToNumber(this.buttonData.shelves_data_yoffset);

					for (let i = 0; i < shelfCount; i++)
					{
						if (this.buttonData.shelves_data_thickness)
						{
							shelfThickness = this.buttonData.shelves_data_thickness[i];
							this.buttonData.thickness = this.buttonData.shelves_data_thickness[0] + this.buttonData.shelves_data_yoffset[shelfCount - 1];
						}
						else
							shelfThickness = this.buttonData.thickness;

						if (this.buttonData.shelves_data_depth)
							shelfDepth = this.buttonData.shelves_data_depth[i];
						else
							shelfDepth = this.buttonData.depth;

						this.shelfMesh = this.AddShelfComponent(this.buttonData.width, shelfThickness, shelfDepth, this.buttonData.shelves_data_yoffset[i]);

						this.mesh.add(this.shelfMesh);
					}

					this.mesh = MeshUtilities.MergeMeshGeometry(this.mesh);

					this.mesh.geometry.matrixAutoUpdate = false;
					this.mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-this.buttonData.width / 2, this.buttonData.thickness / 2 - this.buttonData.shelves_data_thickness[0], -Wall.WALLTHICKNESS));
				}
				else
				{
					this.mesh = this.AddShelfComponent(this.buttonData.width, this.buttonData.thickness, this.buttonData.depth, 0);
					this.mesh.geometry.matrixAutoUpdate = false;
					this.mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-this.buttonData.width / 2, -this.buttonData.thickness / 2, -Wall.WALLTHICKNESS));
				}

				MeshUtilities.SetElement(this.mesh, this);

				this.mesh.castShadow = false;

				this.mesh.visible = true;

				if (this.selected)
				{
					this.GenerateSelectedBoxes(this.mesh, new THREE.Matrix4().makeTranslation(0, 0, -this.buttonData.depth / 2 - SEL_BOX_SIZE / 2));
				}
			}

			this.UpdateMatrix();

			this.regenerate = false;
		}

		return this.mesh;
	};

	this.UpdateMatrix = function ()
	{
		if (this.mesh && this.wall.matrix)
		{
			let matrix;

			if (this.facetIndex != undefined && this.facetIndex != null && this.wall.wallFacets[this.facetIndex])
				matrix = this.wall.wallFacets[this.facetIndex].matrix.clone();
			else
				matrix = new THREE.Matrix4();

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z));

			if (this.wall.eWall == WALL_LEFT || this.wall.eWall == WALL_BACK)
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationY(-MathUtilities.PI));

			this.mesh.matrix = new THREE.Matrix4();
			this.mesh.matrixAutoUpdate = false;
			this.mesh.applyMatrix4(matrix);

			if (this.selected)
			{
				if (this.dragging)
				{
					Elements.ProcessCollisions(this);
				}
			}
		}
	};

	this.GetMatrix = function ()
	{
		return this.mesh.matrix;
	};
}

Shelf.AddShelf = function (shelfButtonData)
{
	let element = new Shelf(shelfButtonData);

	Elements.AddElement(element);

	return element;
};


// The correct place to call parent object is in child class constructor
// as we call it in above Student function code
Shelf.prototype = Object.create(Element.prototype);
// Set the "constructor" property to refer to Student
Shelf.prototype.constructor = Shelf;
