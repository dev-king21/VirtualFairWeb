/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/

function Roof()
{
	this.tileWidth = 0.7;

	this.horizontalProfilePts = null;
	this.verticalProfilePts = null;

	this.frontVisorHeightFromFloor = buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight;
	this.rearVisorHeightFromFloor = buildingDesigner.building.height - buildingDesigner.building.roofRafter.rearVisorHeight - buildingDesigner.building.roofRafter.frontBackHeightDifference;

	let roofExtraLength = Roof.ROOF_THICKNESS + Roof.TILE_THICKNESS;
	let roofExtraLengthYOffset = Math.sin(Math.atan(buildingDesigner.building.roofRafter.frontTanAngleRatio)) * roofExtraLength;

	this.connectionHeight = Math.tan(buildingDesigner.building.roofRafter.data.wall_roof_connection_angle * MathUtilities.RADIAN) * buildingDesigner.building.roofRafter.frontVisorWidth;


	let buildEngine = BuildingDesigner.GetBuildEngineCode(buildingDesigner.building.ID);

	if (buildingDesigner.building.roofRafter.data.bent_bow || (buildEngine != null && buildEngine.toLowerCase() == "barn"))
	{
		this.frontCornerTrimHeight -= roofExtraLengthYOffset;

		this.backCornerTrimHeight -= roofExtraLengthYOffset;
	}

	this.price = 0;

	this.tileTextureName = "";
	this.tileTexture = null;
	this.tileMater = null;

	this.tileColor = null;

	this.roofTextureName = "";
	this.roofTexture = null;
	this.roofMater = null;
	this.roofColor = 0xFFFFFF;

	this.eveTrimColorID = null;

	this.eveTrimColor = "rgb(222,222,222)";
	this.eveTrimMater = new THREE.MeshStandardMaterial({
		color: this.eveTrimColor,
		map: null,
		roughness: 1.0,
		metalness: METALNESS
	});

	this.cornerTrimColorID = null;

	this.cornerTrimColor = "rgb(222,222,222)";
	this.cornerTrimMater = new THREE.MeshStandardMaterial({
		color: this.cornerTrimColor,
		map: null,
		roughness: 1.0,
		metalness: METALNESS
	});

	this.trimColor = "rgb(222,222,222)";
	this.trimMater = new THREE.MeshStandardMaterial({
		color: this.trimColor,
		map: null,
		roughness: 1.0,
		metalness: METALNESS
	});

	let trimShadowMater = new THREE.MeshStandardMaterial({
		color: 0x222222,
		map: null,
		emissive: 0x222222,
		metalness: METALNESS
	});

	this.roofMesh = new THREE.Mesh();
	this.trimMeshes = new THREE.Mesh();

	this.regenerate = true;

	this.GetTextures = function ()
	{
		this.tileTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.tileTextureName, 1, 1);

		if (!MetalBuildingRoof.IsMetalBuildingRoof())
			this.tileMater = new THREE.MeshStandardMaterial({
				color: this.tileColor,
				map: TexturesDataUtilities.TextureLoaded(this.tileTexture),
				roughness: 1.0,
				metalness: METALNESS
			});
		else
			this.tileMater = new THREE.MeshPhongMaterial({
				color: this.tileColor,
				specular: 0x010101,
				shininess: 70,
				map: TexturesDataUtilities.TextureLoaded(this.tileTexture)
			});

		this.tileMater = new THREE.MeshStandardMaterial({
			color: this.tileColor,
			map: TexturesDataUtilities.TextureLoaded(this.tileTexture),
			roughness: 1.0,
			metalness: METALNESS
		});

		this.roofTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.roofTextureName, 1, 1);

		this.roofMater = new THREE.MeshStandardMaterial({
			color: this.roofColor,
			map: TexturesDataUtilities.TextureLoaded(this.roofTexture),
			roughness: 1.0,
			metalness: METALNESS
		});
	};

	this.SetCategoryID = function (categoryID)
	{
		this.categoryID = categoryID;
	};

	this.SetColorID = function (colorID)
	{
		this.colorID = colorID;

		let colorData = ColorsDataUtilities.FindColor(this.colorID);

		if (colorData)
			this.tileColor = colorData.color;
		else
			this.tileColor = null;
	};

	this.SetTileTextureName = function (textureName)
	{
		this.tileTextureName = textureName;
	};

	this.SetRoofTextureName = function (textureName)
	{
		this.roofTextureName = textureName;
	};


	this.SetRoofTextureName("techshield-16in-tile");

	this.SetTileTextureName("gafbr_f1.38x1.38");

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.GeneratePlankFromPoints = function (trimPoints, thickness, trimMater)
	{
		if (!trimMater)
			trimMater = this.trimMater;

		let extrudeSettings = {
			depth: thickness,
			steps: 1,
			material: 1,
			extrudeMaterial: 0,
			bevelEnabled: false,
		};

		let mesh = MeshUtilities.CreateMeshFromCrossSectionPoints(trimPoints, trimPoints, trimMater, extrudeSettings, 0, 0, 0);

		return mesh;
	};

	this.CreateCornerTrim = function (height, width_left_right, width_front_back, thickness)
	{
		let cornerTrim = new THREE.Mesh();

		let xAxisTrimBoard = GeometryUtilities.CreateBoxMesh(width_left_right, height, thickness, this.cornerTrimColor, null);
		cornerTrim.add(xAxisTrimBoard);

		let zAxisTrimBoard = GeometryUtilities.CreateBoxMesh(thickness, height, width_front_back, this.cornerTrimColor, null);
		zAxisTrimBoard.matrixAutoUpdate = false;
		zAxisTrimBoard.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -width_front_back));

		cornerTrim.add(zAxisTrimBoard);

		cornerTrim.castShadow = true;
		cornerTrim.receiveShadow = true;

		return cornerTrim;
	};

	this.CreateCurvedConnectionTrim = function (side, shadow)
	{
		let curvedConnectionTrim = new THREE.Mesh();

		let curveInnerRadiusX = buildingDesigner.building.roofRafter.frontVisorWidth - Wall.WALLTHICKNESS - Trim.CORNER_TRIM_THICKNESS;

		let curveInnerRadiusY = this.connectionHeight - Wall.WALLTHICKNESS;

		let connectionCurvePoints1 = GeometryUtilities.GenerateCurve(curveInnerRadiusX, curveInnerRadiusY);

		let connectionCurvePoints2 = GeometryUtilities.GenerateCurve(curveInnerRadiusX + BOARD_2x4_WIDTH, curveInnerRadiusY + BOARD_2x4_WIDTH);

		connectionCurvePoints2 = AuxUtilities.ReverseArray(connectionCurvePoints2);

		connectionCurvePoints1 = AuxUtilities.MergeArrays(connectionCurvePoints1, connectionCurvePoints2);

		connectionCurvePoints1 = GeometryUtilities.TranslatePoints(connectionCurvePoints1, -curveInnerRadiusX - Wall.WALLTHICKNESS - Trim.CORNER_TRIM_THICKNESS, 0);

		let curvedConnectionTrimSide = this.GeneratePlankFromPoints(connectionCurvePoints1, Trim.CORNER_TRIM_THICKNESS, this.cornerTrimMater);

		let matrix;

		if (shadow)
		{
			let curvedConnectionTrimShadow = this.GeneratePlankFromPoints(connectionCurvePoints1, 0.01, trimShadowMater);

			matrix = new THREE.Matrix4().makeTranslation(BOARD_2x4_WIDTH * 0.1, 0, 0);
			curvedConnectionTrimShadow.matrixAutoUpdate = false;
			curvedConnectionTrimShadow.applyMatrix4(matrix);

			curvedConnectionTrimSide.add(curvedConnectionTrimShadow);
		}

		curvedConnectionTrim.add(curvedConnectionTrimSide);

		curveInnerRadiusY = this.connectionHeight - Wall.WALLTHICKNESS;

		connectionCurvePoints1 = GeometryUtilities.GenerateCurve(curveInnerRadiusX, curveInnerRadiusY);

		connectionCurvePoints2 = GeometryUtilities.GenerateCurve(curveInnerRadiusX + Trim.CORNER_TRIM_THICKNESS, curveInnerRadiusY + Trim.CORNER_TRIM_THICKNESS);

		connectionCurvePoints2 = AuxUtilities.ReverseArray(connectionCurvePoints2);

		connectionCurvePoints1 = AuxUtilities.MergeArrays(connectionCurvePoints1, connectionCurvePoints2);

		connectionCurvePoints1 = GeometryUtilities.TranslatePoints(connectionCurvePoints1, -curveInnerRadiusX - Wall.WALLTHICKNESS - Trim.CORNER_TRIM_THICKNESS, 0);

		let curvedConnectionTrimFront = this.GeneratePlankFromPoints(connectionCurvePoints1, Trim.CORNER_TRIM_THICKNESS, this.cornerTrimMater);

		matrix = new THREE.Matrix4().makeTranslation(0, 0, side == RIGHT ? -Trim.CORNER_TRIM_THICKNESS : Trim.CORNER_TRIM_THICKNESS);
		curvedConnectionTrimFront.matrixAutoUpdate = false;
		curvedConnectionTrimFront.applyMatrix4(matrix);

		curvedConnectionTrim.add(curvedConnectionTrimFront);

		return curvedConnectionTrim;
	};

	this.CreateTrimOrSoffitBoard = function (side, width, height, length, angle)
	{
		let soffitBoard;

		switch (side)
		{
		case (FRONT):
		case (BACK):
			soffitBoard = GeometryUtilities.CreateOrientatedBox(width, height, length, this.eveTrimColor, null, null, null, null, 0, 0, -angle);
			break;

		case (RIGHT):
		case (LEFT):
			if (width)
			{
				soffitBoard = GeometryUtilities.CreateOrientatedBox(width, height, length, this.eveTrimColor, null, null, null, null, 0, 0, -angle);
			}
			else
			{
				let soffitBoardPoints = GeometryUtilities.GetSurfacePoints(buildingDesigner.building.roofRafter.data.rafter_spec, buildingDesigner.building.roofRafter.sideCoordsIndices[0][1], buildingDesigner.building.roofRafter.sideCoordsIndices[1][1], -height, Roof.VERTICAL_TRIM);

				soffitBoardPoints = AuxUtilities.ReverseArray(soffitBoardPoints);

				soffitBoard = this.GeneratePlankFromPoints(soffitBoardPoints, length, this.eveTrimMater);
			}
			break;
		}

		return soffitBoard;
	};

	this.CreateVerticalTrim = function ()
	{
		let verticalTrimMeshes = new THREE.Mesh();

		let frontRightTrim = this.CreateCornerTrim(this.frontCornerTrimHeight, Trim.CORNER_TRIM_WIDTH_ENDS, Trim.CORNER_TRIM_WIDTH_SIDES, Trim.CORNER_TRIM_THICKNESS);

		let trimShadowGeom = new THREE.BoxGeometry(BOARD_2x4_WIDTH, this.frontCornerTrimHeight, 0.01);

		trimShadowGeom.matrixAutoUpdate = false;
		trimShadowGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(BOARD_2x4_WIDTH * 0.6, this.frontCornerTrimHeight / 2, 0));

		let trimShadow = new THREE.Mesh(trimShadowGeom, trimShadowMater);

		frontRightTrim.add(trimShadow);

		trimShadowGeom = new THREE.BoxGeometry(0.01, this.frontCornerTrimHeight, BOARD_2x4_WIDTH);

		trimShadowGeom.matrixAutoUpdate = false;
		trimShadowGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(Trim.CORNER_TRIM_THICKNESS, this.frontCornerTrimHeight / 2 - Trim.CORNER_TRIM_THICKNESS / 2, -BOARD_2x4_WIDTH * 0.66));

		trimShadow = new THREE.Mesh(trimShadowGeom, trimShadowMater);

		frontRightTrim.add(trimShadow);

		let frontLeftTrim = this.CreateCornerTrim(this.frontCornerTrimHeight, Trim.CORNER_TRIM_WIDTH_ENDS, Trim.CORNER_TRIM_WIDTH_SIDES, Trim.CORNER_TRIM_THICKNESS);

		let backRightTrim = this.CreateCornerTrim(this.backCornerTrimHeight, Trim.CORNER_TRIM_WIDTH_ENDS, Trim.CORNER_TRIM_WIDTH_SIDES, Trim.CORNER_TRIM_THICKNESS);

		let backLeftTrim = this.CreateCornerTrim(this.backCornerTrimHeight, Trim.CORNER_TRIM_WIDTH_ENDS, Trim.CORNER_TRIM_WIDTH_SIDES, Trim.CORNER_TRIM_THICKNESS);

		this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - Trim.CORNER_TRIM_THICKNESS - Wall.WALLTHICKNESS, 0, buildingDesigner.building.walls.rightFrontWallCoord + Wall.WALLTHICKNESS);
		frontRightTrim.matrixAutoUpdate = false;
		frontRightTrim.applyMatrix4(this.matrix);

		verticalTrimMeshes.add(frontRightTrim);

		this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - Trim.CORNER_TRIM_THICKNESS - Wall.WALLTHICKNESS, this.frontCornerTrimHeight, buildingDesigner.building.walls.leftFrontWallCoord - Wall.WALLTHICKNESS), new THREE.Matrix4().makeRotationX(MathUtilities.PI));
		frontLeftTrim.matrixAutoUpdate = false;
		frontLeftTrim.applyMatrix4(this.matrix);

		verticalTrimMeshes.add(frontLeftTrim);

		this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + Wall.WALLTHICKNESS + Trim.CORNER_TRIM_THICKNESS, this.backCornerTrimHeight, buildingDesigner.building.walls.rightBackWallCoord + Wall.WALLTHICKNESS), new THREE.Matrix4().makeRotationZ(MathUtilities.PI));
		backRightTrim.matrixAutoUpdate = false;
		backRightTrim.applyMatrix4(this.matrix);

		verticalTrimMeshes.add(backRightTrim);

		this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + Wall.WALLTHICKNESS + Trim.CORNER_TRIM_THICKNESS, 0, buildingDesigner.building.walls.leftBackWallCoord - Wall.WALLTHICKNESS), new THREE.Matrix4().makeRotationY(MathUtilities.PI));
		backLeftTrim.matrixAutoUpdate = false;
		backLeftTrim.applyMatrix4(this.matrix);

		verticalTrimMeshes.add(backLeftTrim);

		if (buildingDesigner.building.porch && !buildingDesigner.building.porch.fullLength)
		{
			let porchInsetTrim = this.CreateCornerTrim(this.backCornerTrimHeight, Trim.CORNER_TRIM_WIDTH_ENDS, Trim.CORNER_TRIM_WIDTH_SIDES, Trim.CORNER_TRIM_THICKNESS);

			if (buildingDesigner.building.porch.length > 0)
			{
				if (buildingDesigner.building.porch.width > 0)
					this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + Wall.WALLTHICKNESS + Trim.CORNER_TRIM_THICKNESS - buildingDesigner.building.porch.length, this.backCornerTrimHeight, buildingDesigner.building.walls.rightFrontWallCoord + Wall.WALLTHICKNESS), new THREE.Matrix4().makeRotationZ(MathUtilities.PI));
				else
					this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + Wall.WALLTHICKNESS + Trim.CORNER_TRIM_THICKNESS - buildingDesigner.building.porch.length, 0, buildingDesigner.building.walls.leftFrontWallCoord - Wall.WALLTHICKNESS), new THREE.Matrix4().makeRotationY(MathUtilities.PI));
				////this.matrix = new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + Wall.WALLTHICKNESS + Trim.CORNER_TRIM_THICKNESS - buildingDesigner.building.porch.length, 0, buildingDesigner.building.walls.leftFrontWallCoord - Wall.WALLTHICKNESS);
			}
			else
			{
				if (buildingDesigner.building.porch.width > 0)
					////this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - Wall.WALLTHICKNESS - Trim.CORNER_TRIM_THICKNESS - buildingDesigner.building.porch.length, this.backCornerTrimHeight, buildingDesigner.building.walls.rightBackWallCoord + Wall.WALLTHICKNESS), new THREE.Matrix4().makeRotationZ(MathUtilities.PI));
					this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - Wall.WALLTHICKNESS - buildingDesigner.building.porch.length, 0, buildingDesigner.building.walls.rightBackWallCoord + Wall.WALLTHICKNESS), new THREE.Matrix4().makeRotationZ(0));
				else
					this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 + Wall.WALLTHICKNESS + Trim.CORNER_TRIM_THICKNESS - buildingDesigner.building.porch.length, 0, buildingDesigner.building.walls.leftBackWallCoord - Wall.WALLTHICKNESS), new THREE.Matrix4().makeRotationY(MathUtilities.PI));

				/*////this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + Wall.WALLTHICKNESS + Trim.CORNER_TRIM_THICKNESS - buildingDesigner.building.porch.length, this.backCornerTrimHeight, (buildingDesigner.building.porch.width > 0 ? buildingDesigner.building.walls.rightFrontWallCoord + Wall.WALLTHICKNESS : buildingDesigner.building.walls.leftFrontWallCoord - Wall.WALLTHICKNESS)), new THREE.Matrix4().makeRotationZ(MathUtilities.PI));
				else
				this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - Wall.WALLTHICKNESS - Trim.CORNER_TRIM_THICKNESS - buildingDesigner.building.porch.length, 0, (buildingDesigner.building.porch.width > 0 ? buildingDesigner.building.walls.rightBackWallCoord + Wall.WALLTHICKNESS : buildingDesigner.building.walls.leftBackWallCoord - Wall.WALLTHICKNESS));
				*/
			}

			porchInsetTrim.matrixAutoUpdate = false;
			porchInsetTrim.applyMatrix4(this.matrix);

			verticalTrimMeshes.add(porchInsetTrim);
		}


		if (buildingDesigner.building.roofRafter.data.wall_roof_connection_angle != 0 && buildingDesigner.building.roofRafter.data.curved_wall_roof_connection)
		{
			let curvedConnectionTrim = this.CreateCurvedConnectionTrim(RIGHT, true);

			this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2, this.frontCornerTrimHeight, buildingDesigner.building.length / 2);
			curvedConnectionTrim.matrixAutoUpdate = false;
			curvedConnectionTrim.applyMatrix4(this.matrix);

			verticalTrimMeshes.add(curvedConnectionTrim);

			curvedConnectionTrim = this.CreateCurvedConnectionTrim(LEFT);

			this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2, this.frontCornerTrimHeight, -buildingDesigner.building.length / 2 - Trim.CORNER_TRIM_THICKNESS);
			curvedConnectionTrim.matrixAutoUpdate = false;
			curvedConnectionTrim.applyMatrix4(this.matrix);

			verticalTrimMeshes.add(curvedConnectionTrim);
		}

		return verticalTrimMeshes;
	};

	this.CreateHorizontalTrim = function (frontOffsetX, rearOffsetX, rafterOffsetY, roofExtraLength, framingOffsetY)
	{
		if (framingOffsetY == undefined || framingOffsetY == null)
			framingOffsetY = 0;

		let horizontalTrimMeshes = new THREE.Mesh();

		let horizontalTrimWidthL = buildingDesigner.building.roofRafter.rafterVerticalWidthL + framingOffsetY;

		let horizontalTrimWidthR = buildingDesigner.building.roofRafter.rafterVerticalWidthR + framingOffsetY;

		if (horizontalTrimWidthL == 0)
			horizontalTrimWidthL = BOARD_2x4_WIDTH;

		if (horizontalTrimWidthR == 0)
			horizontalTrimWidthR = BOARD_2x4_WIDTH;

		let roofTrimWidth = horizontalTrimWidthR > horizontalTrimWidthL ? horizontalTrimWidthR : horizontalTrimWidthL;

		let hipRoof = Elements.GetElementsOfType(ELEM_HIP_ROOF);

		let buildEngine = BuildingDesigner.GetBuildEngineCode(buildingDesigner.building.ID);

		// Gable End Fascia Trim
		if (!hipRoof)
		{
			//Left and Right
			let sideAngle = Roof.VERTICAL_TRIM;

			if (buildingDesigner.building.roofRafter.data.bent_bow || (buildEngine != null && buildEngine.toLowerCase() == "barn"))
			{
				sideAngle = Roof.HORIZONTAL_TRIM;
			}

			let trimPoints;
			if (buildingDesigner.building.roofRafter.data.options && buildingDesigner.building.roofRafter.data.options.gable_trim)
			{
				trimPoints = buildingDesigner.building.roofRafter.data.options.gable_trim;
			}
			else
			{
				trimPoints = GeometryUtilities.GetSurfacePoints(buildingDesigner.building.roofRafter.data.rafter_spec, buildingDesigner.building.roofRafter.sideCoordsIndices[0][1], buildingDesigner.building.roofRafter.sideCoordsIndices[1][1], -roofTrimWidth, sideAngle);

				trimPoints = AuxUtilities.ReverseArray(trimPoints);
			}

			let rightTrim = this.GeneratePlankFromPoints(trimPoints, Trim.TRIM_THICKNESS, this.eveTrimMater);
			rightTrim.castShadow = true;

			let leftTrim = rightTrim.clone();


			let overhangLessTrimAndExtraLength = buildingDesigner.building.roofRafter.data.roof_overhang - roofExtraLength - Trim.TRIM_THICKNESS;

			this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height + rafterOffsetY + framingOffsetY, this.length / 2 - Trim.TRIM_THICKNESS - roofExtraLength + (overhangLessTrimAndExtraLength < 0 ? -overhangLessTrimAndExtraLength + 0.01 : 0));
			rightTrim.matrixAutoUpdate = false;
			rightTrim.applyMatrix4(this.matrix);

			// Gable End Fascia Trim
			horizontalTrimMeshes.add(rightTrim);

			this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height + rafterOffsetY + framingOffsetY, -this.length / 2 + roofExtraLength - (overhangLessTrimAndExtraLength < 0 ? -overhangLessTrimAndExtraLength + 0.01 : 0));
			leftTrim.matrixAutoUpdate = false;
			leftTrim.applyMatrix4(this.matrix);

			// Gable End Fascia Trim
			horizontalTrimMeshes.add(leftTrim);
		}
		else
		{
			let rightTrim = GeometryUtilities.CreateBoxMesh(buildingDesigner.building.width + buildingDesigner.building.roofRafter.frontVisorWidth + buildingDesigner.building.roofRafter.rearVisorWidth, horizontalTrimWidthL, Trim.TRIM_THICKNESS, this.eveTrimColor, null);

			rightTrim.castShadow = true;

			let leftTrim = rightTrim.clone();

			this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height + rafterOffsetY, this.length / 2 - Trim.TRIM_THICKNESS - roofExtraLength);
			rightTrim.matrixAutoUpdate = false;
			rightTrim.applyMatrix4(this.matrix);

			horizontalTrimMeshes.add(rightTrim);

			this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height + rafterOffsetY, -this.length / 2 + roofExtraLength);
			leftTrim.matrixAutoUpdate = false;
			leftTrim.applyMatrix4(this.matrix);

			horizontalTrimMeshes.add(leftTrim);
		}

		//Front and Back (Eve Fascia Trim)
		if (!buildingDesigner.building.roofRafter.data.bent_bow && (buildEngine == undefined || buildEngine == null || buildEngine.toLowerCase() != "barn" || buildingDesigner.building.ID.indexOf("glenwood")))
		{
			let frontTrimOffsetx = frontOffsetX;

			if (frontTrimOffsetx < Trim.TRIM_THICKNESS && (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_FRONT).style == CarportWall.OPEN))
				frontTrimOffsetx = Trim.TRIM_THICKNESS;

			let rearTrimOffsetx = rearOffsetX;

			if (rearTrimOffsetx < Trim.TRIM_THICKNESS && (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_BACK).style == CarportWall.OPEN))
				rearTrimOffsetx = Trim.TRIM_THICKNESS;

			let trimLength = this.length;

			let trimZPos = trimLength / 2;

			if (buildingDesigner.building.roofRafter.data.roof_overhang < Trim.TRIM_THICKNESS)
			{
				let lengthDelta = Trim.TRIM_THICKNESS;

				if (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_LEFT).style == CarportWall.OPEN)
				{
					trimLength += lengthDelta;
				}

				if (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_RIGHT).style == CarportWall.OPEN)
				{
					trimLength += lengthDelta;
				}

				trimZPos = trimLength / 2;


				if (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_LEFT).style == CarportWall.OPEN)
				{
					trimZPos += (lengthDelta / 2);
				}

				if (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_RIGHT).style == CarportWall.OPEN)
				{
					trimZPos -= (lengthDelta / 2);
				}
			}

			let yOffsetForTrimThicknessFront = Trim.TRIM_THICKNESS * buildingDesigner.building.roofRafter.frontTanAngleRatio;

			let frontTrim = GeometryUtilities.CreateBoxMesh(this.length - roofExtraLength * 2, horizontalTrimWidthL - yOffsetForTrimThicknessFront, Trim.TRIM_THICKNESS, this.eveTrimColor, null);
			frontTrim.castShadow = true;

			let backTrim = frontTrim.clone();

			let frontTrimOffsetY = nestedObj(buildingDesigner.building.roofRafter.data,"options.front_trim_offset_y") || 0;

			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight + buildingDesigner.building.roofRafter.rafterVerticalWidthL - horizontalTrimWidthL + framingOffsetY, -this.length / 2 + roofExtraLength), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));

			frontTrim.matrixAutoUpdate = false;
			frontTrim.applyMatrix4(this.matrix);
			if (!(buildingDesigner.buildingButtonData.options && buildingDesigner.buildingButtonData.options.eve_fascia_off))
			{
				horizontalTrimMeshes.add(frontTrim);
			}
			let rearTrimOffsetY = nestedObj(buildingDesigner.building.roofRafter.data,"options.rear_trim_offset_y") || 0;

			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + rearOffsetX + Trim.TRIM_THICKNESS, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontBackHeightDifference - buildingDesigner.building.roofRafter.rearVisorHeight + buildingDesigner.building.roofRafter.rafterVerticalWidthR - horizontalTrimWidthR + framingOffsetY + rearTrimOffsetY, -this.length / 2 + roofExtraLength), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));

			backTrim.matrixAutoUpdate = false;
			backTrim.applyMatrix4(this.matrix);
			if (!(buildingDesigner.buildingButtonData.options && buildingDesigner.buildingButtonData.options.eve_fascia_off))
			{
				horizontalTrimMeshes.add(backTrim);
			}
		}

		horizontalTrimMeshes.castShadow = true;
		horizontalTrimMeshes.receiveShadow = true;

		horizontalTrimMeshes.type = ELEM_ROOFING;

		return horizontalTrimMeshes;
	};

	this.CreateRoofContainerGeometry = function (buildingMeshes)
	{
		let apexCoordsIndices = buildingDesigner.building.roofRafter.GetApexCoordIndices();

		let extendedSurface = GeometryUtilities.GenerateExtendedSurface(buildingDesigner.building.roofRafter.data.rafter_spec, buildingDesigner.building.roofRafter.sideCoordsIndices[0][1], apexCoordsIndices[0], Roof.ROOF_THICKNESS + Roof.TILE_THICKNESS);

		let roofPoints = GeometryUtilities.GetSurfacePoints(extendedSurface, 0, extendedSurface.length - 1, Roof.ROOF_THICKNESS + Roof.TILE_THICKNESS, Roof.ANGLED_TRIM, false);

		roofPoints = AuxUtilities.ReverseArray(roofPoints);

		roofPoints.push([roofPoints[roofPoints.length - 1][0], roofPoints[0][1]]);

		let length = this.length * 2;

		let extrudeSettings = {
			depth: length,
			steps: 1,
			material: 1,
			extrudeMaterial: 0,
			bevelEnabled: false,
		};

		let frontRafteroffsetx = 0;
		let rafterOffsetY = 0;

		if (buildingDesigner.building.roofRafter.data.front_wall_attach_coord != "")
		{
			frontRafteroffsetx = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0];

			if (!buildingDesigner.building.roofRafter.leanToRafter)
				frontRafteroffsetx = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0];
			else
				frontRafteroffsetx = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0] - buildingDesigner.building.roofRafter.data.width;

			rearRafteroffsetx = buildingDesigner.building.roofRafter.width - buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[1][0];

			rafterOffsetY = -buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1];
		}

		//Roof mesh
		let roofContainer = MeshUtilities.CreateMeshFromCrossSectionPoints(roofPoints, roofPoints, this.roofMater, extrudeSettings, 0, 0, 0);

		roofContainer.geometry.matrixAutoUpdate = false;
		roofContainer.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontRafteroffsetx, buildingDesigner.building.height + rafterOffsetY, -length / 2));
		roofContainer.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
		roofContainer.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, buildingDesigner.building.roofRafter.frontVisorWidth));

		return roofContainer;
	};

	this.CreateRoofSubtractContainerGeometry = function (width, length, height)
	{
		let w2 = width / 2;

		let subtractShape = new THREE.Shape(
			[{
				x: -w2,
				y: 0
			},
			{
				x: 0,
				y: length
			},
			{
				x: w2,
				y: 0
			},
			]
		);

		let subtractGeom = new THREE.ExtrudeGeometry(subtractShape, {
			depth: height,
			bevelEnabled: false
		});

		subtractGeom.computeFaceNormals();

		let subtractMater = new THREE.MeshStandardMaterial({
			color: 0xFFFFFF,
			metalness: METALNESS
		});

		this.containerMesh = new THREE.Mesh(subtractGeom, subtractMater);

		return this.containerMesh;
	};

	/**
 	* Gneerates a 3D profile tile mesh from the provided surface with the specified extrude settings and placed at the specified x, y, z coordinate
 	* @function
 	* @param {[[,]]} surface
 	* @param {Object} extrudeSettings
 	* @param {number} x
 	* @param {number} y
 	* @param {number} z
 	* @returns {THREE.Mesh}
 	*/
	this.GenerateTileMeshFromSurface = function (surface, extrudeSettings, x, y, z)
	{
		let tileMesh;

		let newProfilePoints = null;

		let texRot90 = this.data.roof_style != Roof.VERTICAL_ROOF;

		let segmentLength;

		let l2 = GeometryUtilities.GetSurfaceLength(surface) / 2;

		if (this.horizontalProfilePts)
		{
			let newHorizontalProfilePts = AuxUtilities.ReverseArray(this.horizontalProfilePts);

			segmentLength = this.horizontalProfilePts[this.horizontalProfilePts.length - 1][0];

			for (let i = 0; i < newHorizontalProfilePts.length; i++)
			{
				newHorizontalProfilePts[i][0] = segmentLength - newHorizontalProfilePts[i][0];
			}

			if (!buildingDesigner.building.roofRafter.leanToRafter)
			{
				newProfilePoints = ProfileUtilities.Increaselength(newHorizontalProfilePts, l2, true);

				newProfilePoints.pop();

				let newProfilePoints2 = ProfileUtilities.Increaselength(newHorizontalProfilePts, l2, false, l2);

				newProfilePoints = AuxUtilities.MergeArrays(newProfilePoints, newProfilePoints2);
			}
			else
				newProfilePoints = ProfileUtilities.Increaselength(newHorizontalProfilePts, l2 * 2, false);


			newProfilePoints = ProfileUtilities.IncreaseResolutionForSurface(newProfilePoints, surface);
		}
		else
		{
			newProfilePoints = [
				[0, 0.0001],
				[l2, 0.0001]
			];
		}

		tileMesh = new THREE.Mesh();

		let newZYThicknessProfilePts;

		if (this.verticalProfilePts)
		{
			newZYThicknessProfilePts = ProfileUtilities.Increaselength(this.verticalProfilePts, extrudeSettings.depth);
		}
		else
		{
			newZYThicknessProfilePts = [
				[0, 0.0001],
				[extrudeSettings.depth, 0.0001]
			];
		}

		let i = newZYThicknessProfilePts.length - 1;

		let useSurfaceAsBase = !this.data.metal_roof;

		let tileThickness = MetalBuildingRoof.IsMetalBuildingRoof() ? Roof.METAL_ROOF_THICKNESS : Roof.TILE_THICKNESS;

		let frontTilePoints = GeometryUtilities.GetSurfacePointsUsingProfile(surface, 0, surface.length - 1, newZYThicknessProfilePts[i][1], Roof.ANGLED_TRIM, false, newProfilePoints, useSurfaceAsBase, tileThickness);

		let backTilePoints;
		i--;

		let tileSegmentMesh;

		let frontSideClosed, backSideClosed;

		let totalSegmentLength = 0;

		while (i >= 0)
		{
			segmentLength = newZYThicknessProfilePts[i + 1][0] - newZYThicknessProfilePts[i][0];

			totalSegmentLength += segmentLength;

			backTilePoints = GeometryUtilities.GetSurfacePointsUsingProfile(surface, 0, surface.length - 1, newZYThicknessProfilePts[i][1], Roof.ANGLED_TRIM, false, newProfilePoints, useSurfaceAsBase, tileThickness);

			extrudeSettings.depth = segmentLength;


			if (MetalBuildingRoof.IsMetalBuildingRoof())
			{
				frontSideClosed = 0;

				backSideClosed = 0;
			}
			else
			{
				frontSideClosed = (i == (newZYThicknessProfilePts.length - 2));

				backSideClosed = i == 0;
			}

			tileSegmentMesh = MeshUtilities.CreateMeshFromCrossSectionPoints(frontTilePoints, backTilePoints, this.tileMater, extrudeSettings, x, y, z - totalSegmentLength, texRot90, frontSideClosed, backSideClosed);

			tileMesh.add(tileSegmentMesh);

			frontTilePoints = backTilePoints;

			i--;
		}

		if (this.hipRoof)
			tileMesh = MeshUtilities.MergeMeshGeometry(tileMesh);

		tileMesh.castShadow = true;

		return tileMesh;
	};


	this.GenerateTileProfileSectionMesh = function (width, length)
	{
		let extendedSurface = [[0,0],[width, 0]];

		let extrudeSettings = {
			depth: length,
			steps: 1,
			material: 1,
			extrudeMaterial: 0,
			bevelEnabled: false,
		};

		let tileProfileSection = this.GenerateTileMeshFromSurface(extendedSurface, extrudeSettings, 0, 0, 0);

		tileProfileSection = MeshUtilities.MergeMeshGeometry(tileProfileSection);

		return tileProfileSection;
	}


	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			this.Destroy();

			this.GetTextures();

			if (!this.eveTrimColor)
			{
				this.SetEveTrimColor(this.eveTrimColorID);
			}

			if (!this.cornerTrimColor)
			{
				this.SetCornerTrimColor(this.cornerTrimColorID);
			}

			////if (TexturesDataUtilities.TextureLoaded(this.roofTexture) && TexturesDataUtilities.TextureLoaded(this.tileTexture))
			{
				let hipRoof = Elements.GetElementsOfType(ELEM_HIP_ROOF);

				if (hipRoof)
				{
					this.hipRoof = true;
				}

				this.length = buildingDesigner.building.length + buildingDesigner.building.roofRafter.data.roof_overhang * 2;

				this.frontVisorHeightFromFloor = buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight;
				this.rearVisorHeightFromFloor = buildingDesigner.building.height - buildingDesigner.building.roofRafter.rearVisorHeight - buildingDesigner.building.roofRafter.frontBackHeightDifference;


				if (!buildingDesigner.building.roofRafter.leanToRafter)
				{
					this.frontCornerTrimHeight = this.frontVisorHeightFromFloor - this.connectionHeight;
				}
				else
				{
					this.frontCornerTrimHeight = buildingDesigner.building.height;
				}

				this.backCornerTrimHeight = this.rearVisorHeightFromFloor;

				let frontRafteroffsetx = 0;
				let rafterOffsetY = 0;

				if (buildingDesigner.building.roofRafter.data.front_wall_attach_coord != "")
				{
					frontRafteroffsetx = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0];

					if (!buildingDesigner.building.roofRafter.leanToRafter)
						frontRafteroffsetx = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0];
					else
						frontRafteroffsetx = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0] - buildingDesigner.building.roofRafter.data.width;

					rearRafteroffsetx = buildingDesigner.building.roofRafter.width - buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[1][0];

					rafterOffsetY = -buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1];
				}

				let extrudeSettings = {
					depth: this.length,
					steps: 1,
					material: 1,
					extrudeMaterial: 0,
					bevelEnabled: false,
				};

				let extendedSurface = GeometryUtilities.GenerateExtendedSurface(buildingDesigner.building.roofRafter.data.rafter_spec, buildingDesigner.building.roofRafter.sideCoordsIndices[0][1], buildingDesigner.building.roofRafter.sideCoordsIndices[1][1], Roof.ROOF_THICKNESS);

				let roof;

				if (!buildingDesigner.building.roofRafter.data.bent_bow && !nestedObj(this,"data.metal_roof"))
				{
					let roofPoints = GeometryUtilities.GetSurfacePoints(extendedSurface, 0, extendedSurface.length - 1, Roof.ROOF_THICKNESS, Roof.ANGLED_TRIM);

					//Roof mesh
					roof = MeshUtilities.CreateMeshFromCrossSectionPoints(roofPoints, roofPoints, this.roofMater, extrudeSettings, -buildingDesigner.building.roofRafter.wallWidth / 2 - frontRafteroffsetx, buildingDesigner.building.height + rafterOffsetY, -this.length / 2);
					roof.castShadow = true;

					extendedSurface = GeometryUtilities.GenerateExtendedSurface(roofPoints, 0, roofPoints.length / 2 - 1, Roof.TILE_THICKNESS);
				}

				let roofExtraLength = 0;

				if (!buildingDesigner.building.roofRafter.leanToRafter)
				{
					roofExtraLength = buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[0][1]][0] - extendedSurface[0][0];
				}
				else
				{
					roofExtraLength = Roof.ROOF_THICKNESS + Roof.TILE_THICKNESS;
				}

				let tile = this.GenerateTileMeshFromSurface(extendedSurface, extrudeSettings, -buildingDesigner.building.roofRafter.wallWidth / 2 - frontRafteroffsetx, buildingDesigner.building.height - buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1], this.length / 2);
				tile = MeshUtilities.MergeMeshGeometry(tile);

				MeshUtilities.SetMeshCastReceiveShadow(tile, true, false);

				if (this.hipRoof)
				{
					let roofExtraHeight = (Roof.ROOF_THICKNESS + Roof.TILE_THICKNESS) / Math.sin(MathUtilities.PI2 - Math.atan(buildingDesigner.building.roofRafter.frontTanAngleRatio));

					let subtractGeomHeight = buildingDesigner.building.roofRafter.apexHeight + roofExtraHeight + buildingDesigner.building.roofRafter.frontVisorHeight + roofExtraLength * 2;

					let apexCoordsIndices = buildingDesigner.building.roofRafter.GetApexCoordIndices();

					let roofRafterApexOffset = buildingDesigner.building.roofRafter.data.rafter_spec[apexCoordsIndices[0]][0] - buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[0][1]][0] - buildingDesigner.building.width / 2;

					let subtractGeomLength = buildingDesigner.building.width / 2 + roofRafterApexOffset + roofExtraLength;

					let roofContainer = this.CreateRoofSubtractContainerGeometry(buildingDesigner.building.width + (roofExtraLength) * 2 + buildingDesigner.building.roofRafter.frontVisorWidth + buildingDesigner.building.roofRafter.rearVisorWidth, subtractGeomLength, subtractGeomHeight);

					let roofSubtractContainer = roofContainer.clone();
					roofSubtractContainer.geometry = roofContainer.geometry.clone();

					roofSubtractContainer.geometry.matrixAutoUpdate = false;
					roofSubtractContainer.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(MathUtilities.PI2));
					roofSubtractContainer.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.height + subtractGeomHeight - buildingDesigner.building.roofRafter.frontVisorHeight + buildingDesigner.building.roofRafter.rafterVerticalWidthL - roofExtraLength - buildingDesigner.building.roofRafter.rafterVerticalWidthL, -this.length / 2));

					MeshUtilities.CSGMeshWithMeshes(buildingMeshes, roofSubtractContainer, -1, ELEM_ROOF_RAFTER, MeshUtilities.SubtractMesh);

					roof = MeshUtilities.SubtractMesh(roof, roofSubtractContainer);
					tile = MeshUtilities.SubtractMesh(tile, roofSubtractContainer);

					roofSubtractContainer.geometry = roofContainer.geometry.clone();

					roofSubtractContainer.geometry.matrixAutoUpdate = false;
					roofSubtractContainer.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(-MathUtilities.PI2));
					roofSubtractContainer.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight + buildingDesigner.building.roofRafter.rafterVerticalWidthL - roofExtraLength, this.length / 2));


					MeshUtilities.CSGMeshWithMeshes(buildingMeshes, roofSubtractContainer, -1, ELEM_ROOF_RAFTER, MeshUtilities.SubtractMesh);

					roof = MeshUtilities.SubtractMesh(roof, roofSubtractContainer);
					tile = MeshUtilities.SubtractMesh(tile, roofSubtractContainer);

					let roofIntersectContainer = roofContainer.clone();
					roofIntersectContainer.geometry = roofContainer.geometry.clone();

					roofIntersectContainer.geometry.matrixAutoUpdate = false;
					roofIntersectContainer.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(MathUtilities.PI2));
					roofIntersectContainer.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(MathUtilities.PI2));
					roofIntersectContainer.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.width / 2 - roofExtraLength, buildingDesigner.building.height + subtractGeomHeight - buildingDesigner.building.roofRafter.frontVisorHeight, 0));

					let intersectRaftersLeftMeshes = [];

					MeshUtilities.CloneMeshes(buildingMeshes, intersectRaftersLeftMeshes);

					MeshUtilities.CSGMeshWithMeshes(intersectRaftersLeftMeshes, roofIntersectContainer, -1, ELEM_ROOF_RAFTER, MeshUtilities.IntersectMesh);

					let intersectRaftersLeftMesh = MeshUtilities.MergeMeshes(intersectRaftersLeftMeshes, ELEM_ROOF_RAFTER);

					intersectRaftersLeftMesh.geometry.matrixAutoUpdate = false;
					intersectRaftersLeftMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(subtractGeomLength - roofRafterApexOffset, 0, 0));
					intersectRaftersLeftMesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
					intersectRaftersLeftMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -this.length / 2 + roofRafterApexOffset));

					this.roofMesh.add(intersectRaftersLeftMesh);

					let intersectRaftersRightMeshes = [];

					MeshUtilities.CloneMeshes(buildingMeshes, intersectRaftersRightMeshes);

					MeshUtilities.CSGMeshWithMeshes(intersectRaftersRightMeshes, roofIntersectContainer, -1, ELEM_ROOF_RAFTER, MeshUtilities.IntersectMesh);

					let intersectRaftersRightMesh = MeshUtilities.MergeMeshes(intersectRaftersRightMeshes, ELEM_ROOF_RAFTER);

					intersectRaftersRightMesh.geometry.matrixAutoUpdate = false;
					intersectRaftersRightMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(subtractGeomLength - roofRafterApexOffset, 0, 0));
					intersectRaftersRightMesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(MathUtilities.PI2));
					intersectRaftersRightMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, this.length / 2 - roofRafterApexOffset));

					this.roofMesh.add(intersectRaftersRightMesh);

					let intersectRoofLeft = MeshUtilities.IntersectMesh(roof, roofIntersectContainer);
					let intersectTileLeft = MeshUtilities.IntersectMesh(tile, roofIntersectContainer);

					intersectRoofLeft.castShadow = true;
					intersectTileLeft.castShadow = true;


					intersectRoofLeft.geometry.matrixAutoUpdate = false;
					intersectRoofLeft.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(subtractGeomLength - roofRafterApexOffset, 0, 0));
					intersectRoofLeft.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
					intersectRoofLeft.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -this.length / 2 + roofRafterApexOffset));


					intersectTileLeft.geometry.matrixAutoUpdate = false;
					intersectTileLeft.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(subtractGeomLength - roofRafterApexOffset, 0, 0));
					intersectTileLeft.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
					intersectTileLeft.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -this.length / 2 + roofRafterApexOffset));


					this.roofMesh.add(intersectRoofLeft);
					this.roofMesh.add(intersectTileLeft);


					let intersectRoofRight = MeshUtilities.IntersectMesh(roof, roofIntersectContainer);
					let intersectTileRight = MeshUtilities.IntersectMesh(tile, roofIntersectContainer);

					intersectRoofRight.castShadow = true;
					intersectTileRight.castShadow = true;

					intersectRoofRight.geometry.matrixAutoUpdate = false;
					intersectRoofRight.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(subtractGeomLength - roofRafterApexOffset, 0, 0));
					intersectRoofRight.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(MathUtilities.PI2));
					intersectRoofRight.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, this.length / 2 - roofRafterApexOffset));

					intersectTileRight.geometry.matrixAutoUpdate = false;
					intersectTileRight.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(subtractGeomLength - roofRafterApexOffset, 0, 0));
					intersectTileRight.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(MathUtilities.PI2));
					intersectTileRight.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, this.length / 2 - roofRafterApexOffset));


					this.roofMesh.add(intersectRoofRight);
					this.roofMesh.add(intersectTileRight);


					let hipRoofWidth2 = buildingDesigner.building.width / 2 + buildingDesigner.building.roofRafter.frontVisorWidth;
					let sideRafterHeight = buildingDesigner.building.roofRafter.apexHeight + buildingDesigner.building.roofRafter.frontVisorHeight;

					let hipRoofSideRafterBaseLength = Math.sqrt(hipRoofWidth2 * hipRoofWidth2 + hipRoofWidth2 * hipRoofWidth2);


					let sideRafterAngle = Math.atan(hipRoofWidth2 / hipRoofWidth2);


					let hipRoofSideRafterLength = Math.sqrt(hipRoofSideRafterBaseLength * hipRoofSideRafterBaseLength + sideRafterHeight * sideRafterHeight);


					let sideRafterTexture = TexturesDataUtilities.SelectTexture("Southern_yellowpine_rafterleft", THREE.MirroredRepeatWrapping, THREE.MirroredRepeatWrapping);

					let sideRafterMaterial = Material.CreateMaterial(0xFFFFFF, sideRafterTexture);

					let sideHipRoofRafterPoints = [
						[0, buildingDesigner.building.roofRafter.rafterVerticalWidthL],
						[hipRoofSideRafterBaseLength, sideRafterHeight],
						[hipRoofSideRafterBaseLength, sideRafterHeight - BOARD_2x4_WIDTH],
						[0, 0]
					];



					let sideHipRoofRafterFrontLeft = this.GeneratePlankFromPoints(sideHipRoofRafterPoints, BOARD_2x4_THICKNESS, sideRafterMaterial);
					TexturesDataUtilities.AssignUVsToGeometryXY(sideHipRoofRafterFrontLeft.geometry);
					sideHipRoofRafterFrontLeft.geometry.matrixAutoUpdate = false;
					sideHipRoofRafterFrontLeft.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -BOARD_2x4_THICKNESS / 2));


					sideHipRoofRafterFrontLeft.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(-sideRafterAngle));
					sideHipRoofRafterFrontLeft.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.width / 2 - buildingDesigner.building.roofRafter.frontVisorWidth, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight, -buildingDesigner.building.length / 2 - buildingDesigner.building.roofRafter.frontVisorWidth - Wall.WALLTHICKNESS));

					this.roofMesh.add(sideHipRoofRafterFrontLeft);


					let sideHipRoofRafterBackLeft = this.GeneratePlankFromPoints(sideHipRoofRafterPoints, BOARD_2x4_THICKNESS, sideRafterMaterial);
					TexturesDataUtilities.AssignUVsToGeometryXY(sideHipRoofRafterBackLeft.geometry);
					sideHipRoofRafterBackLeft.geometry.matrixAutoUpdate = false;
					sideHipRoofRafterBackLeft.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -BOARD_2x4_THICKNESS / 2));

					sideHipRoofRafterBackLeft.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(Math.PI + sideRafterAngle));
					sideHipRoofRafterBackLeft.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.width / 2 + buildingDesigner.building.roofRafter.frontVisorWidth, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight, -buildingDesigner.building.length / 2 - buildingDesigner.building.roofRafter.frontVisorWidth - Wall.WALLTHICKNESS));

					this.roofMesh.add(sideHipRoofRafterBackLeft);


					let sideHipRoofRafterFrontRight = this.GeneratePlankFromPoints(sideHipRoofRafterPoints, BOARD_2x4_THICKNESS, sideRafterMaterial);
					TexturesDataUtilities.AssignUVsToGeometryXY(sideHipRoofRafterFrontRight.geometry);
					sideHipRoofRafterFrontRight.geometry.matrixAutoUpdate = false;
					sideHipRoofRafterFrontRight.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -BOARD_2x4_THICKNESS / 2));

					sideHipRoofRafterFrontRight.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(sideRafterAngle));
					sideHipRoofRafterFrontRight.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.width / 2 - buildingDesigner.building.roofRafter.frontVisorWidth, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight, buildingDesigner.building.length / 2 + buildingDesigner.building.roofRafter.frontVisorWidth + Wall.WALLTHICKNESS));

					this.roofMesh.add(sideHipRoofRafterFrontRight);


					let sideHipRoofRafterBackRight = this.GeneratePlankFromPoints(sideHipRoofRafterPoints, BOARD_2x4_THICKNESS, sideRafterMaterial);
					TexturesDataUtilities.AssignUVsToGeometryXY(sideHipRoofRafterBackRight.geometry);
					sideHipRoofRafterBackRight.geometry.matrixAutoUpdate = false;
					sideHipRoofRafterBackRight.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -BOARD_2x4_THICKNESS / 2));

					sideHipRoofRafterBackRight.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(Math.PI - sideRafterAngle));
					sideHipRoofRafterBackRight.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.width / 2 + buildingDesigner.building.roofRafter.frontVisorWidth, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight, buildingDesigner.building.length / 2 + buildingDesigner.building.roofRafter.frontVisorWidth + Wall.WALLTHICKNESS));

					this.roofMesh.add(sideHipRoofRafterBackRight);
				}

				if (tdf.displayRoof)
				{
					if (tile)
					{
						this.roofMesh.add(tile);
					}

					if (roof)
					{
						this.roofMesh.add(roof);
					}
				}
				let verticalTrimMeshes = this.CreateVerticalTrim();
				this.trimMeshes.add(verticalTrimMeshes);

				let roofExtraLengthBeyondTrim = roofExtraLength - Trim.TRIM_THICKNESS;

				if (roofExtraLengthBeyondTrim < 0)
					roofExtraLengthBeyondTrim = 0;

				let horizontalTrimMeshes = this.CreateHorizontalTrim(frontRafteroffsetx, rearRafteroffsetx, rafterOffsetY, roofExtraLengthBeyondTrim);
				this.trimMeshes.add(horizontalTrimMeshes);

				if (buildingDesigner.building.roofRafter.data.soffit_board)
				{
					let frontSoffitBoard = this.CreateTrimOrSoffitBoard(FRONT, buildingDesigner.building.roofRafter.frontVisorWidth - Wall.WALLTHICKNESS, buildingDesigner.building.roofRafter.data.soffit_board_width, buildingDesigner.building.length, buildingDesigner.building.roofRafter.leanToRafter ? buildingDesigner.building.roofRafter.rearTanAngleRatio : 0);

					this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - buildingDesigner.building.roofRafter.frontVisorWidth, this.frontVisorHeightFromFloor - buildingDesigner.building.roofRafter.data.soffit_board_width, -buildingDesigner.building.length / 2);
					frontSoffitBoard.matrixAutoUpdate = false;
					frontSoffitBoard.applyMatrix4(this.matrix);

					this.trimMeshes.add(frontSoffitBoard);

					let backSoffitBoard = this.CreateTrimOrSoffitBoard(BACK, buildingDesigner.building.roofRafter.rearVisorWidth - Wall.WALLTHICKNESS, buildingDesigner.building.roofRafter.data.soffit_board_width, buildingDesigner.building.length);

					this.matrix = new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + Wall.WALLTHICKNESS, this.rearVisorHeightFromFloor - buildingDesigner.building.roofRafter.data.soffit_board_width, -buildingDesigner.building.length / 2);
					backSoffitBoard.matrixAutoUpdate = false;
					backSoffitBoard.applyMatrix4(this.matrix);

					this.trimMeshes.add(backSoffitBoard);

					let rightSoffitBoard = this.CreateTrimOrSoffitBoard(RIGHT, hipRoof ? buildingDesigner.building.roofRafter.width : null, buildingDesigner.building.roofRafter.data.soffit_board_width, buildingDesigner.building.roofRafter.data.roof_overhang - Trim.TRIM_THICKNESS - roofExtraLengthBeyondTrim);

					this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontRafteroffsetx, buildingDesigner.building.height + rafterOffsetY, this.length / 2 - buildingDesigner.building.roofRafter.data.roof_overhang);
					rightSoffitBoard.matrixAutoUpdate = false;
					rightSoffitBoard.applyMatrix4(this.matrix);

					this.trimMeshes.add(rightSoffitBoard);

					let leftSoffitBoard = this.CreateTrimOrSoffitBoard(LEFT, hipRoof ? buildingDesigner.building.roofRafter.width : null, buildingDesigner.building.roofRafter.data.soffit_board_width, buildingDesigner.building.roofRafter.data.roof_overhang - Trim.TRIM_THICKNESS - roofExtraLengthBeyondTrim);

					this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontRafteroffsetx, buildingDesigner.building.height + rafterOffsetY, -this.length / 2 + Trim.TRIM_THICKNESS + roofExtraLengthBeyondTrim);
					leftSoffitBoard.matrixAutoUpdate = false;
					leftSoffitBoard.applyMatrix4(this.matrix);

					this.trimMeshes.add(leftSoffitBoard);
				}

				this.trimMeshes = MeshUtilities.MergeMeshGeometry(this.trimMeshes);

				MeshUtilities.SetMeshCastReceiveShadow(this.trimMeshes, true, true);

				this.trimMeshes.type = ELEM_ROOFING;
				this.roofMesh.type = ELEM_ROOFING;

				buildingMeshes.push(this.trimMeshes);
				buildingMeshes.push(this.roofMesh);

				this.regenerate = false;
			}
		}
	};

	this.SetHorizontalProfilePts = function (profilePts)
	{
		if (profilePts)
		{
			this.horizontalProfilePts = profilePts;
		}
		else
		{
			this.horizontalProfilePts = null;
		}
	};

	this.SetVerticalProfilePts = function (profilePts)
	{
		if (profilePts)
		{
			this.verticalProfilePts = profilePts;
		}
		else
		{
			this.verticalProfilePts = null;
		}
	};

	this.SetPrice = function (price)
	{
		this.price = price;
	};

	this.GetRoofingProfiles = async function (categoryID)
	{
		if (cache.lastroofingprofile !== undefined)
		{
			if (cache.lastroofingprofile.categoryID === categoryID)
				return cache.lastroofingprofile.profileData;
		}
		let [err, profileData] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getRoofingProfile", categoryID: categoryID}));


		if (profileData.length)
		{
			if (profileData[0].horizontal_profile[0] === null || profileData[0].horizontal_profile.length === 0)
			{
				profileData[0].horizontal_profile = null;
			}
			else
			{
				//profileData[0].horizontal_profile = JSON.parse(profileData[0].horizontal_profile);
				profileData[0].horizontal_profile = profileData[0].horizontal_profile;
			}

			if (profileData[0].vertical_profile[0] === null || profileData[0].vertical_profile.length === 0)
			{
				profileData[0].vertical_profile = null;
			}
			else
			{
				//profileData[0].vertical_profile = JSON.parse(profileData[0].vertical_profile);
				profileData[0].vertical_profile = profileData[0].vertical_profile;
			}

			cache.lastroofingprofile = {
				"categoryID": categoryID,
				"profileData": profileData[0]
			};
			return profileData[0];
		}
		else
		{
			if (DEBUG)
			{
				alert("Profile data not defined for category ID: " + categoryID);
			}
			return null;
		}
	};

	this.GetRoofPrice = async function (buildingProductID, categoryID)
	{
		if (cache.lastroofingprice !== undefined)
		{
			if ((cache.lastroofingprice.buildingProductID === buildingProductID) && (cache.lastroofingprice.categoryID === categoryID))
				return cache.lastroofingprice.price;
		}

		let [err, priceData] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getRoofingPrice", subscriber_id: SubscriberDataUtilities.subscriber, series_code: SubscriberDataUtilities.series_code,buildingProductID: buildingProductID, categoryID: categoryID}));

		if (err) {
			alert("Error retrieving price data from server.\nPricing may not be displayed correctly.");
			if (DEBUG) {
				console.error(err);
			}
			return 0;
		}
		if (priceData.length > 0)
		{
			cache.lastroofingprice = {
				"buildingProductID": buildingProductID,
				"categoryID": categoryID,
				"price": priceData[0].price
			};
			return priceData[0].price;
		}
		else
		{
			if (DEBUG)
			{
				console.log("Roofing price not defined for: " + buildingProductID);
			}
			return 0;
		}
	};

	this.SetRoofingData = async function (data, horizontalProfilePts, verticalProfilePts)
	{
		if (data && (!buildingDesigner.building.roofRafter.data.bent_bow || !MetalBuildingRoof.IsVerticalMetalBuildingRoof(data.category_id)))
		{
			this.data = data;
			if (!data.options)
			{
				data.options = {};
			}
			this.SetCategoryID(this.data.category_id);
			this.SetTileTextureName(data.textureName);
			this.SetRoofTextureName(data.options.interior_texture || data.texture_file_interior);

			let roofingProfiles = null;

			if (!horizontalProfilePts && !verticalProfilePts)
				roofingProfiles = await this.GetRoofingProfiles(this.data.category_id);
			else
			{
				roofingProfiles = new Object();

				roofingProfiles.horizontal_profile = horizontalProfilePts;

				roofingProfiles.vertical_profile = verticalProfilePts;
			}

			if (roofingProfiles)
			{
				this.SetHorizontalProfilePts(roofingProfiles.horizontal_profile);
				this.SetVerticalProfilePts(roofingProfiles.vertical_profile);

				if (this.data.metal_roof)
				{
					if (roofingProfiles.horizontal_profile)
					{
						this.SetTileTextureName("dutch_vinyl");
					}

					if (roofingProfiles.vertical_profile)
					{
						this.SetTileTextureName("dutch_vinyl");
					}
				}
			}
			else
			{
				if (this.data.metal_roof)
				{
					if (this.data.roof_style == Roof.HORIZONTAL_ROOF)
						this.SetHorizontalProfilePts(Roof.DEFAULT_HORIZONTAL_PTS);
					else
						this.SetHorizontalProfilePts(null);

					if (this.data.roof_style == Roof.VERTICAL_ROOF)
						this.SetVerticalProfilePts(Roof.DEFAULT_VERTICAL_PTS);
					else
						this.SetVerticalProfilePts(null);
				}
			}

			this.SetColorID(this.data.color_id);

			let roofingPrice = await this.GetRoofPrice(buildingDesigner.building.sizeData.product_id, this.data.category_id);

			this.SetPrice(roofingPrice);

			buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
			buildingDesigner.Draw();
		}
		else if (data)
			alert("Horizontal metal roofing must be selected for Bent Bow roofs.");
	};

	this.SetEveTrimColor = function (color)
	{
		if (color)
		{
			this.eveTrimColorID = color;

			let colorData = ColorsDataUtilities.FindColor(this.eveTrimColorID);

			if (colorData)
			{
				this.eveTrimColor = colorData.color;

				this.eveTrimMater = new THREE.MeshStandardMaterial({
					color: this.eveTrimColor,
					map: null,
					roughness: 1.0,
					metalness: METALNESS
				});
			}
			else
				this.eveTrimColor = null;
		}
	};

	this.SetCornerTrimColor = function (color)
	{
		if (color)
		{
			this.cornerTrimColorID = color;

			let colorData = ColorsDataUtilities.FindColor(this.cornerTrimColorID);

			if (colorData)
			{
				this.cornerTrimColor = colorData.color;

				this.cornerTrimMater = new THREE.MeshStandardMaterial({
					color: this.cornerTrimColor,
					map: null,
					roughness: 1.0,
					metalness: METALNESS
				});
			}
			else
				this.cornerTrimColor = null;
		}

	};

	this.SetTrimColor = function (color)
	{
		let eve_color = nestedObj(buildingDesigner.building.options,"fixed_color_eve") || color;
		this.SetEveTrimColor(eve_color);
		this.SetCornerTrimColor(color);
	};

	this.Destroy = function ()
	{
		if (this.roofMesh != null)
		{
			threeScene.remove(this.roofMesh);
			this.roofMesh = new THREE.Mesh();

			threeScene.remove(this.trimMeshes);
			this.trimMeshes = new THREE.Mesh();

			threeRenderer.shadowMap.needsUpdate = true;
		}
	};
}

Roof.ROOF_THICKNESS = 0.041;
Roof.TILE_THICKNESS = 0.04;
Roof.METAL_ROOF_THICKNESS = 0.0001;

Roof.HORIZONTAL_TRIM = 0;
Roof.VERTICAL_TRIM = 1;
Roof.ANGLED_TRIM = 2;

Roof.HORIZONTAL_ROOF = 0;
Roof.VERTICAL_ROOF = 1;

Roof.DEFAULT_HORIZONTAL_PTS = [
	[0, Roof.TILE_THICKNESS],
	[1, Roof.TILE_THICKNESS],
	[2, Roof.TILE_THICKNESS],
	[3, Roof.TILE_THICKNESS]
];

Roof.DEFAULT_VERTICAL_PTS = [
	[0, Roof.TILE_THICKNESS],
	[1, Roof.TILE_THICKNESS],
	[2, Roof.TILE_THICKNESS],
	[3, Roof.TILE_THICKNESS]
];
