/*eslint-env jquery, browser, es6*/
/*eslint quotes:0 */
/*eslint no-unused-vars:1, indent:0*/
/*eslint-disable no-console, no-unused-vars*/
/*global socket, swal */

function to (promise) {
	return promise
		.then(val => [null, val])
		.catch(err => [err]);
}

Number.prototype.pad = function(size) {
	var s = String(this);
	while (s.length < (size || 2)) {s = "0" + s;}
	return s;
};

window.prompt = async function(prompt_text, default_value = "") {
	let [err, result] = await to(swal.fire({
		input: "text",
		text: prompt_text,
		showCancelButton: true,
		inputValue: default_value
	}));
	//console.log(result);
	let returnval;
	if (result.isConfirmed) {
		returnval = result.value;
	} else {
		returnval = null;
	}

	return returnval;
};

window.alert = async function(alert_text) {
	let [err, result] = await to(swal.fire({
		text: alert_text
	}));
};

function AdminUtilities() {
	return;
}

AdminUtilities.Action = async function (action, data) {
	switch (action) {
		case "TrimFromSiding": {
			socket.emit("adminAction", {request: "copy_siding_to_trim", ...data}, function (data) {
				if (data.success) {
					alert("Success!");
				} else {
					alert("Failed");
				}
			});
		}
	}
};

AdminUtilities.DisplayForm = async function (form) {
	switch (form) {
		case "TrimFromSiding": {
			let data = {};
			data.source_subscriber_id = await prompt(`Enter subscriber id:`);
			if (!data.source_subscriber_id) {
				return;
			}
			data.source_series_code = await prompt("Enter series code:");
			if (!data.source_series_code) {
				return;
			}
			data.source_category_id = await prompt("Enter siding category id:");
			if (!data.source_category_id) {
				return;
			}
			data.copy_type = await prompt("A = Append, O = Overwrite, N = New");
			if (["A","O","N"].indexOf(data.copy_type) === -1) {
				return;
			}
			if (data.copy_type == "N") {
				data.trim_set = await prompt("Enter New Trim Set Name:");
				if (!data.trim_set) {
					return;
				}
			}
			AdminUtilities.Action("TrimFromSiding",data);
			break;
		}
	}
};

function checkLoginStatus(data){
	if(data.charAt(0) === "<") {
		// logged out
		let logoutform = `
		<form method="get" id="relogin"><input type="submit" style="visibility:hidden"></form>`;
		$("body").append(logoutform);
		$("#relogin").submit();
	}
}
function switchToInput(eID, iType){
	let iData = $("#"+eID).text();
	let $input = $("<input>", {val: $("#"+eID).text(), type: iType });
	$input.attr("id",eID);
	$input.attr("onblur",`switchToSpan('${eID}','${iType}');`);
	/* $("#"+eID+" ~ .inactive").css("visibility", "visible"); */
	$("#"+eID).replaceWith($input);
	$("#"+eID).focus();
	$("#"+eID).data("origval",iData);

}

function switchToSpan(eID, iType) {
	let iNewData = $(`#${eID}`).val();
	let iOldData = $(`#${eID}`).data("origval");
	let $span = $("<span>", {text: $(`#${eID}`).val()});
	$span.attr("id",eID);
	$span.attr("onclick",`switchToInput('${eID}','${iType}');`);
	if(iNewData == iOldData) {
		$("#"+eID+" ~ .inactive").css("visibility", "hidden");
	} else{
		$("#"+eID+" ~ .inactive").css("visibility", "visible");
		$("#"+eID+" ~ .inactive").data("fieldid",eID.substring(3));
		$("#"+eID+" ~ .inactive").data("oldval",iOldData);
		$("#"+eID+" ~ .inactive").data("newval",iNewData);
	}
	$("#"+eID).replaceWith($span);
}

function refeshstatusboard()
{
	// Refresh the Status Board
}

function addtrial()
{
	// Add trial subscriber
}

function exeCopyRoofing()
{
	// execute Copy Roofing
	console.log("admin.js:fn:exeCopyRoofing");
	let sourceid = $("#sourceid").val();
	let newid = $("#newid").val();
	let source_series = $("#source_series").val();
	let new_series = $("#new_series").val();
	let category_id = $("#category_id").val();
	// req.body.sourceid, req.body.newid
	// req.body.source_series, req.body.new_series
	// req.body.category_id
	$.post({url:"adminui?q=copyroofing", dataType:"json"}, {action: "copysubroofing", sourceid: sourceid, newid: newid, source_series: source_series, new_series: new_series, category_id: category_id}, function(serverReturn, status)
	{
		if(serverReturn.success === true) {
			alert("Roofing Copy Successful");
		}
	});
}

function copyroofing()
{
	// Copy roofing
	console.log("admin.js:fn:copyroofing");
	let dialog, form;
	let dialogFormHTML = `
<div id="dialog-form" title="Copy Roofing">
	<p class="validateTips">All form fields are required.</p>
	<form>
		<fieldset>
			<label for="sourceid">Source ID</label>
			<input type="text" name="sourceid" id="sourceid" class="text ui-widget-content ui-corner-all">
			<label for="source_series">Source Series Code</label>
			<input type="text" name="source_series" id="source_series" class="text ui-widget-content ui-corner-all">
			<label for="category_id">Roofing Category ID</label>
			<input type="text" name="category_id" id="category_id" class="text ui-widget-content ui-corner-all">
			<label for="newid">Destination ID</label>
			<input type="text" name="newid" id="newid" class="text ui-widget-content ui-corner-all">
			<label for="new_series">Destination Series Code</label>
			<input type="text" name="new_series" id="new_series" class="text ui-widget-content ui-corner-all">
			<!-- Allow form submission with keyboard without duplicating the dialog button -->
			<input type="submit" tabindex="-1" style="position:absolute; top:-1000px">
		</fieldset>
	</form>
</div>
`;

	$("body").append(dialogFormHTML);

	dialog = $( "#dialog-form" ).dialog({
		autoOpen: false,
		height: 400,
		width: 350,
		modal: true,
		buttons: {
			"Copy Roofing": exeCopyRoofing,
			Cancel: function() {
				dialog.dialog( "close" );
			}
		},
		close: function() {
			form[ 0 ].reset();
			// allFields.removeClass( "ui-state-error" );
			$("#dialog-form").remove();
		}
	});

	form = dialog.find( "form" ).on( "submit", function( event ) {
		event.preventDefault();
		exeCopyRoofing();
	});

	dialog.dialog( "open" );
}
function copybuilding()
{
	// Copy Building from One Subscriber to another
}

function editbuildings()
{
	// Edit system buildings
}

function SubLoadLasttAccess()
{
	$.post("adminui?q=sublastaccess", {loaddata: "sublastaccess"}, function(data, status)
	{
		var lastaccess = data;//JSON.parse(data);
		for (var i=0; i<lastaccess.length; i++)
		{
			$("#"+lastaccess[i].subscriber_id+"LU").text(lastaccess[i].date.substr(0,10));
		}
		SubLoadNumUsers();
	});
}

function SubLoadNumUsers()
{
	$.post("adminui?q=subnumusers", {loaddata: "subnumusers"}, function(data, status)
	{
		var numusers = JSON.parse(data);
		var newtext;
		for (var i=0; i<numusers.length; i++)
		{
			newtext = numusers[i].users;
			$("#"+numusers[i].subscriber_id+"USR").html(newtext);
		}
		SubLoadNumSavedDesigns();
	});
}

function SubLoadNumSavedDesigns()
{
	$.post("adminui?q=subnumsaveddesigns", {loaddata: "subnumsaveddesigns"}, function(data, status)
	{
		var numdesigns = JSON.parse(data);
		var newtext;
		for (var i=0; i<numdesigns.length; i++)
		{
			newtext = numdesigns[i].designs;
			$("#"+numdesigns[i].subscriber_id+"DSN").html(newtext);
		}
		$("#subscribers").DataTable({
			"columnDefs": [{"type": "num", "targets": "numsort"}],
			"lengthMenu": [[50, 25, -1], [25, 50, "All"]]
		});
	});
}

async function CopySubscriber(sid)
{
	var newid = await prompt("Copying "+sid+"\nEnter new Subscriber ID",sid);
	if (newid == null || newid == "" || newid == sid)
		return;
	else
	{
		$.post("adminui?q=copysubdata", {action: "copysubdata", sourceid: sid, newid: newid}, function(data, status)
		{
			console.log("data: ",data);
			console.log("status: ",status);
			if (data.success)
			{
				alert("Copy Successful!");
				$("#subscribers > tbody").empty();
				LoadSubscriberList();
			}
			else
			{
				alert("Copy ERROR!");
				$("#subscribers > tbody").empty();
				LoadSubscriberList();
			}
		});
	}
}

function ExtendExpirationTwoWeeks(sid)
{
	// let expDate = new Date();
	let expDate = new Date(Date.parse($(`#${sid}>.expdate>span:first`).text()));
	$.post("adminui?q=updateexp", {action: "updateexp", subscriber_id: sid, weekstoadd: "2"}, function(data, status)
	{
		if (data.success) {
			alert("Update Successful!");
			let newDate = new Date();
			newDate.setDate(newDate.getDate() + 14);
			$(`#${sid}>.expdate>span:first`).text(`${newDate.getFullYear()}-${(newDate.getMonth()+1).pad(2)}-${(newDate.getDate()+1).pad(2)}`);
			$(`#${sid}>.expdate`).css("color","orange");
		}
		else {
			alert("Update Failed!");
		}
	});
}

function ExtendExpirationOneMonth(sid)
{
	let expDate = new Date(Date.parse($(`#${sid}>.expdate>span:first`).text()));
	$.post("adminui?q=updateexp", {action: "updateexp", subscriber_id: sid, weekstoadd: "4"}, function(data, status)
	{
		if (data.success) {
			alert("Update Successful!");
			let newDate = new Date();
			newDate.setDate(newDate.getDate() + 28);
			$(`#${sid}>.expdate>span:first`).text(`${newDate.getFullYear()}-${(newDate.getMonth()+1).pad(2)}-${(newDate.getDate()+1).pad(2)}`);
			$(`#${sid}>.expdate`).css("color","green");
		}
		else {
			alert("Update Failed!");
		}
	});
}

async function RefreshSubscriberData(sid)
{
	var dataid = await prompt("Refreshing "+sid+"\nEnter Subscriber ID to copy data from",sid);
	if (dataid == null || dataid == "" || dataid == sid)
		return;
	else
	{
		$.post("adminui?q=refreshtrial", {action: "refreshtrialdata", currentid: sid, dataid: dataid}, function(data, status)
		{
			console.log("data: ",data);
			console.log("status: ",status);
			if (data.success) alert("Refresh Successful!");
			else alert("Refesh ERROR!");
		});
	}
}

async function DeleteSubscriber(sid)
{
	var confirmation = await prompt("Permanently Deleting "+sid+"\nType YES to permanently delete this subscriber","NO");
	if (confirmation !== "YES")
		return;
	else
	{
		$.post("adminui?q=deletesub", {action: "deletesub", currentid: sid}, function(data, status)
		{
			console.log("data: ",data);
			console.log("status: ",status);
			if (data.success)
			{
				alert("Delete Successful!");
				$("#subscribers > tbody").empty();
				LoadSubscriberList();
			}
			else alert("Delete ERROR!");
		});
	}
}

async function ChangeSubscriberID(sid)
{
	var newid = await prompt("Change "+sid+"\nEnter new Subscriber ID",sid);
	if (newid == null || newid == "" || newid == sid)
		return;
	else
	{
		$.post("adminui?q=renamesubid", {action: "renamesubid", sourceid: sid, newid: newid}, function(data, status)
		{
			console.log("data: ",data);
			console.log("status: ",status);
			if (data.success)
			{
				alert("ID Change Successful!");
				$("#subscribers > tbody").empty();
				LoadSubscriberList();
			}
			else
			{
				alert("ID Change ERROR!");
				$("#subscribers > tbody").empty();
				LoadSubscriberList();
			}
		});
	}
}

function LoadSubscriberList()
{
	$.post("adminui", {loaddata: "subscribers"}, function(data, status)
	{
		var subscribers = JSON.parse(data);
		var today, expdate, expstyle, expaction, profilelink, actionlist, copylink, statuslink, subscriber_status;
		today = new Date();
		for (var i=0; i<subscribers.length; i++)
		{
			actionlist = "";
			subscriber_status = "";
			switch (subscribers[i].status)
			{
			case 0:
				subscriber_status = "Status: Flagged for Delete";
				break;
			case 1:
				subscriber_status = "Status: Trial Subscriber";
				break;
			case 2:
				subscriber_status = "Status: Paid Subscriber";
				break;
			case 3:
				subscriber_status = "Status: Free Subscriber";
				break;
			case 4:
				subscriber_status = "Status: Expired Trial Subscriber";
				break;
			case 5:
				subscriber_status = "Status: Expired Paid Subscriber";
				break;
			case 6:
				subscriber_status = "Status: Master Subscriber";
				break;
			case 7:
				subscriber_status = "Status: Subscriber Template";
				break;
			}
			copylink = "&nbsp;<i class='fa fa-clone' aria-hidden='true' title='Copy Subscriber' onclick='CopySubscriber(&apos;" + subscribers[i].subscriber_id + "&apos;)';></i>";
			if (subscribers[i].status == 0) statuslink = "<i class='fa fa-wrench' aria-hidden='true' title='Change ID' onclick='ChangeSubscriberID(&apos;" + subscribers[i].subscriber_id + "&apos;)'></i>&nbsp;"; else statuslink = "";
			if (subscribers[i].url.length > 0) actionlist = "<a href='" + subscribers[i].url + "' target='_blank'><i class='fa fa-external-link' aria-hidden='true' title='Customer Website'></i></a>&nbsp;";
			if (subscribers[i].trello_link !== null) actionlist = actionlist + "<a href='" + subscribers[i].trello_link + "' target='_blank'><i class='fa fa-trello' aria-hidden='true' title='Trello Card'></i></a>&nbsp;";
			expdate = Date.parse(subscribers[i].expiration.substr(0,10));
			if (expdate < today)
			{
				expstyle = "color:red";
				expaction = `&nbsp;<span onclick="ExtendExpirationTwoWeeks('${subscribers[i].subscriber_id}');"><i class='fa fa-calendar-plus-o' aria-hidden='true' title='Set to Two Weeks from Today'></i></span>`;
				actionlist = actionlist + "<i class='fa fa-trash' aria-hidden='true' title='Archive'></i>&nbsp;";
				if (subscribers[i].status == 0) actionlist = actionlist + `<i class="fa fa-recycle" aria-hidden="true" title="Permanently Delete" style="color:red;"></i></a>&nbsp;`;
			}
			else
			{
				let testDate = new Date();
				if(expdate < testDate.setDate(today.getDate() + 30)) {
					expstyle = "color:orange";
					expaction = `&nbsp;<span onclick="ExtendExpirationOneMonth('${subscribers[i].subscriber_id}');"><i class='fa fa-calendar-plus-o' aria-hidden='true' title='Set to 4 Weeks from Today'></i></span>`;
				} else {
					expstyle = "color:green";
					expaction = "&nbsp;";
				}
			}
			if (subscribers[i].status < 8)  // was < 5 -- *** TODO: needs to check for full access for above 4
			{
				profilelink = "<i class='fa fa-id-card-o' aria-hidden='true' title='Edit Subscriber' onclick='SubscriberProfile(&apos;" + subscribers[i].subscriber_id + "&apos;)';></i>&nbsp;";
			}
			else
			{
				profilelink = "";
			}
			if (subscribers[i].status == 0) actionlist += `<i class="fa fa-recycle" aria-hidden="true" title="Permanently Delete" style="color:red;" onclick="DeleteSubscriber('${subscribers[i].subscriber_id}')"></i>&nbsp;`;
			if (subscribers[i].status == 1) actionlist = actionlist + "<i class='fa fa-refresh' aria-hidden='true' title='Refresh Trial Data from Database' onclick='RefreshSubscriberData(&apos;" + subscribers[i].subscriber_id + "&apos;)'></i></a>&nbsp;";

			$("#subscribers > tbody:last-child").append(`
<tr id='${subscribers[i].subscriber_id}'>
	<td style='white-space: nowrap;">&nbsp;&nbsp;<a href='index.html?sc=MT-${subscribers[i].subscriber_id}' target='_blank' title='${subscriber_status}'>${subscribers[i].subscriber_id}</a>${statuslink}${copylink}&nbsp;</td>
	<td class='expdate' style='white-space: nowrap; ${expstyle}'>&nbsp;&nbsp;<span>${subscribers[i].expiration.substr(0,10)}</span>${expaction}&nbsp;</td><td>&nbsp;&nbsp;${profilelink}${subscribers[i].name} ${actionlist}</td>
	<td id='${subscribers[i].subscriber_id}LU'></td>
	<td style='white-space: nowrap; text-align:center' id='${subscribers[i].subscriber_id}USR'>0</td>
	<td style='white-space: nowrap; text-align:center' id='${subscribers[i].subscriber_id}DSN'>0</td>
</tr>`);
		}
		//SubLoadNumUsers();
		SubLoadLasttAccess();

	});
}

function csvupdate() {
	let table, num_keys, data;
	//table = await prompt("Table name to update:");
	table = $("#csv_table_name").val();
	if (table.length < 1) {
		return;
	}
	//num_keys = await prompt("Number of keys:");
	num_keys = $("#num_keys").val();
	if (num_keys.length < 1) {
		return;
	}
	//data = await prompt("Paste data here, first column is key, first row is column names:");
	data = $("#csv_data").val();
	if (data.length < 1) {
		return;
	}
	$.post({url:"adminui?q=csvupdate", dataType:"json"}, {action: "csvupdate", table_name: table, num_keys: num_keys, csv_data: data}, function(serverReturn, status)
	{
		if(serverReturn.success === true) {
			alert("Update success.");
		} else {
			alert("Update failed.");
		}
	});
}

/*

 $expire_dt = new DateTime($row['expiration']);
           echo "<tr><td>&nbsp;&nbsp;<a href='index.php?sc=MT-".$row['subscriber_id']."' target='_blank'>".$row['subscriber_id']."</a>";
           if($row['status']==0) {
           echo "<a href='admin.php?fn=cgid&sc=".$row['subscriber_id']."'><i class='fa fa-wrench' aria-hidden='true' title='Change ID'></i></a>&nbsp;";
           }
           echo "&nbsp;</td>";
           if ($expire_dt < $today_dt) {
               echo "<td style='color:red'>&nbsp;&nbsp;".$row['expiration']."&nbsp;<a href='admin.php?fn=addtime&sc=".$row['subscriber_id']."'><i class='fa fa-calendar-plus-o' aria-hidden='true' title='Add Two Weeks'></i></a>&nbsp;</td>"; }
           else {
               echo "<td>&nbsp;&nbsp;".$row['expiration']."&nbsp;&nbsp;</td>";
           }
           echo "<td>&nbsp;&nbsp;";
           if($row['status']<=5) {
           echo "<a href='admin.php?fn=edit&sc=".$row['subscriber_id']."'><i class='fa fa-id-card-o' aria-hidden='true' title='Edit Subscriber'></i></a>&nbsp;";
           }
           echo " ".$row['name']." ";
           if($row['url']!="") {
           echo "<a href='".$row['url']."' target='_blank'><i class='fa fa-external-link' aria-hidden='true' title='Customer Website'></i></a>&nbsp;";
           }
           if($row['trello_link']!="") {
            echo "<a href='".$row['trello_link']."' target='_blank'><i class='fa fa-trello' aria-hidden='true' title='Trello Card'></i></a>&nbsp;";
           }

           if ($expire_dt < $today_dt) {
           echo "<a href='admin.php?fn=archive&sc=".$row['subscriber_id']."'><i class='fa fa-trash' aria-hidden='true' title='Archive'></i></a>&nbsp;";
           }
           if($row['status']==1) {
           echo "<a href='admin.php?fn=refresh&sc=".$row['subscriber_id']."'><i class='fa fa-refresh' aria-hidden='true' title='Refresh Trial Data from Database'></i></a>&nbsp;";
           }
           if($row['status']==0) {
           echo "<a href='admin.php?fn=delete&sc=".$row['subscriber_id']."'><i class='fa fa-recycle' aria-hidden='true' title='Permanently Delete'></i></a>&nbsp;";
           }
           echo "</td><td>";

           $result2 = $sql_conn2->query( "SELECT * FROM access_log WHERE subscriber_id = '".$row['subscriber_id']."' ORDER BY date DESC");
            if ($result2) {
            $row2 = $result2->fetch_assoc();
           echo $row2['date'];
            }
           echo "&nbsp;</td><td>&nbsp;&nbsp;";
           $result2 = $sql_conn2->query( "SELECT COUNT(*) as total FROM users WHERE subscriber_id = '".$row['subscriber_id']."'");
            if ($result2) {
                $row2 = $result2->fetch_assoc();
                echo $row2['total'];
            }

           echo "&nbsp;</td><td>&nbsp;&nbsp;";
           $result2 = $sql_conn2->query( "SELECT COUNT(*) as total FROM usersheds WHERE subscriber_id = '".$row['subscriber_id']."'");
            if ($result2) {
                $row2 = $result2->fetch_assoc();
                echo $row2['total'];
            }


           echo "</td></tr>";

*/
