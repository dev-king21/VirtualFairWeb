/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Partition(posZ, width, height, stallIndex)
{
	this.posZ = posZ;
	this.width = width;
	this.height = height;

	this.stallIndex = stallIndex;

	this.style = Partition.HALFWALL_GRILL;

	this.baseTextureFileName = "Southern_yellowpine_horizontal";

	this.partitionColor = 0xFFFFFF;

	this.partitionTextureFileName = "BoardandBattenRusticCedartone_f1.542x1.542";

	this.railTextureFileName = "Southern_yellowpine_vertical";

	this.gridBarsTextureFileName = "techshield-16in-tile";

	this.gridTextureFileName = "GridBars";

	this.dropVentInnerTextureFileName = "DropVentInnerTexture";

	this.dropVentInnerObjectCrossBuckFilename = DIR_RESOURCES + DIR_OBJECTS + "partitions/dropventpartition/panel_crossbuck.stl";

	this.partitionTexture = null;
	this.partitionMater = null;

	this.railTexture = null;
	this.railMater = null;
	this.railColor = 0xFFFFFF;

	this.gridTexture = null;
	this.gridColor = 0xFFFFFF;
	this.gridMater = null;

	this.gridBarsTexture = null;
	this.gridBarsColor = 0x999999;

	this.dropVentTexture = null;
	this.dropVentColor = 0xFFFFFF;

	this.dropVentInnerTexture = null;
	this.dropVentInnerTextureColor = 0xFFFFFF;
	this.dropVentInnerMater = null;

	this.crossBuckTexture = null;
	this.crossBuckTextureColor = 0xFFFFFF;
	this.crossBuckMater = null;

	this.mesh = new THREE.Mesh();

	this.matrix = null;

	this.type = ELEM_PARTITION;

	this.selected = false;

	this.regenerate = true;

	this.GetTextures = function ()
	{
		if (this.baseTextureFileName != "")
		{

			this.baseTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.baseTextureFileName, this.width, 0.3);
		}

		if (this.partitionTextureFileName != "")
		{
			this.partitionTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.partitionTextureFileName, this.width, Partition.LOWERBOARDSHEIGHT);
		}

		if (this.railTextureFileName != "")
		{
			this.railTexture = TexturesDataUtilities.SelectTexture(this.railTextureFileName, THREE.RepeatWrapping, THREE.RepeatWrapping);
		}

		if (this.gridBarsTextureFileName != "")
		{
			this.gridBarsTexture = TexturesDataUtilities.SelectTexture(this.gridBarsTextureFileName, THREE.RepeatWrapping, THREE.RepeatWrapping);
		}

		if (this.gridTextureFileName != "")
		{
			this.gridTexture = TexturesDataUtilities.SelectTexture(this.gridTextureFileName, THREE.RepeatWrapping, THREE.RepeatWrapping);

			if (this.style == Partition.SOLIDWALL && this.gridTexture)
				this.gridTexture.repeat.set(2, 1);
		}

		if (this.dropVentInnerTextureFileName != "")
		{
			this.dropVentInnerTexture = TexturesDataUtilities.SelectTexture(this.dropVentInnerTextureFileName, THREE.RepeatWrapping, THREE.RepeatWrapping);
		}
	};

	this.SetSelected = function (selected)
	{
		this.selected = selected;

		if (GUIInput.currentDesignEditorMode == GUIInput.DESIGN_EDIT_MODE.SET_PARTITION && Partition.SelectedPartitionButtonData)
		{
			this.SetPartitionData(Partition.SelectedPartitionButtonData);
			buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

			buildingDesigner.Draw();

			ElementsMenu.ElementsListPricingUpdate();
		}
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.Create2x4Rails = function ()
	{
		let geometry = new THREE.BoxGeometry(this.width, MathUtilities.Feet(2), MathUtilities.Feet(4));

		this.railMater = Material.CreateMaterial(this.railColor, this.railTexture);

		if (this.style == Partition.NO_PARTITION)
		{
			this.railMater.transparent = true;
			this.railMater.opacity = 0.0;
		}

		this.matrix = new THREE.Matrix4().makeTranslation(0, MathUtilities.Feet(2) / 2, 0);
		geometry.matrixAutoUpdate = false;
		geometry.applyMatrix4(this.matrix);

		let rail = new THREE.Mesh(geometry, this.railMater);

		return rail;
	};

	this.CreateCrossBuck = function (width, height, thickness, material)
	{
		let geometry = GeometryUtilities.GetGeometry(this.dropVentInnerObjectCrossBuckFilename);

		geometry.computeBoundingBox();


		let size = new THREE.Vector3();

		size = geometry.boundingBox.getSize(size);

		this.scale = new THREE.Vector3(width / size.x, height / size.y, thickness / size.z);

		TexturesDataUtilities.AssignUVsToGeometryXY(geometry);

		let mesh = new THREE.Mesh(geometry, material);

		mesh.matrix.scale(new THREE.Vector3(this.scale.x, this.scale.y, this.scale.y));

		return mesh;
	};

	this.CreateDropVent = function (width, height, thickness)
	{
		let mesh = new THREE.Mesh();

		//outer frame
		let geometry = new THREE.BoxGeometry(width, height, thickness);

		this.dropVentFrameMater = Material.CreateMaterial(this.dropVentColor, this.partitionTexture);

		let frame = new THREE.Mesh(geometry, this.dropVentFrameMater);

		mesh.add(frame);

		//inner panel
		let innerWidth = width - Partition.dropVentFrameThickness;
		let innerHeight = height - Partition.dropVentFrameThickness;
		let innerThickness = Partition.dropVentFrameThickness + 0.1;

		geometry = new THREE.BoxGeometry(innerWidth, innerHeight, innerThickness);

		this.dropVentInnerMater = Material.CreateMaterial(this.dropVentColor, this.dropVentInnerTexture);

		let innerPanel = new THREE.Mesh(geometry, this.dropVentInnerMater);

		mesh.add(innerPanel);

		//crossBuck
		let crossBuck = this.CreateCrossBuck(innerWidth, innerHeight, innerThickness, this.dropVentInnerMater);
		this.matrix = new THREE.Matrix4().makeTranslation(0, 0, thickness);
		crossBuck.matrixAutoUpdate = false;
		crossBuck.applyMatrix4(this.matrix);

		mesh.add(crossBuck);

		this.matrix = new THREE.Matrix4().makeTranslation(0, height / 2, 0);
		mesh.matrixAutoUpdate = false;
		mesh.applyMatrix4(this.matrix);

		return mesh;
	};

	this.CreateBar = function (posX, posY, posZ, gridHeight)
	{
		let geometry = new THREE.BoxGeometry(Partition.GRIDBARWIDTH, gridHeight, Partition.GRIDBARWIDTH);

		let gridBarsMater = Material.CreateMaterial(this.gridBarsColor, this.gridBarsTexture);

		if (this.style == Partition.NO_PARTITION)
		{
			this.gridBarsMater.transparent = true;
			this.gridBarsMater.opacity = 0.0;
		}

		this.matrix = new THREE.Matrix4().makeTranslation(0, gridHeight / 2, 0);
		geometry.matrixAutoUpdate = false;
		geometry.applyMatrix4(this.matrix);

		this.matrix = new THREE.Matrix4().makeTranslation(posX, posY, posZ);
		geometry.matrixAutoUpdate = false;
		geometry.applyMatrix4(this.matrix);

		let bar = new THREE.Mesh(geometry, gridBarsMater);

		return bar;
	};


	this.CreateGrid = function (gridHeight)
	{
		if (Partition.BARS3D && this.style == Partition.HALFWALL_GRILL)
		{
			let barCount = this.width / Partition.BARSPACING;

			let currentXPos = -this.width / 2;

			this.gridMesh = new THREE.Mesh();

			for (let i = 0; i < barCount; i++)
			{
				this.gridMesh.add(this.CreateBar(currentXPos, 0, 0, gridHeight));

				currentXPos += Partition.BARSPACING;
			}

			this.gridMesh.type = ELEM_PARTITION;

			MeshUtilities.SetElement(this.gridMesh, this);

			return this.gridMesh;
		}
		else
		{
			let geometry = new THREE.BoxGeometry(this.width, gridHeight, 0.01);

			this.gridMater = Material.CreateMaterial(this.gridColor, this.gridTexture);

			if (this.style == Partition.NO_PARTITION)
			{
				this.gridMater.transparent = true;
				this.gridMater.opacity = 0.0;
			}
			else
			if (this.style == Partition.HALFWALL_GRILL)
				this.gridMater.transparent = true;

			this.matrix = new THREE.Matrix4().makeTranslation(0, gridHeight / 2, 0);
			geometry.matrixAutoUpdate = false;
			geometry.applyMatrix4(this.matrix);

			let cube = new THREE.Mesh(geometry, this.gridMater);

			cube.type = ELEM_PARTITION;
			cube.element = this;

			return cube;
		}
	};

	this.GenerateSelectedBoxes = function (parentMesh, matrix)
	{
		let fSelBoxSize = SEL_BOX_SIZE * 2;
		let box_size2 = fSelBoxSize / 2.0;

		let box_offs_x = this.width - fSelBoxSize - box_size2;
		let box_offs_y = this.height + box_size2;

		let box_offs_z = 0;

		let vecOffs = [{
			x: box_size2,
			y: fSelBoxSize,
			z: box_offs_z
		},
		{
			x: box_size2,
			y: box_offs_y / 2,
			z: box_offs_z
		},
		{
			x: box_size2,
			y: box_offs_y,
			z: box_offs_z
		},
		{
			x: box_offs_x,
			y: fSelBoxSize,
			z: box_offs_z
		},
		{
			x: box_offs_x,
			y: box_offs_y / 2,
			z: box_offs_z
		},
		{
			x: box_offs_x,
			y: box_offs_y,
			z: box_offs_z
		},
		{
			x: box_offs_x / 2,
			y: box_offs_y,
			z: box_offs_z
		},
		{
			x: box_offs_x / 2,
			y: fSelBoxSize,
			z: box_offs_z
		}
		];


		let materSelBox = Material.CreateMaterial(SEL_BOX_COLOR, null);

		let totalGeometry = new THREE.Geometry();

		for (let i = 0; i < 8; i++)
		{
			let geomSelBox = new THREE.BoxGeometry(fSelBoxSize, fSelBoxSize, fSelBoxSize);

			let boxMatrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(vecOffs[i].x - this.width / 2, vecOffs[i].y, vecOffs[i].z));

			totalGeometry.merge(geomSelBox, boxMatrix);
		}

		let meshSelBox = new THREE.Mesh(totalGeometry, materSelBox);
		parentMesh.add(meshSelBox);
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			this.GetTextures();

			////if (TexturesDataUtilities.TextureLoaded(this.partitionTexture) && TexturesDataUtilities.TextureLoaded(this.gridTexture) && TexturesDataUtilities.TextureLoaded(this.gridBarsTexture) && TexturesDataUtilities.TextureLoaded(this.railTexture))
			{
				this.mesh = new THREE.Mesh();

				let geomBase = new THREE.BoxGeometry(this.width, HorseBarnBase.BASEWIDTH, HorseBarnBase.BASEWIDTH);

				geomBase.matrixAutoUpdate = false;
				geomBase.applyMatrix4(new THREE.Matrix4().makeTranslation(0, -HorseBarnBase.BASEWIDTH / 2, 0));

				let baseMater = Material.CreateMaterial(0xFFFFFF, TexturesDataUtilities.TextureLoaded(this.baseTexture));

				let meshBase = new THREE.Mesh(geomBase, baseMater);

				MeshUtilities.SetMeshCastReceiveShadow(meshBase, true, true);

				this.mesh.add(meshBase);


				let geometry = new THREE.BoxGeometry(this.width, Partition.LOWERBOARDSHEIGHT, Partition.PARTITION_THICKNESS);

				let partitionMater = Material.CreateMaterial(this.partitionColor, this.partitionTexture);

				this.matrix = new THREE.Matrix4().makeTranslation(0, Partition.LOWERBOARDSHEIGHT / 2, 0);
				geometry.matrixAutoUpdate = false;
				geometry.applyMatrix4(this.matrix);

				if (this.style == Partition.NO_PARTITION)
				{
					partitionMater.transparent = true;
					partitionMater.opacity = 0.0;
				}

				let wall = new THREE.Mesh(geometry, partitionMater);

				wall.type = ELEM_PARTITION;
				wall.element = this;



				this.mesh.add(wall);

				let lowerRail = this.Create2x4Rails();
				lowerRail.matrixAutoUpdate = false;
				lowerRail.applyMatrix4(new THREE.Matrix4().makeTranslation(0, Partition.LOWERBOARDSHEIGHT, 0));
				this.mesh.add(lowerRail);

				if (this.style != Partition.HALFWALL)
				{
					let upperRail = this.Create2x4Rails();
					upperRail.matrixAutoUpdate = false;
					upperRail.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.height - MathUtilities.Feet(2) / 2, 0));
					this.mesh.add(upperRail);

					let gridHeight = this.height - MathUtilities.Feet(2) / 2 - Partition.LOWERBOARDSHEIGHT;

					let grid = this.CreateGrid(gridHeight);
					grid.matrixAutoUpdate = false;
					grid.applyMatrix4(new THREE.Matrix4().makeTranslation(0, Partition.LOWERBOARDSHEIGHT, 0));
					this.mesh.add(grid);
				}

				if (this.style == Partition.SOLIDWALL_DROPVENT)
				{
					let dropVent = this.CreateDropVent(Partition.dropVentWidth, Partition.dropVentHeight, Partition.dropVentThickness);

					dropVent.matrixAutoUpdate = false;
					dropVent.applyMatrix4(new THREE.Matrix4().makeTranslation(0, Partition.LOWERBOARDSHEIGHT + gridHeight / 2 - Partition.dropVentHeight / 2, 0));
					this.mesh.add(dropVent);
				}

				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, this.posZ));

				if (this.selected)
					this.GenerateSelectedBoxes(this.mesh, new THREE.Matrix4());


				this.mesh.type = ELEM_PARTITION;

				MeshUtilities.SetElement(this.mesh, this);

				this.mesh.stallIndex = this.stallIndex;

				buildingMeshes.add(this.mesh);

				this.regenerate = false;
			}
		}
	};

	this.SetStyle = function (newStyle)
	{
		this.style = newStyle;

		if (this.style == Partition.SOLIDWALL || this.style == Partition.SOLIDWALL_DROPVENT)
			this.gridTextureFileName = "Southern_yellowpine_horizontal";
		else
			this.gridTextureFileName = "GridBars";
	};

	this.SetPartitionData = function (buttonData)
	{
		this.buttonData = buttonData;

		switch (buttonData.partitionID)
		{
		case ("PARTITION_HALFWALL_GRILL"):
			this.SetStyle(Partition.HALFWALL_GRILL);
			break;

		case ("PARTITION_HALFWALL"):
			this.SetStyle(Partition.HALFWALL);
			break;

		case ("NO_PARTITIONS"):
			this.SetStyle(Partition.NO_PARTITION);
			break;

		case ("PARTITION_DROPVENT"):
			this.SetStyle(Partition.SOLIDWALL_DROPVENT);
			break;

		case ("PARTITION_SOLIDFULLWALL"):
			this.SetStyle(Partition.SOLIDWALL);
			break;
		}
	};
}

Partition.PARTITION_THICKNESS = INCHTOFEET;
Partition.GRIDBARWIDTH = INCHTOFEET * 0.75;
Partition.BARSPACING = INCHTOFEET * 6;

Partition.NO_PARTITION = 0;
Partition.HALFWALL = 1;
Partition.HALFWALL_GRILL = 2;
Partition.SOLIDWALL = 3;
Partition.SOLIDWALL_DROPVENT = 4;


Partition.PARTITION_STRING = ["No Partition",
	"Half Wall",
	"Half Wall with Grill",
	"Solid Wall",
	"Solid Wall with Drop Vent"
];

Partition.BARS3D = true;

Partition.SelectedPartitionButtonData = null;

Partition.dropVentWidth = 1.8;
Partition.dropVentHeight = 1.8;
Partition.dropVentThickness = 0.2;

Partition.dropVentFrameThickness = 0.2;


Partition.LOWERBOARDSHEIGHT = MathUtilities.Feet(46.5);
