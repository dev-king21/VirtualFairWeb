/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function MetalBuilding(buildingID, roofRafter, sizeData)
{
	Building.call(this, buildingID, roofRafter, sizeData, 5);

	this.floorHeight = 0;

	this.Initialize = async function ()
	{
		this.base = null;

		await this.SetSizeData(this.sizeData);

		this.groundBeneathBuilding = new GroundBeneathBuilding(this.roofRafter.wallWidth, this.length);

		this.groundBeneathBuilding.SetGroundTextureFileName("gravel");

		this.walls = new CarportWalls(this.roofRafter);

		await this.walls.Initialize();

		this.roof = new MetalBuildingRoof();

		if (buildingDesigner.defaultSettings)
		{
			await this.walls.SetSidingData(GuiDataUtilities.GetSidingColorButtonData(buildingDesigner.defaultSettings.siding_id));

			await this.roof.SetRoofingData(GuiDataUtilities.GetRoofingButtonData(buildingDesigner.defaultSettings.roofing_id));

			this.SetTrimColor(buildingDesigner.defaultSettings.trim_color_id);

			if (buildingDesigner.defaultSettings.default_elements)
				this.AddElements(buildingDesigner.defaultSettings.default_elements);
		}
		else
		{
			await this.walls.SetSidingData(GuiDataUtilities.sidingColorButtonData[0]);


			if (!this.roofRafter.data.bent_bow)
				await this.roof.SetRoofingData(GuiDataUtilities.roofingButtonData[0]);
			else
			{
				for (let i = 0; i < GuiDataUtilities.roofingButtonData.length; i++)
				{
					if (!MetalBuildingRoof.IsVerticalMetalBuildingRoof(GuiDataUtilities.roofingButtonData[i].category_id))
					{
						await this.roof.SetRoofingData(GuiDataUtilities.roofingButtonData[i]);
						break;
					}
				}
			}
		}

		// This is scheduled to be changed to this.framing, as it is actually framing and not rafters
		this.rafters = new MetalRafters(this.roofRafter.data.thickness, this.roofRafter.data.width);

		await this.InitializeSidingRoofingTrimAndDefaultElements();

		ElementsMenu.ElementsListPricingUpdate();

		this.initialized = true;
	};

	this.OnClickChangeSidingColor = async function (elementButton)
	{
		GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.SET_SIDING;

		Wall.SelectedSidingButtonData = GuiDataUtilities.sidingColorButtonData[elementButton.btnIndex];

		let selectedWall = this.GetSelectedWall();

		if (selectedWall != null && selectedWall != undefined)
		{
			selectedWall.SetWallSidingData(Wall.SelectedSidingButtonData);

			this.SetRegenerateBuildingAndElementMeshes(true);

			buildingDesigner.Draw();

			this.SetBuildingModified();
			// Show the building and then update pricing data from server to make it more responsive.
			await selectedWall.GetAndSetDimensionWallPrice();
			ElementsMenu.ElementsListPricingUpdate();

			this.SetBuildingModified();
		}
	};

	this.SetRafterAndSizeData = async function (roofRafter, sizeData)
	{
		this.roofRafter = roofRafter;

		await this.SetSizeData(sizeData);

		// This is scheduled to be changed to this.framing, as it is actually framing and not rafters
		this.rafters = new MetalRafters(this.roofRafter.data.thickness, this.roofRafter.data.thickness);

		if (buildingDesigner.building.walls)
		{
			buildingDesigner.building.walls.GetAndSetWallPrices();
		}

		ElementsMenu.ElementsListPricingUpdate();

		this.SetBuildingModified();

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		buildingDesigner.Draw();
	};

	this.SetRegenerateBuildingMeshes = function (regenerate)
	{
		this.regenerateBuildingMeshes = regenerate;

		// This is scheduled to be changed to this.framing, as it is actually framing and not rafters
		if (this.rafters)
		{
			this.rafters.SetRegenerate(regenerate);
		}

		if (this.groundBeneathBuilding)
		{
			this.groundBeneathBuilding.SetRegenerate(regenerate);
		}

		if (this.walls)
		{
			this.walls.SetRegenerate(regenerate);
		}

		if (this.roof)
		{
			this.roof.SetRegenerate(regenerate);
		}
	};

	this.Regenerate = function ()
	{
		if (this.initialized && this.regenerateBuildingMeshes)
		{
			this.RemoveThreeJSSceneMeshes();

			this.buildingMeshes = [];

			// This is scheduled to be changed to this.framing, as it is actually framing and not rafters
			if (this.rafters)
			{
				this.rafters.Generate(this.buildingMeshes);
			}

			if (this.groundBeneathBuilding)
			{
				this.groundBeneathBuilding.Generate(this.buildingMeshes);

				this.groundBeneathBuilding.mesh.receiveShadow = true;
			}

			if (this.walls)
				this.walls.Generate(this.buildingMeshes);

			if (showRoof && this.roof)
				this.roof.Generate(this.buildingMeshes);

			if (this.selected)
			{
				let boxMeshes = new THREE.Mesh();

				this.GenerateSelectedBoxes(boxMeshes, new THREE.Matrix4().makeTranslation(-this.width / 2 - this.roofRafter.leanToWidth, 0, this.length / 2), SEL_BOX_SIZE);

				this.buildingMeshes.push(boxMeshes);
			}
		}

		if (this.regenerateElementMeshes)
		{
			MeshUtilities.CloneMeshes(this.buildingMeshes, this.tempBuildingMeshes);

			this.elementsMesh = Elements.Generate(this.tempBuildingMeshes);

			if (this.elementsMesh)
			{
				this.tempBuildingMeshes.push(this.elementsMesh);
			}
		}
		else
		{
			MeshUtilities.CloneMeshes(this.buildingMeshes, this.tempBuildingMeshes);
			if (this.elementsMesh)
			{
				this.tempBuildingMeshes.push(this.elementsMesh);
			}
		}

		GeometryUtilities.SetWallFaceIndexes(this.tempBuildingMeshes);

		ElementsMenu.ElementsListPricingUpdate();

		this.regenerateBuildingMeshes = false;
		this.regenerateElementMeshes = false;
	};

	this.GetSelectedWall = function ()
	{
		return this.walls.GetSelectedWall();
	};

	this.ClearSelections = function ()
	{
		this.SetSelected(false);

		this.walls.SetSelected(false);

		Elements.ClearSelections();
	};

	this.GetWallString = function (eWall)
	{
		return MetalBuilding.WALL_STRING[eWall];
	};
}

MetalBuilding.WALL_STRING = ["Left",
	"Right",
	"Back",
	"Front"
];
