/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef, no-useless-escape */
function TexturesDataUtilities()
{}

TexturesDataUtilities.textures_list = [];

TexturesDataUtilities.textureFilenamesToBeLoaded = [];

TexturesDataUtilities.currentTextureBeingLoadedIndex = -1;

TexturesDataUtilities.loader = new THREE.TextureLoader();

TexturesDataUtilities.SelectTexture = function (textureName, wrapS, wrapT)
{
	let texture = TexturesDataUtilities.FindTexture(textureName);

	if (texture == null)
	{
		let OnTextureLoaded = new TexturesDataUtilities_OnTextureLoaded(textureName);
		return TexturesDataUtilities.LoadTextureFromName(textureName, OnTextureLoaded.TextureLoaded);
	}

	return texture;
};

TexturesDataUtilities.FindTexture = function (textureName)
{
	for (let i = 0; i < TexturesDataUtilities.textures_list.length; i++)
		if (TexturesDataUtilities.textures_list[i].textureName === textureName)
			return TexturesDataUtilities.textures_list[i];

	return null;
};

TexturesDataUtilities.GetAverageRGB = function (imgEl)
{
	let blockSize,
		defaultRGB = {
			r: 0,
			g: 0,
			b: 0
		}, // for non-supporting envs
		canvas = document.createElement("canvas"),
		context = canvas.getContext && canvas.getContext("2d"),
		data, width, height,
		i = -4,
		length,
		rgb = {
			r: 0,
			g: 0,
			b: 0
		},
		count = 0;

	if (!context)
	{
		return defaultRGB;
	}

	height = canvas.height = imgEl.naturalHeight || imgEl.offsetHeight || imgEl.height;
	width = canvas.width = imgEl.naturalWidth || imgEl.offsetWidth || imgEl.width;

	context.drawImage(imgEl, 0, 0);

	try
	{
		data = context.getImageData(0, 0, width, height);
	}
	catch (e)
	{
		/* security error, img on diff domain */
		return defaultRGB;
	}

	length = data.data.length;

	blockSize = MathUtilities.Round(length, 3);

	while ((i += blockSize * 4) < length)
	{
		++count;
		rgb.r += data.data[i];
		rgb.g += data.data[i + 1];
		rgb.b += data.data[i + 2];
	}

	// ~~ used to floor values
	rgb.r = ~~(rgb.r / count);
	rgb.g = ~~(rgb.g / count);
	rgb.b = ~~(rgb.b / count);

	rgb.r /= 255;
	rgb.g /= 255;
	rgb.b /= 255;

	return rgb;
};

TexturesDataUtilities.GetAvgRGBForTextures = function ()
{
	for (let i = 0; i < TexturesDataUtilities.textures_list.length; i++)
	{
		if (TexturesDataUtilities.textures_list[i].image !== undefined)
		{
			TexturesDataUtilities.textures_list[i].avgRGB = TexturesDataUtilities.GetAverageRGB(TexturesDataUtilities.textures_list[i].image);
		}
	}
};

TexturesDataUtilities.TextureLoaded = function (texture)
{
	if (texture && texture.image !== null && texture.image != undefined && texture.image.complete)
	{
		texture.needsUpdate = true;
		return texture;
	}

	return null;
};

TexturesDataUtilities.GetRealWorldSizedTexture = function (textureName, width, height)
{
	if (textureName == "" || textureName == "null")
		return null;

	if (!TexturesDataUtilities.FindTexture(textureName))
	{
		let OnTextureLoaded = new TexturesDataUtilities_OnTextureLoaded(textureName);
		TexturesDataUtilities.LoadTextureFromName(textureName, OnTextureLoaded.TextureLoaded);
	}

	let elem_texture = TexturesDataUtilities.SelectTexture(textureName, THREE.RepeatWrapping, THREE.RepeatWrapping);

	if (elem_texture && elem_texture.image && elem_texture.image != undefined)
	{
		let real_world_texture_width = elem_texture.realWorldWidth;
		let real_world_texture_height = elem_texture.realWorldHeight;

		if ((width / real_world_texture_width != 1 || height / real_world_texture_height != 1) && (width != -1 && height != -1))
		{
			let elem_texture_clone = elem_texture.clone();
			elem_texture_clone.needsUpdate = true;
			elem_texture_clone.repeat.set(width / real_world_texture_width, height / real_world_texture_height);
			//elem_texture_clone.repeat.set( 1, 1);

			elem_texture_clone.wrapS = THREE.RepeatWrapping;
			elem_texture_clone.wrapT = THREE.RepeatWrapping;

			elem_texture_clone.anisotropy = threeRenderer.capabilities.getMaxAnisotropy();

			return elem_texture_clone;
		}
		else
		{
			/*elem_texture.wrapS      = THREE.MirroredRepeatWrapping;
                elem_texture.wrapT      = THREE.MirroredRepeatWrapping;
                */

			elem_texture.anisotropy = threeRenderer.capabilities.getMaxAnisotropy();

			return elem_texture;
		}
	}

	return null;
};

TexturesDataUtilities.AssignUVsToGeometryXY = function (geometry)
{
	geometry.computeBoundingBox();

	let max = geometry.boundingBox.max;
	let min = geometry.boundingBox.min;

	let offset = new THREE.Vector2(0 - min.x, 0 - min.y);
	let range = new THREE.Vector2(max.x - min.x, max.y - min.y);

	geometry.faceVertexUvs = [];
	geometry.faceVertexUvs[0] = [];
	let faces = geometry.faces;

	for (let i = 0; i < geometry.faces.length; i++)
	{
		let v1 = geometry.vertices[faces[i].a];
		let v2 = geometry.vertices[faces[i].b];
		let v3 = geometry.vertices[faces[i].c];

		geometry.faceVertexUvs[0].push([
			new THREE.Vector2((v1.x + offset.x) / range.x, (v1.y + offset.y) / range.y),
			new THREE.Vector2((v2.x + offset.x) / range.x, (v2.y + offset.y) / range.y),
			new THREE.Vector2((v3.x + offset.x) / range.x, (v3.y + offset.y) / range.y)
		]);
	}

	geometry.uvsNeedUpdate = true;
};

TexturesDataUtilities.AssignUVsToGeometryYX = function (geometry)
{
	geometry.computeBoundingBox();

	let max = geometry.boundingBox.max;
	let min = geometry.boundingBox.min;

	let offset = new THREE.Vector2(0 - min.y, 0 - min.x);
	let range = new THREE.Vector2(max.y - min.y, max.x - min.x);

	geometry.faceVertexUvs = [];
	geometry.faceVertexUvs[0] = [];
	let faces = geometry.faces;

	for (i = 0; i < geometry.faces.length; i++)
	{
		let v1 = geometry.vertices[faces[i].a];
		let v2 = geometry.vertices[faces[i].b];
		let v3 = geometry.vertices[faces[i].c];

		geometry.faceVertexUvs[0].push([
			new THREE.Vector2((v1.y + offset.x) / range.x, (v1.x + offset.y) / range.y),
			new THREE.Vector2((v2.y + offset.x) / range.x, (v2.x + offset.y) / range.y),
			new THREE.Vector2((v3.y + offset.x) / range.x, (v3.x + offset.y) / range.y)
		]);
	}

	geometry.uvsNeedUpdate = true;
};


TexturesDataUtilities.AssignUVsToGeometryZY = function (geometry)
{
	geometry.computeBoundingBox();

	let max = geometry.boundingBox.max;
	let min = geometry.boundingBox.min;

	let offset = new THREE.Vector2(0 - min.z, 0 - min.y);
	let range = new THREE.Vector2(max.z - min.z, max.y - min.y);

	geometry.faceVertexUvs = [];
	geometry.faceVertexUvs[0] = [];
	let faces = geometry.faces;

	for (let i = 0; i < geometry.faces.length; i++)
	{
		let v1 = geometry.vertices[faces[i].a];
		let v2 = geometry.vertices[faces[i].b];
		let v3 = geometry.vertices[faces[i].c];

		geometry.faceVertexUvs[0].push([
			new THREE.Vector2((v1.z + offset.x) / range.x, (v1.y + offset.y) / range.y),
			new THREE.Vector2((v2.z + offset.x) / range.x, (v2.y + offset.y) / range.y),
			new THREE.Vector2((v3.z + offset.x) / range.x, (v3.y + offset.y) / range.y)
		]);
	}

	geometry.uvsNeedUpdate = true;
};

TexturesDataUtilities.AssignUVsToGeometryXZ = function (geometry)
{
	geometry.computeBoundingBox();

	let max = geometry.boundingBox.max;
	let min = geometry.boundingBox.min;

	let offset = new THREE.Vector2(0 - min.x, 0 - min.z);
	let range = new THREE.Vector2(max.x - min.x, max.z - min.z);

	geometry.faceVertexUvs = [];
	geometry.faceVertexUvs[0] = [];
	let faces = geometry.faces;

	for (let i = 0; i < geometry.faces.length; i++)
	{
		let v1 = geometry.vertices[faces[i].a];
		let v2 = geometry.vertices[faces[i].b];
		let v3 = geometry.vertices[faces[i].c];

		geometry.faceVertexUvs[0].push([
			new THREE.Vector2((v1.x + offset.x) / range.x, (v1.z + offset.y) / range.y),
			new THREE.Vector2((v2.x + offset.x) / range.x, (v2.z + offset.y) / range.y),
			new THREE.Vector2((v3.x + offset.x) / range.x, (v3.z + offset.y) / range.y)
		]);
	}

	geometry.uvsNeedUpdate = true;
};



TexturesDataUtilities.AssignUVsToGeometryZX = function (geometry)
{
	geometry.computeBoundingBox();

	let max = geometry.boundingBox.max;
	let min = geometry.boundingBox.min;

	let offset = new THREE.Vector2(0 - min.z, 0 - min.x);
	let range = new THREE.Vector2(max.z - min.z, max.x - min.x);

	geometry.faceVertexUvs = [];
	geometry.faceVertexUvs[0] = [];
	let faces = geometry.faces;

	for (let i = 0; i < geometry.faces.length; i++)
	{
		let v1 = geometry.vertices[faces[i].a];
		let v2 = geometry.vertices[faces[i].b];
		let v3 = geometry.vertices[faces[i].c];

		geometry.faceVertexUvs[0].push([
			new THREE.Vector2((v1.z + offset.x) / range.x, (v1.x + offset.y) / range.y),
			new THREE.Vector2((v2.z + offset.x) / range.x, (v2.x + offset.y) / range.y),
			new THREE.Vector2((v3.z + offset.x) / range.x, (v3.x + offset.y) / range.y)
		]);
	}

	geometry.uvsNeedUpdate = true;
};

TexturesDataUtilities.AddFilenameToBeLoaded = function (filename)
{
	TexturesDataUtilities.textureFilenamesToBeLoaded.push(filename);
};

/**
 * Callback constructor for textures loaded callback
 * @class TexturesDataUtilities_OnTextureLoaded
 * @param {string} texture texture name
 */
function TexturesDataUtilities_OnTextureLoaded (texture)
{

	this.texture = texture;

	this.TextureLoaded = function()
	{
		TexturesDataUtilities.loadingTexture[this.texture] = false;
		delete TexturesDataUtilities.toLoadTexture[texture];
		TexturesDataUtilities.GetAvgRGBForTextures();

		if (buildingDesigner.SetRegenerate && Object.keys(TexturesDataUtilities.toLoadTexture).length === 0)
		{
			buildingDesigner.SetRegenerate(true);

			buildingDesigner.building.SetRegenerateRulers(true);

			buildingDesigner.Draw();

			ElementsMenu.ElementsListPricingUpdate();
		}
	};
}

TexturesDataUtilities.GetTextureData = function (textureName)
{
	for (let i = 0; i < TexturesDataUtilities.textureData.length; i++)
		if (TexturesDataUtilities.textureData[i].textureName === textureName)
			return TexturesDataUtilities.textureData[i];

	return null;
};

TexturesDataUtilities.LoadTextureFromName = function (textureName, onTextureLoaded)
{
	if (!TexturesDataUtilities.loadingTexture[textureName] && TexturesDataUtilities.textureData.length > 0)
	{
		let textureData = TexturesDataUtilities.GetTextureData(textureName);

		if (!textureData)
		{
			//alert("Texture data not in database for: " + textureName);
			if (TexturesDataUtilities.dataLoaded)
			{
				console.log("Texture data not in database for: " + textureName);
			}
			return null;
		}

		let textureFile = DIR_TEXTURES + textureData.textureFile;

		return TexturesDataUtilities.LoadTexture(textureFile, textureData.textureName, textureData.realWorldWidth, textureData.realWorldHeight, onTextureLoaded);
	}

	return null;
};


TexturesDataUtilities.LoadTexture = function (filename, textureName, realWorldWidth, realWorldHeight, onTextureLoaded)
{
	TexturesDataUtilities.loadingTexture[textureName] = true;
	TexturesDataUtilities.toLoadTexture[textureName] = true;

	if (textureName == undefined || textureName == null || textureName == "")
	{
		textureName = filename.replace(/^.*[\\\/]/, "");
	}

	let texture = TexturesDataUtilities.loader.load(RESOURCE_HOST + filename, onTextureLoaded);

	texture.wrapS = THREE.RepeatWrapping;
	texture.wrapT = THREE.RepeatWrapping;
	texture.textureName = textureName;

	texture.realWorldWidth = realWorldWidth;
	texture.realWorldHeight = realWorldHeight;

	TexturesDataUtilities.textures_list.push(texture);

	return texture;
};


TexturesDataUtilities.AddToData = function (textureData)
{
	/*for (let i = 0; i < textureData.length; i++) {
		TexturesDataUtilities.textureData.push(textureData[i]);
	} */
	TexturesDataUtilities.textureData = [...TexturesDataUtilities.textureData, ...textureData];
};

TexturesDataUtilities.GetTextureDataFromServer = async function ()
{
	TexturesDataUtilities.textureData = await NodeJSUtilities.UQuery("dataRequest",{request: "getTextures", subscriber_id: SubscriberDataUtilities.subscriber, series_code: SubscriberDataUtilities.series_code});
	return true;
};

TexturesDataUtilities.dataLoaded = false;

TexturesDataUtilities.textureData = [];

TexturesDataUtilities.loadingTexture = [];
TexturesDataUtilities.toLoadTexture = [];
