/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Stalls()
{
	this.regenerate = true;

	this.stallsList = [];

	this.stallWidth = buildingDesigner.building.length / buildingDesigner.building.stallCount;

	this.doorID = null;

	this.Initialize = function ()
	{
		let zStart = -buildingDesigner.building.length / 2;

		for (let i = 0; i < buildingDesigner.building.stallCount; i++)
		{
			this.stallsList[i] = new Stall(zStart, this.stallWidth, buildingDesigner.building.roofRafter.wallWidth, buildingDesigner.building.backWallHeight, i, (i < buildingDesigner.building.stallCount - 1) ? true : false, true);
			////this.stallsList[i] = new Stall(zStart, this.stallWidth, buildingDesigner.building.roofRafter.wallWidth, buildingDesigner.building.backWallHeight, i, (i<buildingDesigner.building.stallCount-1) ? true : false, false);

			zStart += this.stallWidth;
		}
	};

	this.SetDefaultElements = function (defaultElements)
	{
		this.defaultElements = defaultElements;

		if (this.defaultElements)
		{
			for (let i = 0; i < this.defaultElements.length; i++)
			{
				switch (this.defaultElements[i].object_type)
				{
				case ("door"):
					this.SetDefaultStallDoor(this.defaultElements[i].elem_id);
					break;

				case ("window"):
					this.SetDefaultStallWindow(this.defaultElements[i].elem_id);
					break;
				}
			}
		}
	};

	this.SetDefaultStallDoor = function (id)
	{
		this.doorID = id;
	};

	this.SetDefaultStallWindow = function (id)
	{
		this.windowID = id;
	};

	this.AddDefaultDoor = function (doorData, x, y, z, eWall)
	{
		let element = Door.AddDoor(doorData, Door.LEFT_OPENING);

		element.colorFromBarn = true;

		element.SetWall(buildingDesigner.building.walls.GetWall(eWall));
		element.SetPos(x, y, z);
	};

	this.AddDefaultWindow = function (windowData, x, y, z, eWall)
	{
		let element = Window.AddWindow(windowData);

		element.colorFromBarn = true;

		element.SetWall(buildingDesigner.building.walls.GetWall(eWall));
		element.SetPos(x, y, z);
	};


	this.AddDefaultElements = function ()
	{
		let doorData;

		if (this.doorID && this.doorID != "")
			doorData = GuiDataUtilities.GetDoorButtonData(this.doorID);
		else
			doorData = GuiDataUtilities.doorsButtonData[0];


		let windowData = null;

		if (this.windowID == "null")
			this.windowID = null;

		if (this.windowID && this.windowID != "")
			windowData = GuiDataUtilities.GetWindowButtonData(this.windowID);

		let zStart = -buildingDesigner.building.length / 2;

		for (let i = 0; i < buildingDesigner.building.stallCount; i++)
		{
			this.AddDefaultDoor(doorData, zStart + this.stallWidth / 2, 0, Wall.WALLTHICKNESS, WALL_FRONT);

			if (windowData)
				this.AddDefaultWindow(windowData, zStart + this.stallWidth / 2, buildingDesigner.building.backWallHeight * 2 / 3, -Wall.WALLTHICKNESS, WALL_BACK);

			zStart += this.stallWidth;
		}

		buildingDesigner.building.SetRegenerateElementMeshes(true);

		buildingDesigner.building.SetBuildingModified();
	};

	this.GetSelectedPartition = function ()
	{
		for (let i = 0; i < this.stallsList.length; i++)
		{
			if (this.stallsList[i].partition && this.stallsList[i].partition.selected)
				return this.stallsList[i].partition;
		}

		return null;
	};

	this.ClearSelections = function ()
	{
		for (let i = 0; i < this.stallsList.length; i++)
		{
			if (this.stallsList[i].partition)
				this.stallsList[i].partition.selected = false;
		}
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;

		if (this.stallsList.length > 0)
			for (let i = 0; i < buildingDesigner.building.stallCount; i++)
			{
				this.stallsList[i].SetRegenerate(this.regenerate);
			}
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			this.stallMeshes = new THREE.Mesh();

			for (let i = 0; i < buildingDesigner.building.stallCount; i++)
			{
				this.stallsList[i].Generate(this.stallMeshes);
			}


			for (let i = 0; i < this.stallMeshes.children.length; i++)
			{
				buildingMeshes.push(this.stallMeshes.children[i]);
			}

			this.regenerate = false;
		}
	};

	this.SetPartitionStyle = function (newStyle)
	{
		for (let i = 0; i < buildingDesigner.building.stallCount; i++)
		{
			this.stallsList[i].SetPartitionStyle(newStyle);
		}
	};
}
