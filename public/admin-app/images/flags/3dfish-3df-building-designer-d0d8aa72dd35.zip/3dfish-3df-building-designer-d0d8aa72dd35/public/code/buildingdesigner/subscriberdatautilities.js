/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef, no-global-assign */
/*eslint-parserOptions ecmaVersion:8*/
/* globals NodeJSUtilities, AuxUtilities, features, featureData, interfaceCode, Price_Blurb */
function SubscriberDataUtilities()
{

}

SubscriberDataUtilities.locationData = [];

SubscriberDataUtilities.LoadData = async function()
{
	let err;
	[err, SubscriberDataUtilities.locationData] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getSubscriberData", subscriber_id: SubscriberDataUtilities.subscriber}));
	if (err)
	{
		alert("Error communicating with the server. Please try again. If the problem persists, please contact support.");
		return;
	}
	let activeFeatures;
	[err, activeFeatures] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getActiveFeatures", subscriber_id: SubscriberDataUtilities.subscriber}));
	let featureData;
	[err, featureData] = await to(NodeJSUtilities.UQuery("dataRequest",{request:"getFeatureData", subscriber_id: SubscriberDataUtilities.subscriber}));


	SubscriberDataUtilities.featureData = featureData;
	if (SubscriberDataUtilities.locationData[0] == "Subscriber ID NOT Found")
	{
		window.location.href = "https://mybuilding.3dfish.net/";
	}

	if (SubscriberDataUtilities.locationData.length && SubscriberDataUtilities.locationData.length>0)
		SubscriberDataUtilities.subscriberData = SubscriberDataUtilities.locationData[0];
	else
		SubscriberDataUtilities.subscriberData = SubscriberDataUtilities.locationData;

	//SubscriberDataUtilities.location_number = SubscriberDataUtilities.subscriberData.location_number;
	SubscriberDataUtilities.SetLocation(SubscriberDataUtilities.location_number);

	if (SubscriberDataUtilities.subscriberData.display_prices == 1)
	{
		$("a[href$=tabPricing]").text("Pricing");
	}

	[err, SubscriberDataUtilities.descriptions] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getDescriptions", subscriber_id: SubscriberDataUtilities.subscriber}));

	//SubscriberDataUtilities.descriptions = AuxUtilities.tryParseJSON(descriptionsDataStr);

	if (SubscriberDataUtilities.descriptions.length && SubscriberDataUtilities.descriptions.length>0)
	{
		for (let i=0; i<SubscriberDataUtilities.descriptions.length; i++)
		{
			switch (SubscriberDataUtilities.descriptions[i].category_id)
			{
			case "ORDER":
				if (interfaceNumber < 3)
				{
					$("#tabOrder").html(SubscriberDataUtilities.descriptions[i].long_description);
				}
				break;
			case "GUIDE":
				$("#tabHowto").html(SubscriberDataUtilities.descriptions[i].long_description);
				break;
			case "PRICING":
				Price_Blurb = i + 1;
				break;
			case "PRINT": {
				SubscriberDataUtilities.printPage2 = true;
				$("#printpage2").html(SubscriberDataUtilities.descriptions[i].long_description);
				// $("#printpage2").css('page-break-before','always');
				break;
			}
			}
		}
	}

	SubscriberDataUtilities.design_prefix = activeFeatures[0].design_prefix;
	if (buildingDesigner && buildingDesigner.building && buildingDesigner.building.designID)
	{
		GuiDataUtilities.displayDesignID(buildingDesigner.building.designID);
	}
	$("#design_prefix").text(SubscriberDataUtilities.design_prefix+"_");

	features = activeFeatures[0].active_features;
	if (features===null) features = " ";
	else features = " " + features;
	if (features.indexOf("NOGUIDE")>-1) $("#tabHowtoButton").hide(); else $("#tabHowtoButton").show();
	if (features.indexOf("NOSHELVES")>-1) $("#tabShelvesButton").hide(); else $("#tabShelvesButton").show();
	if (features.indexOf("NOORDER")>-1) $("#tabOrderButton").hide(); else $("#tabOrderButton").show();
	if (features.indexOf("DORMERS")>-1)
	{
		if (interfaceNumber > 2)
		{
			$("#dormers-label").show();
		}
		else
		{
			$("#tabDormersButton").show();
		}
	}
	else
	{
		if (interfaceNumber > 2)
		{
			$("#dormers-label").hide();
		}
		else
		{
			$("#tabDormersButton").hide();
		}

	}

	// featureData = JSON.parse(featureDataStr);
	if ((typeof(interfaceCode) !== "undefined") && (interfaceCode == "if2"))
	{
		if (featureData.interface)
		{
			/* This moved to the interface2.ejs
			if(featureData.interface.if2_menu_bcolor) {
				$(".navbar-inverse").css("background",featureData.interface.if2_menu_bcolor);
			}
			if (featureData.interface.if2_menu_color) {
				$(".navbar-nav").css("color",featureData.interface.if2_menu_color);
			} */

			/*
			Depricated: interface should be loaded in EJS only.
			if (featureData.interface.info_bar_html) {
				let infobarHTML = document.getElementById("infobar-html");

				infobarHTML.attributes["src"].nodeValue = featureData.interface.info_bar_html;

				////infobarHTML.children[1].innerHTML='<object type="text/html" data="' + featureData.interface.info_bar_html + '"></object>';
			} */
		}
		////$("#BuildingsModal").modal('show');
	}

	let vr = TextDataUtilities.GetParameterByName("vr");

	if (vr && vr=="true")
	{
		if (features.indexOf("VR")>-1)
		{
			BuildingDesigner.vrAvailable = BuildingDesigner.vrCheckAvailability();

			BuildingDesigner.vrAvailable.then(
				function(result)
				{
					//threeRenderer.vr.enabled = true;
				},
				function(error)
				{
					//VR devices not found so initialize google cardboard
					ControlsMenu.ShowEnterVR();

					window.addEventListener("deviceorientation", GUIInput.setOrientationControls, true);
				}
			);
		}
	}

	if (buildingDesigner)
	{
		buildingDesigner.logo = SubscriberDataUtilities.subscriberData.logo_file_name ? new Logo(SubscriberDataUtilities.subscriberData.logo_file_name):null;
	}
};

SubscriberDataUtilities.SetLocation = function(location)
{
	SubscriberDataUtilities.location_number = location;
	if (SubscriberDataUtilities.subscriberData && SubscriberDataUtilities.location_number !== 0)
	{
		findLocation:
		for (let i = 0; i<SubscriberDataUtilities.locationData.length; i++)
		{
			if (SubscriberDataUtilities.locationData[i].location_number == location)
			{
				SubscriberDataUtilities.subscriberData = SubscriberDataUtilities.locationData[i];
				SubscriberDataUtilities.location_number = SubscriberDataUtilities.subscriberData.location_number;
				break findLocation;
			}
		}
		if (interfaceCode === "if3")
		{
			$("#phonenumber").html(`<a id="phonelink" href="tel:${SubscriberDataUtilities.subscriberData.phone}">${SubscriberDataUtilities.subscriberData.phone}</a>`);
		}
	}
};

SubscriberDataUtilities.SetPrintout = function()
{
	if (SubscriberDataUtilities.custom_printout)
	{
		if (SubscriberDataUtilities.featureData && SubscriberDataUtilities.featureData.customprintout)
		{
			$("#printpage1").html(SubscriberDataUtilities.featureData.customprintout.html);
		}
	}
	else
	{
		if (SubscriberDataUtilities.featureData && SubscriberDataUtilities.featureData.defaultprintout)
		{
			$("#printpage1").html(SubscriberDataUtilities.featureData.defaultprintout.html);
		}
	}
}

SubscriberDataUtilities.subscriber = "";
SubscriberDataUtilities.design_prefix = "";
SubscriberDataUtilities.location_number = 0;
SubscriberDataUtilities.subscriberData = null;
SubscriberDataUtilities.descriptions = null;
SubscriberDataUtilities.series_code = "";
SubscriberDataUtilities.custom_printout = false;
SubscriberDataUtilities.featureData = {};
SubscriberDataUtilities.print_salesperson = true;
SubscriberDataUtilities.printPage2 = false;

if (window.socket)
{
	socket.on("connect", async () =>
	{
		if (!(typeof AdminUtilities === "undefined"))
		{ //AdminUtilities are not loaded for login.ejs codebase
			AdminUtilities.OnConnectUpdate();
			UserDataUtilities.updateAppStatus();
		}
	});

	socket.on("serverlog", async (data) =>
	{
		if (DEBUG)
		{
			console.log("socket.on(serverlog)");
		}
		if (!(typeof AdminUtilities === "undefined"))
		{
			AdminUtilities.OnServerLog(data);
		}
	});

	socket.on("update", async (data) =>
	{
		if (DEBUG)
		{
			console.log("socket.on(update)");
		}
		if (!(typeof AdminUtilities === "undefined"))
		{
			AdminUtilities.OnUpdate(data);
		}
	});

	socket.on("adminActionResponse", async (data) =>
	{
		if (DEBUG)
		{
			console.log("socket.on(adminActionResponse)");
		}
		if (!(typeof AdminUtilities === "undefined"))
		{
			AdminUtilities.OnAdminActionResponse(data);
		}
	});

	socket.on("request", async (data, fn) =>
	{
		if (data.requesttype)
		{
			switch (data.requesttype)
			{
			case "ident": {
				let [err, result] = await to($.getJSON("https://ipapi.co/json"));
				fn({
					subscriber_id: SubscriberDataUtilities.subscriber,
					ip: result ? result.ip : null,
					tdf_version: window.tdf_version
				});
				break;
			}
			}
		}
	});
}
