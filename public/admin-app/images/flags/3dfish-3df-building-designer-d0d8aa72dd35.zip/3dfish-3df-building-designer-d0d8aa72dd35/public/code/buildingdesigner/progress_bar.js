/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function ProgressBar()
{}

ProgressBar.StartProgressBar = function ()
{
	if ((typeof (interfaceCode) !== "undefined") && (interfaceCode == "if2"))
	{
		let progressBar = document.getElementById("progressBar");
		progressBar.style.visibility = "visible";

		ProgressBar.maximumValue = 100;
		// setInterval(function(){ProgressBar.AutoSetValue();},1500);
		if (typeof (Worker) !== "undefined")
		{
			if (typeof (pbworker) == "undefined")
			{
				pbworker = new Worker("code/buildingdesigner/progress_bar_worker.js");
				pbworker.onmessage = function (event)
				{
					ProgressBar.AutoSetValue();
				};
			}
		}
	}
};

ProgressBar.AutoSetValue = function ()
{
	ProgressBar.currentValue++;
	if (DEBUG)
	{
		console.log("--- AutoInc ---");
	}
	let percentage = ProgressBar.currentValue / ProgressBar.maximumValue * 100;

	percentage = MathUtilities.Round(percentage, 0);

	let percentageStr = percentage + "%";

	let progressBar = document.getElementById("progressBar");

	progressBar.attributes[3].value = percentage;

	progressBar.style.width = percentageStr;

	progressBar.innerHTML = percentageStr;
	progressBar.innerText = percentageStr;
	progressBar.textContent = percentageStr;

	if (percentage >= 100)
		ProgressBar.EndProgressBar();
};

ProgressBar.SetValue = function (value)
{
	if ((typeof (interfaceCode) !== "undefined") && (interfaceCode == "if2"))
	{
		if (ProgressBar.currentValue < value)
		{
			ProgressBar.currentValue = value;

			let percentage = ProgressBar.currentValue / ProgressBar.maximumValue * 100;

			percentage = MathUtilities.Round(percentage, 0);

			let percentageStr = percentage + "%";
			if (DEBUG && (percentage == 20)) console.log("-------- 20% ------ ");
			if (DEBUG && ((percentage > 20) && (percentage < 22))) console.log("-------- 21% ------ ");
			if (DEBUG && ((percentage > 30) && (percentage < 32))) console.log("-------- 31% ------ ");
			let progressBar = document.getElementById("progressBar");

			progressBar.attributes[3].value = percentage;

			progressBar.style.width = percentageStr;

			progressBar.innerHTML = percentageStr;
			progressBar.innerText = percentageStr;
			progressBar.textContent = percentageStr;

			if (percentage >= 100)
				ProgressBar.EndProgressBar();
		}
	}
};

ProgressBar.EndProgressBar = function ()
{
	if ((typeof (interfaceCode) !== "undefined") && (interfaceCode == "if2"))
	{
		let progressBar = document.getElementById("progressBar");
		progressBar.style.visibility = "hidden";
		//clearInterval();
		if (typeof (pbworker) !== "undefined")
		{
			pbworker.terminate();
			pbworkder = undefined;
		}
	}
	else
	{
		$("#objectLoader").hide();
	}
};

ProgressBar.currentValue = 0;
