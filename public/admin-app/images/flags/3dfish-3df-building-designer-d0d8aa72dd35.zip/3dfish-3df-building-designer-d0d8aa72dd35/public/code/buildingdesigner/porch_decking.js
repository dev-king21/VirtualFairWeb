/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function PorchDecking(porch)
{
	this.parent = porch;

	let options = {};
	if (buildingDesigner.buildingButtonData.options && buildingDesigner.buildingButtonData.options.porch)
	{
		options = buildingDesigner.buildingButtonData.options.porch;
	}
	this.deckingTextureFileName = options.deckingTextureFileName || "porch_decking";
	this.deckingTexture = null;
	this.deckingColor = options.deckingColor || 0x999999;

	this.regenerate = true;

	this.SetDeckingColor = function (color)
	{
		this.deckingColor = color;
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.GetTextures = function ()
	{
		if (this.deckingTextureFileName != "")
		{
			this.deckingTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.deckingTextureFileName, 1, 1);
		}
		else
			this.deckingTexture = null;
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			this.GetTextures();

			this.mesh = new THREE.Mesh();

			let deckingMater = new THREE.MeshLambertMaterial({
				color: this.deckingColor,
				map: TexturesDataUtilities.TextureLoaded(this.deckingTexture)
			});

			let deckingPoints = [];

			for (let i=0; i<this.parent.shape.length;i++)
			{
				deckingPoints.push({x: this.parent.shape[i].x, y: -this.parent.shape[i].z});
			}

			let shape = new THREE.Shape(deckingPoints);

			let deckingGeometry = new THREE.ExtrudeGeometry(shape, {
				depth:  buildingDesigner.building.roofRafter.data.soffit_board_width,
				bevelEnabled: false
			});

			this.mesh = new THREE.Mesh(deckingGeometry, deckingMater);

			this.mesh.matrixAutoUpdate = false;
			this.mesh.applyMatrix4(new THREE.Matrix4().makeRotationX(-Math.PI/2));

			if (this.parent.rightSide)
			{
				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(new THREE.Matrix4().makeTranslation((buildingDesigner.building.porch.length>=0 ? 1 * buildingDesigner.building.roofRafter.wallWidth/2 : -1 * buildingDesigner.building.roofRafter.wallWidth/2), buildingDesigner.building.floorHeight, -buildingDesigner.building.length/2 + Wall.WALLTHICKNESS + (buildingDesigner.building.porch.length>0 ? this.parent.backWallLength : this.parent.frontWallLength)));
			}
			else
			{
				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(new THREE.Matrix4().makeTranslation((buildingDesigner.building.porch.length>=0 ? 1 * buildingDesigner.building.roofRafter.wallWidth/2 : -1 * buildingDesigner.building.roofRafter.wallWidth/2), buildingDesigner.building.floorHeight, buildingDesigner.building.length/2 - Wall.WALLTHICKNESS - (buildingDesigner.building.porch.length>0 ? this.parent.backWallLength : this.parent.frontWallLength)));
			}


			this.mesh.receiveShadow = true;

			buildingMeshes.push(this.mesh);

			this.regenerate = false;
		}
	};
}

PorchDecking.DECKING_THICKNESS = 0.01;
