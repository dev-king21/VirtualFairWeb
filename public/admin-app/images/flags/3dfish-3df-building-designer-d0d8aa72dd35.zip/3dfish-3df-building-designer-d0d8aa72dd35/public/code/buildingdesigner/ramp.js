/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

////function Ramp(length, price)
function Ramp(buttonData, length)
{
	////Element.call(this, "Ramp", "Ramp", "", 0, 0, "", "", 0, price);

	Element.call(this, buttonData);

	buttonData.type = ELEM_RAMP;

	this.length = length;

	this.rampColor = 0xDAC6A7;
	this.rampMatter = null;
	this.rampTexture = buttonData.texture_name || "duratemp_interior";

	this.door = null;

	this.rampID = 0;

	this.rampGeom = null;

	this.regenerate = true;

	/**
	 * @method Ramp.GetDesignXMLString
	 * @returns {string} XML String with ramp data
	 */
	this.GetDesignXMLString = function ()
	{
		//let strElemType = ELEM_STRING[buttonData.type];

		let strXml = "<ELEMENT ";

		strXml += " buttonData=\"" + AuxUtilities.JSONStringifyAndEncode(this.buttonData) + "\"";

		if (this.wall)
			strXml += " wall=\"" + WALL_STRING[this.wall.eWall] + "\"";

		strXml += " configurationMode=\"" + this.configurationMode + "\"";

		strXml += " x=\"" + this.pos.x + "\"";
		strXml += " y=\"" + this.pos.y + "\"";
		strXml += " z=\"" + this.pos.z + "\"";

		strXml += " rampID=\"" + this.rampID + "\"";

		strXml += " defaultElementData=\"" + AuxUtilities.JSONStringifyAndEncode(this.defaultElementData) + "\"";

		strXml += "></ELEMENT>";

		return strXml;
	};

	/**
	 * @method Ramp.GetDesignObject
	 * @returns {Object} Ramp object
	 */
	this.GetDesignObject = function ()
	{
		let ramp = {
			buttonData: this.buttonData,
			configurationMode: this.configurationMode,
			x: this.pos.x,
			y: this.pos.y,
			z: this.pos.z,
			rampID: this.rampID,
			defaultElementData: this.defaultElementData
		};
		if (this.wall)
		{
			ramp.wall = this.wall.eWall;
		}
		return ramp;
	};

	this.Initialize = function ()
	{
		for (let i = 0; i < Elements.list.length; i++)
		{
			if (Elements.list[i].buttonData.type == ELEM_DOOR)
				if (Elements.list[i].rampID == this.rampID)
				{
					Elements.list[i].ramp = this;
					this.SetDoor(Elements.list[i]);
				}
		}
	};

	this.GetMatrix = function ()
	{
		return this.mesh.matrix;
	};

	this.SetDoor = function (door)
	{
		if (this.door)
		{
			this.door.ramp = null;
			this.door.rampID = "-1";
		}

		if (door)
		{
			this.door = door;
			this.door.ramp = this;
			this.door.rampID = this.rampID;

			this.data = GuiDataUtilities.GetClosestRampToDoor(door);

			if (this.width != this.door.doorWidth)
			{
				this.rampGeom = null;
			}

			this.width = this.data.width;
			this.height = this.data.height;
			this.SetPrice(this.data.price);
			this.SetName(this.data.display_size + " " +this.buttonData.element_base_name);

			this.SetRegenerate(true);
		}
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate && this.door && this.door.wall)
		{
			if (this.rampGeom == null || this.width != this.door.doorWidth)
			{
				this.rampGeom = new THREE.Geometry();

				let w2 = this.width / 2;

				let v1 = new THREE.Vector3(-w2, -this.height, this.length);
				let v2 = new THREE.Vector3(w2, -this.height, this.length);
				let v3 = new THREE.Vector3(w2, 0, 0);

				this.rampGeom.vertices.push(v1);
				this.rampGeom.vertices.push(v2);
				this.rampGeom.vertices.push(v3);

				v1 = new THREE.Vector3(w2, 0, 0);
				v2 = new THREE.Vector3(-w2, 0, 0);
				v3 = new THREE.Vector3(-w2, -this.height, this.length);

				this.rampGeom.vertices.push(v1);
				this.rampGeom.vertices.push(v2);
				this.rampGeom.vertices.push(v3);


				v1 = new THREE.Vector3(w2, -this.height, this.length);
				v2 = new THREE.Vector3(w2, -this.height, 0);
				v3 = new THREE.Vector3(w2, 0, 0);

				this.rampGeom.vertices.push(v1);
				this.rampGeom.vertices.push(v2);
				this.rampGeom.vertices.push(v3);


				v1 = new THREE.Vector3(-w2, -this.height, this.length);
				v2 = new THREE.Vector3(-w2, 0, 0);
				v3 = new THREE.Vector3(-w2, -this.height, 0);

				this.rampGeom.vertices.push(v1);
				this.rampGeom.vertices.push(v2);
				this.rampGeom.vertices.push(v3);

				this.rampGeom.faces.push(new THREE.Face3(0, 1, 2));
				this.rampGeom.faces.push(new THREE.Face3(3, 4, 5));

				this.rampGeom.faces.push(new THREE.Face3(6, 7, 8));
				this.rampGeom.faces.push(new THREE.Face3(9, 10, 11));

				this.rampGeom.computeFaceNormals();

				let matrix = new THREE.Matrix4();

				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, this.height - Base.RUNNERSIZE, 0));

				this.rampGeom.matrixAutoUpdate = false;
				this.rampGeom.applyMatrix4(matrix);

				let rampTexture = TexturesDataUtilities.SelectTexture(this.rampTexture, THREE.MirroredRepeatWrapping, THREE.MirroredRepeatWrapping);

				this.rampMatter = Material.CreateMaterial(this.rampColor, rampTexture);

				TexturesDataUtilities.AssignUVsToGeometryXZ(this.rampGeom);
			}


			this.mesh = new THREE.Mesh(this.rampGeom, this.rampMatter);

			this.mesh.castShadow = true;

			this.mesh.type = ELEM_RAMP;

			MeshUtilities.SetElement(this.mesh, this);

			if (this.selected)
			{
				this.GenerateSelectedBoxes(this.mesh, new THREE.Matrix4().makeTranslation(0, 0, this.length / 2));
			}

			this.UpdateMatrix();
		}

		return this.mesh;
	};

	this.UpdateMatrix = function ()
	{
		if (this.mesh && this.door && this.door.wall && this.door.wall.matrix)
		{
			let matrix = new THREE.Matrix4();
			matrix = new THREE.Matrix4().multiplyMatrices(this.door.wall.matrix, matrix);

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.door.pos.x, 0, this.door.pos.z));

			if (this.door.wall.eWall == WALL_LEFT || this.door.wall.eWall == WALL_BACK)
			{
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationY(-MathUtilities.PI));
			}

			this.mesh.matrixAutoUpdate = false;
			this.mesh.applyMatrix4(matrix);
		}
	};

	this.DraggingElement = function (wall, facetIndex, vectorPos)
	{
		let elementAndPos = buildingDesigner.building.GetSelectedElement({
			x: GUIInput.vecCurrentMousePos.x,
			y: GUIInput.vecCurrentMousePos.y
		});

		if (elementAndPos != null && elementAndPos.element != null && elementAndPos.element.buttonData.type == ELEM_DOOR)
		{
			if (!elementAndPos.element.ramp)
				this.SetDoor(elementAndPos.element);

			buildingDesigner.building.SetRegenerateElementMeshes(true);
		}
	};

	this.EndDragging = function ()
	{
		this.dragging = false;

		this.dragged = true;

		buildingDesigner.camera.cameraControls.enabled = true;
		
		if (!this.door)
			Elements.DeleteElement(this);

		buildingDesigner.building.SetRegenerateElementMeshes(true);
	};

	this.Destroy = function ()
	{
		this.SetDoor(null);
	};
}

Ramp.AddRamp = function (buttonData, door)
{
	let ramp = new Ramp(buttonData, 3);

	if (door)
	{
		this.SetDoor(door);
	}

	ramp.rampID = "RAMP" + new Date().getTime();

	Elements.AddElement(ramp);

	return ramp;
};
