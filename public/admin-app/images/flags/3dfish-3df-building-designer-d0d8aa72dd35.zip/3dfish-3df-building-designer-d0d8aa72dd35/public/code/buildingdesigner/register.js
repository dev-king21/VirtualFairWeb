/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/
function Register()
{}

Register.Register = async function ()
{
	let registrationForm = document.getElementById("registrationForm");

	if (registrationForm.firstname.value.length == 0 || registrationForm.lastname.value.length == 0 || registrationForm.email.value.length == 0 || registrationForm.registrationUsername.value.length == 0 || registrationForm.registrationPassword.value.length == 0)
		Register.SetRegistrationError("All fields are required!");
	else
	{
		let [err, registrationData] = await to(NodeJSUtilities.UQuery("userAction", {request: "register", data: {firstname: AuxUtilities.properName(registrationForm.firstname.value), lastname: AuxUtilities.properName(registrationForm.lastname.value), email: registrationForm.email.value, username: registrationForm.registrationUsername.value, password:md5(registrationForm.registrationPassword.value), subscriber_id: SubscriberDataUtilities.subscriber, location_number: SubscriberDataUtilities.location_number, zip: UserDataUtilities.zipcode}}));

		if (err)
		{
			Register.SetRegistrationError("Error trying to register.");
			return;
		}
		if (registrationData.status == "success")
		{
			Register.SetRegistrationError("");

			registrationForm.registrationUsername.value = TextDataUtilities.ReplaceAll(registrationForm.registrationUsername.value, TextDataUtilities.PLUS_CODE, "+");

			UserDataUtilities.userID = registrationForm.registrationUsername.value;

			if (registrationData.userData)
			{
				UserDataUtilities.userData = registrationData.userData;
			}
			UserDataUtilities.GetUserData();

			Login.ShowLoggedInHMTL();

			window.location = ("" + window.location).replace(/#[A-Za-z0-9_]*$/, "") + "#closeButton";
			if (interfaceCode === "if3")
			{
				$("#registerFormCloseButton").click();
			}
		}
		else
		{
			if (registrationData.cause == "duplicate")
			{
				Register.SetRegistrationError("Username not available! Please choose another.");
			}
			else if (registrationData.cause === "existing")
			{
				Register.SetRegistrationError("Email already registered. Please log in with your email or user name.");
			}
			else
			{
				Register.SetRegistrationError("Error trying to register.");
			}
		}
	}
};

Register.OnShowRegistrationForm = function ()
{
	Register.SetRegistrationError("");

	let registrationForm = document.getElementById("registrationForm");

	registrationForm.firstname.value = "";
	registrationForm.lastname.value = "";
	registrationForm.email.value = "";

	registrationForm.registrationUsername.value = "";
	registrationForm.registrationPassword.value = "";
};

Register.SetRegistrationError = function (text)
{
	let registrationResult = document.getElementById("registrationResult");
	registrationResult.innerHTML = "<font size='2' color='red'>" + text + "</font>";
};
