/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function CarportWall(parent, eWall)
{
	Wall.call(this, parent, eWall);

	this.mouseOverTransparencyMesh = null;

	this.style = CarportWall.OPEN;

	this.mouseOverWallColor = 0xFFFFFF;

	this.openWallPercentage = 0.0;

	this.partialWallPercentage = 0.33;

	this.fullWallPercentage = 1.0;

	this.mouseOverTransparencyOffset = 0.1;

	this.mouseOverTransparencyThickness = CarportWall.METALWALLTHICKNESS * 0.1;

	/**
	 * @method CarportWall.GetDesignXMLString
	 * @returns {string} XML Carport Wall string
	 */
	this.GetDesignXMLString = function ()
	{
		let wallID;

		if (this.wallData)
			wallID = this.wallData.wallID;
		else
			wallID = "WALL_OPEN";

		strXml = "<WALL wallID=\"" + wallID + "\" sidingID=\"" + this.sidingColorData.siding_id + "\">";

		strXml += "</WALL>";

		return strXml;
	};

	/**
	 * @method CarportWall.GetDesignObject
	 * @returns {Object} Carport Wall Object
	 */
	this.GetDesignObject = function ()
	{
		let wall = {};
		if (this.wallData)
		{
			wall.wallID = this.wallData.wallID;
		}
		else
		{
			wall.wallID = "WALL_OPEN";
		}
		wall.sidingID = this.sidingColorData_siding_id;
		return wall;
	};

	this.GetTextures = function ()
	{
		if (this.sidingCategoryData.texture_name != "")
		{
			this.wallTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.sidingCategoryData.texture_name, -1, -1);
		}

		if (this.sidingCategoryData.texture_name_interior != "")
		{
			this.innerWallTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.sidingCategoryData.texture_name_interior, this.length, this.height);
		}
	};

	this.SetMouseOverTransparency = function (opacity)
	{
		if (this.mouseOverTransparencyMesh)
		{
			if (opacity == 0)
				this.mouseOverTransparencyMesh.material.visible = false;
			else
				this.mouseOverTransparencyMesh.material.visible = true;

			this.mouseOverTransparencyMesh.material.opacity = opacity;
		}
	};

	this.SetSelected = function (selected)
	{
		this.selected = selected;

		if (this.selected)
			this.mouseOverWallColor = 0x0000FF;
		else
			this.mouseOverWallColor = 0xFFFFFF;

		if (this.mouseOverTransparencyMesh)
		{
			this.mouseOverTransparencyMesh.material.color = new THREE.Color(this.mouseOverWallColor);
			this.mouseOverTransparencyMesh.material.needsUpdate = true;
		}

		this.SetMouseOverTransparency(0.5);
	};


	this.SetStyle = function (style)
	{
		this.style = style;

		if (typeof this.style !== "number")
			this.style = CarportWall.WALL_STYLE_STR.indexOf(this.style);

		if (this.style == CarportWall.OPEN)
			this.startHeight = undefined;
	};

	this.GetAndSetDimensionWallPrice = async function ()
	{
		if (this.length && this.wallData && this.wallData.wallID != "WALL_OPEN")
		{
			let sidingPrice = await Walls.GetSidingDimensionPrice(this.wallData.wallID, this.length, this.sidingColorData.category_id, this.walltype);

			if (!sidingPrice && DEBUG)
			{
				console.log("Siding price not defined for: " + buildingDesigner.building.sizeData.product_id);
			}
			else
				this.SetPrice(sidingPrice);
		}
	};

	this.SetWallData = function (data)
	{
		if (data.wallID == "WALL_GABLE" && (this.eWall == WALL_FRONT || this.eWall == WALL_BACK))
			alert("Only front or back walls can have gable ends");
		else
		{
			this.wallData = data;

			switch (this.wallData.wallID)
			{
			case ("WALL_OPEN"):
				this.SetStyle(CarportWall.OPEN);
				this.height = 0;
				break;

			case ("WALL_GABLE"):
				this.SetStyle(CarportWall.GABLE);
				this.height = 0;
				break;

			case ("WALL_PARTIAL_1_5"):
				this.SetStyle(CarportWall.PARTIAL_1_5);
				this.height = 1.5;
				break;

			case ("WALL_PARTIAL_3"):
				this.SetStyle(CarportWall.PARTIAL_3);
				this.height = 3;
				break;

			case ("WALL_PARTIAL_6"):
				this.SetStyle(CarportWall.PARTIAL_6);
				this.height = 6;
				break;

			case ("WALL_CLOSED"):
				this.SetStyle(CarportWall.CLOSED);
				this.height = buildingDesigner.building.height;
				break;
			}

			this.SetSelected(false);

			buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

			buildingDesigner.Draw();

			ElementsMenu.ElementsListPricingUpdate();

			buildingDesigner.building.SetBuildingModified();

			Wall.SelectedWallButtonData = null;
		}
	};

	this.SetWallSidingData = function (data)
	{
		let sidingCategoryData = GuiDataUtilities.GetSidingCategoryButtonData(data.category_id);

		if (sidingCategoryData.profile_points[0] == "[")
			sidingCategoryData.profile_points = JSON.parse(sidingCategoryData.profile_points);

		if (sidingCategoryData.profile_texture_coordinates[0] == "[")
			sidingCategoryData.profile_texture_coordinates = JSON.parse(sidingCategoryData.profile_texture_coordinates);

		this.SetSidingCategoryData(sidingCategoryData);

		this.SetSidingColorData(data);

		GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.IDLE;

		return true;
	};

	this.GenerateMouseOverTransparency = function (buildingMeshes)
	{
		if (this.frontBackWallHeightMax)
		{
			this.wallMater = new THREE.MeshStandardMaterial({
				color: this.mouseOverWallColor,
				map: null,
				metalness: METALNESS
			});

			if (this.selected)
				this.wallMater.opacity = 0.5;
			else
				this.wallMater.opacity = 0.0;

			this.wallMater.transparent = true;

			let tw2 = buildingDesigner.building.roofRafter.wallWidth / 2;
			let tl2 = buildingDesigner.building.length / 2;

			let roofRafterSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[1][1] - buildingDesigner.building.roofRafter.data.rafter_spec[0][1];

			let roofRafterFrontSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[0][1]][1] - buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[0][0]][1];
			let roofRafterBackSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[1][1]][1] - buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[1][0]][1];

			switch (this.eWall)
			{
			case (WALL_FRONT):
				this.wallsPts = [{
					x: -tl2,
					y: 0
				},
				{
					x: -tl2,
					y: this.frontBackWallHeightMax
				},
				{
					x: tl2,
					y: this.frontBackWallHeightMax
				},
				{
					x: tl2,
					y: 0
				},
				];

				this.length = buildingDesigner.building.length;
				this.buildingHeight = buildingDesigner.building.height;
				this.walltype = 1;
				this.height = this.frontBackWallHeightMax;
				break;

			case (WALL_BACK):
				this.wallsPts = [{
					x: -tl2,
					y: 0
				},
				{
					x: -tl2,
					y: this.leftRightWallHeightMax
				},
				{
					x: tl2,
					y: this.leftRightWallHeightMax
				},
				{
					x: tl2,
					y: 0
				},
				];

				this.length = buildingDesigner.building.length;
				this.buildingHeight = buildingDesigner.building.height;
				this.walltype = 1;
				this.height = this.leftRightWallHeightMax;
				break;

			case (WALL_LEFT):
			case (WALL_RIGHT):
				this.startHeight = 0;

				let frontRafteroffsetx = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0];

				let outerWallThickness = Wall.OUTER_WALLTHICKNESS;

				let wallRoofPoints = Wall.GetWallRoofPoints(buildingDesigner.building.roofRafter.data.rafter_spec, buildingDesigner.building.roofRafter.sideCoordsIndices[0][0], buildingDesigner.building.roofRafter.sideCoordsIndices[1][0], -buildingDesigner.building.roofRafter.wallWidth / 2 - frontRafteroffsetx, buildingDesigner.building.height - buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][1]);

				this.wallsPts = [];

				tw2 -= (outerWallThickness - 0.02);

				this.wallsPts.push({
					x: -tw2,
					y: this.startHeight
				});

				this.wallsPts.push({
					x: -tw2,
					y: this.leftRightWallHeightMax
				});

				for (let i = 0; i < wallRoofPoints.length; i++)
				{
					this.wallsPts.push({
						x: wallRoofPoints[i][0],
						y: wallRoofPoints[i][1]
					});
				}

				this.wallsPts.push({
					x: tw2,
					y: this.leftRightWallHeightMax
				});

				this.wallsPts.push({
					x: tw2,
					y: this.startHeight
				});

				this.length = buildingDesigner.building.width;
				this.buildingHeight = buildingDesigner.building.height;
				this.walltype = 2;
				this.height = (this.leftRightWallHeightMax + buildingDesigner.building.roofRafter.roofHeight) - this.startHeight;

				if (this.eWall == WALL_RIGHT)
					this.vecWallExts = [{
						x: -tw2,
						y: 0.0
					}, {
						x: tw2,
						y: buildingDesigner.building.height + buildingDesigner.building.roofRafter.roofHeight
					}];
				else
					this.vecWallExts = [{
						x: tw2,
						y: 0.0
					}, {
						x: -tw2,
						y: buildingDesigner.building.height + buildingDesigner.building.roofRafter.roofHeight
					}];

				break;
			}

			let shapeWall = new THREE.Shape(this.wallsPts);

			let wallGeom = new THREE.ExtrudeGeometry(shapeWall, {
				depth: this.mouseOverTransparencyThickness,
				bevelEnabled: false
			});
			wallGeom.scale(1.0005, 1, 1);

			TexturesDataUtilities.AssignUVsToGeometryXY(wallGeom);

			switch (this.eWall)
			{
			case (WALL_FRONT):
				this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - this.mouseOverTransparencyOffset, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
				wallGeom.matrixAutoUpdate = false;
				wallGeom.applyMatrix4(this.matrix);
				break;

			case (WALL_BACK):
				this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + CarportWall.METALWALLTHICKNESS + this.mouseOverTransparencyOffset, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
				wallGeom.matrixAutoUpdate = false;
				wallGeom.applyMatrix4(this.matrix);
				break;

			case (WALL_LEFT):
				this.matrix = new THREE.Matrix4().makeTranslation(0.0, 0.0, -buildingDesigner.building.length / 2 - this.mouseOverTransparencyOffset);
				wallGeom.matrixAutoUpdate = false;
				wallGeom.applyMatrix4(this.matrix);
				break;

			case (WALL_RIGHT):
				this.matrix = new THREE.Matrix4().makeTranslation(0.0, 0.0, -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length - CarportWall.METALWALLTHICKNESS + this.mouseOverTransparencyOffset);
				wallGeom.matrixAutoUpdate = false;
				wallGeom.applyMatrix4(this.matrix);
				break;
			}

			this.mouseOverTransparencyMesh = new THREE.Mesh(wallGeom, this.wallMater);
			this.mouseOverTransparencyMesh.type = ELEM_WALL_TRANSPARENCY;

			MeshUtilities.SetElement(this.mouseOverTransparencyMesh, this);

			buildingMeshes.push(this.mouseOverTransparencyMesh);

			buildingDesigner.building.lineGuides[this.eWall] = {
				horiz: null,
				vert: null
			};

			this.horizLineGuide.SetRegenerate(true);
			this.vertLineGuide.SetRegenerate(true);

			buildingDesigner.building.lineGuides[this.eWall].horiz = this.horizLineGuide.Generate();
			buildingDesigner.building.lineGuides[this.eWall].vert = this.vertLineGuide.Generate();

			this.regenerate = false;
		}
	};

	this.GeneratePartialWallPoints = function (partialWallPercentage)
	{
		buildingDesigner.building.roof.frontVisorHeightFromFloor = buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight;
		buildingDesigner.building.roof.rearVisorHeightFromFloor = buildingDesigner.building.height - buildingDesigner.building.roofRafter.rearVisorHeight - buildingDesigner.building.roofRafter.frontBackHeightDifference;

		let tw2 = (buildingDesigner.building.roofRafter.wallWidth + CarportWall.METALWALLTHICKNESS * 2) / 2;
		let tl2 = (buildingDesigner.building.length - CarportWall.METALWALLTHICKNESS * 2) / 2;

		let tl2End = -tl2 + buildingDesigner.building.sizeData.actual_combo_building_length;

		let roofRafterSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[1][1] - buildingDesigner.building.roofRafter.data.rafter_spec[0][1];

		let roofRafterFrontSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[0][1]][1] - buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[0][0]][1];
		let roofRafterBackSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[1][1]][1] - buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[1][0]][1];

		switch (this.eWall)
		{
		case (WALL_FRONT):
			this.startHeight = this.frontBackWallHeightMax * (1 - partialWallPercentage);
			this.wallsPts = [{
				x: -tl2,
				y: this.startHeight
			},
			{
				x: -tl2,
				y: this.frontBackWallHeightMax
			},
			{
				x: tl2End,
				y: this.frontBackWallHeightMax
			},
			{
				x: tl2End,
				y: this.startHeight
			},
			];

			this.wallsPtsForElements = this.wallsPts;

			this.length = tl2End - -tl2;

			this.buildingHeight = buildingDesigner.building.height;
			this.walltype = 1;
			this.height = this.frontBackWallHeightMax;

			this.wallCenter = buildingDesigner.building.length / 2;
			break;

		case (WALL_BACK):
			this.startHeight = this.frontBackWallHeightMax * (1 - partialWallPercentage);
			this.wallsPts = [{
				x: -tl2,
				y: this.startHeight
			},
			{
				x: -tl2,
				y: this.leftRightWallHeightMax
			},
			{
				x: tl2End,
				y: this.leftRightWallHeightMax
			},
			{
				x: tl2End,
				y: this.startHeight
			},
			];

			this.wallsPtsForElements = this.wallsPts;

			this.length = tl2End - -tl2;

			this.buildingHeight = buildingDesigner.building.height;
			this.walltype = 1;
			this.height = this.leftRightWallHeightMax;

			this.wallCenter = buildingDesigner.building.length / 2;
			break;

		case (WALL_LEFT):
		case (WALL_RIGHT):
			this.startHeight = this.leftRightWallHeightMax * (1 - partialWallPercentage);

			let frontRafteroffsetx = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0];

			let outerWallThickness = Wall.OUTER_WALLTHICKNESS;

			let wallRoofPoints = Wall.GetWallRoofPoints(buildingDesigner.building.roofRafter.data.rafter_spec, buildingDesigner.building.roofRafter.sideCoordsIndices[0][0], buildingDesigner.building.roofRafter.sideCoordsIndices[1][0], -buildingDesigner.building.roofRafter.wallWidth / 2 - frontRafteroffsetx, buildingDesigner.building.height - buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][1]);

			this.wallsPts = [];
			this.wallsPtsForElements = [];

			tw2 -= (outerWallThickness - 0.02);

			this.wallsPts.push({
				x: -tw2,
				y: this.startHeight
			});

			this.wallsPtsForElements.push(this.wallsPts[this.wallsPts.length - 1]);

			this.wallsPtsForElements.push({
				x: -tw2,
				y: buildingDesigner.building.roof.frontVisorHeightFromFloor
			});

			this.wallsPts.push({
				x: -tw2,
				y: buildingDesigner.building.roof.frontVisorHeightFromFloor
			});

			for (let i = 0; i < wallRoofPoints.length; i++)
			{
				this.wallsPts.push({
					x: wallRoofPoints[i][0],
					y: wallRoofPoints[i][1]
				});

				if (wallRoofPoints[i][0] > -tw2 && wallRoofPoints[i][0] < tw2)
					this.wallsPtsForElements.push({
						x: wallRoofPoints[i][0],
						y: wallRoofPoints[i][1]
					});
			}

			this.wallsPts.push({
				x: tw2,
				y: this.leftRightWallHeightMax
			});
			this.wallsPtsForElements.push(this.wallsPts[this.wallsPts.length - 1]);

			this.wallsPts.push({
				x: tw2,
				y: this.startHeight
			});
			this.wallsPtsForElements.push(this.wallsPts[this.wallsPts.length - 1]);

			this.length = buildingDesigner.building.width;
			this.buildingHeight = buildingDesigner.building.height;
			this.walltype = 2;
			this.height = (this.leftRightWallHeightMax + buildingDesigner.building.roofRafter.roofHeight) - this.startHeight;

			this.wallCenter = this.length / 2;

			if (this.eWall == WALL_RIGHT)
				this.vecWallExts = [{
					x: -tw2,
					y: 0.0
				}, {
					x: tw2,
					y: buildingDesigner.building.height + buildingDesigner.building.roofRafter.roofHeight
				}];
			else
				this.vecWallExts = [{
					x: tw2,
					y: 0.0
				}, {
					x: -tw2,
					y: buildingDesigner.building.height + buildingDesigner.building.roofRafter.roofHeight
				}];

			this.wallCenter = this.length / 2;
			break;
		}
	};

	this.GenerateClosedWallPoints = function ()
	{
		let tw2 = buildingDesigner.building.roofRafter.wallWidth / 2;
		let tl2 = buildingDesigner.building.length / 2;

		let roofRafterSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[1][1] - buildingDesigner.building.roofRafter.data.rafter_spec[0][1];

		let roofRafterFrontSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[0][1]][1] - buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[0][0]][1];
		let roofRafterBackSideWidth = buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[1][1]][1] - buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.sideCoordsIndices[1][0]][1];

		switch (this.eWall)
		{
		case (WALL_FRONT):
			this.wallsPts = [{
				x: -tl2,
				y: 0
			},
			{
				x: -tl2,
				y: this.frontBackWallHeightMax
			},
			{
				x: tl2,
				y: this.frontBackWallHeightMax
			},
			{
				x: tl2,
				y: 0
			},
			];

			this.length = buildingDesigner.building.length;
			this.buildingHeight = buildingDesigner.building.height;
			this.walltype = 1;
			this.height = this.frontBackWallHeightMax;
			break;

		case (WALL_BACK):
			this.wallsPts = [{
				x: -tl2,
				y: 0
			},
			{
				x: -tl2,
				y: this.leftRightWallHeightMax
			},
			{
				x: tl2,
				y: this.leftRightWallHeightMax
			},
			{
				x: tl2,
				y: 0
			},
			];

			this.length = buildingDesigner.building.length;
			this.buildingHeight = buildingDesigner.building.height;
			this.walltype = 1;
			this.height = this.leftRightWallHeightMax;
			break;

		case (WALL_LEFT):
		case (WALL_RIGHT):
			this.wallsPts = [{
				x: -tw2,
				y: 0
			},
			{
				x: -tw2,
				y: this.leftRightWallHeightMax
			},
			{
				x: -tw2 - buildingDesigner.building.roofRafter.frontVisorWidth,
				y: this.frontBackWallHeightMax - buildingDesigner.building.roofRafter.frontVisorHeight
			},
			{
				x: -tw2 - buildingDesigner.building.roofRafter.frontVisorWidth,
				y: this.frontBackWallHeightMax - buildingDesigner.building.roofRafter.frontVisorHeight + roofRafterFrontSideWidth
			},
			{
				x: -tw2 + (buildingDesigner.building.roofRafter.frontRoofWidth - buildingDesigner.building.roofRafter.frontVisorWidth),
				y: this.frontBackWallHeightMax + buildingDesigner.building.roofRafter.roofHeight
			},
			{
				x: tw2 + buildingDesigner.building.roofRafter.rearVisorWidth,
				y: this.leftRightWallHeightMax - buildingDesigner.building.roofRafter.rearVisorHeight + roofRafterBackSideWidth
			},
			{
				x: tw2 + buildingDesigner.building.roofRafter.rearVisorWidth,
				y: this.leftRightWallHeightMax - buildingDesigner.building.roofRafter.rearVisorHeight
			},
			{
				x: tw2,
				y: this.leftRightWallHeightMax
			},
			{
				x: tw2,
				y: 0
			}
			];

			this.length = buildingDesigner.building.width;
			this.buildingHeight = buildingDesigner.building.height;
			this.walltype = 2;
			this.height = this.frontBackWallHeightMax;
			break;
		}
	};

	this.GenerateWallPoints = function ()
	{
		this.GeneratePartialWallPoints(this.wallHeight / this.frontBackWallHeightMax);
	};

	this.CreatePartialWallHorizontalTrim = function ()
	{
		if (this.style != CarportWall.OPEN && this.style != CarportWall.CLOSED && this.startHeight != undefined)
		{
			let trimThickness = Trim.CORNER_TRIM_THICKNESS;
			let trim = GeometryUtilities.CreateBoxMesh(this.length, Trim.CORNER_TRIM_WIDTH_SIDES, trimThickness + CarportWall.METALWALLTHICKNESS, buildingDesigner.building.roof.cornerTrimColor, null);

			let xOffset = -this.length / 2;

			let zOffset = 0;

			switch (this.eWall)
			{
			case (WALL_FRONT):
			case (WALL_RIGHT):
				xOffset = -this.length / 2;
				zOffset = -trimThickness / 2;
				break;

			case (WALL_BACK):
			case (WALL_LEFT):
				zOffset = -trimThickness / 2 - CarportWall.METALWALLTHICKNESS;
				break;
			}

			switch (this.eWall)
			{
			case (WALL_FRONT):
			case (WALL_BACK):
				this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.length / 2 + this.length / 2, 0, 0);
				trim.geometry.matrixAutoUpdate = false;
				trim.geometry.applyMatrix4(this.matrix);
				break;
			}

			this.matrix = new THREE.Matrix4().makeTranslation(xOffset, this.startHeight, zOffset);
			trim.geometry.matrixAutoUpdate = false;
			trim.geometry.applyMatrix4(this.matrix);

			return trim;
		}
		else
			return null;
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate && buildingDesigner.building.sizeData.actual_combo_building_length != undefined)
		{
			if (this.eWall == WALL_FRONT || this.eWall == WALL_BACK)
				this.vertLineGuide.SetPos(new THREE.Vector3(-buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length / 2, 0, 0));
			else
				this.vertLineGuide.SetPos(new THREE.Vector3(0, 0, 0));

			this.frontBackWallHeightMax = buildingDesigner.building.height;

			if (buildingDesigner.building.roofRafter.data.bent_bow)
				this.frontBackWallHeightMax -= Roof.ROOF_THICKNESS;

			this.leftRightWallHeightMax = buildingDesigner.building.height;

			if (this.style == CarportWall.CLOSED)
				this.wallHeight = this.frontBackWallHeightMax;
			else
				this.wallHeight = WallHeights[this.style];

			if (this.wallHeight == 0)
				this.wallHeight += Trim.CORNER_TRIM_WIDTH_SIDES;

			this.GenerateMouseOverTransparency(buildingMeshes);

			this.GetTextures();

			if (this.wallColor == null)
				this.SetColorID(this.colorID);

			if (this.style != CarportWall.OPEN)
			{
				let materials = [];

				materials.push(new THREE.MeshPhongMaterial({
					color: this.wallColor,
					specular: 0x080808,
					shininess: 100,
					map: this.wallTexture
				}));

				materials.push(new THREE.MeshPhongMaterial({
					color: CarportWall.INTERIOR_COLOR,
					specular: 0x080808,
					shininess: 100,
					map: null
				}));

				this.wallMater = materials;

				this.innerWallMater = new THREE.MeshStandardMaterial({
					color: this.wallColor,
					map: this.innerWallTexture,
					roughness: 1.0,
					metalness: METALNESS
				});

				switch (this.style)
				{
				case (CarportWall.OPEN):
					this.wallMater.opacity = 0.0;
					this.wallMater.transparent = true;

					this.innerWallMater.opacity = 0.0;
					this.innerWallMater.transparent = true;
					break;

				case (CarportWall.CLOSED):
					this.wallMater.opacity = 1.0;
					this.wallMater.transparent = false;

					this.innerWallMater.opacity = 1.0;
					this.innerWallMater.transparent = false;
					break;
				}

				this.GenerateWallPoints();

				let shapeWall = new THREE.Shape(this.wallsPts);

				let wallContainerThickness = CarportWall.METALWALLTHICKNESS * 20;

				let wallGeom = new THREE.ExtrudeGeometry(shapeWall, {
					depth: CarportWall.METALWALLTHICKNESS * 20,
					bevelEnabled: false
				});

				wallGeom.scale(1.0005, 1, 1);

				TexturesDataUtilities.AssignUVsToGeometryXY(wallGeom);

				wallGeom.matrixAutoUpdate = false;
				wallGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -wallContainerThickness / 2));
				this.mesh = new THREE.Mesh(wallGeom, this.wallMater);

				////threeScene.add(this.mesh);

				let category = this.categoryID.substring(this.categoryID.length - 2);

				let siding = this.CreateSidingFromProfile(this.wallMater);


				this.matrix = new THREE.Matrix4().makeTranslation(0, this.startHeight, 0.0);
				siding.geometry.matrixAutoUpdate = false;
				siding.geometry.applyMatrix4(this.matrix);

				////threeScene.add(siding);

				this.mesh = MeshUtilities.IntersectMesh(this.mesh, siding);

				wallGeom = this.mesh.geometry;

				if (this.wallMater.length > 1)
				{
					for (i = 0; i < wallGeom.faces.length; i++)
					{
						if (wallGeom.faces[i].normal.z > 0)
						{
							if (this.eWall == WALL_FRONT || this.eWall == WALL_RIGHT)
								wallGeom.faces[i].materialIndex = 0;
							else
								wallGeom.faces[i].materialIndex = 1;
						}
						else
						{
							if (this.eWall == WALL_FRONT || this.eWall == WALL_RIGHT)
								wallGeom.faces[i].materialIndex = 1;
							else
								wallGeom.faces[i].materialIndex = 0;
						}
					}
				}

				let trim = this.CreatePartialWallHorizontalTrim();

				////this.mesh = MeshUtilities.MergeMeshGeometry(this.mesh);

				wallGeom = this.mesh.geometry;

				switch (this.eWall)
				{
				case (WALL_FRONT):
					this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
					wallGeom.matrixAutoUpdate = false;
					wallGeom.applyMatrix4(this.matrix);
					break;

				case (WALL_BACK):
					this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
					wallGeom.matrixAutoUpdate = false;
					wallGeom.applyMatrix4(this.matrix);
					break;

				case (WALL_LEFT):
					this.matrix = new THREE.Matrix4().makeTranslation(0.0, 0.0, -buildingDesigner.building.length / 2 + CarportWall.METALWALLTHICKNESS);
					wallGeom.matrixAutoUpdate = false;
					wallGeom.applyMatrix4(this.matrix);
					break;

				case (WALL_RIGHT):
					this.matrix = new THREE.Matrix4().makeTranslation(0.0, 0.0, -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length - CarportWall.METALWALLTHICKNESS);
					wallGeom.matrixAutoUpdate = false;
					wallGeom.applyMatrix4(this.matrix);
					break;
				}

				trim = this.CreatePartialWallHorizontalTrim();

				////this.mesh = MeshUtilities.MergeMeshGeometry(this.mesh);

				if (trim)
				{
					this.mesh.add(trim);


					let trimGeom = trim.geometry;
					switch (this.eWall)
					{
					case (WALL_FRONT):
						this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
						trimGeom.matrixAutoUpdate = false;
						trimGeom.applyMatrix4(this.matrix);
						break;

					case (WALL_BACK):
						this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
						trimGeom.matrixAutoUpdate = false;
						trimGeom.applyMatrix4(this.matrix);
						break;

					case (WALL_LEFT):
						this.matrix = new THREE.Matrix4().makeTranslation(0.0, 0.0, -buildingDesigner.building.length / 2 + CarportWall.METALWALLTHICKNESS);
						trimGeom.matrixAutoUpdate = false;
						trimGeom.applyMatrix4(this.matrix);
						break;

					case (WALL_RIGHT):
						this.matrix = new THREE.Matrix4().makeTranslation(0.0, 0.0, -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length - CarportWall.METALWALLTHICKNESS);
						trimGeom.matrixAutoUpdate = false;
						trimGeom.applyMatrix4(this.matrix);
						break;
					}
				}

				this.wallMesh = this.mesh;

				this.mesh.type = ELEM_WALL;

				MeshUtilities.SetElement(this.mesh, this);

				this.mesh.castShadow = true;
				this.mesh.receiveShadow = true;

				buildingMeshes.push(this.mesh);

				this.regenerate = false;
			}
		}
	};
}

CarportWall.METALWALLTHICKNESS = 0.0625;

CarportWall.CLOSED = 0;

CarportWall.PARTIAL_1_5 = 1;
CarportWall.PARTIAL_3 = 2;
CarportWall.PARTIAL_6 = 3;
CarportWall.OPEN = 4;
CarportWall.GABLE = 5;


CarportWall.WALL_STYLE_STR = ["WALL_CLOSED",
	"WALL_PARTIAL_1_5",
	"WALL_PARTIAL_3",
	"WALL_PARTIAL_6",
	"WALL_OPEN",
	"WALL_GABLE"
];

let WallHeights = [0, 1.5, 3, 6, -1, 0];

CarportWall.INTERIOR_COLOR = "rgb(255, 255, 255)";
