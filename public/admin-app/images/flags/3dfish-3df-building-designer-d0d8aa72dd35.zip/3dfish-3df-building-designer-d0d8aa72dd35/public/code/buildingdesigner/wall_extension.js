/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function WallExtension(buttonData)
{
	Element.call(this, buttonData);

	buttonData.type = ELEM_WALL_EXTENSION;

	this.mesh = null;

	this.draggable = false;

	this.regenerate = true;

	this.GetDesignXMLString = function()
	{
		let strElemType = ELEM_STRING[this.type];

		let strXml = "<ELEMENT ";

		strXml += " buttonData=\"" + AuxUtilities.JSONStringifyAndEncode(this.buttonData) + "\"";

		if (this.wall)
			strXml += " wall=\"" + WALL_STRING[this.wall.eWall] + "\"";

		strXml += " configurationMode=\"" + this.configurationMode + "\"";

		strXml += " x=\"" + this.pos.x + "\"";
		strXml += " y=\"" + this.pos.y + "\"";
		strXml += " z=\"" + this.pos.z + "\"";

		strXml += " defaultElementData=\"" + AuxUtilities.JSONStringifyAndEncode(this.defaultElementData) + "\"";

		strXml += "></ELEMENT>";

		return strXml;
	};

	/**
	 * @method WallExtension.GetDesignObject
	 * @returns {Object} elementData
	 */
	this.GetDesignObject = function()
	{
		let elementData = {
			buttonData: this.buttonData,
			x: this.pos.x,
			y: this.pos.y,
			z: this.pos.z,
			defaultElementData: this.defaultElementData
		};
		return elementData;
	};

	this.SetSelected = function(selected)
	{
		this.selected = selected;
	};

	this.Generate = function(buildingMeshes)
	{
		if (this.regenerate)
		{
			this.regenerate = false;
		}

		return null;
	};

	this.Destroy = function()
	{
		WallExtension.height -= this.buttonData.height;
		buildingDesigner.building.height -= this.buttonData.height;
		buildingDesigner.building.backWallHeight -= this.buttonData.height;

		if (Object.getPrototypeOf(buildingDesigner.building.rafters) === WoodRafters.prototype)
		{
			buildingDesigner.building.rafters.ModifyWallRafterHeight(-this.buttonData.height);
		}

		buildingDesigner.building.SetRegenerateBuildingMeshes(true);
	};
}

WallExtension.AddWallExtension = function (buttonData)
{
	let wallExtension = new WallExtension(buttonData);

	WallExtension.height += buttonData.height;
	buildingDesigner.building.height += buttonData.height;
	buildingDesigner.building.backWallHeight += buttonData.height;

	if (Object.getPrototypeOf(buildingDesigner.building.rafters) === WoodRafters.prototype)
	{
		buildingDesigner.building.rafters.ModifyWallRafterHeight(buttonData.height);
	}

	Elements.AddElement(wallExtension);

	buildingDesigner.building.SetRegenerateElementMeshes(true);
	buildingDesigner.building.Refresh();

	return wallExtension;
};

WallExtension.height = 0;
