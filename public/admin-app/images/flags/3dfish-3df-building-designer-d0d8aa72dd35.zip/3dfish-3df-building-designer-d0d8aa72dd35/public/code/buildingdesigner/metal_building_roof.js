/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function MetalBuildingRoof()
{
	Roof.call(this);

	this.CreateVerticalTrim = function ()
	{
		let verticalTrimMeshes = new THREE.Mesh();

		if (!buildingDesigner.building.roofRafter.leanToRafter)
			this.frontCornerTrimHeight = this.frontVisorHeightFromFloor - this.connectionHeight;
		else
			this.frontCornerTrimHeight = buildingDesigner.building.height;

		////this.backCornerTrimHeight = this.rearVisorHeightFromFloor;
		this.backCornerTrimHeight = this.frontCornerTrimHeight;


		/*////let minFrontLeftStartHeight;

		if (buildingDesigner.building.walls.GetWall(WALL_FRONT).startHeight != undefined || buildingDesigner.building.walls.GetWall(WALL_LEFT).startHeight != undefined)
		{
			minFrontLeftStartHeight = MathUtilities.Min(buildingDesigner.building.walls.GetWall(WALL_FRONT).startHeight, buildingDesigner.building.walls.GetWall(WALL_LEFT).startHeight);
		}
		else
			minFrontLeftStartHeight = 0;

		this.frontLeftCornerTrimHeight = this.frontCornerTrimHeight - minFrontLeftStartHeight;
		*/

		this.frontLeftCornerTrimHeight = this.frontCornerTrimHeight;


		/*////let minFrontRightStartHeight;

		if (buildingDesigner.building.walls.GetWall(WALL_FRONT).startHeight != undefined || buildingDesigner.building.walls.GetWall(WALL_RIGHT).startHeight != undefined)
		{
			minFrontRightStartHeight = MathUtilities.Min(buildingDesigner.building.walls.GetWall(WALL_FRONT).startHeight, buildingDesigner.building.walls.GetWall(WALL_RIGHT).startHeight);
		}
		else
			minFrontRightStartHeight = 0;

		this.frontRightCornerTrimHeight = this.frontCornerTrimHeight - minFrontRightStartHeight;
		*/

		this.frontRightCornerTrimHeight = this.frontCornerTrimHeight;


		/*////let minBackLeftStartHeight;

		if (buildingDesigner.building.walls.GetWall(WALL_BACK).startHeight != undefined || buildingDesigner.building.walls.GetWall(WALL_LEFT).startHeight != undefined)
		{
			minBackLeftStartHeight = MathUtilities.Min(buildingDesigner.building.walls.GetWall(WALL_BACK).startHeight, buildingDesigner.building.walls.GetWall(WALL_LEFT).startHeight);
		}
		else
			minBackLeftStartHeight = 0;

		this.backLeftCornerTrimHeight = this.backCornerTrimHeight - minBackLeftStartHeight;
		*/

		this.backLeftCornerTrimHeight = this.backCornerTrimHeight;


		/*////let minBackRightStartHeight;

		if (buildingDesigner.building.walls.GetWall(WALL_BACK).startHeight != undefined || buildingDesigner.building && buildingDesigner.building.walls.GetWall(WALL_RIGHT).startHeight != undefined)
		{
			minBackRightStartHeight = MathUtilities.Min(buildingDesigner.building.walls.GetWall(WALL_BACK).startHeight, buildingDesigner.building.walls.GetWall(WALL_RIGHT).startHeight);
		}
		else
			minBackRightStartHeight = 0;

		this.backRightCornerTrimHeight = this.backCornerTrimHeight - minBackRightStartHeight;
		*/

		this.backRightCornerTrimHeight = this.backCornerTrimHeight;


		if (BuildingDesigner.buildingType == BUILDING_SHED || (buildingDesigner.building.walls.GetWall(WALL_FRONT).style != CarportWall.OPEN || buildingDesigner.building.walls.GetWall(WALL_RIGHT).style != CarportWall.OPEN))
		{
			let frontRightTrim = this.CreateCornerTrim(this.frontRightCornerTrimHeight, Trim.CORNER_TRIM_WIDTH_ENDS, Trim.CORNER_TRIM_WIDTH_SIDES, Trim.CORNER_TRIM_THICKNESS);


			////this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth/2 - Trim.CORNER_TRIM_THICKNESS - Wall.WALLTHICKNESS, minFrontRightStartHeight, -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length);
			this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - Trim.CORNER_TRIM_THICKNESS - Wall.WALLTHICKNESS, 0, -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length);
			frontRightTrim.matrixAutoUpdate = false;
			frontRightTrim.applyMatrix4(this.matrix);

			verticalTrimMeshes.add(frontRightTrim);
		}


		if (BuildingDesigner.buildingType == BUILDING_SHED || buildingDesigner.building.walls.GetWall(WALL_FRONT).style != CarportWall.OPEN || buildingDesigner.building.walls.GetWall(WALL_LEFT).style != CarportWall.OPEN)
		{
			let frontLeftTrim = this.CreateCornerTrim(this.frontLeftCornerTrimHeight, Trim.CORNER_TRIM_WIDTH_ENDS, Trim.CORNER_TRIM_WIDTH_SIDES, Trim.CORNER_TRIM_THICKNESS);

			////this.matrix = new THREE.Matrix4().multiplyMatrices( new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth/2 - Wall.WALLTHICKNESS, this.frontLeftCornerTrimHeight + minFrontLeftStartHeight, -buildingDesigner.building.length/2), new THREE.Matrix4().makeRotationX(MathUtilities.PI));
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - Wall.WALLTHICKNESS, this.frontLeftCornerTrimHeight, -buildingDesigner.building.length / 2), new THREE.Matrix4().makeRotationX(MathUtilities.PI));

			frontLeftTrim.matrixAutoUpdate = false;
			frontLeftTrim.applyMatrix4(this.matrix);

			verticalTrimMeshes.add(frontLeftTrim);
		}


		if (BuildingDesigner.buildingType == BUILDING_SHED || (buildingDesigner.building.walls.GetWall(WALL_BACK).style != CarportWall.OPEN || buildingDesigner.building.walls.GetWall(WALL_RIGHT).style != CarportWall.OPEN))
		{
			let backRightTrim = this.CreateCornerTrim(this.backRightCornerTrimHeight, Trim.CORNER_TRIM_WIDTH_ENDS, Trim.CORNER_TRIM_WIDTH_SIDES, Trim.CORNER_TRIM_THICKNESS);

			////this.matrix = new THREE.Matrix4().multiplyMatrices( new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth/2 + Wall.WALLTHICKNESS, this.backRightCornerTrimHeight + minBackRightStartHeight, -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length + Trim.CORNER_TRIM_THICKNESS), new THREE.Matrix4().makeRotationZ(MathUtilities.PI));
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + Wall.WALLTHICKNESS, this.backRightCornerTrimHeight, -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length + Trim.CORNER_TRIM_THICKNESS), new THREE.Matrix4().makeRotationZ(MathUtilities.PI));

			backRightTrim.matrixAutoUpdate = false;
			backRightTrim.applyMatrix4(this.matrix);

			verticalTrimMeshes.add(backRightTrim);
		}


		if (BuildingDesigner.buildingType == BUILDING_SHED || (buildingDesigner.building.walls.GetWall(WALL_BACK).style != CarportWall.OPEN || buildingDesigner.building.walls.GetWall(WALL_LEFT).style != CarportWall.OPEN))
		{
			let backLeftTrim = this.CreateCornerTrim(this.backLeftCornerTrimHeight, Trim.CORNER_TRIM_WIDTH_ENDS, Trim.CORNER_TRIM_WIDTH_SIDES, Trim.CORNER_TRIM_THICKNESS);

			////this.matrix = new THREE.Matrix4().multiplyMatrices( new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth/2 + Trim.CORNER_TRIM_THICKNESS + Wall.WALLTHICKNESS, minBackLeftStartHeight, -buildingDesigner.building.length/2), new THREE.Matrix4().makeRotationY(MathUtilities.PI));
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + Trim.CORNER_TRIM_THICKNESS + Wall.WALLTHICKNESS, 0, -buildingDesigner.building.length / 2), new THREE.Matrix4().makeRotationY(MathUtilities.PI));

			backLeftTrim.matrixAutoUpdate = false;
			backLeftTrim.applyMatrix4(this.matrix);

			verticalTrimMeshes.add(backLeftTrim);
		}

		////verticalTrimMeshes = MeshUtilities.MergeMeshGeometry(verticalTrimMeshes);
		return verticalTrimMeshes;
	};

	this.CreateHorizontalTrim = function (frontOffsetX, rearOffsetX, rafterOffsetY, roofExtraLength, framingOffsetY)
	{
		if (framingOffsetY == undefined || framingOffsetY == null)
			framingOffsetY = 0;

		let horizontalTrimMeshes = new THREE.Mesh();

		/*////let horizontalTrimWidthL = buildingDesigner.building.roofRafter.rafterVerticalWidthL + framingOffsetY;

		let horizontalTrimWidthR = buildingDesigner.building.roofRafter.rafterVerticalWidthR + framingOffsetY;

		if (horizontalTrimWidthL == 0)
			horizontalTrimWidthL = BOARD_2x4_WIDTH;

		if (horizontalTrimWidthR == 0)
			horizontalTrimWidthR = BOARD_2x4_WIDTH;
			*/

		horizontalTrimWidthL = BOARD_2x4_WIDTH;

		horizontalTrimWidthR = BOARD_2x4_WIDTH;

		let roofTrimWidth = horizontalTrimWidthR > horizontalTrimWidthL ? horizontalTrimWidthR : horizontalTrimWidthL;

		let hipRoof = Elements.GetElementsOfType(ELEM_HIP_ROOF);

		let buildEngine = BuildingDesigner.GetBuildEngineCode(buildingDesigner.building.ID);

		if (!hipRoof)
		{
			//Left and Right
			let sideAngle = Roof.VERTICAL_TRIM;

			if (buildingDesigner.building.roofRafter.data.bent_bow || (buildEngine != null && buildEngine.toLowerCase() == "barn"))
				sideAngle = Roof.HORIZONTAL_TRIM;

			let trimPoints1 = GeometryUtilities.GetSurfacePoints(buildingDesigner.building.roofRafter.data.rafter_spec, buildingDesigner.building.roofRafter.sideCoordsIndices[0][1], buildingDesigner.building.roofRafter.sideCoordsIndices[1][1], roofTrimWidth * 0.25, sideAngle, false);

			let trimPoints2 = GeometryUtilities.GetSurfacePoints(trimPoints1, 0, trimPoints1.length - 1, -roofTrimWidth * 0.75, sideAngle);

			let trimPoints = AuxUtilities.ReverseArray(trimPoints2);

			let rightTrim = this.GeneratePlankFromPoints(trimPoints, Trim.TRIM_THICKNESS, this.eveTrimMater);
			rightTrim.castShadow = true;

			////rightTrim.matrix.scale(new THREE.Vector3(1.1, 1., 1));

			let leftTrim = rightTrim.clone();


			////let overhangLessTrimAndExtraLength = buildingDesigner.building.roofRafter.data.roof_overhang - roofExtraLength - Trim.TRIM_THICKNESS;
			let overhangLessTrimAndExtraLength = 0;

			////this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height + rafterOffsetY + framingOffsetY, this.length / 2 - Trim.TRIM_THICKNESS - roofExtraLength + (overhangLessTrimAndExtraLength < 0 ? -overhangLessTrimAndExtraLength + 0.01 : 0));
			this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height + rafterOffsetY + framingOffsetY, this.length / 2);
			rightTrim.matrixAutoUpdate = false;
			rightTrim.applyMatrix4(this.matrix);

			horizontalTrimMeshes.add(rightTrim);

			this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height + rafterOffsetY + framingOffsetY, -this.length / 2 - Trim.TRIM_THICKNESS);
			leftTrim.matrixAutoUpdate = false;
			leftTrim.applyMatrix4(this.matrix);

			horizontalTrimMeshes.add(leftTrim);
		}
		else
		{
			let rightTrim = GeometryUtilities.CreateBoxMesh(buildingDesigner.building.width + buildingDesigner.building.roofRafter.frontVisorWidth + buildingDesigner.building.roofRafter.rearVisorWidth, horizontalTrimWidthL, Trim.TRIM_THICKNESS, this.eveTrimColor, null);

			rightTrim.castShadow = true;

			let leftTrim = rightTrim.clone();

			this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height + rafterOffsetY, this.length / 2 - Trim.TRIM_THICKNESS - roofExtraLength);
			rightTrim.matrixAutoUpdate = false;
			rightTrim.applyMatrix4(this.matrix);

			horizontalTrimMeshes.add(rightTrim);

			this.matrix = new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height + rafterOffsetY, -this.length / 2 + roofExtraLength);
			leftTrim.matrixAutoUpdate = false;
			leftTrim.applyMatrix4(this.matrix);

			horizontalTrimMeshes.add(leftTrim);
		}

		//Front and Back
		if (!buildingDesigner.building.roofRafter.data.bent_bow && (buildEngine == undefined || buildEngine == null || buildEngine.toLowerCase() != "barn" || buildingDesigner.building.ID.indexOf("glenwood")))
		{
			let frontTrimOffsetx = frontOffsetX;

			if (frontTrimOffsetx < Trim.TRIM_THICKNESS && (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_FRONT).style == CarportWall.OPEN))
				frontTrimOffsetx = Trim.TRIM_THICKNESS;

			let rearTrimOffsetx = rearOffsetX;

			if (rearTrimOffsetx < Trim.TRIM_THICKNESS && (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_BACK).style == CarportWall.OPEN))
				rearTrimOffsetx = Trim.TRIM_THICKNESS;

			let trimLength = this.length;

			let trimZPos = trimLength / 2;

			if (buildingDesigner.building.roofRafter.data.roof_overhang < Trim.TRIM_THICKNESS)
			{
				let lengthDelta = Trim.TRIM_THICKNESS;

				if (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_LEFT).style == CarportWall.OPEN)
				{
					trimLength += lengthDelta;
				}

				if (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_RIGHT).style == CarportWall.OPEN)
				{
					trimLength += lengthDelta;
				}

				trimZPos = trimLength / 2;


				if (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_LEFT).style == CarportWall.OPEN)
				{
					trimZPos += (lengthDelta / 2);
				}

				if (BuildingDesigner.buildingType != BUILDING_CARPORT || !buildingDesigner.building.walls.GetWall(WALL_RIGHT).style == CarportWall.OPEN)
				{
					trimZPos -= (lengthDelta / 2);
				}
			}

			let yOffsetForTrimThicknessFront = Trim.TRIM_THICKNESS * buildingDesigner.building.roofRafter.frontTanAngleRatio;

			////let frontTrim = GeometryUtilities.CreateBoxMesh(this.length - roofExtraLength * 2, horizontalTrimWidthL - yOffsetForTrimThicknessFront, Trim.TRIM_THICKNESS, this.eveTrimColor, null);
			let frontTrim = GeometryUtilities.CreateBoxMesh(this.length, horizontalTrimWidthL - yOffsetForTrimThicknessFront, Trim.TRIM_THICKNESS, this.eveTrimColor, null);

			frontTrim.castShadow = true;

			let backTrim = frontTrim.clone();

			////this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight + buildingDesigner.building.roofRafter.rafterVerticalWidthL - horizontalTrimWidthL + framingOffsetY, -this.length / 2 + roofExtraLength), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - frontOffsetX, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight + buildingDesigner.building.roofRafter.rafterVerticalWidthL - horizontalTrimWidthL + framingOffsetY, -this.length / 2), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));

			frontTrim.matrixAutoUpdate = false;
			frontTrim.applyMatrix4(this.matrix);
			horizontalTrimMeshes.add(frontTrim);

			////this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + rearOffsetX + Trim.TRIM_THICKNESS, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontBackHeightDifference - buildingDesigner.building.roofRafter.rearVisorHeight + buildingDesigner.building.roofRafter.rafterVerticalWidthR - horizontalTrimWidthR + framingOffsetY, -this.length / 2 + roofExtraLength), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
			this.matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 + rearOffsetX + Trim.TRIM_THICKNESS, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontBackHeightDifference - buildingDesigner.building.roofRafter.rearVisorHeight + buildingDesigner.building.roofRafter.rafterVerticalWidthR - horizontalTrimWidthR + framingOffsetY, -this.length / 2), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));

			backTrim.matrixAutoUpdate = false;
			backTrim.applyMatrix4(this.matrix);
			horizontalTrimMeshes.add(backTrim);
		}

		horizontalTrimMeshes.castShadow = true;
		horizontalTrimMeshes.receiveShadow = true;

		horizontalTrimMeshes.type = ELEM_ROOFING;

		return horizontalTrimMeshes;
	};

	this.GetTextures = function ()
	{
		this.tileTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.tileTextureName, 1, 1);

		let materials = [];

		materials.push(new THREE.MeshPhongMaterial({
			color: this.tileColor,
			specular: 0x010101,
			shininess: 70,
			map: this.tileTexture
		}));

		materials.push(new THREE.MeshPhongMaterial({
			color: MetalBuildingRoof.INTERIOR_COLOR,
			specular: 0x010101,
			shininess: 70,
			map: null
		}));

		this.tileMater = materials;
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			let mesh = new THREE.Mesh();

			this.GetTextures();

			////if (TexturesDataUtilities.TextureLoaded(this.tileTexture))
			{
				if (this.tileColor == null)
					this.SetColorID(this.colorID);

				this.length = buildingDesigner.building.length + buildingDesigner.building.roofRafter.data.roof_overhang * 2;

				this.frontVisorHeightFromFloor = buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontVisorHeight;
				this.rearVisorHeightFromFloor = buildingDesigner.building.height - buildingDesigner.building.roofRafter.rearVisorHeight - buildingDesigner.building.roofRafter.frontBackHeightDifference;

				let extendedSurface;

				extendedSurface = GeometryUtilities.GenerateExtendedSurface(buildingDesigner.building.roofRafter.data.rafter_spec, buildingDesigner.building.roofRafter.sideCoordsIndices[0][1], buildingDesigner.building.roofRafter.sideCoordsIndices[1][1], Roof.ROOF_THICKNESS);

				if (MetalBuildingRoof.IsVerticalMetalBuildingRoof())
				{
					extendedSurface = GeometryUtilities.GetSurfacePoints(extendedSurface, 0, extendedSurface.length - 1, MetalRafters.HORIZONTAL_ROOF_FRAMING_THICKNESS, Roof.ANGLED_TRIM, false);
				}

				roofExtraLength = Roof.ROOF_THICKNESS + Roof.TILE_THICKNESS;

				let extrudeSettings = {
					depth: this.length,
					steps: 1,
					material: 1,
					extrudeMaterial: 0,
					bevelEnabled: false,
				};

				let frontRafteroffsetx = 0;
				let rafterOffsetY = 0;

				if (buildingDesigner.building.roofRafter.data.front_wall_attach_coord != "")
				{
					frontRafteroffsetx = buildingDesigner.building.roofRafter.frontVisorWidth;

					rearRafteroffsetx = buildingDesigner.building.roofRafter.rearVisorWidth;

					rafterOffsetY = -buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1];
				}

				let tileMesh = this.GenerateTileMeshFromSurface(extendedSurface, extrudeSettings, -buildingDesigner.building.roofRafter.wallWidth / 2 - frontRafteroffsetx, buildingDesigner.building.height - buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1], this.length / 2);

				MeshUtilities.SetMeshCastReceiveShadow(tileMesh, true, false);

				mesh.add(tileMesh);

				let verticalTrimMeshes = this.CreateVerticalTrim();

				MeshUtilities.SetMeshCastReceiveShadow(verticalTrimMeshes, true, true);

				buildingMeshes.push(verticalTrimMeshes);

				let framingOffsetY = 0;

				if (MetalBuildingRoof.IsVerticalMetalBuildingRoof())
				{
					framingOffsetY = MetalRafters.HORIZONTAL_ROOF_FRAMING_THICKNESS / Math.sin(MathUtilities.PI2 - Math.atan(buildingDesigner.building.roofRafter.frontTanAngleRatio));

					framingOffsetY -= BOARD_2x4_THICKNESS * buildingDesigner.building.roofRafter.frontTanAngleRatio;
				}

				let horizontalTrimMeshes = this.CreateHorizontalTrim(frontRafteroffsetx, rearRafteroffsetx, rafterOffsetY, roofExtraLength, framingOffsetY);

				MeshUtilities.SetMeshCastReceiveShadow(horizontalTrimMeshes, true, true);

				buildingMeshes.push(horizontalTrimMeshes);

				mesh = MeshUtilities.MergeMeshGeometry(mesh);
				mesh.castShadow = true;


				this.regenerate = false;
			}

			buildingMeshes.push(mesh);
		}
	};
}


MetalBuildingRoof.IsMetalBuildingRoof = function ()
{
	// ** TODO: Needs separate flag for metal roof, should not be tied to category_id
	let category_id = nestedObj(buildingDesigner,"building.roof.data.category_id") || "    ";
	if (buildingDesigner.building.roofRafter.data.bent_bow || (category_id.substring(0, 2) == "MM" || category_id.substring(category_id.length - 2, category_id.length) == "MR"))
		return true;

	return false;
};

MetalBuildingRoof.IsVerticalMetalBuildingRoof = function (category_id)
{
	if (!category_id && !buildingDesigner.building.roof.data)
		return false;

	if (!category_id)
		category_id = buildingDesigner.building.roof.data.category_id;

	if ((category_id.substring(0, 2) == "GV" || category_id.substring(0, 2) == "MM") && (category_id.substring(category_id.length - 2, category_id.length) == "MR" || category_id.substring(category_id.length - 2, category_id.length) == "TR"))
		return true;

	return false;
};

MetalBuildingRoof.INTERIOR_COLOR = "rgb(255, 255, 255)";
