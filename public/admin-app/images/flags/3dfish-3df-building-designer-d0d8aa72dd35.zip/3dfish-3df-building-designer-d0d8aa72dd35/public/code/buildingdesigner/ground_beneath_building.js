/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function GroundBeneathBuilding()
{
	this.groundTextureFileName = "";

	this.groundTexture = null;
	this.groundColor = 0xE2CEC2;

	Floor.FLOOR_THICKNESS = 0;

	this.regenerate = true;

	this.SetGroundColor = function (color)
	{
		this.groundColor = color;
	};

	this.SetGroundTextureFileName = function (fileName)
	{
		this.groundTextureFileName = fileName;
	};

	this.SetSelected = function (selected)
	{
		this.selected = selected;
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.GetTextures = function ()
	{
		if (this.groundTextureFileName != "")
		{
			this.groundTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.groundTextureFileName, buildingDesigner.building.width, buildingDesigner.building.length);
		}
		else
			this.groundTexture = null;
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			this.GetTextures();

			this.length = buildingDesigner.building.length - Wall.WALLTHICKNESS * 2;

			let groundMatter = new THREE.MeshStandardMaterial({
				color: this.groundColor,
				map: TexturesDataUtilities.TextureLoaded(this.groundTexture),
				roughness: 1.0,
				metalness: METALNESS
			});

			let groundGeom = new THREE.BoxGeometry(buildingDesigner.building.width * 1.01, GroundBeneathBuilding.Thickness, this.length * 1.01);

			groundGeom.matrixAutoUpdate = false;
			groundGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(0.0, GroundBeneathBuilding.Thickness / 2, 0.0));

			this.mesh = new THREE.Mesh(groundGeom, groundMatter);
			this.mesh.type = ELEM_FLOORING;

			////this.mesh.receiveShadow = true;

			buildingMeshes.push(this.mesh);

			this.regenerate = false;
		}
	};
}

GroundBeneathBuilding.Thickness = 0.01;
