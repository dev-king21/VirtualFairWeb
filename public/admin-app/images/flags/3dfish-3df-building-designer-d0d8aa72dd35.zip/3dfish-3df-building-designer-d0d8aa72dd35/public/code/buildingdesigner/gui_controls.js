/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2 */
/*eslint-disable no-console, no-unused-vars, no-undef*/
function ControlsMenu()
{}

ControlsMenu.ShowEnterVR = function (device)
{
	let button = document.createElement("button");
	button.style.display = "none";

	button.style.position = "absolute";

	button.style.bottom = "0px";
	button.style.padding = "0px 0px 0px 0px";
	button.style.border = "1px solid #fff";
	button.style.borderRadius = "4px";
	button.style.background = "rgba(0,0,0,0.1)";
	button.style.color = "#fff";
	button.style.font = "normal 13px sans-serif";
	button.style.textAlign = "center";
	button.style.opacity = "1.0";
	button.style.outline = "none";
	button.style.zIndex = "9999999";


	button.style.display = "block";

	button.style.cursor = "pointer";
	button.style.left = "calc(50% - 50px)";
	button.style.width = "100px";

	button.textContent = "ENTER VR";

	button.onmouseenter = function ()
	{
		button.style.opacity = "1.0";
	};
	button.onmouseleave = function ()
	{
		button.style.opacity = "0.5";
	};

	button.onclick = function ()
	{
		////device.isPresenting ? device.exitPresent() : device.requestPresent( [ { source: renderer.domElement } ] );
		if (!buildingDesigner.camera.effect)
		{
			this.textContent = "EXIT VR";
			buildingDesigner.camera.effect = new THREE.StereoEffect(threeRenderer);
			BuildingDesigner.LaunchFullscreen(document.documentElement);
		}
		else
		{
			this.textContent = "ENTER VR";
			buildingDesigner.camera.SetCanvasDimensions(canvasMain.clientWidth, canvasMain.clientHeight);
			buildingDesigner.camera.effect = null;
			BuildingDesigner.ExitFullscreen(document.documentElement);
		}

		buildingDesigner.InitializeCameraAndRender();
	};

	////renderer.vr.setDevice( device );

	document.body.appendChild(button);
};

ControlsMenu.OnLoadZoomImage = function ()
{};

ControlsMenu.OnLoadSpinImage = function ()
{
	contextSpin.drawImage(ControlsMenu.imageSpinControl[0], 0, 0);
};

ControlsMenu.InitZoomControl = function ()
{
	let img = new Image();
	ControlsMenu.imageZoomArray.push(img);
	img.onload = ControlsMenu.OnLoadZoomImage;
	img.src = DIR_MISC + "/" + ControlsMenu.ZOOM_STATE_IMAGE[0];

	for (let i = 1; i < ControlsMenu.ZOOM_STATE_IMAGE.length; i++)
	{
		img = new Image();
		img.src = DIR_MISC + "/" + ControlsMenu.ZOOM_STATE_IMAGE[i];
		ControlsMenu.imageZoomArray.push(img);
	}
};

ControlsMenu.InitSpinControl = function ()
{
	let img = new Image();
	ControlsMenu.imageSpinControl.push(img);
	img.onload = ControlsMenu.OnLoadSpinImage;
	img.src = DIR_MISC + "/" + ControlsMenu.SPIN_STATE_IMAGE[0];

	for (let i = 1; i < ControlsMenu.SPIN_STATE_IMAGE.length; i++)
	{
		img = new Image();
		img.src = DIR_MISC + "/" + ControlsMenu.SPIN_STATE_IMAGE[i];
		ControlsMenu.imageSpinControl.push(img);
	}
};

ControlsMenu.AdjustZoomControlsPosition = function ()
{
	/* // depricated -- use style instead to control position
	let pos_x = canvasMain.offsetLeft + canvasMain.clientWidth - ControlsMenu.ZOOM_CONTROL_SIZE_X * 2 - ControlsMenu.SPIN_CONTROL_SLOT_X;
	let pos_y = canvasMain.offsetTop + ControlsMenu.SPIN_CONTROL_SLOT_Y - ControlsMenu.ZOOM_CONTROL_SIZE_Y;

	let zoomControlImage = document.getElementById( "zoomin" );

	zoomControlImage.style.left = pos_x + "px";
	zoomControlImage.style.top  = pos_y + "px";

	pos_x = canvasMain.offsetLeft + canvasMain.clientWidth - ControlsMenu.ZOOM_CONTROL_SIZE_X - ControlsMenu.SPIN_CONTROL_SLOT_X;

	zoomControlImage = document.getElementById( "zoomout" );

	zoomControlImage.style.left = pos_x + "px";
	zoomControlImage.style.top  = pos_y + "px";
	*/
};

ControlsMenu.AdjustSpinControlPosition = function ()
{
	/*  // depricated -- use style instead to control position
	let pos_x = canvasMain.offsetLeft + canvasMain.clientWidth - ControlsMenu.SPIN_CONTROL_SIZE_X - ControlsMenu.SPIN_CONTROL_SLOT_X;
	let pos_y = canvasMain.offsetTop + ControlsMenu.SPIN_CONTROL_SLOT_Y;

	canvasSpin.style.left = pos_x + "px";
	canvasSpin.style.top  = pos_y + "px";
	*/
};

ControlsMenu.SetZoomInState = function (state)
{
	ControlsMenu.zoomInState = state;
	switch (ControlsMenu.zoomInState)
	{
	case (ControlsMenu.ZOOM_IN_STATE_UP):
		ControlsMenu.KillZoomTimer();
		break;

	case (ControlsMenu.ZOOM_IN_STATE_DOWN):
		ControlsMenu.zoomTimer = window.setInterval(ControlsMenu.OnZoomTimer, ControlsMenu.ZOOM_TIMER_INTERVAL);
		break;
	}
};

ControlsMenu.SetZoomOutState = function (state)
{
	ControlsMenu.zoomOutState = state;
	switch (ControlsMenu.zoomOutState)
	{
	case (ControlsMenu.ZOOM_OUT_STATE_UP):
		ControlsMenu.KillZoomTimer();
		break;

	case (ControlsMenu.ZOOM_OUT_STATE_DOWN):
		ControlsMenu.zoomTimer = window.setInterval(ControlsMenu.OnZoomTimer, ControlsMenu.ZOOM_TIMER_INTERVAL);
		break;
	}
};

ControlsMenu.ZoomInNormal = function ()
{
	ControlsMenu.SetZoomInState(ControlsMenu.ZOOM_IN_STATE_NORMAL);
};

ControlsMenu.ZoomInDown = function ()
{
	ControlsMenu.SetZoomInState(ControlsMenu.ZOOM_IN_STATE_DOWN);
};

ControlsMenu.ZoomInOver = function ()
{
	if (ControlsMenu.zoomInState != ControlsMenu.ZOOM_IN_STATE_DOWN)
		ControlsMenu.SetZoomInState(ControlsMenu.ZOOM_IN_STATE_OVER);
};

ControlsMenu.ZoomInUp = function ()
{
	ControlsMenu.SetZoomInState(ControlsMenu.ZOOM_IN_STATE_UP);
};

ControlsMenu.ZoomOutNormal = function ()
{
	ControlsMenu.SetZoomOutState(ControlsMenu.ZOOM_OUT_STATE_NORMAL);
};

ControlsMenu.ZoomOutDown = function ()
{
	ControlsMenu.SetZoomOutState(ControlsMenu.ZOOM_OUT_STATE_DOWN);
};

ControlsMenu.ZoomOutOver = function ()
{
	if (ControlsMenu.zoomOutState != ControlsMenu.ZOOM_OUT_STATE_DOWN)
		ControlsMenu.SetZoomOutState(ControlsMenu.ZOOM_OUT_STATE_OVER);
};

ControlsMenu.ZoomOutUp = function ()
{
	ControlsMenu.SetZoomOutState(ControlsMenu.ZOOM_OUT_STATE_UP);
};

ControlsMenu.CanvasCoordsToState = function (vecCoords)
{
	let eState = ControlsMenu.SPIN_STATE_IDLE;

	if (!isNaN(vecCoords.x) && !isNaN(vecCoords.y))
	{
		//if(DEBUG) {console.log("x:",vecCoords.x," y:",vecCoords.y);}
		let vecPos = new THREE.Vector2(vecCoords.x - ControlsMenu.SPIN_CONTROL_SIZE_X / 2.0,
			ControlsMenu.SPIN_CONTROL_SIZE_Y / 2.0 - vecCoords.y);

		let fRadius = vecPos.length();

		if (fRadius < ControlsMenu.SPIN_CONTROL_MIDDLE_RADIUS)
			eState = ControlsMenu.SPIN_STATE_MIDDLE;
		else if (Math.abs(vecPos.x) < ControlsMenu.SPIN_CONTROL_SIZE_X / 10.0)
		{
			eState = (vecPos.y < 0.0) ? ControlsMenu.SPIN_STATE_DOWN : ControlsMenu.SPIN_STATE_UP;
		}
		else if (Math.abs(vecPos.y) < ControlsMenu.SPIN_CONTROL_SIZE_Y / 10.0)
		{
			eState = (vecPos.x < 0.0) ? ControlsMenu.SPIN_STATE_LEFT : ControlsMenu.SPIN_STATE_RIGHT;
		}
	}
	//if(DEBUG) {console.log("eState: ",eState," stateSpin",ControlsMenu.stateSpin);}
	return eState;
};

ControlsMenu.SetSpinState = function (mouseOrTouchCoord)
{
	let eNewState = ControlsMenu.CanvasCoordsToState(mouseOrTouchCoord);
	if (eNewState !== ControlsMenu.stateSpin && !ControlsMenu.keyState)
	{
		ControlsMenu.KillRotateTimer();

		contextSpin.drawImage(ControlsMenu.imageSpinControl[eNewState], 0, 0);
		ControlsMenu.stateSpin = eNewState;
	}
};

ControlsMenu.OnMouseMoveSpin = function (event)
{
	if (contextSpin && !AuxUtilities.IsMobileOrTablet())
	{
		ControlsMenu.SetSpinState({
			x: event.offsetX,
			y: event.offsetY
		});
	}
};

ControlsMenu.OnMouseLeaveSpin = function (event)
{
	ControlsMenu.OnMouseMoveSpin({
		offsetX: -1,
		offsetY: -1
	});
};


ControlsMenu.OnMouseDownSpin = function (event)
{
	if (DEBUG)
	{
		console.log("MouseDownSpin");
	}
	let mouseOrTouchCoord = GUIInput.GetMouseOrTouchCoords(event);

	ControlsMenu.SetSpinState(mouseOrTouchCoord);

	if (ControlsMenu.stateSpin !== ControlsMenu.SPIN_STATE_IDLE && ControlsMenu.stateSpin !== ControlsMenu.SPIN_STATE_MIDDLE)
	{
		ControlsMenu.KillRotateTimer();
		ControlsMenu.rotateTimer = window.setInterval(ControlsMenu.OnRotateTimer, ControlsMenu.ROTATE_TIMER_INTERVAL);
	}
	else if (ControlsMenu.stateSpin == ControlsMenu.SPIN_STATE_MIDDLE)
	{
		////ControlsMenu.OnSpinMiddleClick();

		clearInterval(ControlsMenu.mouseUpTimer);
		ControlsMenu.mouseUpTimer = window.setInterval(ControlsMenu.OnMouseUpSpin, 1000);
	}
};

ControlsMenu.OnRotateRightClick = function ()
{
	let currentAngle = buildingDesigner.camera.cameraControls.azimuthAngle;

	currentAngle /= MathUtilities.PI2;

	currentAngle = MathUtilities.Round(currentAngle, 1);

	currentAngle = (Math.floor(currentAngle) + 1) * MathUtilities.PI2;

	buildingDesigner.camera.cameraControls.rotateTo(currentAngle, buildingDesigner.camera.cameraControls.polarAngle, true);
};

ControlsMenu.OnRotateLeftClick = function ()
{
	let currentAngle = buildingDesigner.camera.cameraControls.azimuthAngle;

	currentAngle /= MathUtilities.PI2;

	currentAngle = MathUtilities.Round(currentAngle, 1);

	let floorAngle = Math.floor(currentAngle);

	if (currentAngle == floorAngle)
		currentAngle--;
	else
		currentAngle = floorAngle;

	currentAngle = Math.floor(currentAngle) * MathUtilities.PI2;

	buildingDesigner.camera.cameraControls.rotateTo(currentAngle, buildingDesigner.camera.cameraControls.polarAngle, true);
};

ControlsMenu.OnSpinMiddleClick = function (event)
{
	if (buildingDesigner.camera.modeCamera == Camera.CAM_MODE_EXTERIOR)
	{
		buildingDesigner.camera.SetView(Camera.CAM_MODE_INTERIOR);
		$("#buttonInterior").hide();
		$("#buttonExterior").show();
	}
	else
	{
		buildingDesigner.camera.SetView(Camera.CAM_MODE_EXTERIOR);
		$("#buttonExterior").hide();
		$("#buttonInterior").show();
	}

	buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

	buildingDesigner.Draw();
};

ControlsMenu.OnMouseUpSpin = function (event)
{
	clearInterval(ControlsMenu.mouseUpTimer);
	ControlsMenu.mouseUpTimer = null;

	ControlsMenu.KillRotateTimer();

	if (ControlsMenu.stateSpin == ControlsMenu.SPIN_STATE_MIDDLE)
		ControlsMenu.OnSpinMiddleClick();

	ControlsMenu.stateSpin = ControlsMenu.SPIN_STATE_IDLE;
	contextSpin.drawImage(ControlsMenu.imageSpinControl[ControlsMenu.stateSpin], 0, 0);
};

ControlsMenu.OnZoomTimer = function ()
{
	if (ControlsMenu.zoomInState == ControlsMenu.ZOOM_IN_STATE_DOWN)
	{
		buildingDesigner.camera.Zoom(ControlsMenu.ZOOM_TIMER_STEP);
	}

	if (ControlsMenu.zoomOutState == ControlsMenu.ZOOM_OUT_STATE_DOWN)
	{
		buildingDesigner.camera.Zoom(-ControlsMenu.ZOOM_TIMER_STEP);
	}
};

ControlsMenu.OnRotateTimer = function ()
{
	let sign = (buildingDesigner.camera.modeCamera == Camera.CAM_MODE_EXTERIOR) ? 1.0 : -1.0;

	let angle;

	switch (ControlsMenu.stateSpin)
	{
	case ControlsMenu.SPIN_STATE_LEFT:
		////buildingDesigner.camera.AdjustHorizAngle(-sign * ControlsMenu.ROTATE_TIMER_STEP);
		////buildingDesigner.camera.cameraControls.rotate( ControlsMenu.ROTATE_TIMER_STEP);
		buildingDesigner.camera.cameraControls.rotate( -sign * ControlsMenu.ROTATE_TIMER_STEP, 0, true);
		////ControlsMenu.OnRotateLeftClick();

		break;

	case ControlsMenu.SPIN_STATE_RIGHT:
		////buildingDesigner.camera.AdjustHorizAngle(sign * ControlsMenu.ROTATE_TIMER_STEP);
		buildingDesigner.camera.cameraControls.rotate( sign * ControlsMenu.ROTATE_TIMER_STEP, 0, true);
		break;

	case ControlsMenu.SPIN_STATE_UP:
		////buildingDesigner.camera.AdjustVertAngle(sign * ControlsMenu.ROTATE_TIMER_STEP);
		buildingDesigner.camera.cameraControls.rotate(0, -sign * ControlsMenu.ROTATE_TIMER_STEP, true);
		break;

	case ControlsMenu.SPIN_STATE_DOWN:
		////buildingDesigner.camera.AdjustVertAngle(-sign * ControlsMenu.ROTATE_TIMER_STEP);
		buildingDesigner.camera.cameraControls.rotate(0, sign * ControlsMenu.ROTATE_TIMER_STEP, true);
		break;
	}

	////if (buildingDesigner.building.selected)
	////buildingDesigner.building.SetRulerWalls(buildingDesigner.camera.g_fCameraHorizAngleExterior);

	////buildingDesigner.InitializeCameraAndRender();
};

ControlsMenu.ReturnToHome = function()
{
	buildingDesigner.InitializeCameraAndRender();
};

ControlsMenu.KillZoomTimer = function ()
{
	if (ControlsMenu.zoomTimer !== null)
	{
		clearInterval(ControlsMenu.zoomTimer);
		ControlsMenu.zoomTimer = null;
	}
};


ControlsMenu.KillRotateTimer = function ()
{
	if (ControlsMenu.rotateTimer !== null)
	{
		clearInterval(ControlsMenu.rotateTimer);
		ControlsMenu.rotateTimer = null;
	}
};

ControlsMenu.imageZoomArray = [];
ControlsMenu.imageSpinControl = [];


// Zoom control constants
ControlsMenu.ZOOM_IN_STATE_NORMAL = 0;
ControlsMenu.ZOOM_IN_STATE_OVER = 1;
ControlsMenu.ZOOM_IN_STATE_DOWN = 2;
ControlsMenu.ZOOM_IN_STATE_UP = 3;
ControlsMenu.ZOOM_OUT_STATE_NORMAL = 4;
ControlsMenu.ZOOM_OUT_STATE_OVER = 5;
ControlsMenu.ZOOM_OUT_STATE_DOWN = 6;
ControlsMenu.ZOOM_OUT_STATE_UP = 7;
ControlsMenu.ZOOM_STATE_IMAGE = ["zoom_in_normal.png",
	"zoom_in_over.png",
	"zoom_in_down.png",
	"zoom_in_normal.png",
	"zoom_out_normal.png",
	"zoom_out_over.png",
	"zoom_out_down.png",
	"zoom_out_normal.png"
];
// Key State constants
ControlsMenu.KEY_STATE_UP = 0;
ControlsMenu.KEY_STATE_DOWN = 1;

// Spin control constants
ControlsMenu.SPIN_STATE_IDLE = 0;
ControlsMenu.SPIN_STATE_MIDDLE = 1;
ControlsMenu.SPIN_STATE_LEFT = 2;
ControlsMenu.SPIN_STATE_UP = 3;
ControlsMenu.SPIN_STATE_RIGHT = 4;
ControlsMenu.SPIN_STATE_DOWN = 5;
ControlsMenu.SPIN_STATE_IMAGE = ["SpinIdle-1.png",
	"SpinMiddle-1.png",
	"SpinLeft-1.png",
	"SpinUp-1.png",
	"SpinRight-1.png",
	"SpinDown-1.png"
];



ControlsMenu.ZOOM_CONTROL_SIZE_X = 32;
ControlsMenu.ZOOM_CONTROL_SIZE_Y = 32;
ControlsMenu.SPIN_CONTROL_SIZE_X = 150;
ControlsMenu.SPIN_CONTROL_SIZE_Y = 150;
ControlsMenu.SPIN_CONTROL_SLOT_X = 10;
ControlsMenu.SPIN_CONTROL_SLOT_Y = 40;
ControlsMenu.SPIN_CONTROL_MIDDLE_RADIUS = 24;

ControlsMenu.zoomInState = ControlsMenu.ZOOM_IN_STATE_NORMAL;
ControlsMenu.zoomOutState = ControlsMenu.ZOOM_OUT_STATE_NORMAL;
ControlsMenu.stateSpin = ControlsMenu.SPIN_STATE_IDLE;

ControlsMenu.ZOOM_TIMER_INTERVAL = 40;
ControlsMenu.ZOOM_TIMER_STEP = 0.04;

ControlsMenu.ROTATE_TIMER_INTERVAL = 40;
ControlsMenu.ROTATE_TIMER_STEP = THREE.Math.degToRad(1.0); // degrees

ControlsMenu.zoomTimer = null;
ControlsMenu.rotateTimer = null;
ControlsMenu.mouseUpTimer = null;
ControlsMenu.keyState = 0;
