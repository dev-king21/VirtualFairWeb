/*const isSafari = navigator.vendor && navigator.vendor.indexOf("Apple") > -1 &&
				navigator.userAgent &&
				navigator.userAgent.indexOf("CriOS") == -1 &&
				navigator.userAgent.indexOf("FxiOS") == -1;

if (isSafari) this.top.location !== this.location && (this.top.location = this.location);*/
/*try {
	let test1 = {a: "test"};
	let test2 = {b: "test", ...test1};
} catch (e) {
	console.warn("spread test failed.");
}*/
// check for TextEncoder support and Array.prototype.flat support since spread can't be tested for
if ((typeof TextEncoder === "undefined") || (typeof Array.prototype.flat === "undefined"))
{
	console.warn("old browser.");
	window.location.href = "https://mybuilding.3dfish.net/oldbrowser.html";
}

if (!feature.async)
{
	window.location.href = "https://mybuilding.3dfish.net/oldbrowser.html";
}
