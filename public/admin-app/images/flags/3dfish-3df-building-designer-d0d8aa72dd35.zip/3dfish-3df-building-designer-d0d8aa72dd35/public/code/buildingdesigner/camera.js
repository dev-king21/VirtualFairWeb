/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2 */
/*eslint-disable no-console, no-unused-vars, no-undef*/

/**
 * Handles the Camera
 * @constructor Camera
 */
function Camera()
{
	"use strict";
	/*////let vr = TextDataUtilities.GetParameterByName("vr");

	if (vr && vr=="true")
	{
		this.effect = new THREE.StereoEffect(threeRenderer);
	}
	else
	{
		this.effect = null;
	}*/

	CameraControls.install( { THREE: THREE } );

	this.clock = new THREE.Clock();

	this.canvasWidth = 0;
	this.canvasHeight = 0;

	this.cameraQuad = null;
	this.prevCameraQuad = null;

	this.cameraSubQuad = null;
	this.prevCameraSubQuad = null;

	this.camRadius = 70;

	this.camHeight = 5;

	this.vecCamAxisX = new THREE.Vector3( 1.0, 0.0, 0.0 );
	this.vecCamAxisY = new THREE.Vector3( 0.0, 1.0, 0.0 );
	this.vecCamAxisZ = new THREE.Vector3( 0.0, 0.0, 1.0 );

	this.vecCamCenter = new THREE.Vector3( 0.0, this.camHeight, 0.0 );


	this.modeCamera = Camera.CAM_MODE_EXTERIOR;

	this.exteriorPos = new THREE.Vector3();
	this.interiorPos = new THREE.Vector3();

	this.g_fCameraHorizAngleExterior = Camera.CAM_HORIZ_INITIAL_ANGLE;
	this.g_fCameraVertAngleExterior = Camera.CAM_VERT_INITIAL_ANGLE;

	this.g_fCameraHorizAngleInterior = Camera.CAM_HORIZ_INITIAL_ANGLE;
	this.g_fCameraVertAngleInterior = Camera.CAM_VERT_INITIAL_ANGLE;


	this.g_fCameraHorizAngleExteriorPrev = Camera.CAM_HORIZ_INITIAL_ANGLE;
	this.g_fCameraVertAngleExteriorPrev = Camera.CAM_VERT_INITIAL_ANGLE;

	this.g_fCameraHorizAngleInteriorPrev = Camera.CAM_HORIZ_INITIAL_ANGLE;
	this.g_fCameraVertAngleInteriorPrev = Camera.CAM_VERT_INITIAL_ANGLE;

	this.pan = false;

	this.threeCamera = new THREE.PerspectiveCamera( Camera.CAM_VERTICAL_FOV, canvascontainer.clientWidth/canvascontainer.clientHeight, Camera.CAM_BASE_NEAREST, Camera.CAM_BASE_FURTHEST );

	this.cameraControls = new CameraControls( this.threeCamera, threeRenderer.domElement );

	this.cameraControls.mouseButtons.left  = CameraControls.ACTION.ROTATE;

	this.cameraControls.mouseButtons.right = CameraControls.ACTION.ROTATE;

	this.cameraControls.mouseButtons.wheel = CameraControls.ACTION.ZOOM;

	this.cameraControls.minZoom = Camera.MIN_CAM_ZOOM_EXTERIOR;
	this.cameraControls.maxZoom = Camera.MAX_CAM_ZOOM_EXTERIOR;

    this.cameraControls.touches.two = CameraControls.ACTION.TOUCH_ZOOM;

	this.cameraControls.minPolarAngle = 0;
	this.cameraControls.maxPolarAngle = Math.PI/2;

	this.threeCamera.fov = Camera.CAM_VERTICAL_FOV;

	this.SetCanvasDimensions = function(width, height, forPrint)
	{
		this.prevCanvasWidth = this.canvasWidth;
		this.prevCanvasHeight = this.canvasHeight;

		if (!forPrint)
		{
			width = canvascontainer.clientWidth;
			height = canvascontainer.clientHeight;
		}
		this.canvasWidth = width;
		this.canvasHeight = height;

		if (DEBUG)
			console.log("w: ",this.canvasWidth," h: ",this.canvasHeight);

		this.threeCamera.aspect = this.canvasWidth/this.canvasHeight;

		this.threeCamera.updateProjectionMatrix();

		threeRenderer.setSize( this.canvasWidth, this.canvasHeight);
		this.cameraControls.setViewport(0, 0, this.canvasWidth, this.canvasHeight);
	};

	this.Update = function ()
	{
		const delta = this.clock.getDelta();

        ////Elements.draggableElement = null;

		////if (Elements.draggableElement == null)
        let updated = this.cameraControls.update(delta);

		if (updated)
		{
			this.CalculateCameraQuad();
		}

		return updated;
	};

	this.SetView = function (mode, transition)
	{
		this.modeCamera = mode;

		if (this.modeCamera == Camera.CAM_MODE_EXTERIOR)
		{
			buildingDesigner.camera.cameraControls.minZoom = Camera.MIN_CAM_ZOOM_EXTERIOR;

			this.interiorPos = this.cameraControls._camera.position.clone();
			this.interiorZoom = this.cameraControls._camera.zoom;

			this.cameraControls.setPosition(this.exteriorPos.x, this.exteriorPos.y, this.exteriorPos.z, transition);
			this.cameraControls.zoomTo(this.exteriorZoom, transition);

			this.cameraControls.minPolarAngle = 0;
			this.cameraControls.maxPolarAngle = Math.PI / 2;

			this.cameraControls.azimuthRotateSpeed = 1;
			this.cameraControls.polarRotateSpeed = 1;
		}
		else
		{
			buildingDesigner.camera.cameraControls.minZoom = Camera.MIN_CAM_ZOOM_INTERIOR;

			this.exteriorPos = this.cameraControls._camera.position.clone();
			this.exteriorZoom = this.cameraControls._camera.zoom;

			this.cameraControls.setPosition(this.interiorPos.x, this.interiorPos.y, this.interiorPos.z);
			this.cameraControls.zoomTo(this.interiorZoom);

			this.cameraControls.minPolarAngle = 0;
			this.cameraControls.maxPolarAngle = Math.PI;

			this.cameraControls.azimuthRotateSpeed = 0.2;
			this.cameraControls.polarRotateSpeed = 0.5;
		}
	};

	this.CalculateInteriorViewPosition = function(horizAngle, vertAngle, zoom)
	{
		let vecCam;

		this.camRadius = 1;

		let fCamCentX = 0;
		let fCamCentZ;

		if (!buildingDesigner.building.porch)
		{
			fCamCentZ = -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length / 2;
		}
		else
		{
			let shortestBackFrontWall = buildingDesigner.building.walls.backWallLength < buildingDesigner.building.walls.frontWallLength ? buildingDesigner.building.walls.backWallLength : buildingDesigner.building.walls.frontWallLength;

			if (buildingDesigner.building.porch.rightSide)
			{
				fCamCentZ = buildingDesigner.building.walls.leftBackWallCoord + shortestBackFrontWall / 2;
			}
			else
			{
				fCamCentZ = buildingDesigner.building.walls.rightFrontWallCoord - shortestBackFrontWall / 2;
			}
		}

		this.camHeight = buildingDesigner.building.height * 0.66;

		if (this.camHeight < 5)
		{
			this.camHeight = 5;
		}
		else
		{
			if (this.camHeight > 7)
			{
				this.camHeight = 7;
			}
		}

		this.vecCamCenter = new THREE.Vector3( fCamCentX, this.camHeight, fCamCentZ );

		vecCam = new THREE.Vector3( 0.0, 0.0, this.camRadius ).applyAxisAngle( this.vecCamAxisX, -vertAngle);
		vecCam = vecCam.applyAxisAngle( this.vecCamAxisY, horizAngle);

		vecCam.add(this.vecCamCenter);
		this.interiorPos = vecCam.clone();
		this.interiorZoom = zoom;
	}


	this.CalculateExteriorViewPosition = function(horizAngle, vertAngle, zoom)
	{
		let vecCam;

		let maxWidthLength = (buildingDesigner.building.width > buildingDesigner.building.length) ? buildingDesigner.building.width : buildingDesigner.building.length;
		let maxWidthLengthHeight = (maxWidthLength > buildingDesigner.building.height) ? maxWidthLength : buildingDesigner.building.height;

		this.camRadius = ((maxWidthLengthHeight + buildingDesigner.building.height * 4)/ 2.0) + maxWidthLength * 2;

		if (this.camRadius > Camera.MAX_CAM_RADIUS)
		{
			this.camRadius  = Camera.MAX_CAM_RADIUS;
		}

		this.vecCamCenter = new THREE.Vector3( 0.0, this.camHeight, 0.0 );

		vecCam = new THREE.Vector3( 0.0, 0.0, this.camRadius ).applyAxisAngle(this.vecCamAxisX, -vertAngle);
		vecCam = vecCam.applyAxisAngle(this.vecCamAxisY, horizAngle);

		vecCam.add(this.vecCamCenter);
		this.exteriorPos = vecCam.clone();
		this.exteriorZoom = zoom;
	}

	this.InitializeViews = function()
	{
		this.camHeight = 5;

		if (buildingDesigner.building)
		{
			this.CalculateInteriorViewPosition(this.g_fCameraHorizAngleInterior, this.g_fCameraVertAngleInterior, 0.27);

			this.CalculateExteriorViewPosition(this.g_fCameraHorizAngleExterior, this.g_fCameraVertAngleExterior, 1);

			this.cameraControls.setTarget(this.vecCamCenter.x, this.vecCamCenter.y, this.vecCamCenter.z);

			//set these here because SetView() will store current position and zoom for interior before setting exterior view
			this.threeCamera.position.set(this.interiorPos.x, this.interiorPos.y, this.interiorPos.z);
			this.threeCamera.zoom = this.interiorZoom;

			this.SetView(Camera.CAM_MODE_EXTERIOR, this.modeCamera == Camera.CAM_MODE_EXTERIOR ? true : false);

			$("#buttonExterior").hide();
			$("#buttonInterior").show();
		}
	};

	this.SetPartitionsPositionAndOrientation = function()
	{
		this.g_fCameraHorizAngleExterior = Camera.CAM_HORIZ_PARTITION_ANGLE;
		this.g_fCameraVertAngleExterior = Camera.CAM_VERT_PARTITION_ANGLE;

		this.zoomExterior = Camera.CAM_PARTITION_ZOOM;
	};

	this.CalculateCameraQuad = function()
	{
		////let cameraAngle = this.g_fCameraHorizAngleExterior % (Math.PI * 2);

		let cameraAngle = this.cameraControls.azimuthAngle % (Math.PI * 2);

		if (cameraAngle<0)
			cameraAngle = Math.PI * 2 + cameraAngle;

		if (cameraAngle >= 0 && cameraAngle < Math.PI / 2 && this.cameraQuad != Camera.QUAD1)
		{
			this.prevCameraQuad = this.cameraQuad;
			this.cameraQuad = Camera.QUAD1;
		}
		else
		if (cameraAngle >= Math.PI / 2 && cameraAngle < Math.PI && this.cameraQuad != Camera.QUAD2)
		{
			this.prevCameraQuad = this.cameraQuad;
			this.cameraQuad = Camera.QUAD2;
		}
		else
		if (cameraAngle >= Math.PI  && cameraAngle < Math.PI * 3/2 && this.cameraQuad != Camera.QUAD3)
		{
			this.prevCameraQuad = this.cameraQuad;
			this.cameraQuad = Camera.QUAD3;
		}
		else
		if (cameraAngle >= Math.PI * 3/2  && cameraAngle < Math.PI * 2 && this.cameraQuad != Camera.QUAD4)
		{
			this.prevCameraQuad = this.cameraQuad;
			this.cameraQuad = Camera.QUAD4;
		}

		if (cameraAngle >= 0 && cameraAngle < Math.PI * 1/4 && this.cameraSubQuad != Camera.SUBQUAD1)
		{
			this.prevCameraSubQuad = this.cameraSubQuad;
			this.cameraSubQuad = Camera.SUBQUAD1;
		}
		else
		if (cameraAngle >= Math.PI * 1/4 && cameraAngle < Math.PI * 2/4 && this.cameraSubQuad != Camera.SUBQUAD2)
		{
			this.prevCameraSubQuad = this.cameraSubQuad;
			this.cameraSubQuad = Camera.SUBQUAD2;
		}
		else
		if (cameraAngle >= Math.PI * 2/4 && cameraAngle < Math.PI * 3/4 && this.cameraSubQuad != Camera.SUBQUAD3)
		{
			this.prevCameraSubQuad = this.cameraSubQuad;
			this.cameraSubQuad = Camera.SUBQUAD3;
		}
		else
		if (cameraAngle >= Math.PI * 3/4 && cameraAngle < Math.PI * 4/4 && this.cameraSubQuad != Camera.SUBQUAD4)
		{
			this.prevCameraSubQuad = this.cameraSubQuad;
			this.cameraSubQuad = Camera.SUBQUAD4;
		}
		else
		if (cameraAngle >= Math.PI * 4/4 && cameraAngle < Math.PI * 5/4 && this.cameraSubQuad != Camera.SUBQUAD5)
		{
			this.prevCameraSubQuad = this.cameraSubQuad;
			this.cameraSubQuad = Camera.SUBQUAD5;
		}
		else
		if (cameraAngle >= Math.PI * 5/4 && cameraAngle < Math.PI * 6/4 && this.cameraSubQuad != Camera.SUBQUAD6)
		{
			this.prevCameraSubQuad = this.cameraSubQuad;
			this.cameraSubQuad = Camera.SUBQUAD6;
		}
		else
		if (cameraAngle >= Math.PI * 6/4 && cameraAngle < Math.PI * 7/4 && this.cameraSubQuad != Camera.SUBQUAD7)
		{
			this.prevCameraSubQuad = this.cameraSubQuad;
			this.cameraSubQuad = Camera.SUBQUAD7;
		}
		else
		if (cameraAngle >= Math.PI * 7/4 && cameraAngle < Math.PI * 8/4 && this.cameraSubQuad != Camera.SUBQUAD8)
		{
			this.prevCameraSubQuad = this.cameraSubQuad;
			this.cameraSubQuad = Camera.SUBQUAD8;
		}
	};

	this.SetModeCameraMode = function(modeCamera)
	{
		this.modeCameraPrev = this.modeCamera;

		this.modeCamera = modeCamera;
	};

	this.SetHorizAngle = function(angle)
	{
		if (this.modeCamera == Camera.CAM_MODE_INTERIOR)
		{
			this.g_fCameraHorizAngleInteriorPrev = this.g_fCameraHorizAngleInterior;
			this.g_fCameraHorizAngleInterior = angle;
		}
		else
		{
			this.g_fCameraHorizAngleExteriorPrev = this.g_fCameraHorizAngleExterior;
			this.g_fCameraHorizAngleExterior = angle;
		}

		this.CalculateCameraQuad();
	};


	this.SetVertAngle = function(angle)
	{
		if (this.modeCamera == Camera.CAM_MODE_INTERIOR)
		{
			this.g_fCameraVertAngleInteriorPrev = this.g_fCameraVertAngleInterior;
			this.g_fCameraVertAngleInterior = angle;
		}
		else
		{
			this.g_fCameraVertAngleExteriorPrev = this.g_fCameraVertAngleExterior;
			this.g_fCameraVertAngleExterior = angle;
		}
	};


	this.SetZoom = function(zoom)
	{
		if (this.modeCamera == Camera.CAM_MODE_EXTERIOR)
		{
			this.prevZoomExterior = this.zoomExterior;
			this.zoomExterior = zoom;

			if (this.zoomExterior < Camera.MIN_CAM_ZOOM_EXTERIOR)
				this.zoomExterior = Camera.MIN_CAM_ZOOM_EXTERIOR;
			else
			if (this.zoomExterior > Camera.MAX_CAM_ZOOM_EXTERIOR)
				this.zoomExterior = Camera.MAX_CAM_ZOOM_EXTERIOR;
		}
		else
		{
			this.prevZoomInterior = this.zoomInterior;
			this.zoomInterior = zoom;

			if (this.zoomInterior < Camera.MIN_CAM_ZOOM_INTERIOR)
				this.zoomInterior = Camera.MIN_CAM_ZOOM_INTERIOR;
			else
			if (this.zoomInterior > Camera.MAX_CAM_ZOOM_INTERIOR)
				this.zoomInterior = Camera.MAX_CAM_ZOOM_INTERIOR;
		}


		this.SetPositionAndOrientation();

		buildingDesigner.Draw();
	};


	this.Zoom = function(delta)
	{
		this.cameraControls.zoom(delta, true);
	};


	this.RevertToPreviousSettings = function()
	{
		this.modeCamera = this.modeCameraPrev;

		this.g_fCameraHorizAngleInterior = this.g_fCameraHorizAngleInteriorPrev;
		this.g_fCameraHorizAngleExterior = this.g_fCameraHorizAngleExteriorPrev;


		this.g_fCameraVertAngleInterior = this.g_fCameraVertAngleInteriorPrev;
		this.g_fCameraVertAngleExterior = this.g_fCameraVertAngleExteriorPrev;

		this.zoomExterior = this.prevZoomExterior;
		this.zoomInterior = this.prevZoomInterior;

		this.canvasWidth = this.prevCanvasWidth;
		this.canvasHeight= this.prevCanvasHeight;

		threeRenderer.setSize(this.canvasWidth, this.canvasHeight);
	};

	this.UnprojectCanvasToWorld = function( mousePos )
	{
		let vecWorldPnt = new THREE.Vector3();

		vecWorldPnt.x =  (mousePos.x / canvasMain.clientWidth ) * 2.0 - 1.0;
		vecWorldPnt.y = -(mousePos.y / canvasMain.clientHeight) * 2.0 + 1.0;
		vecWorldPnt.z = 0.5;

		vecWorldPnt.unproject( this.threeCamera );
		return vecWorldPnt;
	};

	this.GetRayCaster = function( mousePos)
	{
		let vecMouse = this.UnprojectCanvasToWorld( mousePos );

		let rayCaster = new THREE.Raycaster( this.threeCamera.position, vecMouse.sub( this.threeCamera.position ).normalize() );

		return rayCaster;
	};
}

Camera.prototype.getThreeCamera = function(){
	return this.threeCamera;
};

Camera.CAM_MODE_EXTERIOR = 0;
Camera.CAM_MODE_INTERIOR = 1;


Camera.CAM_VERTICAL_FOV = 15.0;

Camera.CAM_BASE_NEAREST = 1;
Camera.CAM_BASE_FURTHEST = 270.0;

Camera.CAM_MIN_VERT_ANGLE_EXTERIOR = THREE.Math.degToRad( 0.0 );
Camera.CAM_MAX_VERT_ANGLE_EXTERIOR = THREE.Math.degToRad( 90.0 );

Camera.CAM_MIN_VERT_ANGLE_INTERIOR = THREE.Math.degToRad( 0.0 );
Camera.CAM_MAX_VERT_ANGLE_INTERIOR = THREE.Math.degToRad( 90.0 );

Camera.MIN_CAM_ZOOM_EXTERIOR = 0.4;
Camera.MAX_CAM_ZOOM_EXTERIOR = 4;

Camera.MIN_CAM_ZOOM_INTERIOR = 0.15;
Camera.MAX_CAM_ZOOM_INTERIOR = 2.5;

Camera.CAM_HORIZ_INITIAL_ANGLE_DEG = -40;
Camera.CAM_HORIZ_INITIAL_ANGLE = THREE.Math.degToRad( -40.0 );
Camera.CAM_VERT_INITIAL_ANGLE  = THREE.Math.degToRad( 15.0 );

Camera.CAM_HORIZ_FRONT_ANGLE = THREE.Math.degToRad( 0.0 );
Camera.CAM_HORIZ_LEFT_ANGLE = THREE.Math.degToRad( 90.0 );
Camera.CAM_HORIZ_BACK_ANGLE = THREE.Math.degToRad( 180.0 );
Camera.CAM_HORIZ_RIGHT_ANGLE = THREE.Math.degToRad( 270.0 );

Camera.CAM_INITIAL_ZOOM = 1;

Camera.CAM_HORIZ_PARTITION_ANGLE = THREE.Math.degToRad( 45.0 );
Camera.CAM_VERT_PARTITION_ANGLE  = THREE.Math.degToRad( 55.0 );
Camera.CAM_PARTITION_ZOOM = 0.64;

Camera.MAX_CAM_RADIUS = GRASS_RADIUS*0.81;

Camera.QUAD1 = 0;
Camera.QUAD2 = 1;
Camera.QUAD3 = 2;
Camera.QUAD4 = 3;


Camera.SUBQUAD1 = 0;
Camera.SUBQUAD2 = 1;
Camera.SUBQUAD3 = 2;
Camera.SUBQUAD4 = 3;
Camera.SUBQUAD5 = 4;
Camera.SUBQUAD6 = 5;
Camera.SUBQUAD7 = 6;
Camera.SUBQUAD8 = 7;
