// Copyrighted 2014-2018 by 3D Fish, LLC
// All rights reserved.
// Un-authorized reproduction prohibited
// Violators will be prosecuted.

/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef, no-useless-escape*/

async function AuxUtilities()
{

}

window.alert = async function(alert_text)
{
	let [err, result] = await to(swal.fire({
		text: alert_text
	}));
};

async function reportError(errorcode, err) {
	$.post("/errorreport", {
		errorcode: errorcode,
		statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID}, error: ${JSON.stringify(err)}`
	});
}

function to (promise)
{
	return promise
		.then(val => [null, val])
		.catch(err => [err]);
}

Number.prototype.pad = function(size)
{
	let s = String(this);
	while (s.length < (size || 2))
	{
		s = "0" + s;
	}
	return s;
};

/**
 * Determines if a nested object exists, and if it does, returns the value of the object.
 * @param {*} obj any object
 * @param {string} path string with the dotted path
 */
function nestedObj(obj, path)
{
	if (((typeof obj !== "object") && (typeof obj !== "function")) || (obj === null))
	{
		return undefined;
	}
	pathA = path.split(".");
	for (let i = 0; i < pathA.length; i++)
	{
		if ((obj === null) || (!obj.hasOwnProperty(pathA[i])))
		{
			return undefined;
		}
		obj = obj[pathA[i]];
	}
	return obj;
}

function switchToInput(eID, iType)
{
	let iData = $("#"+eID).text();
	let $input = $("<input>", {val: $("#"+eID).text(), type: iType });
	$input.attr("id",eID);
	$input.attr("onblur",`switchToSpan('${eID}','${iType}');`);
	/* $("#"+eID+" ~ .inactive").css("visibility", "visible"); */
	$("#"+eID).replaceWith($input);
	$("#"+eID).focus();
	$("#"+eID).data("origval",iData);

}

function switchToSpan(eID, iType)
{
	let iNewData = $(`#${eID}`).val();
	let iOldData = $(`#${eID}`).data("origval");
	let $span = $("<span>", {text: $(`#${eID}`).val()});
	$span.attr("id",eID);
	$span.attr("onclick",`switchToInput('${eID}','${iType}');`);
	if (iNewData == iOldData)
	{
		$("#"+eID+" ~ .inactive").css("visibility", "hidden");
	}
	else
	{
		$("#"+eID+" ~ .inactive").css("visibility", "visible");
		$("#"+eID+" ~ .inactive").data("fieldid",eID.substring(3));
		$("#"+eID+" ~ .inactive").data("oldval",iOldData);
		$("#"+eID+" ~ .inactive").data("newval",iNewData);
	}
	$("#"+eID).replaceWith($span);
}

const promiseTimeout = async function(ms, promise)
{
	// Create a promise that rejects in <ms> milliseconds
	let timeout = new Promise((resolve, reject) =>
	{
		let id = setTimeout(() =>
		{
			clearTimeout(id);
			resolve({timedOut: true})
		}, ms)
	})

	// Returns a race between our timeout and the passed in promise
	let result = await Promise.race([
		promise,
		timeout
	])
	if (result.timedOut)
	{
		throw ("timed out");
	}
	else
	{
		return result;
	}
}

// this came from the npm module es6-dynamic-template at github.com/mikemaccana/dynamic-template
function fillTemplate(templateString, templateVariables)
{
	const keys = Object.keys(templateVariables);
	const values = Object.values(templateVariables);
	let templateFunction = new Function(...keys, `return \`${templateString}\`;`);
	return templateFunction(...values);
}

Array.prototype.indexOfObject = function (property, value)
{
	for (let i = 0, len = this.length; i < len; i++)
	{
		if (this[i][property] === value)
			return i;
	}

	return -1;
};

function changeCss(className, classValue)
{
	// we need invisible container to store additional css definitions
	let cssMainContainer = $("#css-modifier-container");
	if (cssMainContainer.length == 0)
	{
		cssMainContainer = $("<div id=\"css-modifier-container\"></div>");
		cssMainContainer.hide();
		cssMainContainer.appendTo($("body"));
	}

	// and we need one div for each class
	classContainer = cssMainContainer.find("div[data-class=\"" + className + "\"]");
	if (classContainer.length == 0)
	{
		classContainer = $("<div data-class=\"" + className + "\"></div>");
		classContainer.appendTo(cssMainContainer);
	}

	// append additional style
	classContainer.html("<style>" + className + " {" + classValue + "}</style>");
}

AuxUtilities.sleep = function (ms)
{
	return new Promise(resolve => setTimeout(resolve, ms));
};

AuxUtilities.SetFormValues = function(form, data, options={})
{
	for (field in data)
	{
		if (form[field])
		{
			form[field].value = data[field];
		}
	}
}

AuxUtilities.roundNumber = function (rnum, rlength)
{ // Arguments: number to round, number of decimal places
	let newnumber = Math.round(rnum*Math.pow(10,rlength))/Math.pow(10,rlength);
	return newnumber;
};

AuxUtilities.IsSet = function (value)
{
	if (value != null && value != undefined && value > -1)
		return true;

	return false;
};

AuxUtilities.IsMobile = function ()
{
	let check = false;

	(function (a)
	{
		if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|subscriber(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4)))
			check = true;
	}
	)	(navigator.userAgent || navigator.vendor || window.opera);

	return check;
};

AuxUtilities.IsMobileOrTablet = function ()
{
	let check = false;

	(function (a)
	{
		if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|subscriber(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4)))
			check = true;
	}
	)	(navigator.userAgent || navigator.vendor || window.opera);

	return check;
};

AuxUtilities.GetURLParameter = function (name)
{
	try {
	return decodeURIComponent((new RegExp("[?|&]" + name + "=" + "([^&;]+?)(&|#|;|$)").exec(location.search) || [null, ""])[1].replace(/\+/g, "%20")) || null;
	} catch (err) {
		throw err;
	}
};

AuxUtilities.GetURLHashParameter = function (name)
{
	//// let re = new RegExp("#.*[?&]" + name + "=([^&]+)(&|$)");
	let re = new RegExp("[\?&]"+name+"=([^&#]*)","i");
	let match = location.href.match(re);

	return (match ? match[1] : "");
};

AuxUtilities.IsHTTPS = function ()
{
	if (window.location.protocol.indexOf("https:") > -1)
		return true;
	else
		return false;
};

AuxUtilities.IsRemote = function ()
{
	if (window.location.host.indexOf("localhost") > -1)
		return false;

	return true;
};

AuxUtilities.LoadHTML = function (attributeName)
{
	let z, i, a, file, xhttp;
	let elem = document.getElementById(attributeName);

	if (elem)
	{
		file = elem.getAttribute("src");

		if (file)
		{
			xhttp = new XMLHttpRequest();

			xhttp.elem = elem;

			xhttp.onreadystatechange = function ()
			{
				if (xhttp.readyState == 4 && xhttp.status == 200)
				{
					xhttp.elem.innerHTML = xhttp.responseText;
				}
			};

			xhttp.open("GET", file, false);
			xhttp.send();

			return;
		}
	}
};

AuxUtilities.MergeArrays = function (array1, array2)
{
	for (let i = 0; i < array2.length; i++)
	{
		array1.push(array2[i]);
	}

	return array1;
};


AuxUtilities.ReverseArray = function (points)
{
	let points2 = [];

	for (let i = points.length - 1; i >= 0; i--)
	{
		points2.push([points[i][0], points[i][1]]);
	}

	return points2;
};

AuxUtilities.InvertArray = function (points)
{
	let points2 = [];

	for (let i = 0; i < points.length; i++)
	{
		points2.push([points[i][0], points[i][1] * -1]);
	}

	return points2;
};

AuxUtilities.ExtractDataFromArray = function (array, elementFunction)
{
	let resultArray = [];
	let value;

	for (let i = 0; i < array.length; i++)
	{
		value = elementFunction(array[i]);

		if (value != null)
			resultArray.push(value);
	}


	resultArray = resultArray.filter(function onlyUnique(value, index, self)
	{
		return self.indexOf(value) === index;
	}
	);

	resultArray.sort(function (a, b)
	{
		return TextDataUtilities.RemoveCharacterAndTrimString(a, "*") - TextDataUtilities.RemoveCharacterAndTrimString(b, "*");
	});

	return resultArray;
};

AuxUtilities.Convert2DimensionalArrayToXYValuedArray = function(array)
{
	let newArray;

	if (array[0].x == undefined)
	{
		newArray = [];

		for (let i = 0; i < array.length; i++)
		{
			newArray.push({x: array[i][0], y: array[i][1], u: array[i][2], u2: array[i][3], v: array[i][4], v2: array[i][5], s: array[i][6]});
		}
	}
	else
		newArray = array;

	return newArray;
};


AuxUtilities.JSONStringifyAndEncode = function (object)
{
	let jsonString = JSON.stringify(object);

	jsonString = TextDataUtilities.ReplaceAll(jsonString, "\"", TextDataUtilities.INVERTED_COMMA_CODE);

	jsonString = TextDataUtilities.ReplaceAll(jsonString, "[", TextDataUtilities.LEFT_BRACKET_CODE);

	jsonString = TextDataUtilities.ReplaceAll(jsonString, "]", TextDataUtilities.RIGHT_BRACKET_CODE);

	jsonString = TextDataUtilities.ReplaceAll(jsonString, "&", TextDataUtilities.AMPERSAND_CODE);

	jsonString = TextDataUtilities.ReplaceAll(jsonString, " ", TextDataUtilities.SPACE_CODE);

	return jsonString;
};


AuxUtilities.JSONDecodeAndParse = function (string)
{
	if (!string)
		return null;

	string = TextDataUtilities.ReplaceAll(string, TextDataUtilities.AMPERSAND_CODE, "&");
	string = TextDataUtilities.ReplaceAll(string, TextDataUtilities.INVERTED_COMMA_CODE, "\"");

	string = TextDataUtilities.ReplaceAll(string, TextDataUtilities.LEFT_BRACKET_CODE, "[");
	string = TextDataUtilities.ReplaceAll(string, TextDataUtilities.RIGHT_BRACKET_CODE, "]");

	string = decodeURI(string);

	return AuxUtilities.tryParseJSON(string);
};


AuxUtilities.tryParseJSON = function (jsonString)
{
	try
	{
		let o = JSON.parse(jsonString);

		if (o && typeof o === "object")
		{
			return o;
		}
	}
	catch (e)
	{
		console.log(e);
	}

	return false;
};

AuxUtilities.escapeSQuote = function(pstring)
{
	return pstring.replace(/'/g, "\\'");
};

AuxUtilities.toggleFullscreen = async function()
{
	if (document.fullscreenElement)
	{
		document.exitFullscreen();
	}
	else
	{
		document.body.requestFullscreen();
	}
}

AuxUtilities.properName = function(name) {

	if (name===name.toLowerCase() || name===name.toUpperCase()) {
		return ("" + name.replace(/[^\s\-\']+[\s\-\']*/g, function (word) {
			return word.charAt(0).toUpperCase() + word.substr(1).toLowerCase();
			}).replace(/\b(Van|De|Der|Da|Von)\b/g, function (nobiliaryParticle) {
			return nobiliaryParticle.toLowerCase();
			}).replace(/Mc(.)/g, function (match, letter3) {
			return 'Mc' + letter3.toUpperCase();
	}));
	} else {
		return name;
	}
}
