/*eslint-env jquery, browser, es6*/
/*eslint-parserOptions ecmaVersion:2018*/
/*eslint no-unused-vars:1, no-trailing-spaces:2, quotes: ["warn", "double", { "allowTemplateLiterals":true}] */
/*eslint-disable no-console, no-unused-vars, no-undef*/
function LoadingSavingUtilities() {}

function Int32ToBytes(num) {
	let buffer = new ArrayBuffer(4);

	view = new DataView(buffer);
	view.setUint32(0, num, false);

	let arr = new Uint8Array(buffer);

	return arr;
}

function BytesToInt32(bytes) {
	let buffer = new ArrayBuffer(4);
	let view = new Int8Array(buffer);

	for (let i = 0; i < 4; i++)
		view[i] = bytes[i];

	let dv = new DataView(buffer, 0);

	return dv.getInt32(0);
}

LoadingSavingUtilities.CompressString = function (uncompressedString) {
	let Buffer = require("buffer").Buffer;
	let LZ4 = require("lz4");

	let input = new Buffer(uncompressedString);

	let output = new Buffer(LZ4.encodeBound(input.length));

	let compressedSize = LZ4.encodeBlock(input, output);

	let lengthBytes = Int32ToBytes(input.length);

	let compressedString = "";

	for (let i = 0; i < lengthBytes.length; i++) {
		compressedString += String.fromCharCode(lengthBytes[i]);
	}

	for (let i = 0; i < compressedSize; i++) {
		compressedString += String.fromCharCode(output[i]);
	}

	compressedString = encodeURI(compressedString);

	return compressedString;
};

/**
 * Returns a saveable XML string of the current building
 * @function LoadingSavingUtilities.GetDesignXMLString
 * @returns {string} XML Design string
 */
LoadingSavingUtilities.GetDesignXMLString = function () {
	let designString = "<?xml version=\"1.0\"?>";
	designString += "<CSDESIGNER_FILE version=\"1.0\" subscriber=\"" + SubscriberDataUtilities.subscriber + "\" series_code=\"" + SubscriberDataUtilities.series_code + "\">";

	designString += buildingDesigner.GetDesignXMLString();
	designString += "</CSDESIGNER_FILE>";

	designString = LoadingSavingUtilities.CompressString(designString);

	return designString;
};

/**
 * returns a saveable object of the current building
 * @function LoadingSavingUtilities.GetDesignObject
 * @returns {Object} Building Design Object
 */
LoadingSavingUtilities.GetDesignObject = function () {
	let designObject = {};
	designObject.TDFDESIGN = {
		version: 2,
		subscriber: SubscriberDataUtilities.subscriber,
		series_code: SubscriberDataUtilities.series_code,
		BUILDING: buildingDesigner.GetDesignObject()
	};
	return designObject;
};

/**
 * Decompresses and previously compressed string
 * @function LoadingSavingUtilities.DecompressString
 * @param {string} compressedString
 */
LoadingSavingUtilities.DecompressString = function (compressedString) {
	compressedString = decodeURI(compressedString);

	let sizeBytes = [];

	for (let i = 0; i < 4; i++) {
		sizeBytes[i] = compressedString.charCodeAt(i);
	}

	let bufView = [];

	for (let i = 4; i < compressedString.length; i++) {
		bufView[i - 4] = compressedString.charCodeAt(i);
	}

	let uncompressedSize = BytesToInt32(sizeBytes);

	let Buffer = require("buffer").Buffer;
	let LZ4 = require("lz4");

	let uncompressed = new Buffer(uncompressedSize);

	LZ4.decodeBlock(bufView, uncompressed);

	let str = "";

	for (let i = 0; i < uncompressed.length; i++) {
		str += String.fromCharCode(uncompressed[i]);
	}

	return str;
};

/**
 * Loads a saved building from an XML string or a saved Object
 * @function LoadingSavingUtilities.LoadBuilding
 * @async
 * @param {string|Object} design saved XML design string or design object
 */
LoadingSavingUtilities.LoadBuilding = async function (design) {
	if(typeof design === "string") {
		let designString = design;
		designString = LoadingSavingUtilities.DecompressString(designString);

		designString = TextDataUtilities.ReplaceAll(designString, "\n", TextDataUtilities.NEWLINE_CODE);

		let parser = new DOMParser();
		let xmlDoc = parser.parseFromString(designString, "text/xml");

		if (xmlDoc.hasErrors) {
			$.post("/errorreport", {
			errorcode: "3DF-LoadFail-01",
			statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID} err: xlmDoc ${JSON.stringify(xmlDoc.hasErrors)}`
			});
			GuiDataUtilities.Alert("Failed to load file.");
		} else {
			let nodeRoot = xmlDoc.getElementsByTagName("CSDESIGNER_FILE");

			if (nodeRoot[0]) {
				let ver = nodeRoot[0].getAttribute("version");
				let designSubscriberID = nodeRoot[0].getAttribute("subscriber");

				let series_code = nodeRoot[0].getAttribute("series_code");

				if (series_code != SubscriberDataUtilities.series_code)
					return null;

				if (designSubscriberID == SubscriberDataUtilities.subscriber) {
					let shedNew = null;
					if (ver === "1.0") {
						return await LoadingSavingUtilities.LoadTDFDesignerFileVersion10(nodeRoot[0]);
					} else {
						$.post("/errorreport", {
							errorcode: "3DF-LoadFail-02",
							statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID} err: Version ${ver} is not supported.`
						});
						GuiDataUtilities.Alert("Error. Version " + ver + " is not supported.");
					}
				}
			} else {
				$.post("/errorreport", {
					errorcode: "3DF-LoadFail-03",
					statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID} err: File should ahve one valid <CSDESIGNER_FILE> element`
				});
				GuiDataUtilities.Alert("Error. File should have one valid <CSDESIGNER_FILE> element.");
			}
		}

		return null;
	} else {
		if (design === IndexDB.persistentDesignObject) {
			if ((SubscriberDataUtilities.subscriber !== design.TDFDESIGN.subscriber) || (SubscriberDataUtilities.series_code !== design.TDFDESIGN.series_code)) {
				IndexDB.DeleteIndexDB();
				return null;
			}
		}
		return await LoadingSavingUtilities.LoadTDFDesignerObject(design);
	}
};

/**
 * @function LoadingSavingUtilities.LoadWebDesign
 * @async
 * @param {string} designID
 * @param {string} version
 * @returns {Promise} buildingLoaded object
 */
LoadingSavingUtilities.LoadWebDesign = async function (designID, version) {
	$("#link_"+designID).addClass("loading");
	let buildingLoaded = null;
	buildingDesigner.defaultSettings = null;
	BuildingDesigner.buildingChangedbyUser = false;

	if (version == null || version == undefined) {
		version = "2";
	}

	if (version === "1") {
		$.post("/errorreport", {
			errorcode: "3DF-LoadFail-04",
			statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID} err: Outdated saved file version.`
		});
		GuiDataUtilities.Alert("Your saved building was saved with a previous version of the Shed Designer\nPlease contact your dealer to have them convert it to the new Designer.\nThanks.");
		return 0;
	}

	let savedDesign = await LoadingSavingUtilities.GetSavedWebDesign(designID);

	if (savedDesign) {
		if (typeof savedDesign.designData === "string") {
			let str = ("[object Object]");
			if (savedDesign.designData.indexOf(str) > -1) {
				savedDesign.designData = savedDesign.designData.substr(str.length);
			}
		}

		LoadingSavingUtilities.designID = designID;
		LoadingSavingUtilities.designMetaData = savedDesign.designMetaData;
		buildingLoaded = LoadingSavingUtilities.LoadBuilding(savedDesign.designData);
	}

	return buildingLoaded;
};

/**
 * XML design save format 1.0 loader
 * @function LoadingSavingUtilities.LoadTDFDesignerFileVersion10
 * @async
 * @param {string} nodeString XML node string
 * @returns {boolean} true
 */
LoadingSavingUtilities.LoadTDFDesignerFileVersion10 = async function (nodeString) {
	let nodesShed = nodeString.getElementsByTagName("SHED");

	if (nodesShed.length == 1) {
		let nodeShed = nodesShed[0];

		let eShedType;

		let buildingID = nodeShed.getAttribute("id");

		if (!buildingDesigner.IsValidBuilding(buildingID)) {
			$.post("/errorreport", {
				errorcode: "3DF-LoadFail-05",
				statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID} err: Building code not in system.`
			});
			GuiDataUtilities.Alert("Error: The building design you are trying to load references a building code that is no longer in the system. If you need to retrieve this design, please contact support.");
			return false;
		}

		let width = nodeShed.getAttribute("width");
		let length = nodeShed.getAttribute("length");
		let height = nodeShed.getAttribute("height");

		buildingDesigner.buildingSizes = await GuiDataUtilities.LoadBuildingSizes(buildingID);

		let buildingSizeIndex = buildingDesigner.GetBuildingIndexForWidthLengthHeightDisplay(width, length, height);

		if (buildingSizeIndex > -1) {
			await buildingDesigner.LaunchCreateBuildingCode(buildingID, buildingSizeIndex, nodeShed);
		} else {
			$.post("/errorreport", {
				errorcode: "3DF-LoadFail-06",
				statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID} err: Building size not available.`
			});
			GuiDataUtilities.Alert("Error: Building size of saved design no longer supported. Building NOT loaded. Please contact support to be able to retrieve this design.");
			return false;
		}
	} else {
		$.post("/errorreport", {
			errorcode: "3DF-LoadFail-07",
			statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID} err: File missing valid <SHED> element.`
		});
		GuiDataUtilities.Alert("Error. File should contain one valid <SHED> element.");
	}

	return true;
};

/**
 * Saved building design object loader
 * @function LoadingSavingUtilities.LoadTDFDesignerObject
 * @async
 * @param {Object} savedDesignObject
 * @returns {boolean} true
 */
LoadingSavingUtilities.LoadTDFDesignerObject = async function (savedDesignObject) {
	$("#loading").show();
	$("#spinner").addClass("fa-spin");
	buildingDesigner.buildingSizes = await GuiDataUtilities.LoadBuildingSizes(savedDesignObject.TDFDESIGN.BUILDING.id);

	let buildingSizeIndex = buildingDesigner.GetBuildingIndexForWidthLengthHeightDisplay(savedDesignObject.TDFDESIGN.BUILDING.width, savedDesignObject.TDFDESIGN.BUILDING.length, savedDesignObject.TDFDESIGN.BUILDING.height);

	if ((buildingSizeIndex === -1) && (!nestedObj(window.featureData,"config.dont_ignore_height_when_loading"))) {
		buildingSizeIndex = buildingDesigner.GetBuildingIndexForWidthLengthHeightDisplay(savedDesignObject.TDFDESIGN.BUILDING.width, savedDesignObject.TDFDESIGN.BUILDING.length, 0);
	}

	if (buildingSizeIndex > -1) {
		await buildingDesigner.LaunchCreateBuildingCode(savedDesignObject.TDFDESIGN.BUILDING.id, buildingSizeIndex, savedDesignObject);
	} else {
		$("#loading").hide();
		$("#spinner").removeClass("fa-spin");
		$(".loading").removeClass("loading");
		$.post("/errorreport", {
			errorcode: "3DF-LoadFail-08",
			statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID} err: Building size no longer supported.`
		});
		GuiDataUtilities.Alert("Error: Building size of saved design no longer supported. Building NOT loaded. Please contact support to be able to retrieve this design.");
		return false;
	}
	$("#loading").hide();
	$("#spinner").removeClass("fa-spin");
	$(".loading").removeClass("loading");
	return true;
};

LoadingSavingUtilities.xmlError = function (err) {
	$.post("/errorreport", {
		errorcode: "3DF-LoadFail-09",
		statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID} XML err: ${JSON.stringify(err)}`
	});
	GuiDataUtilities.Alert(err);
};

/**
 * Save design as a default design
 * @function LoadingSavingUtilities.SetDesignAsDefaultForBuilding
 * @async
 * @param {string} subscriber_id
 * @param {string} building_id
 * @param {number} width
 * @param {string} design_id
 * @returns {string}
 */
LoadingSavingUtilities.SetDesignAsDefaultForBuilding = async function (subscriber_id, building_id, width, design_id) {
	let params = {
		building_id: building_id,
		width: width,
		design_id: design_id,
		subscriber_id: subscriber_id,
		series_code: SubscriberDataUtilities.series_code
	};

	let [err,resultStr] = await NodeJSUtilities.UQuery("adminAction",{request: "setDesignAsDefaultForBuilding", ...params});

	return resultStr;
};

/**
 * @function LoadingSavingUtilities.checkDesignID
 * @param {string} formName ID of the form with the design id input
 */
LoadingSavingUtilities.checkDesignID = async function (formName) {
	let saveToWebForm = document.getElementById(formName);

	let params = {
		subscriber_id: SubscriberDataUtilities.subscriber,
		design_id: saveToWebForm.design_id.value
	};

	let [err,result] = await to(NodeJSUtilities.UQuery("userAction", {request:"checkDesignID", ...params}));

	if (result.result === "ID Not Found")
	{
		$("#designidmsg").html(`&nbsp;<span style="color:green">ID Available</span>`);
	}
	else
	{
		$("#designidmsg").html(`&nbsp;<span style="color:red">ID In Use</span>`);
	}
};

LoadingSavingUtilities.OnClickSaveToWeb = function (formName) {
	let saveToWebForm = document.getElementById(formName);

	let designStr = LoadingSavingUtilities.GetDesignXMLString();

	let data_format = "XML";

	let saveDesignResult = NodeJSUtilities.SaveDesignToWeb(SubscriberDataUtilities.subscriber, SubscriberDataUtilities.series_code, UserDataUtilities.userID, SubscriberDataUtilities.location_number, saveToWebForm.design_id.value, saveToWebForm.designNameForWeb.value, BUILDING_STRING[BuildingDesigner.buildingType], data_format, designStr);

	saveDesignResult = JSON.parse(saveDesignResult);

	if (saveDesignResult.result == "save success!") {
		let saveAsDefaultForBuilding = document.getElementById("saveAsDefaultForBuilding").checked;

		if (saveAsDefaultForBuilding && saveDesignResult.design_id != "")

			LoadingSavingUtilities.SetDesignAsDefaultForBuilding(SubscriberDataUtilities.subscriber, buildingDesigner.building.ID, buildingDesigner.building.sizeData.width_display, saveDesignResult.design_id);


		Login.LoadWebDesignsList();
	} else {
		$.post("/errorreport", {
			errorcode: "3DF-SaveFail-03",
			statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID} err: XML Save failed.`
		});
		alert("Save Failed.");
	}

	saveToWebForm.designNameForWeb.value = "";
};

LoadingSavingUtilities.SaveToServer = async function(design_id, shed_name, userid) {
	LoadingSavingUtilities.savingDesign = true;
	let saveDesignResult, err;
	let designObject = LoadingSavingUtilities.GetDesignObject();
	if (!userid) {
		userid = UserDataUtilities.userID;
	}
	let formData = new FormData();
	formData.append("subscriber_id", SubscriberDataUtilities.subscriber);
	formData.append("series_code", SubscriberDataUtilities.series_code);
	formData.append("userID", userid);
	formData.append("location_number", SubscriberDataUtilities.location_number);
	formData.append("tdf_version", tdf_version);
	formData.append("design_id", design_id);
	formData.append("designNameForWeb", shed_name);
	formData.append("building_name", buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].building_display_name);
	formData.append("building_width", buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].width_display);
	formData.append("building_length", buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].length_display);
	formData.append("building_type", BUILDING_STRING[BuildingDesigner.buildingType]);
	// This is here because the metalbuilding designer is not defining building for some reason (6/27/2019)
	if (typeof window.building === "undefined") {
		window.building = {};
		window.building.subTotal = 0;
		window.building.detailList = [];
		window.building.detailListHTML = "";
		window.building.detailListText = "";
	}
	formData.append("building_price_subtotal", building.subTotal);
	formData.append("product_id",buildingDesigner.building.sizeData.product_id);
	formData.append("linked_product_id", buildingDesigner.building.sizeData.linked_product_id);
	formData.append("shortDescription",building.baseDescription);
	formData.append("building_detail_list_text", building.detailListText);
	formData.append("building_detail_list_html", building.detailListHTML);
	formData.append("building_detail_list", JSON.stringify(building.detailList));
	formData.append("data_format", "JSON");
	let blob = new Blob([JSON.stringify(designObject)], {
		type: "application/json"
	});
	//formData.append("designData", blob);


	let formData2 = {};
	for (data of formData) {
		let newStr = `{"${data[0]}":${JSON.stringify(data[1])}}`;
		let newObj = JSON.parse(newStr);
		formData2 = { ...formData2, ...newObj};
	}
	[err, saveDesignResult] = await to(NodeJSUtilities.UQuery("userAction", {
		request: "saveDesignToWeb",
		subscriber_id: SubscriberDataUtilities.subscriber,
		location_number: SubscriberDataUtilities.location_number,
		series_code: SubscriberDataUtilities.series_code,
		formData: formData2
		}));
	if(err) {
		console.log("error saving design.");
		throw err;
	}
	if (saveDesignResult.s3url) {
		let result;
		[err,result] = await to($.ajax({
			url: saveDesignResult.s3url,
			type: "PUT",
			data: blob,
			dataType: "text",
			cache: false,
			contentType: "multipart/form-data",
			processData: false
		}));
		let err2, result2;

		[err2,result2] = await to(NodeJSUtilities.UQuery("userAction", {request: "recordS3SaveResult", err: err, result:result, saveDesignResult: saveDesignResult, userID: formData.get("userID"), building_type: BUILDING_STRING[BuildingDesigner.buildingType], subscriber_id: formData.get("subscriber_id"), series_code: SubscriberDataUtilities.series_code}));

	}
	LoadingSavingUtilities.savingDesign = false;
	if(err) {
		console.log("error saving design.");
		throw err;
	}
	buildingDesigner.building.designID = saveDesignResult.short_design_id;
	return saveDesignResult;
}

LoadingSavingUtilities.OnClickSaveToServer = async function (formName) {
	if(LoadingSavingUtilities.savingDesign) {
		return;
	}
	LoadingSavingUtilities.savingDesign = true;
	$("#buttonSaveToWeb").hide();
	$("#saveStatusMsg").html("<font color='blue'>Saving Design...</font>");
	let saveToWebForm = document.getElementById(formName);
	let saveDesignResult, err;

	//let designObject = LoadingSavingUtilities.GetDesignObject();
	// let designStr = LoadingSavingUtilities.GetDesignXMLString();

	// let data_format = "XML";

	//let saveDesignResult = NodeJSUtilities.SaveDesignToWeb(SubscriberDataUtilities.subscriber, SubscriberDataUtilities.series_code, UserDataUtilities.userID, SubscriberDataUtilities.location_number, saveToWebForm.design_id.value, saveToWebForm.designNameForWeb.value, BUILDING_STRING[BuildingDesigner.buildingType], data_format, designStr);
	/*let formData = new FormData();
	formData.append("subscriber_id", SubscriberDataUtilities.subscriber);
	formData.append("series_code", SubscriberDataUtilities.series_code);
	formData.append("userID", UserDataUtilities.userID);
	formData.append("location_number", SubscriberDataUtilities.location_number);
	formData.append("design_id", saveToWebForm.design_id.value);
	formData.append("designNameForWeb", saveToWebForm.designNameForWeb.value);
	formData.append("building_name", buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].building_display_name);
	formData.append("building_width", buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].width_display);
	formData.append("building_length", buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].length_display);
	formData.append("building_type", BUILDING_STRING[BuildingDesigner.buildingType]);
	formData.append("data_format", "JSON");
	let blob = new Blob([JSON.stringify(designObject)], {
		type: "application/json"
	});
	formData.append("designData", blob);

	[err,saveDesignResult] = await to($.ajax({
		type: "POST",
		url: "/saveDesignToWeb",
		contentType: false,
		processData: false,
		data: formData
	}));
	if(err) {
		console.log("error saving design.");
	}
	*/
	[err,saveDesignResult] = await to(LoadingSavingUtilities.SaveToServer(saveToWebForm.design_id.value,saveToWebForm.designNameForWeb.value));
	// saveDesignResult = JSON.parse(saveDesignResult);
	if (err) {
		$.post("/errorreport", {
			errorcode: "3DF-SaveFail-01",
			statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID} err: ${JSON.stringify(err)}, readystate: ${err.readyState}, responseText: ${err.responseText}`
		});
		alert("Save Failed.");
		$("#saveStatusMsg").html("<font color='red'>Error Saving Design.</font>");
	} else if ((saveDesignResult.success) || (saveDesignResult.result == "save success!")) {
		let saveAsDefaultForBuilding = document.getElementById("saveAsDefaultForBuilding").checked;

		if (saveAsDefaultForBuilding && saveDesignResult.design_id != "")

			LoadingSavingUtilities.SetDesignAsDefaultForBuilding(SubscriberDataUtilities.subscriber, buildingDesigner.building.ID, buildingDesigner.building.sizeData.width_display, saveDesignResult.design_id);


		Login.LoadWebDesignsList();
		$("#saveStatusMsg").html("<font color='green'>Design successfully saved.</font>");
	} else {
		$.post("/errorreport", {
			errorcode: "3DF-SaveFail-02",
			statuscode: `subscriber_id: ${SubscriberDataUtilities.subscriber}, userID: ${UserDataUtilities.userID}, server response: ${JSON.stringify(saveDesignResult)}`
		});
		alert("Save Failed.");
		$("#saveStatusMsg").html("<font color='red'>Error Saving Design.</font>");
	}

	LoadingSavingUtilities.savingDesign = false;
	$("#buttonSaveToWeb").show();
	saveToWebForm.designNameForWeb.value = "";
	await AuxUtilities.sleep(5000);
	$("#saveStatusMsg").html("");
};

/**
 * Retrieve list of saved designs for the specified user
 * @function LoadingSavingUtilities.GetSavedWebDesigns
 * @async
 * @param {string} userID
 * @param {string} subscriber_id
 * @returns {Promise} Promise for Array of saved designs
 */
LoadingSavingUtilities.GetSavedWebDesigns = async function (userID, subscriber_id) {
	let err;
	[err,LoadingSavingUtilities.saveWebDesigns] = await to(NodeJSUtilities.UQuery("userDataRequest",{request: "getSavedWebDesigns", userID: userID, building_type: BUILDING_STRING[BuildingDesigner.buildingType], subscriber_id: subscriber_id, series_code: SubscriberDataUtilities.series_code}));
	if (err) {
		throw err;
	}

	return LoadingSavingUtilities.saveWebDesigns;
};

/**
 * Load saved design from server
 * @function LoadingSavingUtilities.GetSavedWebDesign
 * @async
 * @param {string} design_id
 * @returns {Promise} Saved design data if exists otherwise null
 */
LoadingSavingUtilities.GetSavedWebDesign = async function (design_id) {
	let params = {
		subscriber_id: SubscriberDataUtilities.subscriber,
		designID: design_id,
		series_code: SubscriberDataUtilities.series_code
	};

	let [err, savedDesign] = await to(NodeJSUtilities.UQuery("userDataRequest",{request: "getSavedWebDesign", ...params}));
	if(savedDesign.success) {
		try {
		//savedDesignStr = JSON.parse(savedDesignStr).designData;
			if (savedDesign.data_format === "JSON") {
				designData = JSON.parse(savedDesign.designData);
				delete savedDesign.designData;
				if (designData.url) {
					[err,designData] = await to($.ajax({ url: designData.url, dataType: "json"}));
					if (err) {
						if (err.status >= 400 && err.status < 500) {
							$.post({url: "/errorreport", data:{
								errorcode: "3DF-LoadFail-10",
								statuscode: {subscriber_id: SubscriberDataUtilities.subscriber, userID: UserDataUtilities.userID, design_id: savedDesign.design_id, err: err}
							}, dataType: "json"});
							GuiDataUtilities.Alert("Saved Design File not found.");
							return null;
						}
						$.post({url: "/errorreport", data:{
							errorcode: "3DF-LoadFail-11",
							statuscode: {subscriber_id: SubscriberDataUtilities.subscriber, userID: UserDataUtilities.userID, design_id: savedDesign.design_id, err: err}
						}, dataType: "json"});
						GuiDataUtilities.Alert("Error trying to load Saved Design File.");
						return null;
					}
					//savedDesign = JSON.parse(savedDesign);
				}
			} else {
				designData = savedDesign.designData;
				delete savedDesign.designData;
			}
		} catch (ex) {
			return null;
		}

		return {designData: designData, designMetaData: savedDesign};
	} else {
		if(savedDesign.err) {
			GuiDataUtilities.Alert(savedDesign.err);
			return null;
		} else {
			GuiDataUtilities.Alert("Unable to load saved design.");
			return null;
		}
	}
};

LoadingSavingUtilities.closingCode = function() {
	if (LoadingSavingUtilities.savingDesign) {
		return false;
	}
	return null;
};

LoadingSavingUtilities.saveWebDesigns = null;
LoadingSavingUtilities.loadingDefaultBuilding = false;
LoadingSavingUtilities.savingDesign = false;

LoadingSavingUtilities.designID = "";
LoadingSavingUtilities.designMetaData = {};
LoadingSavingUtilities.lastDesignID = "";

window.onbeforeunload = LoadingSavingUtilities.closingCode;
