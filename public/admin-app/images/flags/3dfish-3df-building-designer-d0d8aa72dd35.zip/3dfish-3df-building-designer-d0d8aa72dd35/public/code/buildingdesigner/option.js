/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

////function OptionElement(name, elem_ID, object3D_ID, width, height, width_display, height_display, price)
function OptionElement(buttonData)
{
	////Element.call(this, name, elem_ID, object3D_ID, width, height, width_display, height_display, 1, price);
	Element.call(this, buttonData);

	this.buttonData.type = ELEM_OPTION;

	this.AddObjects();

	let default_color = nestedObj(buttonData,"options.default_trim_color_id") || nestedObj(buildingDesigner.building,"options.defaults.option_trim_color_id");
	if (default_color)
	{
		let trimColor = ColorsDataUtilities.FindColor(default_color);
		if (trimColor)
		{
			this.trimColor = trimColor.color;
			this.trimColor_name = trimColor.color_name;
			this.trimColor_id = trimColor.color_id;
		}
	}

	this.Generate = function (buildingMeshes, subtractGeometryFromWall = false)
	{
		//if (this.dragging && Elements.IsElementInCollision(this))
		//this.collision = true;

		if (this.regenerate && this.wall && this.wall.matrix)
		{
			//if (this.component3DObjects.mesh == null)
			{
				////if (this.dragging && Elements.IsElementInCollision(this))
				////this.collision = true;

				if (this.component3DObjects.boundingBox == null)
				{
					this.component3DObjects.CalculateGeometryScale(this.buttonData.width, this.buttonData.height, this.buttonData.height);
					this.component3DObjects.CalculateGeometryCenter();
				}

				if (this.component3DObjects.boundingBox)
				{

					////this.component3DObjects.ComputeBoundingBoxForAllObjects(false, false);

					////let size = this.component3DObjects.boundingBox.getSize();

					let size = new THREE.Vector3();

					size = this.component3DObjects.boundingBox.getSize(size);

					//this.component3DObjects.scale = new THREE.Vector3(this.width/size.x, this.height/size.y, this.height/size.y);

					this.length = size.z * this.component3DObjects.scale.z;

					/*
                this.component3DObjects.ComputeBoundingBoxForAllObjects(false, false);

                let size = this.component3DObjects.boundingBox.getSize();

                this.totalWidth = size.x * this.component3DObjects.scale.x;
                this.totalHeight = size.y * this.component3DObjects.scale.y;
                */

					this.component3DObjects.Generate(buildingMeshes, this.component3DObjects.scale, true);

					this.component3DObjects.SetCameraAndConfigurationModeVisibility(buildingDesigner.camera.modeCamera, this.configurationMode);

					if (this.selected)
					{
						this.GenerateSelectedBoxes(this.component3DObjects.mesh, this.component3DObjects.mesh.matrix);
						//this.GenerateSelectedBoxes(this.component3DObjects.mesh, new THREE.Matrix4().makeTranslation(0, 0, -this.length/this.component3DObjects.scale.z), new THREE.Vector3(1/this.component3DObjects.scale.x,1/this.component3DObjects.scale.y,1/this.component3DObjects.scale.z));

						////this.component3DObjects.mesh = MeshUtilities.MergeMeshGeometry(this.component3DObjects.mesh);
					}

					this.component3DObjects.mesh.type = ELEM_OPTION;

					MeshUtilities.SetElement(this.component3DObjects.mesh, this);

					this.component3DObjects.mesh.castShadow = true;

					this.component3DObjects.mesh.visible = true;
				}
			}


			this.UpdateMatrix();

			if (!this.dragging && subtractGeometryFromWall)
				this.SubtractCutoutGeometryFromBuildingMeshes(buildingMeshes, 1 / this.component3DObjects.scale.z);

			this.regenerate = false;
		}

		/*////let subtractMaterial = new THREE.MeshStandardMaterial ( { color: 0xffffff, map: null, roughness: 1.0, metalness: METALNESS} );

        this.mesh = new THREE.Mesh(this.trimCutoutGeometry, subtractMaterial );

        return this.mesh;
        */


		return this.component3DObjects.mesh;
	};
}

Option.AddOption = function (optionButtonData)
{
	let element = new OptionElement(optionButtonData);

	Elements.AddElement(element);

	return element;
};

// The correct place to call parent object is in child class constructor
// as we call it in above Student function code
OptionElement.prototype = Object.create(Element.prototype);
// Set the "constructor" property to refer to Student
OptionElement.prototype.constructor = OptionElement;
