/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Ruler(element, subtype)
{
	this.element = element;
	this.subtype = subtype;

	this.length = 0;

	this.wall = null;

	this.matrix = null;

	this.pos = new THREE.Vector3(0, 0, 0);

	this.yRot = 0;

	this.mesh = null;
	this.meshValueText = null;
	this.meshDescriptionText = null;

	this.rulerColor = 0xFFFF00;

	////this.type = ELEM_RULER;

	this.rulerTextureFileName = "Ruler";
	this.rulerTexture = null;

	this.visible = false;

	this.regenerate = true;


	this.textAndLogoCanvas = document.createElement("canvas");
	this.textAndLogoContext = this.textAndLogoCanvas.getContext("2d");

	this.textAndLogoContext.font = "Bold 100px Arial";
	this.textAndLogoContext.fillStyle = Ruler.RULER_TEXT_COLOR;

	this.textAndLogoTexture = new THREE.Texture(this.textAndLogoCanvas);


	this.textAndLogoCanvas2 = document.createElement("canvas");
	this.textAndLogoContext2 = this.textAndLogoCanvas2.getContext("2d");

	this.textAndLogoContext2.font = "Bold 100px Arial";
	this.textAndLogoContext2.fillStyle = Ruler.RULER_TEXT_COLOR;

	this.textAndLogoTexture2 = new THREE.Texture(this.textAndLogoCanvas2);

	this.descriptionText = "";

	this.SetVisibility = function(visible)
	{
		if (typeof this.visible === "object") {
			console.warn("Attempt to set ruler visibility for ruler with global setting.");
			return;
		} else {
			this.visible = visible;
		}

		if (this.mesh) {
			this.mesh.material.visible = visible;
		}

		if (this.meshValueText) {
			this.meshValueText.material.visible = visible;
		}

		if (this.meshDescriptionText) {
			this.meshDescriptionText.material.visible = visible;
		}
	};

	this.SetDescriptionText = function(text)
	{
		this.descriptionText = text;
	};

	this.GetTexturesAsync = async function ()
	{
		if (this.rulerTextureFileName != "")
		{
			Ruler.RULER_WIDTH = TexturesDataUtilities.GetTextureData(this.rulerTextureFileName).realWorldHeight;

			this.rulerTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.rulerTextureFileName, this.length, Ruler.RULER_WIDTH);
		}
	};

	this.GetTextures = function ()
	{
		if (this.rulerTextureFileName != "")
		{
			Ruler.RULER_WIDTH = TexturesDataUtilities.GetTextureData(this.rulerTextureFileName).realWorldHeight;

			this.rulerTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.rulerTextureFileName, this.length, Ruler.RULER_WIDTH);
		}
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	// .Generate is called once for each ruler ( width, length, height )
	this.Generate = function ()
	{
		let visible;
		if (typeof this.visible === "object") {
			visible = this.visible.visible;
		} else {
			visible = this.visible;
		}
		if (!AuxUtilities.IsMobile() && this.regenerate && visible)
		{
			this.Destroy();

			this.GetTextures();

			let geometry = new THREE.BoxGeometry(this.length, Ruler.RULER_WIDTH, Ruler.RULER_THICKNESS);

			let material = new THREE.MeshBasicMaterial({
				color: this.rulerColor,
				map: TexturesDataUtilities.TextureLoaded(this.rulerTexture)
			});

			this.mesh = new THREE.Mesh(geometry, material);

			threeScene.add(this.mesh);
			threeRenderer.shadowMap.needsUpdate = true;


			let fRoundedLength = MathUtilities.Round(this.length, 2);

			this.textAndLogoContext.clearRect(0, 0, this.textAndLogoCanvas.width, this.textAndLogoCanvas.height);

			this.textAndLogoContext.fillText(fRoundedLength.toString(), 0, 100);

			this.textAndLogoTexture.needsUpdate = true;


			let matterText = new THREE.MeshBasicMaterial( {map: this.textAndLogoTexture, side:THREE.DoubleSide } );
			matterText.transparent = true;

			this.meshValueText = new THREE.Mesh(new THREE.PlaneGeometry(4, 3), matterText);

			let matrix = new THREE.Matrix4().makeTranslation(4, 0, 0);

			this.meshValueText.geometry.matrixAutoUpdate = false;
			this.meshValueText.geometry.applyMatrix4(matrix);

			threeScene.add(this.meshValueText);


			this.textAndLogoContext2.clearRect(0, 0, this.textAndLogoCanvas.width, this.textAndLogoCanvas2.height);

			this.textAndLogoContext2.fillText(this.descriptionText, 50, 100);

			this.textAndLogoTexture2.needsUpdate = true;

			matterText = new THREE.MeshBasicMaterial( {map: this.textAndLogoTexture2, side:THREE.DoubleSide } );
			matterText.transparent = true;

			this.meshDescriptionText = new THREE.Mesh(new THREE.PlaneGeometry(8, 6), matterText);

			threeScene.add(this.meshDescriptionText);

			threeRenderer.shadowMap.needsUpdate = true;

			this.UpdateMatrix();

			this.regenerate = false;
		}
	};

	this.UpdateMatrix = function ()
	{
		let visible;
		if (typeof this.visible === "object") {
			visible = this.visible.visible;
		} else {
			visible = this.visible;
		}
		if ((!AuxUtilities.IsMobile()) && visible && this.wall && this.wall.matrix)
		{
			let wallMatrix = this.wall.matrix;

			max = undefined;

			for (let i=0; i<this.wall.wallFacets.length; i++)
			{
				pos = new THREE.Vector3().setFromMatrixPosition(this.wall.wallFacets[i].matrix);

				if (this.wall.eWall == WALL_FRONT || this.wall.eWall == WALL_BACK)
					value = Math.abs(pos.x);
				else
					value = Math.abs(pos.z);

				if (value>max || !max)
				{
					max = value;

					wallMatrix = this.wall.wallFacets[i].matrix;
				}
			}

			let matrix = new THREE.Matrix4();

			matrix = new THREE.Matrix4().multiplyMatrices(wallMatrix, matrix);

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z));

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationY(this.yRot));

			if (this.subtype == Ruler.VERT_RULER)
			{
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, this.length / 2, 0));
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationZ(MathUtilities.PI / 2));
			}
			else
			{
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, 0, Ruler.RULER_WIDTH/2));
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationX(-Math.PI/2));
			}

			this.mesh.matrix = new THREE.Matrix4();
			this.mesh.matrixAutoUpdate = false;
			this.mesh.applyMatrix4(matrix);

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, -Ruler.RULER_WIDTH*1.5, 0.1));

			this.meshValueText.matrix = new THREE.Matrix4();
			this.meshValueText.matrixAutoUpdate = false;
			this.meshValueText.applyMatrix4(matrix);

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, -Ruler.RULER_WIDTH*2.5, 0.1));

			this.meshDescriptionText.matrix = new THREE.Matrix4();
			this.meshDescriptionText.matrixAutoUpdate = false;
			this.meshDescriptionText.applyMatrix4(matrix);
		}
	};

	this.UpdateLength = function ()
	{
		if (this.wall.eWall == WALL_RIGHT || this.wall.eWall == WALL_FRONT)
			this.length = element.pos.x + element.wall.length / 2;
		else
			this.length = element.wall.length / 2 - element.pos.x;

		if (this.wall.eWall == WALL_RIGHT || this.wall.eWall == WALL_LEFT)
			this.length += Wall.WALLTHICKNESS;
	};

	this.SetWall = function (wall)
	{
		if (!this.wall || this.wall != wall)
		{
			this.wall = wall;
		}

		if (this.wall)
			return true;
		else
			return false;
	};

	this.SetQuads = function (quad, subQuad)
	{
		let changed = false;

		if (this.quad != quad)
		{
			this.quad = quad;

			changed = true;
		}

		if (this.subQuad != subQuad)
		{
			this.subQuad = subQuad;

			changed = true;
		}

		return changed;
	};

	this.SetPos = function (x, y, z)
	{
		this.pos.x = x;
		this.pos.y = y;
		this.pos.z = z;
	};

	this.SetPos = function (vector)
	{
		this.pos.x = vector.x;
		this.pos.y = vector.y;
		this.pos.z = vector.z;
	};

	this.SetLength = function (length)
	{
		this.length = length;
	};


	this.SetOrientation = function (cameraSubQuad)
	{
		switch (cameraSubQuad)
		{
		case (Camera.SUBQUAD1):
			this.yRot =  Math.PI/2;
			break;
		case (Camera.SUBQUAD2):
			this.yRot =  Math.PI;
			break;
		case (Camera.SUBQUAD3):
			this.yRot =  Math.PI;
			break;
		case (Camera.SUBQUAD4):
			this.yRot =  -MathUtilities.PI2;
			break;
		case (Camera.SUBQUAD5):
			this.yRot =  -MathUtilities.PI2;
			break;
		case (Camera.SUBQUAD6):
			this.yRot =  0;
			break;
		case (Camera.SUBQUAD7):
			this.yRot =  0;
			break;
		case (Camera.SUBQUAD8):
			this.yRot =  MathUtilities.PI2;
			break;
		}

		this.UpdateMatrix();
	};



	this.Destroy = function ()
	{
		if (this.mesh != null)
		{
			threeScene.remove(this.mesh);
			threeScene.remove(this.meshValueText);
			threeScene.remove(this.meshDescriptionText);
			threeRenderer.shadowMap.needsUpdate = true;
			this.mesh = null;
			this.meshValueText = null;
			this.meshDescriptionText = null;
		}
	};
}

Ruler.HORIZ_RULER = 1;
Ruler.VERT_RULER = 2;

Ruler.RULER_WIDTH = 1.0;

Ruler.RULER_TEXT_FONT = `code/vendor/three-js-${THREE.REVISION}/fonts/helvetiker_regular.typeface.json`;

Ruler.rulerFont = null;

Ruler.RULER_TEXT_SIZE = 0.029762;

Ruler.RULER_TEXT_COLOR = "rgba(0, 0, 0, 1.0)";

Ruler.FONT_HEIGHT_CAM_RADIUS_RATIO = 0.0001;

Ruler.RULER_THICKNESS = 0.1;

Ruler.RULER_IN_FRONT_WALL_DISTANCE = 1.0;

Ruler.VERTICAL_RULER_IN_FRONT_WALL_DISTANCE = 4.0;

Ruler.RULER_SIDE_WALL_DISTANCE = 3.0;
