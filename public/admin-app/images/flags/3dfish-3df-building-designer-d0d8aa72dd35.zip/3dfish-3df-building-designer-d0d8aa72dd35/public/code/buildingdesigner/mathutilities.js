/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function MathUtilities()
{}

MathUtilities.ALMOST_ZERO = 0.0001;
MathUtilities.PI = Math.PI;
MathUtilities.PI360 = Math.PI*2;
MathUtilities.PI2 = Math.PI / 2.0;
MathUtilities.PI4 = Math.PI / 4.0;
MathUtilities.RADIAN = Math.PI / 180;

MathUtilities.Feet = function (inches)
{
	return 0.08333333 * inches;
};

MathUtilities.Equals = function (value1, value2, range)
{
	if (Math.abs(value1 - value2) <= range)
		return true;

	return false;
};

MathUtilities.GetAngleBetween3Vectors = function(vector1, vector2, vector3)
{
	let newVector1 = vector1.clone().sub(vector2);
	let newVector3 = vector3.clone().sub(vector2);

	angle = newVector1.angleTo(newVector3);

	return angle;
};

MathUtilities.GetPerpendicular = function (line)
{
	let perp = new THREE.Vector2(-line.y, line.x);

	perp.divideScalar(perp.length());

	return perp;
};

MathUtilities.Min = function (value1, value2)
{
	if (value1 == undefined)
		return value2;

	if (value2 == undefined)
		return value1;

	return Math.min(value1, value2);
};

MathUtilities.Round = function (num, dec)
{
	let fDec = Math.pow(10, dec);

	return Math.round(num * fDec) / fDec;
};

MathUtilities.ValueInArray = function (array, value, range)
{
	for (let i = 0; i < array.length; i++)
	{
		if (Math.abs(array[i] - value) <= range)
			return true;
	}

	return false;
};

MathUtilities.ConvertArrayToNumber = function (stringArray)
{
	let newArray = [];
	for (let i = 0; i < stringArray.length; i++)
	{
		newArray[i] = stringArray[i] * 1;
	}

	return newArray;
};

MathUtilities.RotateVector = function (vector, xRot, yRot, zRot, angle)
{
	let x = vector.x;
	let y = vector.y;
	let z = vector.z;

	if (xRot)
	{
		newZ = z * Math.cos(angle) - y * Math.sin(angle);
		newY = z * Math.sin(angle) + y * Math.cos(angle);

		y = newY;
		z = newZ;
	}

	if (yRot)
	{
		newX = x * Math.cos(angle) - z * Math.sin(angle);
		newZ = x * Math.sin(angle) + z * Math.cos(angle);

		x = newX;
		z = newZ;
	}

	if (zRot)
	{
		newX = x * Math.cos(angle) - y * Math.sin(angle);
		newY = x * Math.sin(angle) + y * Math.cos(angle);

		x = newX;
		y = newY;
	}

	return new THREE.Vector3(x, y, z);
};


