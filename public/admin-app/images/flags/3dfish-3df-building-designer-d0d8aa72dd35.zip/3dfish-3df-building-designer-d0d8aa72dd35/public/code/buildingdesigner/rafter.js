/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Rafter(rafterData)
{
	this.wallWidth = 0;
	this.leanToWidth = 0;

	this.data = rafterData;

	this.Process = function ()
	{
		if (!this.data.rafter_spec)
		{
			console.warn("missing rafter data. Generating generic rafters");
			this.data.rafter_spec = [[0,0],[0,3],[64.875,31.25],[129.5,3],[129.5,0],[127.25,0],[124,1.5],[124,3],[120.75,3],[64.875,27.25],[8.5,3],[5.5,3],[5.5,1.5],[2,0]];
			this.data.front_wall_attach_coord = [[5.5,1.5],[5.5,3]];
			this.data.rear_wall_attach_coord = [[124,1.5],[124,3]];
			this.data.thickness = 1.5;
			this.data.width = 3.504;
			this.data.material_type = "wood";
			this.data.units = "inches";
			GuiDataUtilities.Alert("Missing data in saved design file, default rafter data substituted, design may not appear as saved.  Please contact support.");
		}
		let xOff = this.data.rafter_spec[0][0];
		let yOff = this.data.rafter_spec[0][1];

		for (let i = 0; i < this.data.rafter_spec.length; i++)
		{
			this.data.rafter_spec[i][0] -= xOff;
			this.data.rafter_spec[i][1] -= yOff;
		}

		if (this.data.units == "inches")
		{
			for (let i = 0; i < this.data.rafter_spec.length; i++)
			{
				this.data.rafter_spec[i][0] = MathUtilities.Feet(this.data.rafter_spec[i][0]);
				this.data.rafter_spec[i][1] = MathUtilities.Feet(this.data.rafter_spec[i][1]);
			}

			if (this.data.front_wall_attach_coord && this.data.front_wall_attach_coord.length > 0)
			{
				this.data.front_wall_attach_coord[0][0] = MathUtilities.Feet(this.data.front_wall_attach_coord[0][0]);
				this.data.front_wall_attach_coord[0][1] = MathUtilities.Feet(this.data.front_wall_attach_coord[0][1]);

				this.data.front_wall_attach_coord[1][0] = MathUtilities.Feet(this.data.front_wall_attach_coord[1][0]);
				this.data.front_wall_attach_coord[1][1] = MathUtilities.Feet(this.data.front_wall_attach_coord[1][1]);
			}

			if (this.data.rear_wall_attach_coord && this.data.rear_wall_attach_coord.length > 0)
			{
				this.data.rear_wall_attach_coord[0][0] = MathUtilities.Feet(this.data.rear_wall_attach_coord[0][0]);
				this.data.rear_wall_attach_coord[0][1] = MathUtilities.Feet(this.data.rear_wall_attach_coord[0][1]);

				this.data.rear_wall_attach_coord[1][0] = MathUtilities.Feet(this.data.rear_wall_attach_coord[1][0]);
				this.data.rear_wall_attach_coord[1][1] = MathUtilities.Feet(this.data.rear_wall_attach_coord[1][1]);
			}


			if (this.data.front_height_extension_attach_coord && this.data.front_height_extension_attach_coord.length > 0)
			{
				this.data.front_height_extension_attach_coord[0][0] = MathUtilities.Feet(this.data.front_height_extension_attach_coord[0][0]);
				this.data.front_height_extension_attach_coord[0][1] = MathUtilities.Feet(this.data.front_height_extension_attach_coord[0][1]);

				this.data.front_height_extension_attach_coord[1][0] = MathUtilities.Feet(this.data.front_height_extension_attach_coord[1][0]);
				this.data.front_height_extension_attach_coord[1][1] = MathUtilities.Feet(this.data.front_height_extension_attach_coord[1][1]);
			}

			if (this.data.rear_height_extension_attach_coord && this.data.rear_height_extension_attach_coord.length > 0)
			{
				this.data.rear_height_extension_attach_coord[0][0] = MathUtilities.Feet(this.data.rear_height_extension_attach_coord[0][0]);
				this.data.rear_height_extension_attach_coord[0][1] = MathUtilities.Feet(this.data.rear_height_extension_attach_coord[0][1]);

				this.data.rear_height_extension_attach_coord[1][0] = MathUtilities.Feet(this.data.rear_height_extension_attach_coord[1][0]);
				this.data.rear_height_extension_attach_coord[1][1] = MathUtilities.Feet(this.data.rear_height_extension_attach_coord[1][1]);
			}


			this.data.thickness = MathUtilities.Feet(this.data.thickness);
			this.data.width = MathUtilities.Feet(this.data.width);
			this.data.roof_overhang = MathUtilities.Feet(this.data.roof_overhang);
			this.data.max_gap = MathUtilities.Feet(this.data.max_gap);
			this.data.wall_height_segment_on_rafter = MathUtilities.Feet(this.data.wall_height_segment_on_rafter);


			if (this.data.lean_to)
			{
				this.data.lean_to_attach_coord[0][0] = MathUtilities.Feet(this.data.lean_to_attach_coord[0][0]);
				this.data.lean_to_attach_coord[0][1] = MathUtilities.Feet(this.data.lean_to_attach_coord[0][1]);

				this.data.lean_to_attach_coord[1][0] = MathUtilities.Feet(this.data.lean_to_attach_coord[1][0]);
				this.data.lean_to_attach_coord[1][1] = MathUtilities.Feet(this.data.lean_to_attach_coord[1][1]);
			}

			this.data.units = "feet";
		}

		if (BuildingDesigner.buildingType == BUILDING_CARPORT)
		{
			let point1 = new THREE.Vector2(this.data.rafter_spec[this.data.rafter_spec.length - 1][0], this.data.rafter_spec[this.data.rafter_spec.length - 1][1]);
			let point2 = new THREE.Vector2(this.data.rafter_spec[0][0], this.data.rafter_spec[0][1]);

			let point3 = new THREE.Vector2(this.data.front_wall_attach_coord[0][0], this.data.front_wall_attach_coord[0][1]);
			let point4 = new THREE.Vector2(this.data.front_wall_attach_coord[0][0], this.data.front_wall_attach_coord[0][1] + 1);


			let interSectPoint = GeometryUtilities.LinesIntersectPoint(point1, point2, point3, point4);

			this.data.front_wall_attach_coord[0][1] = interSectPoint.y;

			this.data.front_wall_attach_coord[1][0] = this.data.front_wall_attach_coord[0][0];
			this.data.front_wall_attach_coord[1][1] = this.data.front_wall_attach_coord[0][1];


			this.data.front_height_extension_attach_coord[0][1] = interSectPoint.x;
			this.data.front_height_extension_attach_coord[0][1] = interSectPoint.y;


			point3 = new THREE.Vector2(this.data.front_wall_attach_coord[0][0] + this.data.thickness, this.data.front_wall_attach_coord[1][1]);
			point4 = new THREE.Vector2(this.data.front_wall_attach_coord[0][0] + this.data.thickness, this.data.front_wall_attach_coord[1][1] + 1);


			interSectPoint = GeometryUtilities.LinesIntersectPoint(point1, point2, point3, point4);


			this.data.front_height_extension_attach_coord[1][0] = interSectPoint.x;
			this.data.front_height_extension_attach_coord[1][1] = interSectPoint.y;



			point1 = new THREE.Vector2(this.data.rafter_spec[this.data.rafter_spec.length - 2][0], this.data.rafter_spec[this.data.rafter_spec.length - 2][1]);
			point2 = new THREE.Vector2(this.data.rafter_spec[this.data.rafter_spec.length - 1][0], this.data.rafter_spec[this.data.rafter_spec.length - 1][1]);

			point3 = new THREE.Vector2(this.data.rear_wall_attach_coord[0][0], this.data.rear_wall_attach_coord[0][1]);
			point4 = new THREE.Vector2(this.data.rear_wall_attach_coord[0][0], this.data.rear_wall_attach_coord[0][1] + 1);


			interSectPoint = GeometryUtilities.LinesIntersectPoint(point1, point2, point3, point4);

			this.data.rear_wall_attach_coord[0][1] = interSectPoint.y;

			this.data.rear_wall_attach_coord[1][0] = this.data.rear_wall_attach_coord[0][0];
			this.data.rear_wall_attach_coord[1][1] = this.data.rear_wall_attach_coord[0][1];


			this.data.rear_height_extension_attach_coord[1][1] = interSectPoint.x;
			this.data.rear_height_extension_attach_coord[1][1] = interSectPoint.y;

			point3 = new THREE.Vector2(this.data.rear_wall_attach_coord[1][0] - this.data.thickness, this.data.rear_wall_attach_coord[0][1]);
			point4 = new THREE.Vector2(this.data.rear_wall_attach_coord[1][0] - this.data.thickness, this.data.rear_wall_attach_coord[0][1] + 1);


			interSectPoint = GeometryUtilities.LinesIntersectPoint(point1, point2, point3, point4);


			this.data.rear_height_extension_attach_coord[0][0] = interSectPoint.x;
			this.data.rear_height_extension_attach_coord[0][1] = interSectPoint.y;

		}


		this.apexCoordsIndices = this.GetApexCoordIndices();

		if (this.apexCoordsIndices[0] == 1 && this.apexCoordsIndices[1] == 0)
		{
			this.leanToRafter = true;
		}
		else
			this.leanToRafter = false;

		this.sideCoordsIndices = this.GetSideCoordIndices();

		if (this.data.front_wall_attach_coord != "" && this.data.rear_wall_attach_coord != "")
		{
			this.width = this.GetExtents(this.data.rafterspec).x;

			if (!this.leanToRafter)
				this.wallWidth = this.data.rear_wall_attach_coord[0][0] - this.data.front_wall_attach_coord[0][0];
			else
				this.wallWidth = this.data.rear_wall_attach_coord[0][0] - (this.data.front_wall_attach_coord[0][0] - this.data.width);

			this.frontBackHeightDifference = this.data.front_wall_attach_coord[1][1] - this.data.rear_wall_attach_coord[1][1];

			this.frontAttachJointHeight = this.data.front_wall_attach_coord[1][1] - this.data.front_wall_attach_coord[0][1];
			this.rearAttachJointHeight = this.data.rear_wall_attach_coord[1][1] - this.data.rear_wall_attach_coord[0][1];

			if (this.data.lean_to)
			{
				this.leanToWidth = this.data.front_wall_attach_coord[0][0];
				this.frontLeanToHeightDifference = this.data.front_wall_attach_coord[1][1] - this.data.lean_to_attach_coord[1][1];
			}

			// This is scheduled to be changed -- Visor not the correct term -- should be Overhang
			this.frontVisorWidth = this.data.front_wall_attach_coord[0][0] - this.data.rafter_spec[0][0];

			if (this.leanToRafter)
			{
				this.frontVisorWidth -= this.data.width;
			}

			if (this.data.bent_bow)
			{
				this.frontVisorHeight = 0;
			}
			else
			{
				this.frontVisorHeight = this.data.front_wall_attach_coord[1][1] - this.data.rafter_spec[0][1];
			}

			this.rearVisorWidth = this.GetExtents(this.data.rafter_spec).x - this.data.rear_wall_attach_coord[0][0];

			if (this.data.bent_bow)
			{
				this.rearVisorHeight = 0;
			}
			else
			{
				this.rearVisorHeight = this.data.rear_wall_attach_coord[1][1] - this.data.rafter_spec[this.sideCoordsIndices[1][0]][1];
			}

			this.roofHeight = this.data.rafter_spec[this.apexCoordsIndices[0]][1] - this.data.front_wall_attach_coord[1][1];
		}
		else
		{
			this.width = this.GetExtents(this.data.rafterspec).x;
			this.wallWidth = this.GetExtents(this.data.rafterspec).x;

			this.frontBackHeightDifference = 0;
			this.frontVisorWidth = 0;
		}

		this.frontRoofWidth = this.data.rafter_spec[this.apexCoordsIndices[0]][0] - this.data.rafter_spec[this.sideCoordsIndices[0][1]][0];
		this.frontRoofHeight = this.data.rafter_spec[this.apexCoordsIndices[0]][1] - this.data.rafter_spec[this.sideCoordsIndices[0][1]][1];

		if (this.frontRoofWidth == 0)
			this.frontTanAngleRatio = 0;
		else
			this.frontTanAngleRatio = this.frontRoofHeight / this.frontRoofWidth;

		this.rearRoofWidth = this.data.rafter_spec[this.sideCoordsIndices[1][1]][0] - this.data.rafter_spec[this.apexCoordsIndices[0]][0];
		this.rearRoofHeight = this.data.rafter_spec[this.apexCoordsIndices[0]][1] - this.data.rafter_spec[this.sideCoordsIndices[1][1]][1];

		this.rearTanAngleRatio = this.rearRoofHeight / this.rearRoofWidth;

		this.rafterVerticalWidth = this.data.rafter_spec[this.apexCoordsIndices[0]][1] - this.data.rafter_spec[this.apexCoordsIndices[1]][1];

		this.apexHeight = this.data.rafter_spec[this.apexCoordsIndices[0]][1] - this.data.rafter_spec[this.sideCoordsIndices[0][1]][1];

		this.frontRoofLength = Math.sqrt(this.frontRoofWidth * this.frontRoofWidth + this.apexHeight * this.apexHeight);
		this.rearRoofLength = Math.sqrt(this.rearRoofWidth * this.rearRoofWidth + this.apexHeight * this.apexHeight);

		//Calculate the width of the rafters on the left and right sides
		if (this.sideCoordsIndices[0][1] != -1)
			this.rafterVerticalWidthL = this.data.rafter_spec[this.sideCoordsIndices[0][1]][1] - this.data.rafter_spec[this.sideCoordsIndices[0][0]][1];
		else
			this.rafterVerticalWidthL = 0;

		if (this.sideCoordsIndices[1][1] != -1)
			this.rafterVerticalWidthR = this.data.rafter_spec[this.sideCoordsIndices[1][1]][1] - this.data.rafter_spec[this.sideCoordsIndices[1][0]][1];
		else
			this.rafterVerticalWidthR = 0;
	};

	this.GetExtents = function ()
	{
		let minX = 9999;
		let maxX = -9999;

		let minY = 9999;
		let maxY = -9999;

		let x, y, z;

		for (let i = 0; i < this.data.rafter_spec.length; i++)
		{
			x = this.data.rafter_spec[i][0];
			y = this.data.rafter_spec[i][1];

			if (x > maxX)
			{
				maxX = x;
			}

			if (x < minX)
			{
				minX = x;
			}

			if (y > maxY)
			{
				maxY = y;
			}

			if (y < minY)
			{
				minY = y;
			}
		}

		return {
			x: maxX - minX,
			y: maxY - minY
		};
	};


	this.GetCoordIndice = function (x, y)
	{
		for (let i = 0; i < this.data.rafter_spec.length; i++)
		{

			if (MathUtilities.Equals(this.data.rafter_spec[i][0], x, 0.01) && MathUtilities.Equals(this.data.rafter_spec[i][1], y, 0.01))
			{
				return i;
			}
		}

		return null;
	};

	this.GetApexCoordIndices = function ()
	{
		let maxY1 = -1;
		let max1Index = -1;

		let maxY2 = -1;
		let max2Index = -1;

		for (let i = 0; i < this.data.rafter_spec.length; i++)
		{
			if (this.data.rafter_spec[i][1] > maxY1)
			{
				maxY1 = this.data.rafter_spec[i][1];
				max1Index = i;
			}
		}

		for (let i = 0; i < this.data.rafter_spec.length; i++)
		{
			if (this.data.rafter_spec[i][1] > maxY2 && this.data.rafter_spec[i][1] != maxY1)
			{
				maxY2 = this.data.rafter_spec[i][1];
				max2Index = i;
			}
		}

		return [max1Index, max2Index];
	};

	this.GetSideCoordIndices = function ()
	{
		let minX = 9999;
		let minXIndex1 = -1;
		let minXIndex2 = -1;

		let maxX = -1;
		let maxXIndex1 = -1;
		let maxXIndex2 = -1;

		for (let i = 0; i < this.data.rafter_spec.length; i++)
		{
			if (this.data.rafter_spec[i][0] < minX)
			{
				minX = this.data.rafter_spec[i][0];
				minXIndex1 = i;
			}


			if (this.data.rafter_spec[i][0] >= maxX)
			{
				maxX = this.data.rafter_spec[i][0];
				maxXIndex1 = i;
			}
		}

		if (this.data.rafter_spec[minXIndex1][0] == this.data.rafter_spec[minXIndex1 + 1][0])
			minXIndex2 = minXIndex1 + 1;
		else
			minXIndex2 = minXIndex1;

		if (this.data.rafter_spec[maxXIndex1][0] == this.data.rafter_spec[maxXIndex1 - 1][0])
			maxXIndex2 = maxXIndex1 - 1;
		else
			maxXIndex2 = maxXIndex1;

		return [
			[minXIndex1, minXIndex2],
			[maxXIndex1, maxXIndex2]
		];
	};

	this.HeightAtXCoord = function (x)
	{
		let i;

		let segmentFound = false;

		for (i = this.sideCoordsIndices[0][1]; i < this.sideCoordsIndices[1][1]; i++)
		{
			if (x >= this.data.rafter_spec[i][0] && x < this.data.rafter_spec[i + 1][0])
			{
				segmentFound = true;
				break;
			}
		}

		if (x == this.data.rafter_spec[this.sideCoordsIndices[1][1]][0])
		{
			return this.data.rafter_spec[this.sideCoordsIndices[1][1]][1];
		}

		if (segmentFound)
		{
			if (x == this.data.rafter_spec[i][0])
				return this.data.rafter_spec[i][1];
			else
			{
				let angleRatio = (this.data.rafter_spec[i + 1][1] - this.data.rafter_spec[i][1]) / (this.data.rafter_spec[i + 1][0] - this.data.rafter_spec[i][0]);

				let height = ((x - this.data.rafter_spec[i][0]) * angleRatio) + this.data.rafter_spec[i][1];

				return height;
			}
		}

		return null;
	};

	this.GenerateRafter = function (rafter_sh, extrudeSettings, x, y, z, rafterMaterial, subtractGeom, buildingMeshes, addGeom)
	{
		let geom = new THREE.ExtrudeGeometry(rafter_sh, extrudeSettings);
		TexturesDataUtilities.AssignUVsToGeometryXY(geom);

		if (subtractGeom != null && subtractGeom.length > 0)
		{
			for (let i = 0; i < subtractGeom.length; i++)
			{
				let subtractGeomBSP = new ThreeBSP(subtractGeom[i]);

				let csgRafter = new ThreeBSP(geom);

				let subtract_bsp = csgRafter.subtract(subtractGeomBSP);

				let result = subtract_bsp.toMesh(new THREE.MeshNormalMaterial());

				geom = result.geometry;
			}
		}

		geom.matrixAutoUpdate = false;
		geom.applyMatrix4(new THREE.Matrix4().makeTranslation(x, y, z));

		let rafterMesh = new THREE.Mesh(geom, rafterMaterial);

		rafterMesh.receiveShadow = true;
		rafterMesh.castShadow = true;

		// this is the rafters only, not the framing.
		buildingMeshes.push(rafterMesh);
	};
}

Rafter.WALL_WOOD_RAFTER_WIDTH = BOARD_2x4_WIDTH;
