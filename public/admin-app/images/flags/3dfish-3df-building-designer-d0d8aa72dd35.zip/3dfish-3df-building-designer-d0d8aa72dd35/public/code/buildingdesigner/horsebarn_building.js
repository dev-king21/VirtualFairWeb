/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

/**
 * Horsebarn Building Designer
 */
function HorseBarnBuilding(buildingID, roofRafter, sizeData, stallCount)
{
	Building.call(this, buildingID, roofRafter, sizeData, stallCount);

	this.stalls = null;

	this.floorHeight = 0;

	this.initialized = false;

	this.Initialize = async function()
	{
		await this.SetSizeData(this.sizeData);

		this.base = new HorseBarnBase();

		this.groundBeneathBuilding = new GroundBeneathBuilding(this.width, this.length);
		this.groundBeneathBuilding.SetGroundTextureFileName("ground");

		this.walls = new Walls();

		await this.walls.Initialize();

		this.roof = new Roof();

		await this.roof.SetRoofingData(GuiDataUtilities.roofingButtonData[0]);

		// This is scheduled to be changed to this.framing, as it is actually framing and not rafters
		this.rafters = new WoodRafters(this.roofRafter.data.thickness, buildingDesigner.building.roofRafter.data.width);

		this.stalls = new Stalls();

		if (buildingDesigner.defaultSettings)
		{
			await this.walls.SetSidingData(GuiDataUtilities.GetSidingColorButtonData(buildingDesigner.defaultSettings.siding_id));

			await this.roof.SetRoofingData(GuiDataUtilities.GetRoofingButtonData(buildingDesigner.defaultSettings.roofing_id));

			this.SetTrimColor(buildingDesigner.defaultSettings.trim_color_id);

			this.stalls.SetDefaultElements(buildingDesigner.defaultSettings.default_elements);
		}
		else
		{
			await this.walls.SetSidingData(GuiDataUtilities.sidingColorButtonData[0]);

			await this.roof.SetRoofingData(GuiDataUtilities.roofingButtonData[0]);
		}

		this.stalls.Initialize();

		await this.InitializeSidingRoofingTrimAndDefaultElements();

		ElementsMenu.ElementsListPricingUpdate();

		this.initialized = true;
	};

	this.AddDefaultElements = function ()
	{
		this.stalls.AddDefaultElements();
	};

	this.SetRegenerateBuildingMeshes = function (regenerate)
	{
		this.regenerateBuildingMeshes = regenerate;

		if (this.base)
		{
			this.base.SetRegenerate(regenerate);
		}

		if (this.groundBeneathBuilding)
		{
			this.groundBeneathBuilding.SetRegenerate(regenerate);
		}

		// This is scheduled to be changed to this.framing, as it is actually framing and not rafters
		if (this.rafters)
		{
			this.rafters.SetRegenerate(regenerate);
		}

		if (this.walls)
		{
			this.walls.SetRegenerate(regenerate);
		}

		if (this.roof)
		{
			this.roof.SetRegenerate(regenerate);
		}

		if (this.stalls)
		{
			this.stalls.SetRegenerate(regenerate);
		}
	};

	this.Regenerate = function ()
	{
		if (this.initialized && this.regenerateBuildingMeshes)
		{
			this.RemoveThreeJSSceneMeshes();

			this.buildingMeshes = [];

			this.groundBeneathBuilding.Generate(this.buildingMeshes);

			this.groundBeneathBuilding.mesh.geometry.matrixAutoUpdate = false;
			this.groundBeneathBuilding.mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, -HorseBarnBase.BASEWIDTH, 0));

			this.base.Generate(this.buildingMeshes);

			this.stalls.Generate(this.buildingMeshes);

			// This is scheduled to be changed to this.framing, as it is actually framing and not rafters
			this.rafters.Generate(this.buildingMeshes);
			this.walls.Generate(this.buildingMeshes);

			if (showRoof)
				this.roof.Generate(this.buildingMeshes);

			////MeshUtilities.TranslateMeshes(this.buildingMeshes, 0, HorseBarnBase.BASEWIDTH, 0)

			this.SetRegenerateRulers(true);
			this.GenerateRulers();

			this.regenerateBuildingMeshes = false;
		}

		this.tempBuildingMeshes = [];

		if (this.regenerateElementMeshes)
		{
			MeshUtilities.CloneMeshes(this.buildingMeshes, this.tempBuildingMeshes);

			this.elementsMesh = Elements.Generate(this.tempBuildingMeshes);

			if (this.elementsMesh)
			{
				this.elementsMesh.matrixAutoUpdate = false;
				this.elementsMesh.applyMatrix4(new THREE.Matrix4().makeTranslation(0, HorseBarnBase.BASEWIDTH, 0));
			}


			this.regenerateElementMeshes = false;
		}
		else
		{
			MeshUtilities.CloneMeshes(this.buildingMeshes, this.tempBuildingMeshes);
		}

		MeshUtilities.TranslateMeshes(this.tempBuildingMeshes, 0, HorseBarnBase.BASEWIDTH, 0);
	};

	this.ElementsListPricingUpdate1 = function ()
	{
		if (SubscriberDataUtilities.subscriberData)
		{
			let elementsList = document.getElementById("elementsList");
			if (elementsList)
			{
				tdf.display_prices = SubscriberDataUtilities.subscriberData.display_prices;
				tdf.display_totals = SubscriberDataUtilities.subscriberData.display_prices;
				if (admin_settings.pricing_override)
				{
					switch (admin_settings.price_setting)
					{
					case "PRICING":
					{
						tdf.display_prices = true;
						tdf.display_totals = true;
						break;
					}
					case "TOTALONLY":
					{
						tdf.display_prices = false;
						tdf.display_totals = true;
						break;
					}
					case "NOPRICING":
					{
						tdf.display_prices = false;
						tdf.display_totals = false;
						break;
					}
					}
				}

				//while (elementsList.options.length > 0)
				//	elementsList.options.remove(0);
				$(elementsList).empty();

				let sizeData = buildingDesigner.building.sizeData;

				let fTotalPrice = sizeData.price;

				let leanToStr = "";
				if (buildingDesigner.building.roofRafter.data.lean_to)
				{
					let leanToPrice = GuiDataUtilities.GetLeanToPrice(buildingDesigner.building.roofRafter.data.rafter_id, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].length);

					let leanToPriceString = "";

					if (tdf.display_prices)
						leanToPriceString = " ($" + leanToPrice + ")";

					leanToStr = " and " + buildingDesigner.building.roofRafter.data.lean_to_width_display + " Lean-to" + leanToPriceString;

					fTotalPrice += leanToPrice;
				}

				//let optNew;
				if (tdf.display_prices)
				{
					tdf.liTemplate = "<li ${attr}>${item} ${price}</li>";
				}
				else
				{
					tdf.liTemplate = "<li ${attr}>${item}</li>";
				}

				let addItem = function (item, price, element,index)
				{
					if (!price)
					{
						price = "";
					}
					if (element)
					{
						let selected = "";
						if (element.selected)
						{
							selected = " element_selected";
						}
						$("#elementsList").append(fillTemplate(tdf.liTemplate,{item: item, price: price, attr: `class="selectable_element element_${index}${selected}"`}));
						$(`#elementsList li.element_${index}`).prop("element",element).click(function()
						{
							ElementsMenu.OnClickElementsList(this);
						});
						$(element).prop("index",index);
					}
					else
					{
						$("#elementsList").append(fillTemplate(tdf.liTemplate,{item: item, price: price, attr: ""}));
					}
				};

				//if (tdf.display_prices)
				//	optNew = new Option(sizeData.building_display_name + ": " + sizeData.width_display + "x" + sizeData.length_display + leanToStr + " $" + fTotalPrice);
				//else
				//	optNew = new Option(sizeData.building_display_name + ": " + sizeData.width_display + "x" + sizeData.length_display + leanToStr);

				//elementsList.options.add(optNew);
				addItem(sizeData.building_display_name + ": " + sizeData.width_display + "x" + sizeData.length_display + leanToStr + " ","$" + fTotalPrice);

				//if (tdf.display_prices)
				//	optNew = new Option(buildingDesigner.building.roof.data.display_name + ": $" + buildingDesigner.building.roof.price);
				//else
				//	optNew = new Option(buildingDesigner.building.roof.data.display_name);

				$("#building_style").text(sizeData.building_display_name);
				$("#width_display").text(sizeData.width_display);
				$("#length_display").text(sizeData.length_display);


				//elementsList.options.add(optNew);
				addItem(buildingDesigner.building.roof.data.display_name + ": ","$" + buildingDesigner.building.roof.price);

				fTotalPrice += buildingDesigner.building.roof.price;

				let trimColorString = "";

				if (buildingDesigner.building.roof.cornerTrimColorID)
				{
					let colorData = ColorsDataUtilities.FindColor(buildingDesigner.building.roof.cornerTrimColorID);
					if (colorData)
					{
						trimColorString = " with " + colorData.color_name + " trim";
					}
				}

				//if (tdf.display_prices == 1)
				//	optNew = new Option(buildingDesigner.building.walls.walls[0].sidingColorData.display_name + " Siding" + trimColorString + ": $" + buildingDesigner.building.walls.walls[0].price);
				//else
				//	optNew = new Option(buildingDesigner.building.walls.walls[0].sidingColorData.display_name + " Siding" + trimColorString);

				//elementsList.options.add(optNew);
				addItem(buildingDesigner.building.walls.walls[0].sidingColorData.display_name + " Siding" + trimColorString + ": ","$" + buildingDesigner.building.walls.walls[0].price);

				fTotalPrice += buildingDesigner.building.walls.walls[0].price;

				let lastIndex;
				for (let i = 0; i < Elements.list.length; i++)
				{
					//if (tdf.display_prices == 1)
					//	optNew = new Option(ELEM_STRING[Elements.list[i].buttonData.type] + ": " + Elements.list[i].buttonData.element_name + " " + Elements.list[i].buttonData.width_display + "x" + Elements.list[i].buttonData.height_display + " $" + Elements.list[i].price);
					//else
					//	optNew = new Option(ELEM_STRING[Elements.list[i].buttonData.type] + ": " + Elements.list[i].buttonData.element_name + " " + Elements.list[i].buttonData.width_display + "x" + Elements.list[i].buttonData.height_display);

					//optNew.element = Elements.list[i];

					//elementsList.options.add(optNew);
					addItem(ELEM_STRING[Elements.list[i].buttonData.type] + ": " + Elements.list[i].buttonData.element_name + " " + Elements.list[i].buttonData.width_display + "x" + Elements.list[i].buttonData.height_display + " ","$" + Elements.list[i].price,Elements.list[i],i);

					fTotalPrice += Elements.list[i].price;
					lastIndex = i;
				}


				if (buildingDesigner.building.stalls)
				{
					for (let i = 0; i < buildingDesigner.building.stalls.stallsList.length; i++)
					{
						if (buildingDesigner.building.stalls.stallsList[i].GetPartitionStyle() != Partition.NO_PARTITION)
						{
							//if (tdf.display_prices == 1)
							//	optNew = new Option("Partition: " + Partition.PARTITION_STRING[buildingDesigner.building.stalls.stallsList[i].GetPartitionStyle()] + " $" + buildingDesigner.building.stalls.stallsList[i].partition.price);
							//else
							//	optNew = new Option("Partition: " + Partition.PARTITION_STRING[buildingDesigner.building.stalls.stallsList[i].GetPartitionStyle()]);

							//optNew.element = buildingDesigner.building.stalls.stallsList[i].partition;

							//elementsList.options.add(optNew);
							addItem("Partition: " + Partition.PARTITION_STRING[buildingDesigner.building.stalls.stallsList[i].GetPartitionStyle()] + " ","$" + buildingDesigner.building.stalls.stallsList[i].partition.price,buildingDesigner.building.stalls.stallsList[i].partition,i+lastIndex+1);

							fTotalPrice += buildingDesigner.building.stalls.stallsList[i].partition.price;
						}
					}
				}

				if (tdf.display_prices === 1)
				{
					//optNew = new Option("Sub Total Price as Shown: $" + fTotalPrice);
					//elementsList.options.add(optNew);
					addItem("Sub Total Price as Shown: ","$" + fTotalPrice);

					$("#price_display").text("Price as Displayed: " + currency(fTotalPrice));

					let tax = SubscriberDataUtilities.subscriberData.tax_percent;

					let taxMultiplier = tax / 100;
					let fPrice = MathUtilities.Round(fTotalPrice * taxMultiplier, 2);

					//optNew = new Option("Tax (" + tax + "%): $" + fPrice);
					//elementsList.options.add(optNew);
					addItem("Tax (" + tax + "%): ","$" + fPrice);

					fTotalPrice += fPrice;
					//optNew = new Option("Total Price with tax: $" + fTotalPrice);
					//elementsList.options.add(optNew);
					addItem("Total Price with tax: ","$" + fTotalPrice);
				}
				else
				{
					//optNew = new Option("For More Information and to Order - Contact " + SubscriberDataUtilities.subscriberData.name);
					//elementsList.options.add(optNew);
					addItem("For More Information and to Order - Contact " + SubscriberDataUtilities.subscriberData.name);
				}

				let printPagePricing = document.getElementById("printPagePricing");

				if (printPagePricing)
					printPagePricing.innerHTML = elementsList.innerHTML;
			}
		}
	};

	this.ClearSelections = function ()
	{
		this.SetSelected(false);

		this.walls.SetSelected(false);

		this.stalls.ClearSelections();

		Elements.ClearSelections();
	};
}
