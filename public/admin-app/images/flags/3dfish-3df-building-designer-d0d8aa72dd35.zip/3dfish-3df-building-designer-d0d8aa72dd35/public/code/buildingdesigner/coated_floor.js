/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function CoatedFloor(buttonData)
{
	////Element.call(this, "Coated Floor", "CoatedFloor", "", buildingDesigner.building.width, CoatedFloor.COATED_FLOORTHICK, "", "", buildingDesigner.building.length, price);

	Element.call(this, buttonData);

	this.coatedFloorColor = 0xFFFFFF;

	this.width = buildingDesigner.building.width;
	this.length = buildingDesigner.building.length;

	buttonData.type = ELEM_COATED_FLOOR;

	this.mesh = null;

	this.draggable = false;

	this.regenerate = true;

	this.GetDesignXMLString = function()
	{
		let strElemType = ELEM_STRING[this.type];

		let strXml = "<ELEMENT ";


		strXml += " buttonData=\"" + AuxUtilities.JSONStringifyAndEncode(this.buttonData) + "\"";

		if (this.wall)
			strXml += " wall=\"" + WALL_STRING[this.wall.eWall] + "\"";

		strXml += " configurationMode=\"" + this.configurationMode + "\"";

		strXml += " x=\"" + this.pos.x + "\"";
		strXml += " y=\"" + this.pos.y + "\"";
		strXml += " z=\"" + this.pos.z + "\"";


		strXml += " defaultElementData=\"" + AuxUtilities.JSONStringifyAndEncode(this.defaultElementData) + "\"";



		strXml += "></ELEMENT>";

		return strXml;
	};

	/**
	 * @method CoatedFloor.GetDesignObject
	 * @returns {Object} elementData
	 */
	this.GetDesignObject = function()
	{
		let elementData = {
			buttonData: this.buttonData,
			x: this.pos.x,
			y: this.pos.y,
			z: this.pos.z,
			defaultElementData: this.defaultElementData
		};
		return elementData;
	};

	this.SetSelected = function(selected)
	{
		this.selected = selected;
	};

	this.GetTextures = function()
	{
		if (buttonData.texture_name != "")
		{
			this.coatedFloorTexture = TexturesDataUtilities.GetRealWorldSizedTexture(buttonData.texture_name, this.width, this.length);
		}
		else
			this.coatedFloorTexture = null;
	};

	this.Generate = function(buildingMeshes)
	{
		if (this.regenerate)
		{
			this.width = buildingDesigner.building.width;
			this.length = buildingDesigner.building.length;
			this.GetTextures();

			////if (TexturesDataUtilities.TextureLoaded(this.coatedFloorTexture))
			{
				let coatedFloorMatter = new THREE.MeshStandardMaterial ({color: this.coatedFloorColor, map: TexturesDataUtilities.TextureLoaded(this.coatedFloorTexture), roughness: 1.0, metalness: METALNESS});

				let coatedFloorGeom = new THREE.BoxGeometry(this.width - Wall.WALLTHICKNESS*2, CoatedFloor.COATED_FLOORTHICK, this.length - Wall.WALLTHICKNESS*2);

				coatedFloorGeom.matrixAutoUpdate = false;
				coatedFloorGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(0.0, Floor.FLOOR_THICKNESS + CoatedFloor.COATED_FLOORTHICK/2, 0.));

				this.mesh = new THREE.Mesh(coatedFloorGeom, coatedFloorMatter);

				this.mesh.type = ELEM_COATED_FLOOR;

				MeshUtilities.SetElement(this.mesh, this);

				this.mesh.castShadow = true;

				if (this.selected)
				{
					this.GenerateSelectedBoxes(this.mesh, new THREE.Matrix4().makeTranslation(0,SEL_BOX_SIZE,0), new THREE.Vector3(0.9, 0.9, 0.9));
				}

				this.regenerate = false;
			}
		}

		return this.mesh;
	};

	this.Destroy = function()
	{
		buildingDesigner.building.floor.SetFloorColor(0xC29369);
		buildingDesigner.building.floor.SetFloorTextureFileName("");

		buildingDesigner.building.SetRegenerateBuildingMeshes(true);
	};
}

CoatedFloor.AddCoatedFloor = function (buttonData)
{
	let coatedFloor = new CoatedFloor(buttonData);

	Elements.AddElement(coatedFloor);

	buildingDesigner.building.SetRegenerateElementMeshes(true);

	return coatedFloor;
};

CoatedFloor.COATED_FLOORTHICK = 0.01;
