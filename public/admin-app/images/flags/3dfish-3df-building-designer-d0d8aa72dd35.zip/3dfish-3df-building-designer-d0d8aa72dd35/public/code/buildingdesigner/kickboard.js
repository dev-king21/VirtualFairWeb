/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/
function KickBoard(length, x, y, z, angle)
{
	this.length = length;
	this.height = KickBoard.HEIGHT;

	this.kickBoardColor = 0xFFFFFF;

	if (KickBoard.DATA == null)
	{
		// KickBoard.DATA = KickBoard.GetKickBoardData();
		KickBoard.GetKickBoardData();
	}

	this.kickBoardTextureName = "";
	if (KickBoard.DATA)
		this.kickBoardTextureName = KickBoard.DATA.texture;

	this.kickBoardTexture = null;
	this.kickBoardMater = null;

	this.mesh = new THREE.Mesh();

	this.matrix = null;

	this.type = ELEM_KICKBOARD;

	this.selected = false;

	this.regenerate = true;

	this.GetTextures = function ()
	{
		if (this.kickBoardTextureName && this.kickBoardTextureName != "")
		{
			////this.kickBoardTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.kickBoardTextureName, this.length, KickBoard.HEIGHT);
			this.kickBoardTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.kickBoardTextureName, 1, 1);
		}
	};

	this.SetSelected = function (selected)
	{
		this.selected = selected;
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.GenerateKickBoardMesh = function (length, height, thickness, mater)
	{
		let points = [];

		/*points.push( { x: 0, y: 0 } );
        points.push( { x: length, y: 0 } );
        points.push( { x: length, y: height } );
        points.push( { x: 0, y: height } );
        */

		points.push({
			x: 0,
			y: 0
		});
		points.push({
			x: 0,
			y: height
		});
		points.push({
			x: length,
			y: height
		});
		points.push({
			x: length,
			y: 0
		});



		let extrudeSettings = {
			depth: thickness,
			steps: 1,
			material: 1,
			extrudeMaterial: 0,
			bevelEnabled: false,
		};

		let mesh = MeshUtilities.CreateMeshFromCrossSectionPoints(points, points, mater, extrudeSettings, 0, 0, 0);

		//mesh.geometry.matrixAutoUpdate = false;
		//mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation( -length/2, 0, 0));

		/*mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(MathUtilities.PI/2));
        mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(MathUtilities.PI/2));
		*/

		return mesh;
	};

	this.Generate = function (kickBoardMeshes)
	{
		if (this.regenerate)
		{
			this.GetTextures();

			////if (TexturesDataUtilities.TextureLoaded(this.kickBoardTexture))
			{
				let meshElement = null;

				if (this.mesh.element)
					meshElement = this.mesh.element;

				this.mesh = new THREE.Mesh();

				let kickBoardMater = Material.CreateMaterial(this.kickBoardColor, TexturesDataUtilities.TextureLoaded(this.kickBoardTexture));

				/*let geometry = new THREE.BoxGeometry(this.length, KickBoard.HEIGHT, KickBoard.THICKNESS);
                this.mesh = new THREE.Mesh( geometry, kickBoardMater );
                */



				////this.mesh = GeometryUtilities.CreateOrientatedBox(this.length, KickBoard.HEIGHT, KickBoard.THICKNESS, this.kickBoardColor, this.kickBoardTexture, null, null, new THREE.Vector3(x, y + KickBoard.HEIGHT/2), 0, angle, 0);

				////this.mesh = GeometryUtilities.CreateOrientatedBox(this.length, KickBoard.HEIGHT, KickBoard.THICKNESS, this.kickBoardColor, this.kickBoardTexture, null, null, new THREE.Vector3(x, y + KickBoard.HEIGHT/2), 0, 0, 0);

				this.mesh = this.GenerateKickBoardMesh(KickBoard.HEIGHT, KickBoard.THICKNESS, this.length, kickBoardMater, null, null, new THREE.Vector3(x, y + KickBoard.HEIGHT / 2), 0, 0, 0);

				this.mesh.geometry.matrixAutoUpdate = false;
				this.mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, -KickBoard.THICKNESS / 2, 0));

				this.mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationZ(MathUtilities.PI / 2));
				this.mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(MathUtilities.PI / 2));

				this.mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-this.length / 2, 0, 0));

				////threeScene.add(this.mesh);


				this.mesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(angle));

				this.mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(x, y, z));


				this.mesh.type = ELEM_KICKBOARD;
				this.mesh.element = meshElement ? meshElement : this;

				kickBoardMeshes.push(this.mesh);

				this.regenerate = false;
			}
		}
	};


}

KickBoard.GetKickBoardData = async function ()
{
	let err;
	[err, KickBoard.DATA] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getKickboardData", subscriber_id: SubscriberDataUtilities.subscriber}));
	if (err)
	{
		throw err;
	}
	KickBoard.DATA = KickBoard.DATA[0];
	//return kickBoardData[0];
};

KickBoard.HEIGHT = MathUtilities.Feet(46.5);
KickBoard.THICKNESS = INCHTOFEET * 2;

KickBoard.DATA = null;
