/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Stall(zStart, width, length, height, stallIndex, createPartition, createKickBoards)
{
	this.zStart = zStart;
	this.width = width;
	this.length = length;
	this.height = height;

	this.stallIndex = stallIndex;

	if (!createPartition)
		this.partition = null;
	else
	{
		this.partition = new Partition(this.zStart + this.width, this.length, height, this.stallIndex);

		this.partition.SetPartitionData(GuiDataUtilities.partitionsButtonData[0]);
	}


	if (!createKickBoards)
		this.kickBoards = null;
	else
	{
		this.kickBoards = new StallKickBoards(this);
	}



	this.type = ELEM_STALL;

	this.regenerate = true;

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;

		if (this.partition)
			this.partition.SetRegenerate(this.regenerate);

		if (this.kickBoards)
			this.kickBoards.SetRegenerate(this.regenerate);
	};

	this.Generate = function (stallMeshes)
	{
		if (this.regenerate)
		{
			if (this.partition)
				this.partition.Generate(stallMeshes);

			if (this.kickBoards)
				this.kickBoards.Generate(stallMeshes);

			this.regenerate = false;
		}
	};

	this.SetPartitionStyle = function (newStyle)
	{
		if (this.partition)
			this.partition.SetStyle(newStyle);
	};

	this.GetPartitionStyle = function ()
	{
		if (this.partition)
			return this.partition.style;
		else
			return Partition.NO_PARTITION;
	};
}
