/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2 */
/*eslint-disable no-console, no-unused-vars, no-undef*/

/**
 * @constructor
 */
function Walls()
{
	this.price = 0;

	this.wallTexture = null;

	this.wallColor = 0xFFFFFF;

	this.regenerate = true;

	this.walls = [];

	this.sidingColorData = null;

	this.setCornerTrimColor = false;

	this.Initialize = async function ()
	{
		this.wallLength = buildingDesigner.building.length - Wall.WALLTHICKNESS * 2;

		if (buildingDesigner.building.porch)
		{
			this.frontWallLength = buildingDesigner.building.porch.frontWallLength;
			this.backWallLength = buildingDesigner.building.porch.backWallLength;
		}
		else
		{
			this.frontWallLength = this.wallLength;
			this.backWallLength = this.wallLength;
		}

		if (buildingDesigner.building.porch)
		{
			if (buildingDesigner.building.porch.rightSide)
			{
				this.leftFrontWallCoord = -this.wallLength / 2;
				this.rightFrontWallCoord = -this.wallLength / 2 + this.frontWallLength;
			}
			else
			{
				this.leftFrontWallCoord = this.wallLength / 2 - this.frontWallLength;
				this.rightFrontWallCoord = this.wallLength / 2;
			}
		}
		else
		{
			this.leftFrontWallCoord = -this.wallLength / 2;
			this.rightFrontWallCoord = this.wallLength / 2;
		}

		if (buildingDesigner.building.porch)
		{
			if (buildingDesigner.building.porch.rightSide)
			{
				this.leftBackWallCoord = -this.wallLength / 2;
				this.rightBackWallCoord = -this.wallLength / 2 + this.backWallLength;
			}
			else
			{
				this.leftBackWallCoord = this.wallLength / 2 - this.backWallLength;
				this.rightBackWallCoord = this.wallLength / 2;
			}
		}
		else
		{
			this.leftBackWallCoord = -this.wallLength / 2;
			this.rightBackWallCoord = this.wallLength / 2;
		}

		this.leftRightWallCoord = -buildingDesigner.building.roofRafter.wallWidth / 2;

		this.rightWallLength = buildingDesigner.building.roofRafter.wallWidth;

		if (buildingDesigner.building.porch && !buildingDesigner.building.porch.fullLength)
		{
			if (buildingDesigner.building.porch.width > 0)
				this.rightWallLength -= (Math.abs(buildingDesigner.building.porch.length) + Wall.WALLTHICKNESS);

			if (buildingDesigner.building.porch.length < 0)
				this.leftRightWallCoord -= buildingDesigner.building.porch.length;
		}


		this.rightRightWallCoord = this.leftRightWallCoord + this.rightWallLength;



		this.leftLeftWallCoord = -buildingDesigner.building.roofRafter.wallWidth / 2;

		this.leftWallLength = buildingDesigner.building.roofRafter.wallWidth;

		if (buildingDesigner.building.porch && !buildingDesigner.building.porch.fullLength)
		{
			if (buildingDesigner.building.porch.width < 0)
				this.leftWallLength -= (Math.abs(buildingDesigner.building.porch.length) + Wall.WALLTHICKNESS);

			if (buildingDesigner.building.porch.length < 0)
				this.leftLeftWallCoord -= buildingDesigner.building.porch.length;
		}

		this.rightLeftWallCoord = this.leftLeftWallCoord + this.leftWallLength;


		for (let i = 0; i < 4; i++)
		{
			if (!this.walls[i])
				this.walls[i] = new Wall(this, i);

			this.walls[i].Initialize();
		}

		if (this.sidingColorData) {
			let sidingPrice = await Walls.GetSidingPrice(buildingDesigner.building.sizeData.product_id, this.sidingColorData.category_id);
			this.SetPrice(sidingPrice);
		}
	};

	/**
	 * @method Walls.GetDesignXMLString
	 * @returns {string} XML string with 4 walls
	 */
	this.GetDesignXMLString = function ()
	{
		let strXml = "<WALLS_LIST>";

		for (let i = 0; i < this.walls.length; i++)
		{
			strXml += this.walls[i].GetDesignXMLString();
		}

		strXml += "</WALLS_LIST>";

		return strXml;
	};

	/**
	 * @method Walls.GetDesignObject
	 * @returns {Object} walls Object with array of wall objects
	 */
	this.GetDesignObject = function ()
	{
		let walls = {};
		walls.WALL = [];
		for (let i=0; i < this.walls.length; i++)
		{
			walls.WALL[i] = this.walls[i].GetDesignObject();
		}
		return walls;
	};

	this.LoadWallsFromXML = async function (xmlDesignDoc)
	{
		let nodesWallList = xmlDesignDoc.getElementsByTagName("WALLS_LIST");

		if (nodesWallList.length > 0)
		{
			let nodeWalls = nodesWallList[0].getElementsByTagName("WALL");

			for (let i = 0; i < nodeWalls.length; i++)
			{
				await this.LoadWallFromXML(nodeWalls[i], i);
			}
		}
	};

	/**
	 * @method WALLS.LoadWallsFromObject
	 * @async
	 * @param {Object} building savedDesignObject.TDFDESIGN.BUILDING
	 */
	this.LoadWallsFromObject = async function (building)
	{
		if (building.WALLS_LIST && building.WALLS_LIST.WALL)
		{
			for (let i=0;i < building.WALLS_LIST.WALL.length; i++)
			{
				await this.LoadWallFromObject(building.WALLS_LIST.WALL[i], i);
			}
			if (BuildingDesigner.buildingType !== BUILDING_CARPORT)
			{
				this.sidingCategoryData = building.WALLS_LIST.WALL[0].sidingCategoryData;
				this.sidingColorData = building.WALLS_LIST.WALL[0].sidingColorData;
			}
		}
	};

	/**
	 * @method Walls.LoadWallFromXML
	 * @async
	 * @param {string} nodeWallData
	 * @param {number} wallIndex
	 */
	this.LoadWallFromXML = async function (nodeWallData, wallIndex)
	{
		let wallID = nodeWallData.getAttribute("wallID");

		let sidingCategoryData = nodeWallData.getAttribute("sidingCategoryData");

		let sidingColorData = nodeWallData.getAttribute("sidingColorData");

		if (sidingCategoryData == "undefined" || sidingCategoryData == "null")
		{
			sidingCategoryData = null;
		}

		if (sidingCategoryData)
		{
			sidingCategoryData = AuxUtilities.JSONDecodeAndParse(sidingCategoryData);
		}

		if (sidingColorData == "undefined" || sidingColorData == "null")
		{
			sidingColorData = null;
		}

		if (sidingColorData)
		{
			sidingColorData = AuxUtilities.JSONDecodeAndParse(sidingColorData);
		}

		let wallData = GuiDataUtilities.GetWallButtonData(wallID);

		if (wallData)
		{
			this.walls[wallIndex].SetWallData(wallData);
		}

		if (sidingColorData && sidingCategoryData)
		{
			await this.walls[wallIndex].SetWallSidingData(sidingColorData, sidingCategoryData);
		}
		else
		{
			let sidingID = nodeWallData.getAttribute("sidingID");
			await this.walls[wallIndex].SetWallSidingData(GuiDataUtilities.GetSidingColorButtonData(sidingID));
		}

		if (BuildingDesigner.buildingType == BUILDING_CARPORT)
		{
			await this.walls[wallIndex].GetAndSetDimensionWallPrice();
		}
	};

	/**
	 * @method Walls.LoadWallFromObject
	 * @async
	 * @param {Object} wall
	 * @param {number} wallIndex
	 */
	this.LoadWallFromObject = async function (wall, wallIndex)
	{
		let wallData = GuiDataUtilities.GetWallButtonData(wall.wallID);
		if (wallData)
		{
			this.walls[wallIndex].SetWallData(wallData);
		}
		if (wall.sidingCategoryData && wall.sidingCategoryData)
		{
			await this.walls[wallIndex].SetWallSidingData(wall.sidingColorData, wall.sidingCategoryData);
		}
		else
		{
			// non-archive version
			if (wall.sidingID)
			{
				await this.walls[wallIndex].SetWallSidingData(GuiDataUtilities.GetSidingColorButtonData(wall.sidingID));
			}
		}
		if (BuildingDesigner.buildingType == BUILDING_CARPORT)
		{
			await this.walls[wallIndex].GetAndSetDimensionWallPrice();
		}
	};

	this.SetSelected = function (selected)
	{
		for (let i = 0; i < this.walls.length; i++)
		{
			this.walls[i].SetSelected(selected);
		}
	};

	this.SetWallTextureName = function (textureName)
	{
		this.textureName = textureName;

		for (let i = 0; i < this.walls.length; i++)
		{
			this.walls[i].SetWallTextureName(this.textureName);
		}
	};

	this.SetMouseOverTransparency = function (opacity)
	{};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;

		for (let i = 0; i < this.walls.length; i++)
		{
			this.walls[i].SetRegenerate(this.regenerate);
		}
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			for (let i = 0; i < this.walls.length; i++)
			{
				this.walls[i].Generate(buildingMeshes);
			}

			this.regenerate = false;
		}
	};

	this.GetWall = function (eWall)
	{
		return this.walls[eWall];
	};

	this.GetSelectedWall = function ()
	{
		for (let i = 0; i < this.walls.length; i++)
		{
			if (this.walls[i].selected)
				return this.walls[i];
		}
	};

	this.SetPrice = function (price)
	{
		this.price = price;
	};

	this.SetCategoryID = function (categoryID)
	{
		this.categoryID = categoryID;

		for (let i = 0; i < this.walls.length; i++)
		{
			this.walls[i].SetCategoryID(this.categoryID);
		}
	};

	this.SetColorID = function (colorID)
	{
		this.colorID = colorID;

		for (let i = 0; i < this.walls.length; i++)
		{
			this.walls[i].SetColorID(this.colorID);
		}

		if (this.sidingCategoryData)
		{
			if ((buildingDesigner.building.eveTrimUsesSidingColorSetting && this.sidingCategoryData.set_eve_trim_color) || buildingDesigner.building.sidingSetsEveTrimColor)
			{
				buildingDesigner.building.SetEveTrimColor(this.colorID);
			}

			if ((buildingDesigner.building.cornerTrimUsesSidingColorSetting && this.sidingCategoryData.set_corner_trim_color) || buildingDesigner.building.sidingSetsCornerTrimColor)
			{
				buildingDesigner.building.SetCornerTrimColor(this.colorID);
			}
		}
	};

	this.SetSidingData = async function (data)
	{
		if (data)
		{
			this.sidingColorData = data;
			this.sidingCategoryData = GuiDataUtilities.GetSidingCategoryButtonData(data.category_id);
			let sidingCategoryIndex = GuiDataUtilities.sidingCategoryButtonData.findIndex(element => element.category_id == data.category_id);

			if (this.sidingCategoryData)
			{
				ElementsMenu.OnClickShowSidingColorsForCategory(sidingCategoryIndex);
				if ((buildingDesigner.building.eveTrimUsesSidingColorSetting && this.sidingCategoryData.set_eve_trim_color) || buildingDesigner.building.sidingSetsEveTrimColor)
				{
					buildingDesigner.building.SetEveTrimColor(data.color_id);
				}
				else if (!buildingDesigner.building.roof.eveTrimColorID)
				{
					buildingDesigner.building.SetEveTrimColor(GuiDataUtilities.trimColorButtonData[0].color_id);
				}

				if ((buildingDesigner.building.cornerTrimUsesSidingColorSetting && this.sidingCategoryData.set_corner_trim_color) || buildingDesigner.building.sidingSetsCornerTrimColor)
				{
					buildingDesigner.building.SetCornerTrimColor(data.color_id);
				}
				else if (!buildingDesigner.building.roof.cornerTrimColorID)
				{
					buildingDesigner.building.SetCornerTrimColor(GuiDataUtilities.trimColorButtonData[0].color_id);
				}
			}

			for (let i = 0; i < this.walls.length; i++)
			{
				await this.walls[i].SetWallSidingData(data, this.sidingCategoryData, false);

				if (BuildingDesigner.buildingType === BUILDING_CARPORT)
					await this.walls[i].GetAndSetDimensionWallPrice();
			}
			// Set the total price for all four walls
			if (BuildingDesigner.buildingType !== BUILDING_CARPORT)
			{
				let sidingPrice = await Walls.GetSidingPrice(buildingDesigner.building.sizeData.product_id, this.sidingCategoryData.category_id);
				this.SetPrice(sidingPrice);
			}
		}
	};

	this.GetSidingData = function ()
	{
		return this.sidingColorData;
	};
}

Walls.GetSidingPrice = async function (buildingProductID, categoryID)
{
	if (cache.lastsidingprice !== undefined)
	{
		if ((cache.lastsidingprice.buildingProductID === buildingProductID) && (cache.lastsidingprice.categoryID === categoryID))
			return cache.lastsidingprice.price;
	}
	let [err, priceData] = await to(NodeJSUtilities.UQuery("dataRequest", {request: "getSidingPrice", subscriber_id: SubscriberDataUtilities.subscriber, series_code: SubscriberDataUtilities.series_code, buildingProductID: buildingProductID, categoryID: categoryID}));

	if ((priceData.length > 0) && (priceData[0].price > 0))
	{
		cache.lastsidingprice = {
			"buildingProductID": buildingProductID,
			"categoryID": categoryID,
			"price": priceData[0].price
		};

		return priceData[0].price;
	}
	else
	{
		if (DEBUG)
		{
			console.warn("Siding price not defined for: " + buildingProductID);
		}

		cache.lastsidingprice = {
			"buildingProductID": buildingProductID,
			"categoryID": categoryID,
			"price": 0
		};

		return 0;
	}
};

Walls.GetSidingDimensionPrice = async function (wallID, width, categoryID, walltype)
{
	if (width == null)
		return 0;

	let height;

	switch (wallID)
	{
	case ("WALL_GABLE"):
		height = 0;
		break;

	case ("WALL_PARTIAL_1_5"):
		height = 1.5;
		break;

	case ("WALL_PARTIAL_3"):
		height = 3;
		break;

	case ("WALL_PARTIAL_6"):
		height = 6;
		break;

	case ("WALL_CLOSED"):
		height = buildingDesigner.building.height;
		break;
	}

	if (height > buildingDesigner.building.height)
	{
		height = buildingDesigner.building.height;
	}

	let [err, priceData] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getSidingDimensionPrice", subscriber_id: SubscriberDataUtilities.subscriber, series_code: SubscriberDataUtilities.series_code, width: width, height: height, categoryID: categoryID, walltype: walltype}));

	if (priceData.length && priceData[0].price)
		return priceData[0].price;
	else
		return 0;
};

Walls.GetMainSidingCategoryCode = function (categoryID)
{
	switch (true)
	{
	case (categoryID.indexOf("SP") > -1):
		return "SP";

	case (categoryID.indexOf("SL") > -1):
		return "SL";

	case (categoryID.indexOf("TV") > -1):
		return "TV";

	case (categoryID.indexOf("DV") > -1):
		return "DV";

	case (categoryID.indexOf("BB") > -1):
		return "BB";

	case (categoryID.indexOf("DT") > -1):
		return "DT";

	case (categoryID.indexOf("MS") > -1):
		return "MS";
	}

	return "";
};
