/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function PorchTrim(porch)
{
	this.parent = porch;

	this.regenerate = true;

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	/**
	 * @method PorchTrim.AddTrim
	 * @param trimAngle for setting the join angle of trim planks
	 * @param rotateAngle for orientation of the trim
	 * @param x, y, z for placement of the trim
	 * @param convex sets whether the trim is convex or concave
	 * @returns {THREE.Mesh} 3D mesh object for the trim
	 */
	this.AddTrim = function(trimAngle, rotateAngle, x, y, z, convex = true)
	{
		let trimGeometry = Trim.CreateTrimFromAngle(trimAngle, convex);

		let mesh = new THREE.Mesh(trimGeometry, this.cornerTrimMater);

		mesh.matrixAutoUpdate = false;
		mesh.applyMatrix4(new THREE.Matrix4().makeRotationY(rotateAngle));

		mesh.applyMatrix4(new THREE.Matrix4().makeTranslation(x, y, z));

		mesh.receiveShadow = true;

		return mesh;
	}

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate && this.parent.length==0)
		{
			this.cornerTrimMater = new THREE.MeshStandardMaterial(
				{
					color: buildingDesigner.building.roof.cornerTrimColor,
					map: null,
					roughness: 1.0,
					metalness: METALNESS
				});


			let angle = MathUtilities.GetAngleBetween3Vectors(this.parent.shape[0], this.parent.shape[1], this.parent.shape[2]);

			let trimMesh;

			let matrix;

			if (this.parent.rightSide)
			{
				trimMesh = this.AddTrim(angle, -(MathUtilities.PI2-angle/2), buildingDesigner.building.roofRafter.wallWidth/2 + this.parent.shape[1].x, buildingDesigner.building.floorHeight, buildingDesigner.building.length/2 - this.parent.innerWallRadius - this.parent.width + this.parent.shape[1].z);
			}
			else
			{
				trimMesh = this.AddTrim(angle, -(MathUtilities.PI2-angle/2), buildingDesigner.building.roofRafter.wallWidth/2 + this.parent.shape[1].x, buildingDesigner.building.floorHeight, buildingDesigner.building.length/2 - this.parent.innerWallRadius - this.parent.width - this.parent.shape[1].z);

				matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.height + buildingDesigner.building.floorHeight, 0), new THREE.Matrix4().makeRotationX(Math.PI));

				trimMesh.matrixAutoUpdate = false;
				trimMesh.applyMatrix4(matrix);
			}

			buildingMeshes.push(trimMesh);

			angle = MathUtilities.GetAngleBetween3Vectors(this.parent.shape[1], this.parent.shape[2], this.parent.shape[3]);

			if (this.parent.rightSide)
				trimMesh = this.AddTrim(angle, -angle/2, buildingDesigner.building.roofRafter.wallWidth/2 + this.parent.shape[2].x, buildingDesigner.building.floorHeight, buildingDesigner.building.length/2 - this.parent.innerWallRadius - this.parent.width + this.parent.shape[2].z);
			else
			{
				trimMesh = this.AddTrim(angle, -angle/2, buildingDesigner.building.roofRafter.wallWidth/2 + this.parent.shape[2].x, buildingDesigner.building.floorHeight, buildingDesigner.building.length/2 - this.parent.innerWallRadius - this.parent.width - this.parent.shape[2].z);

				matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.height + buildingDesigner.building.floorHeight, 0), new THREE.Matrix4().makeRotationX(Math.PI));

				trimMesh.matrixAutoUpdate = false;
				trimMesh.applyMatrix4(matrix);
			}

			buildingMeshes.push(trimMesh);


			angle = Math.PI/2;

			if (this.parent.rightSide)
				trimMesh = this.AddTrim(Math.PI/2, angle/2 + angle, buildingDesigner.building.roofRafter.wallWidth/2 + this.parent.shape[2].x, buildingDesigner.building.floorHeight, buildingDesigner.building.length/2 - this.parent.innerWallRadius - this.parent.width + this.parent.shape[3].z, false);
			else
			{
				trimMesh = this.AddTrim(Math.PI/2, angle/2 + angle, buildingDesigner.building.roofRafter.wallWidth/2 + this.parent.shape[2].x, buildingDesigner.building.floorHeight, buildingDesigner.building.length/2 - this.parent.innerWallRadius - this.parent.width - this.parent.shape[3].z, false);

				matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.height + buildingDesigner.building.floorHeight, 0), new THREE.Matrix4().makeRotationX(Math.PI));

				trimMesh.matrixAutoUpdate = false;
				trimMesh.applyMatrix4(matrix);
			}

			buildingMeshes.push(trimMesh);
		}
		else if (!this.parent.fullLength && buildingDesigner.building.sizeData.size_options.corner_porch_trim && buildingDesigner.building.sizeData.size_options.corner_porch_trim.toLowerCase()=="true")
		{

			this.cornerTrimMater = new THREE.MeshStandardMaterial(
				{
					color: buildingDesigner.building.roof.cornerTrimColor,
					map: null,
					roughness: 1.0,
					metalness: METALNESS
				});


			let angle = Math.PI/2;

			let trimMesh;

			let matrix;

			if (this.parent.rightSide)
			{
				if (buildingDesigner.building.porch.length<0)
					trimMesh = this.AddTrim(angle, angle/2 + angle, -buildingDesigner.building.roofRafter.wallWidth/2 - Trim.TRIM_THICKNESS + this.parent.shape[1].x, buildingDesigner.building.floorHeight, buildingDesigner.building.length/2 - this.parent.width + Trim.TRIM_THICKNESS);
				else
					trimMesh = this.AddTrim(angle, -angle/2 - angle, buildingDesigner.building.roofRafter.wallWidth/2 + this.parent.shape[1].x + Trim.TRIM_THICKNESS, buildingDesigner.building.floorHeight, buildingDesigner.building.length/2 - this.parent.width + Trim.TRIM_THICKNESS);
			}
			else
			{
				if (buildingDesigner.building.porch.length<0)
					trimMesh = this.AddTrim(angle, angle/2, -buildingDesigner.building.roofRafter.wallWidth/2 - Trim.TRIM_THICKNESS + this.parent.shape[1].x, buildingDesigner.building.floorHeight, -buildingDesigner.building.length/2 - this.parent.width - Trim.TRIM_THICKNESS);
				else
					trimMesh = this.AddTrim(angle, -angle/2, buildingDesigner.building.roofRafter.wallWidth/2 + this.parent.shape[1].x + Trim.TRIM_THICKNESS, buildingDesigner.building.floorHeight, -buildingDesigner.building.length/2 - this.parent.width - Trim.TRIM_THICKNESS);
			}

			buildingMeshes.push(trimMesh);
		}
	};
}
