// element.js
/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/

/**
 * @class
 * @param {Object} buttonData
 */
function Element(buttonData)
{
	this.buttonData = buttonData;

	this.pos = new THREE.Vector3(9999, 9999, 9999);

	this.mousePosOnElement = new THREE.Vector3(0, 0, 0);

	this.color = 0xFFFFFF;
	this.texture = null;

	this.trimColor = null;

	this.colorFromBarn = false;

	this.wall = null;

	this.cutoutMode = 1;

	this.component3DObjects = new Component3DObjects(this);

	this.configurationMode = OBJECT_CONFIGURATION1;

	this.draggable = true;
	this.dragging = false;

	this.isAttached = false;

	this.collision = false;

	this.selected = false;

	this.regenerate = true;

	this.horizRuler = new Ruler(this, Ruler.HORIZ_RULER);
	this.vertRuler = new Ruler(this, Ruler.VERT_RULER);

	this.horizRuler.visible = {get visible() {return tdf.elementHorizRulerVisible}};
	this.vertRuler.visible = {get visible() {return tdf.elementVertRulerVisible}};

	this.framingColor = 0xFFFFFF;
	this.framingTextureFilename = "Southern_yellowpine_horizontal";
	this.framingTexture = null;

	this.defaultElementData = null;

	this.loadedObjectFromDesign = false;

	this.Initialize = function ()
	{};

	this.GetDesignXMLString = function ()
	{
		let strXml = "";

		if (!this.dormer)
		{
			let strElemType = ELEM_STRING[this.type];

			strXml = "<ELEMENT ";
			strXml += " buttonData=\"" + AuxUtilities.JSONStringifyAndEncode(this.buttonData) + "\"";

			if (this.wall)
				strXml += " wall=\"" + WALL_STRING[this.wall.eWall] + "\"";

			strXml += " configurationMode=\"" + this.configurationMode + "\"";

			strXml += " x=\"" + this.pos.x + "\"";
			strXml += " y=\"" + this.pos.y + "\"";
			strXml += " z=\"" + this.pos.z + "\"";

			strXml += " trimColor=\"" + this.trimColor + "\"";

			strXml += " defaultElementData=\"" + AuxUtilities.JSONStringifyAndEncode(this.defaultElementData) + "\"";

			strXml += "></ELEMENT>";
		}
		return strXml;
	};

	/**
	 * @method Element.getDesignObject
	 * @returns {Object}
	 */
	this.GetDesignObject = function()
	{
		let element = {};
		if (!this.dormer)
		{
			element.buttonData = this.buttonData;
			if (this.wall)
			{
				element.wall = this.wall.eWall;
				element.facetIndex = this.facetIndex;
			}
			element.configurationMode = this.configurationMode;
			element.x = this.pos.x;
			element.y = this.pos.y;
			element.z = this.pos.z;
			element.trimColor = this.trimColor;
			element.defaultElementData = this.defaultElementData;
		}
		return element;
	};

	this.SetName = function (name)
	{
		buttonData.element_name = name;
	}

	this.SetPrice = function (price)
	{
		buttonData.price = price;
	};

	this.GetPrice = function (price)
	{
		return buttonData.price;
	};

	this.SetColor = function (color)
	{
		this.color = color;
		this.colorFromBarn = false;
	};

	this.SetColorID = function (colorID)
	{
		this.colorID = colorID;
	};

	this.AddObjects = function ()
	{
		let filename;
		let geometry;

		if (buildingDesigner.xmlDesignDoc && Elements.loadedObjectData.length > 0)
		{
			this.loadedObjectFromDesign = true;

			for (let i = 0; i < Elements.loadedObjectData.length; i++)
			{
				if (Elements.loadedObjectData[i].object3D_ID == this.buttonData.object3D_ID)
				{
					filename = DIR_RESOURCES + DIR_OBJECTS + Elements.loadedObjectData[i].objectType + "/" + Elements.loadedObjectData[i].objectFile;

					let fileData = designString = TextDataUtilities.ReplaceAll(Elements.loadedObjectData[i].fileData, TextDataUtilities.NEWLINE_CODE, "\n");
					geometry = GeometryUtilities.objLoader.parse(fileData);


					if (geometry.type == "Group")
					{
						geometry = geometry.children[0].geometry;
					}

					if (geometry.type == "BufferGeometry")
					{
						let bufferedGeometry;
						bufferedGeometry = new THREE.Geometry().fromBufferGeometry(geometry);
						geometry.dispose();
						geometry = bufferedGeometry;
					}

					if (RESOURCE_HOST && (filename.indexOf(RESOURCE_HOST) === -1))
					{
						filename = RESOURCE_HOST + filename + "_Archived";
					}
					else
					{
						filename = filename + "_Archived";
					}

					Elements.loadedObjectData[i].fileDataFilename = filename;

					GeometryUtilities.fileData[filename] = Elements.loadedObjectData[i].fileData;

					GeometryUtilities.geometry[filename] = geometry;

					this.AddObject(filename, Elements.loadedObjectData[i]);
				}
			}
		}
		else if (buildingDesigner.savedDesignObject && buildingDesigner.savedDesignObject.TDFDESIGN && Elements.loadedObjectData.length > 0)
		{
			this.loadedObjectFromDesign = true;

			for (let i = 0; i < Elements.loadedObjectData.length; i++)
			{
				if (Elements.loadedObjectData[i].object3D_ID == this.buttonData.object3D_ID)
				{
					filename = DIR_RESOURCES + DIR_OBJECTS + Elements.loadedObjectData[i].objectType + "/" + Elements.loadedObjectData[i].objectFile;

					let fileData = designString = TextDataUtilities.ReplaceAll(Elements.loadedObjectData[i].fileData, TextDataUtilities.NEWLINE_CODE, "\n");
					geometry = GeometryUtilities.objLoader.parse(fileData);


					if (geometry.type == "Group")
					{
						geometry = geometry.children[0].geometry;
					}

					if (geometry.type == "BufferGeometry")
					{
						let bufferedGeometry = new THREE.Geometry().fromBufferGeometry(geometry);
						geometry.dispose();
						geometry = bufferedGeometry;
					}

					if (RESOURCE_HOST && (filename.indexOf(RESOURCE_HOST) === -1))
					{
						filename = RESOURCE_HOST + filename + "_Archived";
					}
					else
					{
						filename = filename + "_Archived";
					}

					Elements.loadedObjectData[i].fileDataFilename = filename;

					GeometryUtilities.fileData[filename] = Elements.loadedObjectData[i].fileData;

					GeometryUtilities.geometry[filename] = geometry;

					this.AddObject(filename, Elements.loadedObjectData[i]);
				}
			}
		}
		else
		{
			// let geometry;

			for (let i = 0; i < ObjectDataUtilities.objectData.length; i++)
			{
				if (ObjectDataUtilities.objectData[i].object3D_ID == this.buttonData.object3D_ID)
				{
					filename = DIR_RESOURCES + DIR_OBJECTS + ObjectDataUtilities.objectData[i].objectType + "/" + ObjectDataUtilities.objectData[i].objectFile;

					ObjectDataUtilities.objectData[i].fileDataFilename = filename;

					this.AddObject(filename, ObjectDataUtilities.objectData[i]);
				}
			}
		}

		this.component3DObjects.CalculateGeometryScale(this.buttonData.width, this.buttonData.height, this.buttonData.height);
		this.component3DObjects.CalculateGeometryCenter();

		this.SetMousePosOnElementVector(this.component3DObjects.geometryCenter);
	};

	this.AddObject = function (geometry, objectData)
	{
		this.component3DObjects.AddObject(geometry, objectData);
	};

	/**
	 * @method Element.GetObjectsData
	 * @returns {Object} Object encoded for XML Storage
	 */
	this.GetObjectsData = function ()
	{
		let objectsDataArray = this.component3DObjects.GetObjectsData();

		return objectsDataArray;
	};

	/**
	 * @method Element.GetObjectsDataObject
	 * @returns {Object} Object for Object storage
	 */
	this.GetObjectsDataObject = function()
	{
		let objectsDataArray = this.component3DObjects.GetObjectsDataObject();

		return objectsDataArray;
	};

	this.UpdateModifiedElements3DObjects = function ()
	{
		this.component3DObjects.UpdateModified3DObjects();
	};

	this.SetPos = function (x, y, z)
	{
		this.pos.x = x;
		this.pos.y = y;
		this.pos.z = z;

		this.UpdateMatrix();
	};

	this.SetMousePosOnElement = function (x, y, z)
	{
		this.mousePosOnElement.x = x;
		this.mousePosOnElement.y = y;
		this.mousePosOnElement.z = z;
	};

	this.SetMousePosOnElementVector = function (vector)
	{
		this.mousePosOnElement.x = vector.x;
		this.mousePosOnElement.y = vector.y;
		this.mousePosOnElement.z = vector.z;
	};

	this.GetMatrix = function ()
	{
		return this.component3DObjects.mesh.matrix;
	};

	this.ClearSelections = function ()
	{
		this.selected = false;

		this.horizRuler.Destroy();
		this.vertRuler.Destroy();

		this.component3DObjects.ClearSelections();
	};

	this.SetSelected = function (selected)
	{
		this.selected = selected;

		if (!this.selected)
		{
			this.horizRuler.Destroy();
			this.vertRuler.Destroy();
		}
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;

		if (this.horizRuler) {
			this.horizRuler.SetRegenerate(regenerate);
		}
		if (this.vertRuler) {
			this.vertRuler.SetRegenerate(regenerate);
		}
		if (buildingDesigner.building)
		{
			buildingDesigner.building.SetRegenerateElementMeshes(regenerate);
		}
	};

	this.GenerateRulers = function ()
	{
		if (!(features.indexOf("NORULERS") > -1))
		{
			let length, height;

			switch (this.wall.eWall)
			{
			case (WALL_FRONT):
				length = (this.pos.x - this.buttonData.width / 2) + buildingDesigner.building.length / 2;
				height = (this.pos.y - this.buttonData.height / 2);

				this.horizRuler.yRot = 0;
				this.vertRuler.yRot = 0;
				break;

			case (WALL_RIGHT):
				length = (this.pos.x - this.buttonData.width / 2) + buildingDesigner.building.roofRafter.wallWidth / 2;
				height = (this.pos.y - this.buttonData.height / 2);

				this.horizRuler.yRot = 0;
				this.vertRuler.yRot = 0;
				break;

			case (WALL_LEFT):
				length = buildingDesigner.building.roofRafter.wallWidth / 2 - (this.pos.x + this.buttonData.width / 2);
				height = (this.pos.y - this.buttonData.height / 2);

				this.horizRuler.yRot = Math.PI;
				this.vertRuler.yRot = Math.PI;
				break;

			case (WALL_BACK):
				length = buildingDesigner.building.length / 2 - (this.pos.x + this.buttonData.width / 2);
				height = (this.pos.y - this.buttonData.height / 2);

				this.horizRuler.yRot = Math.PI;
				this.vertRuler.yRot = Math.PI;
				break;

			}

			if (this.wall.eWall == WALL_RIGHT || this.wall.eWall == WALL_LEFT)
				length += Wall.WALLTHICKNESS;

			this.horizRuler.SetLength(length);
			this.vertRuler.SetLength(height);

			let pos;

			switch (this.wall.eWall)
			{
			case (WALL_FRONT):
				pos = new THREE.Vector3(-buildingDesigner.building.length / 2 + this.horizRuler.length / 2, Ruler.RULER_WIDTH / 2, Ruler.RULER_IN_FRONT_WALL_DISTANCE);
				break;

			case (WALL_RIGHT):
				pos = new THREE.Vector3(-buildingDesigner.building.roofRafter.wallWidth / 2 + this.horizRuler.length / 2, Ruler.RULER_WIDTH / 2, Ruler.RULER_IN_FRONT_WALL_DISTANCE);
				break;

			case (WALL_LEFT):
				pos = new THREE.Vector3(buildingDesigner.building.roofRafter.wallWidth / 2 - this.horizRuler.length / 2, Ruler.RULER_WIDTH / 2, -Ruler.RULER_IN_FRONT_WALL_DISTANCE);
				break;

			case (WALL_BACK):
				pos = new THREE.Vector3(buildingDesigner.building.length / 2 - this.horizRuler.length / 2, Ruler.RULER_WIDTH / 2, -Ruler.RULER_IN_FRONT_WALL_DISTANCE);
				break;
			}

			if (this.wall.eWall == WALL_RIGHT)
				pos.x -= Wall.WALLTHICKNESS;
			else
			if (this.wall.eWall == WALL_LEFT)
				pos.x += Wall.WALLTHICKNESS;

			this.horizRuler.SetPos(pos);
			this.vertRuler.SetPos(pos);

			this.horizRuler.Generate();
			this.vertRuler.Generate();
		}
	};

	this.Generate = function (buildingMeshes, subtractGeometryFromWall = false)
	{
		if (this.regenerate)
		{
			if (this.component3DObjects.boundingBox == null)
			{
				this.component3DObjects.CalculateGeometryScale(this.buttonData.width, this.buttonData.height, this.buttonData.height);
				this.component3DObjects.CalculateGeometryCenter();
			}

			this.component3DObjects.Generate(buildingMeshes, this.component3DObjects.scale);
			this.component3DObjects.SetCameraAndConfigurationModeVisibility(buildingDesigner.camera.modeCamera, this.configurationMode);

			this.length = size.z * this.component3DObjects.scale.z;

			if (this.wall)
			{
				this.UpdateMatrix();

				if (!this.dragging && subtractGeometryFromWall)
					this.SubtractCutoutGeometryFromBuildingMeshes(buildingMeshes, 1 / this.component3DObjects.scale.z);

				if (this.selected)
					this.GenerateSelectedBoxes(this.component3DObjects.mesh, this.component3DObjects.mesh.matrix);
			}

			this.regenerate = false;
		}

		if (this.selected)
		{
			this.GenerateRulers();
		}

		return this.component3DObjects.mesh;
	};

	this.UpdateMatrix = function ()
	{
		if (this.component3DObjects.mesh && this.wall.matrix)
		{
			let matrix = new THREE.Matrix4();

			if (this.dormer && this.dormer.component3DObjects.mesh)
			{
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, this.dormer.component3DObjects.mesh.matrix);
			}
			else
			if (this.facetIndex != undefined && this.facetIndex != null && this.wall.wallFacets.length > this.facetIndex)
			{
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, this.wall.wallFacets[this.facetIndex].matrix);
				////matrix = new THREE.Matrix4().multiplyMatrices(matrix, this.wall.matrix);
			}
			else
			{
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, this.wall.matrix);
			}

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z));

			if (this.wall.eWall == WALL_LEFT || this.wall.eWall == WALL_BACK)
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationY(-MathUtilities.PI));

			if (this.dragging)
			{
				if (buildingDesigner.camera.modeCamera == Camera.CAM_MODE_EXTERIOR)
					matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, 0, DRAGGING_Z_SHIFT));
				else
					matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, 0, -DRAGGING_Z_SHIFT));
			}

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(-this.component3DObjects.geometryCenter.x, -this.component3DObjects.geometryCenter.y, 0));

			matrix.scale(new THREE.Vector3(this.component3DObjects.scale.x, this.component3DObjects.scale.y, this.component3DObjects.scale.y));

			this.component3DObjects.mesh.matrix = new THREE.Matrix4();
			this.component3DObjects.mesh.matrixAutoUpdate = false;
			this.component3DObjects.mesh.applyMatrix4(matrix);

			if (this.selected)
			{
				this.horizRuler.SetRegenerate(true);
				this.vertRuler.SetRegenerate(true);

				this.GenerateRulers();

				if (this.dragging)
				{
					Elements.ProcessCollisions(this);
				}
			}
		}
	};

	this.GetClosestWallRafterCoords = function ()
	{
		if (this.wall.eWall == WALL_FRONT || this.wall.eWall == WALL_BACK)
		{
			if (!buildingDesigner.building.rafters.frontBackRafterCoords.length)
			{
				return {
					leftCoord: this.pos.x - this.buttonData.width / 2,
					rightCoord: this.pos.x + this.buttonData.width / 2
				};
			}
		}
		else
		if (this.wall.eWall == WALL_LEFT || this.wall.eWall == WALL_RIGHT)
		{
			if (!buildingDesigner.building.rafters.leftRightRafterCoords.length)
			{
				return {
					leftCoord: this.pos.x - this.buttonData.width / 2,
					rightCoord: this.pos.x + this.buttonData.width / 2
				};
			}
		}

		let rafterCoord1 = -1,
			rafterCoord2 = -1;

		let rafterIndex1 = -1,
			rafterIndex2 = -1;

		let startCoord = this.pos.x - this.buttonData.width / 2;
		let endCoord = this.pos.x + this.buttonData.width / 2;

		if (this.boundingBox)
		{
			let boxWidth = (this.boundingBox.max.x - this.boundingBox.min.x) + buildingDesigner.building.roofRafter.data.thickness * 4;

			boxWidth *= this.component3DObjects.scale.x;

			startCoord = this.pos.x - boxWidth / 2;
			endCoord = this.pos.x + boxWidth / 2;
		}


		if (this.wall.eWall == WALL_FRONT || this.wall.eWall == WALL_BACK)
		{
			for (let i = 1; i < buildingDesigner.building.rafters.frontBackRafterCoords.length; i++)
			{
				if (buildingDesigner.building.rafters.frontBackRafterCoords[i] + buildingDesigner.building.rafters.thickness / 2 > startCoord && rafterCoord1 == -1)
				{
					rafterCoord1 = buildingDesigner.building.rafters.frontBackRafterCoords[i - 1];
					rafterIndex1 = i - 1;
				}

				if (buildingDesigner.building.rafters.frontBackRafterCoords[i] - buildingDesigner.building.rafters.thickness / 2 > endCoord && rafterCoord2 == -1)
				{
					rafterCoord2 = buildingDesigner.building.rafters.frontBackRafterCoords[i];
					rafterIndex2 = i;

					break;
				}
			}

			if (rafterCoord1 == buildingDesigner.building.rafters.frontBackRafterCoords[0])
				rafterCoord1 += buildingDesigner.building.roofRafter.data.width;
			else
				rafterCoord1 += buildingDesigner.building.rafters.thickness / 2;

			if (rafterCoord2 == -1)
			{
				rafterCoord2 = buildingDesigner.building.rafters.frontBackRafterCoords[buildingDesigner.building.rafters.frontBackRafterCoords.length - 1];
			}

			if (rafterCoord2 == buildingDesigner.building.rafters.frontBackRafterCoords[buildingDesigner.building.rafters.frontBackRafterCoords.length - 1])
				rafterCoord2 -= buildingDesigner.building.roofRafter.data.width;
			else
				rafterCoord2 -= buildingDesigner.building.rafters.thickness / 2;
		}


		if (this.wall.eWall == WALL_LEFT || this.wall.eWall == WALL_RIGHT)
		{
			for (let i = 1; i < buildingDesigner.building.rafters.leftRightRafterCoords.length; i++)
			{
				if (buildingDesigner.building.rafters.leftRightRafterCoords[i] + buildingDesigner.building.rafters.thickness / 2 > startCoord && rafterCoord1 == -1)
				{
					rafterCoord1 = buildingDesigner.building.rafters.leftRightRafterCoords[i - 1];
					rafterIndex1 = i - 1;
				}

				if (buildingDesigner.building.rafters.leftRightRafterCoords[i] - buildingDesigner.building.rafters.thickness / 2 > endCoord && rafterCoord2 == -1)
				{
					rafterCoord2 = buildingDesigner.building.rafters.leftRightRafterCoords[i];
					rafterIndex2 = i;

					break;
				}
			}

			if (rafterCoord1 == buildingDesigner.building.rafters.leftRightRafterCoords[0])
				rafterCoord1 += BOARD_2x4_WIDTH + buildingDesigner.building.rafters.thickness;
			else
				rafterCoord1 += buildingDesigner.building.rafters.thickness / 2;

			if (rafterCoord2 == -1)
			{
				rafterCoord2 = buildingDesigner.building.rafters.leftRightRafterCoords[buildingDesigner.building.rafters.leftRightRafterCoords.length - 1];
			}

			if (rafterCoord2 == buildingDesigner.building.rafters.leftRightRafterCoords[buildingDesigner.building.rafters.leftRightRafterCoords.length - 1])
				rafterCoord2 -= (BOARD_2x4_WIDTH + buildingDesigner.building.rafters.thickness);
			else
				rafterCoord2 -= buildingDesigner.building.rafters.thickness / 2;
		}

		return {
			leftCoord: rafterCoord1,
			rightCoord: rafterCoord2,
			leftCoordIndex: rafterIndex1,
			rightCoordIndex: rafterIndex2
		};
	};


	this.ComputeCutoutGeometryForRafters = function ()
	{
		let rafterCoords = this.GetClosestWallRafterCoords();

		let rafterCutoutBoxPoints = [{
			x: rafterCoords.leftCoord,
			y: this.pos.y - this.buttonData.height / 2 - BOARD_2x4_THICKNESS
		},
		{
			x: rafterCoords.rightCoord,
			y: this.pos.y - this.buttonData.height / 2 - BOARD_2x4_THICKNESS
		},
		{
			x: rafterCoords.rightCoord,
			y: this.pos.y + this.buttonData.height / 2 + BOARD_2x4_THICKNESS
		},
		{
			x: rafterCoords.leftCoord,
			y: this.pos.y + this.buttonData.height / 2 + BOARD_2x4_THICKNESS
		}
		];

		let geom = new THREE.ExtrudeGeometry(new THREE.Shape(rafterCutoutBoxPoints), {
			depth: 1,
			bevelEnabled: false
		});

		if (this.wall.eWall == WALL_FRONT || this.wall.eWall == WALL_RIGHT)
		{
			geom.matrixAutoUpdate = false;
			geom.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -1));
		}
		else
		{
			geom.matrixAutoUpdate = false;
			geom.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, Wall.INNER_WALLTHICKNESS));
		}

		return geom;
	};

	this.SubtractCutoutGeometryFromMeshes = function (meshes, depth, pos, scale)
	{
		this.cutoutGeometry = this.component3DObjects.ComputeCutoutGeometry(buildingDesigner.camera.modeCamera == Camera.CAM_MODE_INTERIOR, this.buttonData.wall_cutout_mode, depth);

		if (this.cutoutGeometry)
		{
			let matrix = new THREE.Matrix4();

			if (pos != null && pos != undefined)
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(pos.x, pos.y, pos.z));

			if (scale != null && scale != undefined)
			{
				matrix.scale(new THREE.Vector3(scale.x, scale.y, scale.y));
			}

			this.cutoutGeometry.matrixAutoUpdate = false;
			this.cutoutGeometry.applyMatrix4(matrix);

			let subtractMaterial = new THREE.MeshStandardMaterial({
				color: 0xffffff,
				map: null,
				roughness: 1.0,
				metalness: METALNESS
			});

			let subtractMesh = new THREE.Mesh(this.cutoutGeometry, subtractMaterial);

			MeshUtilities.SubtractMeshFromMeshes(meshes, subtractMesh, this.wall.eWall);
		}

		return meshes;
	};

	this.SubtractCutoutGeometryFromBuildingMeshes = function (buildingMeshes, depth)
	{
		if (this.component3DObjects.mesh)
		{
			if (depth <= 0)
				depth = 0.1;

			this.cutoutGeometry = this.component3DObjects.ComputeCutoutGeometry(buildingDesigner.camera.modeCamera == Camera.CAM_MODE_INTERIOR, this.buttonData.wall_cutout_mode, depth, false);

			if (this.cutoutGeometry)
			{
				this.cutoutGeometry.computeBoundingBox();

				if (this.buttonData.double_door_from_single_door)
				{
					this.cutOutWidth = this.cutoutGeometry.boundingBox.max.x - this.cutoutGeometry.boundingBox.min.x;

					GeometryUtilities.ResizeBoundingBox(this.cutoutGeometry.boundingBox, this.cutOutWidth, 0, 0);

					this.cutoutGeometry = GeometryUtilities.CreateGeometryFromBoundingBox(this.cutoutGeometry.boundingBox);
				}

				//first for the walls
				if (this.cutoutGeometry)
				{
					this.cutoutGeometry.computeBoundingBox();

					this.boundingBox = this.cutoutGeometry.boundingBox.clone();

					this.cutOutWidth = this.cutoutGeometry.boundingBox.max.x - this.cutoutGeometry.boundingBox.min.x;

					this.cutOutWidth *= this.component3DObjects.scale.x;

					this.cutOutHeight = this.cutoutGeometry.boundingBox.max.y - this.cutoutGeometry.boundingBox.min.y;

					this.cutOutHeight *= this.component3DObjects.scale.y;


					this.cutOutLength = this.cutoutGeometry.boundingBox.max.z - this.cutoutGeometry.boundingBox.min.z;

					this.cutOutLength *= this.component3DObjects.scale.z;


					this.cutOutCenter = new THREE.Vector3((this.cutoutGeometry.boundingBox.min.x + this.cutoutGeometry.boundingBox.max.x) / 2, (this.cutoutGeometry.boundingBox.min.y + this.cutoutGeometry.boundingBox.max.y) / 2, (this.cutoutGeometry.boundingBox.min.z + this.cutoutGeometry.boundingBox.max.z) / 2);

					this.cutOutCenter.x *= this.component3DObjects.scale.x;
					this.cutOutCenter.y *= this.component3DObjects.scale.y;
					this.cutOutCenter.z *= this.component3DObjects.scale.z;

					this.raftersCutoutGeometry = null;

					if (this.component3DObjects.InteriorVisibility())
					{
						GeometryUtilities.ResizeBoundingBox(this.cutoutGeometry.boundingBox, buildingDesigner.building.roofRafter.data.width / this.component3DObjects.scale.x * 2, buildingDesigner.building.roofRafter.data.width / this.component3DObjects.scale.y * 2, 0);

						this.raftersCutoutGeometry = GeometryUtilities.CreateGeometryFromBoundingBox(this.cutoutGeometry.boundingBox);
					}


					if (buildingDesigner.building.base)
					{
						matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.floorHeight, 0), this.component3DObjects.mesh.matrix);
					}
					else
					{
						matrix = this.component3DObjects.mesh.matrix;
					}

					this.cutoutGeometry.matrixAutoUpdate = false;
					this.cutoutGeometry.applyMatrix4(matrix);

					MeshUtilities.SubtractMeshFromMeshes(buildingMeshes, this.cutoutGeometry, this.wall.eWall);

					GeometryUtilities.SetWallFaceIndexes(buildingMeshes);
				}

				//next for the rafters and kickboards
				if (this.raftersCutoutGeometry)
				{
					let matrix;

					if (buildingDesigner.building.base)
					{
						matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.floorHeight, 0), this.component3DObjects.mesh.matrix);
					}
					else
					{
						matrix = this.component3DObjects.mesh.matrix;
					}

					this.raftersCutoutGeometry.matrixAutoUpdate = false;
					this.raftersCutoutGeometry.applyMatrix4(matrix);

					MeshUtilities.SubtractMeshFromMeshes(buildingMeshes, this.raftersCutoutGeometry, -1, ELEM_KICKBOARD);
				}
			}



			if (this.buttonData.wall_cutout_mode == 1)
				this.trimCutoutGeometry = this.component3DObjects.ComputeCutoutGeometry(buildingDesigner.camera.modeCamera == Camera.CAM_MODE_INTERIOR, 1, BOARD_2x4_THICKNESS / this.component3DObjects.scale.z * 2, true);
			else
				this.trimCutoutGeometry = null;

			if (this.trimCutoutGeometry)
			{
				if (this.buttonData.double_door_from_single_door)
				{
					this.trimCutoutGeometry.computeBoundingBox();

					GeometryUtilities.ResizeBoundingBox(this.trimCutoutGeometry.boundingBox, (this.trimCutoutGeometry.boundingBox.max.x - this.trimCutoutGeometry.boundingBox.min.x) * this.trimCutoutGeometry.scale.x, 0, 0);

					this.trimCutoutGeometry = GeometryUtilities.CreateGeometryFromBoundingBox(this.trimCutoutGeometry.boundingBox);
				}


				if (buildingDesigner.building.base)
				{
					this.trimCutoutGeometry.matrixAutoUpdate = false;
					////this.trimCutoutGeometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.floorHeight / this.component3DObjects.scale.y, BOARD_2x4_THICKNESS / this.component3DObjects.scale.z * 0.5));
					this.trimCutoutGeometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.floorHeight / this.component3DObjects.scale.y, 0));
					this.trimCutoutGeometry.applyMatrix4(this.component3DObjects.mesh.matrix);
				}
				else
				{
					this.trimCutoutGeometry.matrixAutoUpdate = false;
					this.trimCutoutGeometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, BOARD_2x4_THICKNESS / this.component3DObjects.scale.z * 0.5));
					this.trimCutoutGeometry.applyMatrix4(this.component3DObjects.mesh.matrix);
				}

				MeshUtilities.SubtractMeshFromMeshes(buildingMeshes, this.trimCutoutGeometry, this.wall.eWall);
			}
		}
	};

	this.GetInteriorFramingTexture = function ()
	{
		if (!buildingDesigner.building.metalFraming)
			this.framingTexture = TexturesDataUtilities.SelectTexture("Southern_yellowpine_vertical", THREE.MirroredRepeatWrapping, THREE.MirroredRepeatWrapping);
		else
			this.framingTexture = TexturesDataUtilities.SelectTexture("MetalRafter", THREE.MirroredRepeatWrapping, THREE.MirroredRepeatWrapping);

		if (this.framingTexture)
			this.framingTexture.repeat.set(1, 1);
	};

	this.GenerateInteriorFraming = function ()
	{
		this.GetInteriorFramingTexture();

		////if (TexturesDataUtilities.TextureLoaded(this.framingTexture))
		{
			let rafterCoords = this.GetClosestWallRafterCoords();

			let rafterCoordsCenter = (rafterCoords.leftCoord + rafterCoords.rightCoord) / 2;

			let rafterXOffset = rafterCoordsCenter - this.pos.x;

			if (this.wall.eWall == WALL_LEFT || this.wall.eWall == WALL_BACK)
				rafterXOffset *= -1;

			let plankLength = rafterCoords.rightCoord - rafterCoords.leftCoord;

			let horizontalPlank1 = GeometryUtilities.CreateBoxMesh(plankLength, buildingDesigner.building.rafters.thickness, BOARD_2x4_WIDTH, this.framingColor, this.framingTexture);

			TexturesDataUtilities.AssignUVsToGeometryXY(horizontalPlank1.geometry);

			horizontalPlank1.type = ELEM_FRAMING;

			let matrix = new THREE.Matrix4();

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation((-plankLength / 2 + rafterXOffset) * 1 / this.component3DObjects.scale.x, this.buttonData.height / 2 * 1 / this.component3DObjects.scale.y, -(BOARD_2x4_WIDTH + Wall.WALLTHICKNESS) * 1 / this.component3DObjects.scale.z));

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.component3DObjects.geometryCenter.x * 1 / this.component3DObjects.scale.x, this.component3DObjects.geometryCenter.y * 1 / this.component3DObjects.scale.y, this.component3DObjects.geometryCenter.z * 1 / this.component3DObjects.scale.z));

			matrix.scale(new THREE.Vector3(1 / this.component3DObjects.scale.x, 1 / this.component3DObjects.scale.y, 1 / this.component3DObjects.scale.y));

			horizontalPlank1.geometry.matrixAutoUpdate = false;
			horizontalPlank1.geometry.applyMatrix4(matrix);

			this.component3DObjects.mesh.add(horizontalPlank1);

			return horizontalPlank1;
		}
	};

	this.SetWall = function (wall, facetIndex)
	{
		if (this.wall)
		{
			if (this.wall.vertLineGuide)
				this.wall.vertLineGuide.SetVisibility(false);

			if (this.wall.horizLineGuide)
				this.wall.horizLineGuide.SetVisibility(false);
		}

		this.wall = wall;

		this.facetIndex = facetIndex;

		this.horizRuler.SetWall(this.wall);

		this.vertRuler.SetWall(this.wall);

		this.UpdateMatrix();
	};

	this.GetElementPointsOnWall = function ()
	{
		let points = [
			new THREE.Vector2(this.pos.x - (this.buttonData.width / 2), this.pos.y - this.buttonData.height / 2),//bottom right
			new THREE.Vector2(this.pos.x - (this.buttonData.width / 2), this.pos.y + (this.buttonData.height / 2)),//top right
			new THREE.Vector2(this.pos.x + (this.buttonData.width / 2), this.pos.y + (this.buttonData.height / 2)),//top left
			new THREE.Vector2(this.pos.x + (this.buttonData.width / 2), this.pos.y - this.buttonData.height / 2)//bottom left
		];

		return points;
	};

	this.CalculateElementPosOnWall = function (wallAndPosOnWall)
	{
		let elementPos = wallAndPosOnWall.vectorPos.clone();

		let mtxWorldToElem;
		if (typeof wallAndPosOnWall.wall.wallFacets === "undefined")
		{
			mtxWorldToElem = new THREE.Matrix4().getInverse(wallAndPosOnWall.wall.matrix);
		}
		else
		{
			mtxWorldToElem= new THREE.Matrix4().getInverse(wallAndPosOnWall.wall.wallFacets[wallAndPosOnWall.wallFacetIndex].matrix);
		}
		elementPos.applyMatrix4(mtxWorldToElem);

		let centerOffset = this.mousePosOnElement.clone();

		if (wallAndPosOnWall.wall.eWall == WALL_RIGHT || wallAndPosOnWall.wall.eWall == WALL_FRONT)
		{
			centerOffset.x -= this.component3DObjects.geometryCenter.x;
			elementPos.x -= centerOffset.x;
		}
		else
		{
			centerOffset.x -= this.component3DObjects.geometryCenter.x;
			elementPos.x += centerOffset.x;
		}


		centerOffset.y -= this.component3DObjects.geometryCenter.y;
		elementPos.y -= centerOffset.y;

		if (wallAndPosOnWall.wall.eWall == WALL_LEFT || wallAndPosOnWall.wall.eWall == WALL_BACK)
			elementPos.z = -Wall.WALLTHICKNESS;
		else
			elementPos.z = Wall.WALLTHICKNESS;

		return elementPos;
	};



	this.StartDragging = function ()
	{
		this.dragging = true;

		this.originalPos = this.pos.clone();

		this.origWall = this.wall;
		this.origFacetIndex = this.facetIndex;

		buildingDesigner.camera.cameraControls.enabled = false;

		buildingDesigner.camera.cameraControls._state = 0;

		////Elements.SetRegenerate(true);
		////buildingDesigner.building.SetRegenerateElementMeshes(true);
	};

	this.DraggingElement = function (wall, facetIndex, vectorPos)
	{
		this.SetWall(wall, facetIndex);

		if (this.wall.eWall == WALL_FRONT || this.wall.eWall == WALL_BACK)
		{
			centerPos = -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length / 2;

			distToCenter = Math.abs(vectorPos.x - (-buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length / 2));
		}
		else
		{
			centerPos = 0;

			distToCenter = Math.abs(vectorPos.x);
		}

		if (distToCenter < LineGuide.SNAP_TO_CENTER_RANGE)
			vectorPos.x = centerPos;

		if (Math.abs(vectorPos.y - this.wall.height / 2) < LineGuide.SNAP_TO_CENTER_RANGE)
			vectorPos.y = this.wall.height / 2;

		this.SetPos(vectorPos.x, vectorPos.y, vectorPos.z + (wall.wallFacets ? wall.wallFacets[facetIndex].zOffset : 0));

		if (distToCenter < LineGuide.CENTER_RANGE)
		{
			this.wall.vertLineGuide.SetVisibility(true);
			this.wall.vertLineGuide.UpdateMatrix();
		}
		else
			this.wall.vertLineGuide.SetVisibility(false);

		if (Math.abs(vectorPos.y - this.wall.height / 2) < LineGuide.CENTER_RANGE)
		{
			this.wall.horizLineGuide.SetVisibility(true);
			this.wall.horizLineGuide.UpdateMatrix();
		}
		else
			this.wall.horizLineGuide.SetVisibility(false);

	};

	this.EndDragging = function ()
	{
		this.dragging = false;

		this.dragged = true;

		buildingDesigner.camera.cameraControls.enabled = true;

		if (!this.wall)
		{
			let wallAndPosOnWall = buildingDesigner.building.GetWallMouseOver({
				x: GUIInput.vecCurrentMousePos.x,
				y: GUIInput.vecCurrentMousePos.y
			});

			if (wallAndPosOnWall != null && wallAndPosOnWall.wall.style == Wall.CLOSED)
			{
				wallAndPosOnWall.vectorPos = this.CalculateElementPosOnWall(wallAndPosOnWall);

				buildingDesigner.building.DraggingElement(wallAndPosOnWall.wall, wallAndPosOnWall.wallFacetIndex, wallAndPosOnWall.vectorPos);

				Elements.ProcessCollisions(this);
			}
		}

		if (this.wall)
		{
			if (this.wall.vertLineGuide)
				this.wall.vertLineGuide.SetVisibility(false);

			if (this.wall.horizLineGuide)
				this.wall.horizLineGuide.SetVisibility(false);
		}

		if (this.collision && this.buttonData.type != ELEM_LEG_BRACES || (!this.collision && this.buttonData.type == ELEM_HINGE))
		{
			if (!this.originalPos || this.originalPos.x == 9999)
			{
				this.AfterDragging();
				Elements.DeleteElement(this);
				if (tdf.placementAlert) {
					swal.fire({title: "Oops", icon: "error",html:`It doesn't fit here.<br><br><input type='checkbox' onchange='tdf.placementAlert = !tdf.placementAlert;'> Don't display again.`});
				}
			}
			else
			{
				this.pos = this.originalPos.clone();

				this.wall = this.origWall;
				this.facetIndex = this.origFacetIndex;

				this.collision = false;
			}
		}
		else
		{
			if(this.originalPos)
				if ((this.pos.x !== this.originalPos.x) || (this.pos.y !== this.originalPos.y))
				{
					buildingDesigner.building.SetDesignModified();
				}
		}

		buildingDesigner.building.SetRegenerateElementMeshes(true);
	};


	this.AfterDragging = function ()
	{

	};

	this.GenerateSelectedBoxes = function (parentMesh, matrix, scale, height)
	{
		if (this.mesh || this.component3DObjects.mesh)
		{
			if (scale == null || scale == undefined)
				scale = new THREE.Vector3(1, 1, 1);

			let max;
			let min;

			if (this.component3DObjects.mesh)
			{
				if (!this.component3DObjects.boundingBox)
					this.component3DObjects.ComputeBoundingBoxForAllObjects(false, false, true);

				if (this.component3DObjects.boundingBox)
				{
					max = this.component3DObjects.boundingBox.max;
					min = this.component3DObjects.boundingBox.min;
				}
				else
				{
					max = 0;
					min = 0;
				}
			}
			else
			if (this.mesh)
			{
				if (!this.mesh.geometry.boundingBox)
					this.mesh.geometry.computeBoundingBox();

				if (this.mesh.geometry.boundingBox)
				{
					max = this.mesh.geometry.boundingBox.max;
					min = this.mesh.geometry.boundingBox.min;
				}
				else
				{
					max = 0;
					min = 0;
				}
			}

			let xWidth = max.x - min.x;
			let yHeight = max.y - min.y;
			let zLength = max.z - min.z;

			let fSelBoxSizeX = SEL_BOX_SIZE / this.component3DObjects.scale.x;

			let fSelBoxSizeY = SEL_BOX_SIZE / this.component3DObjects.scale.y;

			let fSelBoxSizeZ = SEL_BOX_SIZE / this.component3DObjects.scale.z;

			let box_sizeX2 = fSelBoxSizeX / 2.0;
			let box_sizeY2 = fSelBoxSizeY / 2.0;
			let box_sizeZ2 = fSelBoxSizeZ / 2.0;

			let box_offs_x = xWidth + box_sizeX2;

			box_offs_x /= 2;

			let box_offs_y;

			if (height == undefined)
			{
				box_offs_y = yHeight + box_sizeY2;
			}
			else
				box_offs_y = height + box_sizeY2;

			box_offs_y /= 2;

			let box_offs_z = box_sizeZ2;

			box_offs_z = 0;

			let vecOffs = [{
				x: -box_offs_x,
				y: -box_offs_y,
				z: box_offs_z
			},
			{
				x: -box_offs_x,
				y: 0,
				z: box_offs_z
			},
			{
				x: -box_offs_x,
				y: box_offs_y,
				z: box_offs_z
			},
			{
				x: box_offs_x,
				y: -box_offs_y,
				z: box_offs_z
			},
			{
				x: box_offs_x,
				y: 0,
				z: box_offs_z
			},
			{
				x: box_offs_x,
				y: box_offs_y,
				z: box_offs_z
			},
			{
				x: 0,
				y: box_offs_y,
				z: box_offs_z
			},
			{
				x: 0,
				y: -box_offs_y,
				z: box_offs_z
			}
			];

			let materSelBox = Material.CreateMaterial(SEL_BOX_COLOR, null);

			let totalGeometry = new THREE.Geometry();

			for (let i = 0; i < 8; i++)
			{
				let geomSelBox = new THREE.BoxGeometry(fSelBoxSizeX, fSelBoxSizeY, fSelBoxSizeZ);
				let boxMatrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(vecOffs[i].x, vecOffs[i].y, vecOffs[i].z + zLength / 2));

				totalGeometry.merge(geomSelBox, boxMatrix);
			}

			for (let i = 0; i < 8; i++)
			{
				let geomSelBox = new THREE.BoxGeometry(fSelBoxSizeX, fSelBoxSizeY, fSelBoxSizeZ);

				let boxMatrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(vecOffs[i].x, vecOffs[i].y, vecOffs[i].z - zLength / 2));

				totalGeometry.merge(geomSelBox, boxMatrix);
			}

			let meshSelBoxes = new THREE.Mesh(totalGeometry, materSelBox);

			meshSelBoxes.matrixAutoUpdate = false;
			meshSelBoxes.applyMatrix4(new THREE.Matrix4().makeTranslation(this.component3DObjects.geometryCenter.x / this.component3DObjects.scale.x, this.component3DObjects.geometryCenter.y / this.component3DObjects.scale.y, this.component3DObjects.geometryCenter.z / this.component3DObjects.scale.z).scale(new THREE.Vector3(scale.x, scale.y, scale.y)));

			if (height != undefined)
			{
				meshSelBoxes.matrixAutoUpdate = false;
				meshSelBoxes.applyMatrix4(new THREE.Matrix4().makeTranslation(0, yHeight / 2, 0));
			}

			meshSelBoxes.matrixWorldNeedsUpdate = true;

			parentMesh.add(meshSelBoxes);
		}
	};

	this.SetCollision = function (collision)
	{
		this.collision = collision;

		if (collision)
		{
			if (this.component3DObjects.mesh)
				MeshUtilities.SetMaterialOpacity(this.component3DObjects.mesh, Element.COLLISION_OPACITY);

			if (this.mesh)
				MeshUtilities.SetMaterialOpacity(this.mesh, Element.COLLISION_OPACITY);
		}
		else
		{
			if (this.component3DObjects.mesh)
				MeshUtilities.SetMaterialOpacity(this.component3DObjects.mesh, 1.0);

			if (this.mesh)
				MeshUtilities.SetMaterialOpacity(this.mesh, 1.0);
		}
	};

	this.Destroy = function ()
	{
		if (this.dormer)
			this.dormer.attachedElement = null;

		if (this.attachedElement)
		{
			Elements.DeleteElement(this.attachedElement);
		}

		this.horizRuler.Destroy();
		this.vertRuler.Destroy();
	};
}

Element.COLLISION_OPACITY = 0.1;
