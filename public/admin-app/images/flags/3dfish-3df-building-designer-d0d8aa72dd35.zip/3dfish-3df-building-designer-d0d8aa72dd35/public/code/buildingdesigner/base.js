/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Base()
{
	////this.width = width;
	if (!Floor.OPTIONS)
	{
		Floor.OPTIONS = {};
	}
	this.length = buildingDesigner.building.length - Wall.WALLTHICKNESS * 2;

	this.runnerColor = Floor.OPTIONS.runner_color || 0x604E2A;

	this.fsr_dist2_ratio = 0.221429;
	this.fsr_dist3_ratio = 0.242857;

	this.regenerate = true;

	this.SetRegenerate = function(regenerate)
	{
		this.regenerate = regenerate;
	};

	this.Generate = function(buildingMeshes)
	{
		let runnerMatter = Material.CreateMaterial( this.runnerColor, null );

		let runnerSize = Floor.OPTIONS.runner_size || Base.RUNNERSIZE;
		let y_offset = (-runnerSize / 2.0);
		let runnerVectors = [];
		// Transport Runners
		let dist1 = Floor.OPTIONS.runner_dist1 || 2.833333;
		// Outer Runners
		let dist2 = buildingDesigner.building.roofRafter.wallWidth / 2.0 - runnerSize / 2.0;

		// number and spacing of runners
		if (buildingDesigner.building.roofRafter.wallWidth<9)
		{
			dist1 = (buildingDesigner.building.roofRafter.wallWidth / 2) - 0.1;
		}

		if (!Floor.OPTIONS.runnerVectors)
		{
			// Transport Runners
			runnerVectors.push(
				{ x: -dist1, y: y_offset, z: 0.0, minWidth: 0, maxWidth: 32 },
				{ x:  dist1, y: y_offset, z: 0.0, minWidth: 0, maxWidth: 32 }
			);
			// Center Runner
			if (!(Floor.OPTIONS.no_center_runner || Floor.OPTIONS.no_center_runner10))
			{
				runnerVectors.push(
					{ x: 0.0, y: y_offset, z: 0.0, minWidth: 9, maxWidth: 11 }
				);
			}
			if (!(Floor.OPTIONS.no_center_runner || Floor.OPTIONS.no_center_runner12))
			{
				runnerVectors.push(
					{ x: 0.0, y: y_offset, z: 0.0, minWidth: 11, maxWidth: 13 }
				);
			}
			if (!(Floor.OPTIONS.no_center_runner || Floor.OPTIONS.no_center_runner14))
			{
				runnerVectors.push(
					{ x: 0.0, y: y_offset, z: 0.0, minWidth: 13, maxWidth: 15 }
				);
			}
			if (!(Floor.OPTIONS.no_center_runner || Floor.OPTIONS.no_center_runner16))
			{
				runnerVectors.push(
					{ x: 0.0, y: y_offset, z: 0.0, minWidth: 15, maxWidth: 17 }
				);
			}
			// Outer Runners
			if (!Floor.OPTIONS.no_outer_runners10)
			{
				runnerVectors.push(
					{ x: -dist2, y: y_offset, z: 0.0, minWidth: 9, maxWidth: 11 },
					{ x:  dist2, y: y_offset, z: 0.0, minWidth: 9, maxWidth: 11 }
				);
			}
			runnerVectors.push(
				{ x: -dist2, y: y_offset, z: 0.0, minWidth: 11, maxWidth: 32 },
				{ x:  dist2, y: y_offset, z: 0.0, minWidth: 11, maxWidth: 32 }
			);
		}
		else
		{
			runnerVectors = JSON.parse(JSON.stringify(Floor.OPTIONS.runnerVectors));
			for (let runnerVector of runnerVectors)
			{
				runnerVector.y = y_offset;
				switch (runnerVector.x)
				{
				case "-d1": {
					runnerVector.x = -dist1;
					break;
				}
				case "+d1": {
					runnerVector.x = dist1;
					break;
				}
				case "-d2": {
					runnerVector.x = -dist2;
					break;
				}
				case "+d2": {
					runnerVector.x = dist2;
					break;
				}
				}
			}
		}

		let lengthAdjustment = Floor.OPTIONS.length_adjustment || 0;
		for ( let i = 0; i < runnerVectors.length; i++ )
		{
			if ((buildingDesigner.building.roofRafter.wallWidth > runnerVectors[i].minWidth) && (buildingDesigner.building.roofRafter.wallWidth < runnerVectors[i].maxWidth))
			{
				let geomRunner = new THREE.BoxGeometry( runnerSize, runnerSize, this.length + lengthAdjustment);

				geomRunner.matrixAutoUpdate = false;
				geomRunner.applyMatrix4( new THREE.Matrix4().makeTranslation( runnerVectors[i].x, runnerVectors[i].y, runnerVectors[i].z ) );

				let meshRunner = new THREE.Mesh( geomRunner, runnerMatter );

				buildingMeshes.push( meshRunner );
			}
		}
	};
}

Base.RUNNERSIZE = 0.292;  // 3.5 inches
