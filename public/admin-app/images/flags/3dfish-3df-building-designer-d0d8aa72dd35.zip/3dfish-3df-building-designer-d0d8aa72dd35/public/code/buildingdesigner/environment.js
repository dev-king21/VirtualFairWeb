/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Environment(background, groundTextureName)
{
	this.regenerate = true;

	this.backGround = new BackGround(background);

	this.ground = new Ground(groundTextureName);

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;

		this.ground.SetRegenerate(regenerate);
		this.backGround.SetRegenerate(regenerate);
	};

	this.Draw = function ()
	{
		if (this.regenerate)
		{
			this.Destroy();

			this.ground.Draw();
			this.backGround.Draw();

			this.regenerate = false;
		}
	};

	this.Destroy = function ()
	{
		this.ground.Destroy();
		this.backGround.Destroy();
	};
}
