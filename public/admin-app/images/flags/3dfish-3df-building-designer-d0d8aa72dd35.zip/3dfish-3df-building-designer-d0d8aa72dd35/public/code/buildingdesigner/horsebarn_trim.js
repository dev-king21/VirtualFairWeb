/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Trim()
{}

Trim.TRIM_THICKNESS = INCHTOFEET * 3 / 4;
Trim.CORNER_TRIM_THICKNESS = BOARD_2x4_THICKNESS;
Trim.CORNER_TRIM_WIDTH_SIDES = BOARD_2x4_WIDTH;
Trim.CORNER_TRIM_WIDTH_ENDS = BOARD_2x4_WIDTH;
