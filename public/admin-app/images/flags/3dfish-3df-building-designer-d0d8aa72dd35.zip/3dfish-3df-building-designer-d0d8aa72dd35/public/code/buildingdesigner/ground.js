/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Ground(textureName)
{
	this.mesh = null;

	this.regenerate = true;

	this.textureName = textureName;

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.Draw = function ()
	{
		////if (this.regenerate)
		{
			this.Destroy();

			let groundTexture2 = TexturesDataUtilities.SelectTexture(this.textureName, THREE.RepeatWrapping, THREE.RepeatWrapping);

			if (groundTexture2)
			{				
				groundTexture2.repeat.set((GRASS_RADIUS*2)/groundTexture2.realWorldWidth, (GRASS_RADIUS*2)/groundTexture2.realWorldHeight);
				groundTexture2.anisotropy = threeRenderer.capabilities.getMaxAnisotropy();
			}

			let groundMaterial;

			groundTexture2 = TexturesDataUtilities.TextureLoaded(groundTexture2);

			if (groundTexture2)
				groundMaterial = new THREE.MeshLambertMaterial({
					color: 0xBBBBBB,
					map: TexturesDataUtilities.TextureLoaded(groundTexture2)
				});
			else
				groundMaterial = new THREE.MeshLambertMaterial({
					color: COLOR_GROUND,
					map: null
				});
			
			let radius = GRASS_RADIUS;
			let segments = BACKGROUND_CURVE_SEGMENTS;

			this.mesh = new THREE.Mesh(new THREE.CircleGeometry(radius, segments), groundMaterial);

			this.mesh.position.y = 0;
			this.mesh.rotation.x = -MathUtilities.PI2;

			if (!AuxUtilities.IsMobileOrTablet())
				this.mesh.receiveShadow = true;

			threeScene.add(this.mesh);
			threeRenderer.shadowMap.needsUpdate = true;

			this.regenerate = false;
		}
	};

	this.Destroy = function ()
	{
		if (this.mesh != null)
		{
			threeScene.remove(this.mesh);
			threeRenderer.shadowMap.needsUpdate = true;
			this.mesh = null;
		}
	};
}
