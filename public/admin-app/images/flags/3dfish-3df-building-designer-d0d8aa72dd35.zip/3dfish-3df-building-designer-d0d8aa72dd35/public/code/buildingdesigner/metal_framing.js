/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function MetalRafters(thickness, wallRafterWidth)
{
	if (!wallRafterWidth)
	{
		wallRafterWidth = Rafter.WALL_WOOD_RAFTER_WIDTH;
		buildingDesigner.building.roofRafter.data.width = Rafter.WALL_WOOD_RAFTER_WIDTH;
	}

	if (!buildingDesigner.building.roofRafter.data.designLoaded && buildingDesigner.building.roofRafter.data.bent_bow)
	{
		buildingDesigner.building.roofRafter.data.rafter_spec = MetalRafters.GetBentBowRafterPoints();

		let lowerSurface = GeometryUtilities.GetSurfacePoints(buildingDesigner.building.roofRafter.data.rafter_spec, buildingDesigner.building.roofRafter.sideCoordsIndices[0][1], buildingDesigner.building.roofRafter.sideCoordsIndices[1][1], -buildingDesigner.building.roofRafter.rafterVerticalWidth, Roof.ANGLED_TRIM, false);

		lowerSurface = AuxUtilities.ReverseArray(lowerSurface);

		buildingDesigner.building.roofRafter.data.rafter_spec = AuxUtilities.MergeArrays(buildingDesigner.building.roofRafter.data.rafter_spec, lowerSurface);
	}

	Rafters.call(this, thickness, wallRafterWidth);

	this.rafterColor = MetalRafters.METAL_RAFTERS_COLOR;

	this.GenerateFrameRafters = function (roofFrameMeshes, wallMeshesFront, wallMeshesBack, wallMeshesLeft, wallMeshesRight)
	{
		let cornerx = -buildingDesigner.building.roofRafter.wallWidth / 2;
		let cornerz = -buildingDesigner.building.walls.wallLength / 2;

		let rafters = [];

		let extrudeSettings = {
			depth: this.thickness,
			steps: 1,
			material: 1,
			extrudeMaterial: 0,
			bevelEnabled: false,
		};

		let numberOfRafters = (buildingDesigner.building.walls.wallLength - this.thickness) / buildingDesigner.building.roofRafter.data.max_gap;
		numberOfRafters = Math.round(numberOfRafters);
		let rafterSpacing = (buildingDesigner.building.walls.wallLength - this.thickness) / numberOfRafters;

		numberOfRafters++; //for the end leg

		let rafterMaterial = new THREE.MeshBasicMaterial({
			color: 0xdddddd,
			map: null
		});

		let apexCoordsIndices = buildingDesigner.building.roofRafter.GetApexCoordIndices();

		//front back vertical and roof rafters
		let rafteroffsetx = 0;
		let rafterOffsetY = 0;

		if (buildingDesigner.building.roofRafter.data.front_wall_attach_coord.length > 0)
		{
			rafteroffsetx = -buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0];
		}

		if (buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord.length > 0)
		{
			rafterOffsetY = -buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][1];
		}


		let baseAndStrutCoords = null;

		if (buildingDesigner.building.roofRafter.data.truss_strut_ratio_coords.length > 0)
		{
			baseAndStrutCoords = this.GenerateBaseAndStrutCoords();
		}


		let rafter_sh_1 = new THREE.Shape();

		rafter_sh_1.moveTo(buildingDesigner.building.roofRafter.data.rafter_spec[0][0], buildingDesigner.building.roofRafter.data.rafter_spec[0][1]);
		for (let i = 1; i < buildingDesigner.building.roofRafter.data.rafter_spec.length; i++)
		{
			rafter_sh_1.lineTo(buildingDesigner.building.roofRafter.data.rafter_spec[i][0], buildingDesigner.building.roofRafter.data.rafter_spec[i][1]);
		}

		//height extensions
		let extensionHeight = buildingDesigner.building.height - buildingDesigner.building.roofRafter.data.wall_height_segment_on_rafter;
		let rafter_sh_2 = new THREE.Shape();
		if ((!buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord) || (buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord.length < 2))
		{
			buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord = buildingDesigner.building.roofRafter.data.front_wall_attach_coord;
		}
		if ((!buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord) || (buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord.length < 2))
		{
			buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord = buildingDesigner.building.roofRafter.data.rear_wall_attach_coord;
		}

		rafter_sh_2.moveTo(buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][0], buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][1]);
		rafter_sh_2.lineTo(buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[1][0], buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[1][1]);
		rafter_sh_2.lineTo(buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[1][0], buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][1] - extensionHeight);
		rafter_sh_2.lineTo(buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][0], buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][1] - extensionHeight);


		let rafter_sh_3 = new THREE.Shape();

		rafter_sh_3.moveTo(buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[0][0], buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[0][1]);
		rafter_sh_3.lineTo(buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[1][0], buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[1][1]);
		rafter_sh_3.lineTo(buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[1][0], buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[1][1] - (extensionHeight - buildingDesigner.building.roofRafter.frontBackHeightDifference));
		rafter_sh_3.lineTo(buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[0][0], buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[1][1] - (extensionHeight - buildingDesigner.building.roofRafter.frontBackHeightDifference));



		let subtractGeom = null;

		buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_1, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, cornerz, rafterMaterial, subtractGeom, roofFrameMeshes);

		buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_2, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, cornerz, rafterMaterial, subtractGeom, wallMeshesFront);
		buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_3, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, cornerz, rafterMaterial, subtractGeom, wallMeshesBack);

		this.frontBackRafterCoords[0] = -buildingDesigner.building.walls.wallLength / 2;

		for (let i = 1; i < (numberOfRafters - 1); i++)
		{
			this.frontBackRafterCoords[i] = (i * rafterSpacing) + cornerz;

			buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_1, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, (i * rafterSpacing) - (this.thickness / 2) + cornerz, rafterMaterial, subtractGeom, roofFrameMeshes);

			buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_2, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, (i * rafterSpacing) - (this.thickness / 2) + cornerz, rafterMaterial, subtractGeom, wallMeshesFront);
			buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_3, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, (i * rafterSpacing) - (this.thickness / 2) + cornerz, rafterMaterial, subtractGeom, wallMeshesBack);
		}

		this.frontBackRafterCoords[numberOfRafters - 1] = buildingDesigner.building.walls.wallLength / 2 - this.thickness;

		buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_1, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, buildingDesigner.building.walls.wallLength / 2 - this.thickness, rafterMaterial, subtractGeom, roofFrameMeshes);

		buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_2, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, buildingDesigner.building.walls.wallLength / 2 - this.thickness, rafterMaterial, subtractGeom, wallMeshesFront);
		buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_3, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, buildingDesigner.building.walls.wallLength / 2 - this.thickness, rafterMaterial, subtractGeom, wallMeshesBack);


		if (baseAndStrutCoords)
		{
			this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, cornerz, rafterMaterial, roofFrameMeshes, roofFrameMeshes);

			this.GenerateRafterBase(baseAndStrutCoords.baseCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, cornerz, rafterMaterial, roofFrameMeshes);


			for (let i = 1; i < (numberOfRafters - 1); i++)
			{
				this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, (i * rafterSpacing) - (this.thickness / 2) + cornerz, rafterMaterial, roofFrameMeshes, roofFrameMeshes);

				this.GenerateRafterBase(baseAndStrutCoords.baseCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, (i * rafterSpacing) - (this.thickness / 2) + cornerz, rafterMaterial, roofFrameMeshes);
			}

			this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, buildingDesigner.building.walls.wallLength / 2 - this.thickness, rafterMaterial, roofFrameMeshes, roofFrameMeshes);

			this.GenerateRafterBase(baseAndStrutCoords.baseCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, buildingDesigner.building.walls.wallLength / 2 - this.thickness, rafterMaterial, roofFrameMeshes);


			this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, cornerz, rafterMaterial, roofFrameMeshes, roofFrameMeshes, true);

			for (let i = 1; i < (numberOfRafters - 1); i++)
			{
				this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, (i * rafterSpacing) - (this.thickness / 2) + cornerz, rafterMaterial, roofFrameMeshes, roofFrameMeshes, true);
			}

			this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, buildingDesigner.building.walls.wallLength / 2 - this.thickness, rafterMaterial, roofFrameMeshes, roofFrameMeshes, true);
		}


		if (buildingDesigner.building.sizeData.combo_building_length != -1)
		{
			let rafterCoord = buildingDesigner.building.GetClosestSideWallRafterCoord(buildingDesigner.building.sizeData.combo_building_length);

			if (rafterCoord.index > -1)
				buildingDesigner.building.sizeData.actual_combo_building_length = rafterCoord.coord + buildingDesigner.building.length / 2 + this.wallRafterWidth;
		}
		else
		{
			buildingDesigner.building.sizeData.actual_combo_building_length = buildingDesigner.building.length;
		}


		let leftWall = buildingDesigner.building.walls.GetWall(WALL_LEFT);

		let rightWall = buildingDesigner.building.walls.GetWall(WALL_RIGHT);

		if (BuildingDesigner.buildingType == BUILDING_SHED || (leftWall.style == CarportWall.CLOSED || rightWall.style == CarportWall.CLOSED))
		{
			//left right vertical rafters
			numberOfRafters = (buildingDesigner.building.roofRafter.wallWidth - this.thickness) / buildingDesigner.building.roofRafter.data.max_gap;
			numberOfRafters = Math.ceil(numberOfRafters);

			let xInc = (buildingDesigner.building.roofRafter.wallWidth - this.thickness) / numberOfRafters;

			this.leftRightRafterCoords[0] = -buildingDesigner.building.roofRafter.wallWidth / 2;

			let fOffsX;

			let geomRafters = [];

			let geomWallRafter;

			let mesh;

			let roofHeightAtRafter;

			let xOffsets = [0, 11, 20];

			for (i = 1; i < numberOfRafters; i++)
			{
				fOffsX = -buildingDesigner.building.roofRafter.wallWidth / 2 + this.thickness / 2.0 + xInc * i;

				roofHeightAtRafter = buildingDesigner.building.height + buildingDesigner.building.roofRafter.HeightAtXCoord(fOffsX - -buildingDesigner.building.roofRafter.wallWidth / 2 + buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0]) - buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1];

				roofHeightAtRafter -= Roof.ROOF_THICKNESS;

				this.leftRightRafterCoords[i] = fOffsX;

				if (BuildingDesigner.buildingType == BUILDING_SHED || (rightWall.style == CarportWall.CLOSED))
				{
					geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(this.thickness, roofHeightAtRafter - this.thickness, this.wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryXY);
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(fOffsX, this.thickness, -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length - this.wallRafterWidth / 2 - Wall.WALLTHICKNESS));

					mesh = new THREE.Mesh(geomWallRafter, rafterMaterial);
					mesh.eWall = WALL_RIGHT;

					wallMeshesRight.push(mesh);
				}

				if (BuildingDesigner.buildingType == BUILDING_SHED || (leftWall.style == CarportWall.CLOSED))
				{
					geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(this.thickness, roofHeightAtRafter - this.thickness, this.wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryXY);
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(fOffsX, this.thickness, -buildingDesigner.building.walls.wallLength / 2 + this.wallRafterWidth / 2));

					mesh = new THREE.Mesh(geomWallRafter, rafterMaterial);
					mesh.eWall = WALL_LEFT;

					wallMeshesLeft.push(mesh);
				}
			}

			this.leftRightRafterCoords[numberOfRafters] = buildingDesigner.building.roofRafter.wallWidth / 2;
		}


		//horizontal base
		//front back
		let geom = GeometryUtilities.CreateGeomYSymmetricBox(this.wallRafterWidth, this.thickness, buildingDesigner.building.walls.wallLength, TexturesDataUtilities.AssignUVsToGeometryXZ);

		if (BuildingDesigner.buildingType == BUILDING_CARPORT)
		{
			let mesh = new THREE.Mesh(geom.clone(), rafterMaterial);
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 + this.wallRafterWidth / 2.0, 0, 0));
			mesh.receiveShadow = true;
			wallMeshesFront.push(mesh);
		}

		if (buildingDesigner.building.crossMember)
		{
			mesh = new THREE.Mesh(geom.clone(), rafterMaterial);
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 + this.wallRafterWidth / 2.0, buildingDesigner.building.height/2 - this.thickness/2 + (BuildingDesigner.buildingType == BUILDING_SHED ? Floor.FLOOR_THICKNESS:0), 0));
			mesh.receiveShadow = true;
			wallMeshesFront.push(mesh);
		}

		if (BuildingDesigner.buildingType == BUILDING_CARPORT)
		{
			mesh = new THREE.Mesh(geom.clone(), rafterMaterial);
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 - this.wallRafterWidth / 2.0, 0, 0));
			mesh.receiveShadow = true;
			wallMeshesBack.push(mesh);
		}

		if (buildingDesigner.building.crossMember)
		{
			mesh = new THREE.Mesh(geom.clone(), rafterMaterial);
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 - this.wallRafterWidth / 2.0, buildingDesigner.building.height/2 - this.thickness/2 + (BuildingDesigner.buildingType == BUILDING_SHED ? Floor.FLOOR_THICKNESS : 0), 0));
			mesh.receiveShadow = true;
			wallMeshesBack.push(mesh);
		}


		if (BuildingDesigner.buildingType == BUILDING_CARPORT)
		{
			//left right
			if (leftWall.style == CarportWall.CLOSED)
			{
				let geom = GeometryUtilities.CreateGeomYSymmetricBox(buildingDesigner.building.roofRafter.wallWidth, this.thickness, this.wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);

				let mesh = new THREE.Mesh(geom, rafterMaterial);
				mesh.geometry.matrixAutoUpdate = false;
				mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -buildingDesigner.building.walls.wallLength / 2 + this.wallRafterWidth / 2));
				mesh.receiveShadow = true;
				wallMeshesLeft.push(mesh);

				if (buildingDesigner.building.crossMember)
				{
					mesh = new THREE.Mesh(geom.clone(), rafterMaterial);
					mesh.geometry.matrixAutoUpdate = false;
					mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.height / 2 - this.thickness / 2, -buildingDesigner.building.walls.wallLength / 2 + this.wallRafterWidth / 2));
					mesh.receiveShadow = true;
					wallMeshesLeft.push(mesh);
				}
			}

			if (rightWall.style == CarportWall.CLOSED)
			{
				let geom = GeometryUtilities.CreateGeomYSymmetricBox(buildingDesigner.building.roofRafter.wallWidth, this.thickness, this.wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);

				let mesh = new THREE.Mesh(geom, rafterMaterial);
				mesh.geometry.matrixAutoUpdate = false;
				mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length - this.wallRafterWidth / 2 - Wall.WALLTHICKNESS));
				mesh.receiveShadow = true;
				wallMeshesRight.push(mesh);

				if (buildingDesigner.building.crossMember)
				{
					mesh = new THREE.Mesh(geom.clone(), rafterMaterial);
					mesh.geometry.matrixAutoUpdate = false;
					mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.height / 2 - this.thickness / 2, -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length - this.wallRafterWidth / 2 - Wall.WALLTHICKNESS));
					mesh.receiveShadow = true;
					wallMeshesRight.push(mesh);
				}
			}
		}
		else if (buildingDesigner.building.crossMember)
		{
			let geom = GeometryUtilities.CreateGeomYSymmetricBox(buildingDesigner.building.roofRafter.wallWidth, this.thickness, this.wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);

			mesh = new THREE.Mesh(geom.clone(), rafterMaterial);
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.height / 2 - this.thickness / 2 + Floor.FLOOR_THICKNESS, -buildingDesigner.building.walls.wallLength / 2 + this.wallRafterWidth / 2));
			mesh.receiveShadow = true;
			wallMeshesLeft.push(mesh);

			mesh = new THREE.Mesh(geom.clone(), rafterMaterial);
			mesh.geometry.matrixAutoUpdate = false;
			mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, buildingDesigner.building.height / 2 - this.thickness / 2 + Floor.FLOOR_THICKNESS, -buildingDesigner.building.length / 2 + buildingDesigner.building.sizeData.actual_combo_building_length - this.wallRafterWidth / 2 - Wall.WALLTHICKNESS));
			mesh.receiveShadow = true;
			wallMeshesRight.push(mesh);
		}
	};


	this.CreateHorizontalRoofFrame = function (roofFrameMeshes, x, y, z, angle)
	{
		let roofExtraLength = Roof.ROOF_THICKNESS + Roof.TILE_THICKNESS;

		let geometry = new THREE.BoxGeometry(MetalRafters.HORIZONTAL_ROOF_FRAMING_WIDTH, MetalRafters.HORIZONTAL_ROOF_FRAMING_THICKNESS, buildingDesigner.building.length - roofExtraLength * 2 - BOARD_2x4_THICKNESS * 2);

		let rafterMaterial = new THREE.MeshBasicMaterial({
			color: 0xdddddd,
			map: null
		});

		let frame = new THREE.Mesh(geometry, rafterMaterial);


		frame.geometry.matrixAutoUpdate = false;
		frame.geometry.applyMatrix4(new THREE.Matrix4().makeRotationZ(angle));

		frame.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(x, y, z));

		roofFrameMeshes.push(frame);
	};

	this.GenerateHorizontalRoofFraming = function (roofFrameMeshes)
	{
		let framingPoints = GeometryUtilities.GetSurfacePoints(buildingDesigner.building.roofRafter.data.rafter_spec, buildingDesigner.building.roofRafter.sideCoordsIndices[0][1], buildingDesigner.building.roofRafter.sideCoordsIndices[1][1], MetalRafters.HORIZONTAL_ROOF_FRAMING_THICKNESS / 2, Roof.ANGLED_TRIM, false);

		framingPoints = GeometryUtilities.IncreaseResolution(framingPoints, 0, framingPoints.length - 1, MetalRafters.HORIZONTAL_ROOF_FRAMING_SPACING);

		let apexCoorIndex = GeometryUtilities.GetApexCoordIndex(framingPoints);

		framingPoints = GeometryUtilities.ReplaceApexWithAdjCoords(framingPoints, MetalRafters.HORIZONTAL_ROOF_FRAMING_SHIFT);

		framingPoints = GeometryUtilities.GenerateExtendedSurface(framingPoints, 0, framingPoints.length - 1, -MetalRafters.HORIZONTAL_ROOF_FRAMING_SHIFT);

		let frontRafteroffsetx = 0;
		let rafterOffsetY = 0;

		if (buildingDesigner.building.roofRafter.data.front_wall_attach_coord != "")
		{
			frontRafteroffsetx = buildingDesigner.building.roofRafter.frontVisorWidth;

			rearRafteroffsetx = buildingDesigner.building.roofRafter.rearVisorWidth;

			rafterOffsetY = -buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1];
		}

		let frontAngle = Math.atan(buildingDesigner.building.roofRafter.frontTanAngleRatio);
		let rearAngle = -Math.atan(buildingDesigner.building.roofRafter.rearTanAngleRatio);

		let angle = frontAngle;

		for (let i = 0; i < framingPoints.length; i++)
		{
			if (i > apexCoorIndex)
				angle = rearAngle;

			this.CreateHorizontalRoofFrame(roofFrameMeshes, -buildingDesigner.building.roofRafter.wallWidth / 2 + framingPoints[i][0] - frontRafteroffsetx, buildingDesigner.building.height + rafterOffsetY + framingPoints[i][1], 0, angle);
		}
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			let texture1 = TexturesDataUtilities.GetRealWorldSizedTexture("MetalRafter", this.wallRafterWidth, buildingDesigner.building.height);

			let texture2 = TexturesDataUtilities.GetRealWorldSizedTexture("MetalRafter", buildingDesigner.building.width * 2, this.wallRafterWidth * 2);

			let extents = buildingDesigner.building.roofRafter.GetExtents();

			////if (TexturesDataUtilities.TextureLoaded(texture1))
			{
				let roofFrameMeshes = [];
				let wallMeshesFront = [];
				let wallMeshesBack = [];

				let wallMeshesLeft = [];
				let wallMeshesRight = [];

				this.GenerateFrameRafters(roofFrameMeshes, wallMeshesFront, wallMeshesBack, wallMeshesLeft, wallMeshesRight);

				if (MetalBuildingRoof.IsVerticalMetalBuildingRoof())
					this.GenerateHorizontalRoofFraming(roofFrameMeshes);

				let totalGeom1 = new THREE.Geometry();

				for (i = 0; i < wallMeshesFront.length; i++)
				{
					totalGeom1.merge(wallMeshesFront[i].geometry);
				}

				let totalGeom2 = new THREE.Geometry();

				for (i = 0; i < wallMeshesBack.length; i++)
				{
					totalGeom2.merge(wallMeshesBack[i].geometry);
				}

				let totalGeom3 = null;

				if (wallMeshesLeft.length > 0)
				{
					totalGeom3 = new THREE.Geometry();

					for (i = 0; i < wallMeshesLeft.length; i++)
					{
						totalGeom3.merge(wallMeshesLeft[i].geometry);
					}
				}


				let totalGeom4 = null;

				if (wallMeshesRight.length > 0)
				{
					totalGeom4 = new THREE.Geometry();

					for (i = 0; i < wallMeshesRight.length; i++)
					{
						totalGeom4.merge(wallMeshesRight[i].geometry);
					}
				}

				let totalGeom5 = new THREE.Geometry();

				for (i = 0; i < roofFrameMeshes.length; i++)
				{
					totalGeom5.merge(roofFrameMeshes[i].geometry);
				}


				let mesh;

				mesh = GeometryUtilities.CreatePhongMeshFromGeometry(totalGeom1, this.rafterColor, texture1);

				mesh.castShadow = true;
				mesh.receiveShadow = true;

				mesh.type = ELEM_WALL_RAFTER;

				mesh.eWall = WALL_FRONT;

				buildingMeshes.push(mesh);


				mesh = GeometryUtilities.CreatePhongMeshFromGeometry(totalGeom2, this.rafterColor, texture1);

				mesh.castShadow = true;
				mesh.receiveShadow = true;

				mesh.type = ELEM_WALL_RAFTER;

				mesh.eWall = WALL_BACK;

				buildingMeshes.push(mesh);


				if (totalGeom3)
				{
					mesh = GeometryUtilities.CreatePhongMeshFromGeometry(totalGeom3, this.rafterColor, texture1);

					mesh.castShadow = true;
					mesh.receiveShadow = true;

					mesh.type = ELEM_WALL_RAFTER;

					mesh.eWall = WALL_LEFT;

					buildingMeshes.push(mesh);
				}

				if (totalGeom4)
				{
					mesh = GeometryUtilities.CreatePhongMeshFromGeometry(totalGeom4, this.rafterColor, texture1);

					mesh.castShadow = true;
					mesh.receiveShadow = true;

					mesh.type = ELEM_WALL_RAFTER;

					mesh.eWall = WALL_RIGHT;


					buildingMeshes.push(mesh);
				}

				mesh = GeometryUtilities.CreatePhongMeshFromGeometry(totalGeom5, this.rafterColor, texture2);

				mesh.castShadow = true;
				mesh.receiveShadow = true;

				mesh.type = ELEM_WALL_RAFTER;

				buildingMeshes.push(mesh);
			}

			this.regenerate = false;
		}
	};
}

MetalRafters.GetBentBowCurve = function (roofAngle, startX)
{
	let segmentCount = 10;

	let angleOfRotation = -(MathUtilities.PI / 2 - Math.atan(roofAngle));

	let x = startX;
	let y = 0;

	let segmentAngle = angleOfRotation / segmentCount;

	if (startX > 0)
		segmentAngle *= -1;

	let x2, y2;

	let curvePoints = [];

	for (let i = 0; i < segmentCount; i++)
	{
		x2 = x * Math.cos(segmentAngle) - y * Math.sin(segmentAngle);
		y2 = x * Math.sin(segmentAngle) + y * Math.cos(segmentAngle);

		curvePoints.push([x2, y2]);

		x = x2;
		y = y2;
	}

	return curvePoints;
};

MetalRafters.GetBentBowRafterPoints = function ()
{
	let points = buildingDesigner.building.roofRafter.data.rafter_spec;
	let start = buildingDesigner.building.roofRafter.sideCoordsIndices[0][1];
	let end = buildingDesigner.building.roofRafter.sideCoordsIndices[1][1];

	let newPoints = [];

	let frontRoofAngle = Math.tan(buildingDesigner.building.roofRafter.frontTanAngleRatio);
	let rearRoofAngle = Math.tan(buildingDesigner.building.roofRafter.rearTanAngleRatio);

	let frontCurvePoints = this.GetBentBowCurve(frontRoofAngle, -MetalRafters.BentBowRafterCurveRadius);
	let rearCurvePoints = this.GetBentBowCurve(rearRoofAngle, MetalRafters.BentBowRafterCurveRadius);

	let adj = MetalRafters.BentBowRafterCurveRadius + frontCurvePoints[frontCurvePoints.length - 1][0];
	let yOffset = -(frontCurvePoints[frontCurvePoints.length - 1][1] - adj * buildingDesigner.building.roofRafter.frontTanAngleRatio);

	let xOffset = MetalRafters.BentBowRafterCurveRadius + points[start][0];

	newPoints.push([points[start][0], points[start][1] + yOffset]);

	yOffset += points[start][1];

	for (let i = 0; i < frontCurvePoints.length; i++)
	{
		newPoints.push([frontCurvePoints[i][0] + xOffset, frontCurvePoints[i][1] + yOffset]);
	}

	for (let j = start + 1; j < end; j++)
	{
		newPoints.push(points[j]);
	}

	adj = MetalRafters.BentBowRafterCurveRadius - rearCurvePoints[rearCurvePoints.length - 1][0];
	yOffset = -(rearCurvePoints[rearCurvePoints.length - 1][1] - adj * buildingDesigner.building.roofRafter.rearTanAngleRatio);

	xOffset = -MetalRafters.BentBowRafterCurveRadius + points[end][0];

	yOffset += points[end][1];

	for (let i = rearCurvePoints.length - 1; i >= 0; i--)
	{
		newPoints.push([rearCurvePoints[i][0] + xOffset, rearCurvePoints[i][1] + yOffset]);
	}

	yOffset -= points[end][1];

	newPoints.push([points[end][0], points[end][1] + yOffset]);

	let xOff = newPoints[0][0];
	let yOff = newPoints[0][1];

	for (let i = 0; i < newPoints.length; i++)
	{
		newPoints[i][0] -= xOff;
		newPoints[i][1] -= yOff;
	}

	buildingDesigner.building.roofRafter.sideCoordsIndices[0][0] = 0;
	buildingDesigner.building.roofRafter.sideCoordsIndices[0][1] = 0;

	buildingDesigner.building.roofRafter.sideCoordsIndices[1][0] = newPoints.length - 1;
	buildingDesigner.building.roofRafter.sideCoordsIndices[1][1] = newPoints.length - 1;


	buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][0] = newPoints[buildingDesigner.building.roofRafter.sideCoordsIndices[0][0]][0];
	buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][1] = newPoints[buildingDesigner.building.roofRafter.sideCoordsIndices[0][0]][1];

	buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[1][0] = newPoints[buildingDesigner.building.roofRafter.sideCoordsIndices[0][1]][0] + buildingDesigner.building.roofRafter.data.thickness;
	buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[1][1] = newPoints[buildingDesigner.building.roofRafter.sideCoordsIndices[0][1]][1];


	buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[0][0] = newPoints[buildingDesigner.building.roofRafter.sideCoordsIndices[1][0]][0];
	buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[0][1] = newPoints[buildingDesigner.building.roofRafter.sideCoordsIndices[1][0]][1];

	buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[1][0] = newPoints[buildingDesigner.building.roofRafter.sideCoordsIndices[1][1]][0] - buildingDesigner.building.roofRafter.data.thickness;
	buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[1][1] = newPoints[buildingDesigner.building.roofRafter.sideCoordsIndices[1][1]][1];


	buildingDesigner.building.roofRafter.data.front_wall_attach_coord[0][0] = buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][0];
	buildingDesigner.building.roofRafter.data.front_wall_attach_coord[0][1] = buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][1];

	buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0] = buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][0];
	buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1] = buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][1];



	buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[0][0] = buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[0][0];
	buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[0][1] = buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[0][1];

	buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[1][0] = buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[0][0];
	buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[1][1] = buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[0][1];

	buildingDesigner.building.roofRafter.data.rafter_spec = newPoints;

	buildingDesigner.building.roofRafter.apexCoordsIndices = buildingDesigner.building.roofRafter.GetApexCoordIndices();

	buildingDesigner.building.roofRafter.roofHeight = buildingDesigner.building.roofRafter.data.rafter_spec[buildingDesigner.building.roofRafter.apexCoordsIndices[0]][1] - buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1];

	buildingDesigner.building.roofRafter.frontBackHeightDifference = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1] - buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[1][1];

	return newPoints;
};

MetalRafters.METAL_RAFTERS_COLOR = 0xBBBBBB;

MetalRafters.HORIZONTAL_ROOF_FRAMING_SPACING = 3;
MetalRafters.HORIZONTAL_ROOF_FRAMING_THICKNESS = 0.15;
MetalRafters.HORIZONTAL_ROOF_FRAMING_WIDTH = 0.3;
MetalRafters.HORIZONTAL_ROOF_FRAMING_SHIFT = MetalRafters.HORIZONTAL_ROOF_FRAMING_WIDTH * 2;

MetalRafters.BentBowRafterCurveRadius = 1.54;
