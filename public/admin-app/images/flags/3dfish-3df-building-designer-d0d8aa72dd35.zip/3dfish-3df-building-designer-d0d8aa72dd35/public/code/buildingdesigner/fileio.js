/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function FileIO()
{}

FileIO.fileExistsCache = [];

/**
 * This function is depricated and is being replaced by FileIO.FileExistsAsync
 */
FileIO.FileExists = function (urlToFile)
{
	if (FileIO.fileExistsCache[urlToFile] === undefined)
	{
		let xhr = new XMLHttpRequest();
		xhr.open("HEAD", urlToFile, false);
		xhr.send();

		if (xhr.status == "200")
		{
			FileIO.fileExistsCache[urlToFile] = true;
		}
		else if (xhr.status == "404")
		{
			FileIO.fileExistsCache[urlToFile] = false;
		}
		else
			FileIO.fileExistsCache[urlToFile] = false;
	}

	return FileIO.fileExistsCache[urlToFile];
};

/**
 * @function
 * @async
 */
FileIO.FileExistsAsync = async function (urlToFile)
{
	if (FileIO.fileExistsCache[urlToFile] === undefined)
	{
		try
		{
			result = await $.ajax({
				url: urlToFile,
				type: "HEAD",
				async: true
			});
			FileIO.fileExistsCache[urlToFile] = true;
		}
		catch (error)
		{
			FileIO.fileExistsCache[urlToFile] = false;
		}
	}
	return FileIO.fileExistsCache[urlToFile];
};

/**
 * Create the XHR object.
 * @function
 * @param {string} method
 * @param {string} url
 * @returns {object} XHR object or null if not supported
 */
function createCORSRequest(method, url)
{
	let xhr = new XMLHttpRequest();
	if ("withCredentials" in xhr)
	{
		// XHR for Chrome/Firefox/Opera/Safari.
		xhr.open(method, url, true);
	}
	else if (typeof XDomainRequest != "undefined")
	{
		// XDomainRequest for IE.
		xhr = new XDomainRequest();
		xhr.open(method, url);
	}
	else
	{
		// CORS not supported.
		xhr = null;
	}
	return xhr;
}

/**
 * Make the actual CORS request.
 * @function
 * @param {string} url
 */
function makeCorsRequest(url)
{
	// This is a sample server that supports CORS.
	//let url = 'http://html5rocks-cors.s3-website-us-east-1.amazonaws.com/index.html';

	let xhr = createCORSRequest("POST", url);
	if (!xhr)
	{
		alert("CORS not supported");
		return;
	}

	// Response handlers.
	xhr.onload = function ()
	{
		let text = xhr.responseText;
		let title = getTitle(text);
		alert("Response from CORS request to " + url + ": " + title);
	};

	xhr.onerror = function ()
	{
		alert("Woops, there was an error making the request.");
	};

	xhr.send();
}

FileIO.SendFormData = function (url, formData)
{
	try
	{
		let oRequest = new XMLHttpRequest();
		oRequest.open("POST", url, false);
		oRequest.send(formData);

		if (oRequest.status == 200)
		{
			return oRequest.responseText;
		}
		else
		{
			alert("Error Message 3DF-1024\nError executing XMLHttpRequest call! Status code:" + oRequest.status);
			$.post("/errorreport", {
				errorcode: "3DF-1024",
				statuscode: oRequest.status
			});

			return "";
		}
	}
	catch (ex)
	{
		return "";
	}
};

FileIO.GetFileData = async function (url, params, method)
{
	/* try {
		let oRequest = new XMLHttpRequest();

		if (params == null || params == undefined)
			params = "";

		if (method == null || method == undefined)
			method = "POST";

		if (method == "GET")
			url += "?" + params;

		oRequest.open(method, url, false);

		//Send the proper header information along with the request
		oRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

		oRequest.overrideMimeType("text/plain");

		if (method == "GET")
			oRequest.send();
		else
			oRequest.send(params);

		if (oRequest.status == 200) {
			return oRequest.responseText;
		} else {
			alert("Error Message 3DF-1025\nError executing XMLHttpRequest call! Status code:" + oRequest.status);
			$.post("/errorreport", {
				errorcode: "3DF-1025",
				statuscode: oRequest.status
			});

			return "";
		}
	} catch (ex) {
		return "";
	} */
	try
	{
		let result = await $.ajax({
			url: url,
			type: method,
			data: params
		});
		return result;
	}
	catch (error)
	{
		return "";
	}
};

FileIO.GetFileDataE = async function (url, params, method)
{
	try
	{
		let result = await $.ajax({
			url: url,
			type: method,
			data: params
		});
		return result;
	}
	catch (error)
	{
		throw (error);
	}
};

FileIO.GetFileDataS = function (command, params)
{
	return new Promise(function(resolve, reject)
	{
		socket.emit(command,params, function(data)
		{
			if (typeof data === "string" && data.length > 0)
			{
				resolve(JSON.parse(data));
			}
			else
			{
				resolve(data);
			}
		})
	})
};

FileIO.PGetFileData = async function (url, params, method)
{
	let result, err;

	[err, result] = await to($.ajax({
		url: url,
		type: method,
		data: params
	}));
	if (err)
	{
		alert("Error Message 3DF-1025-1\nError executing Server Request! Status code:" + err);
		$.post("/errorreport", {
			errorcode: "3DF-1025-1",
			statuscode: err
		});

		return "";
	}
	else
	{
		return result;
	}
	/*
	try
	{
		let oRequest = new XMLHttpRequest();

		if (params == null || params == undefined)
			params = "";

		if (method == null || method == undefined)
			method = "POST";

		if (method == "GET")
			url += "?" + params;

		oRequest.open(method,url,false);

		//Send the proper header information along with the request
		oRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

		oRequest.overrideMimeType("text/plain");

		if (method == "GET")
			oRequest.send();
		else
			oRequest.send(params);

		if (oRequest.status==200)
		{
			return oRequest.responseText;
		}
		else
		{
			alert("Error Message 3DF-1025\nError executing XMLHttpRequest call! Status code:" + oRequest.status);
			$.post("/errorreport", { errorcode: "3DF-1025", statuscode: oRequest.status });

			return "";
		}
	}
	catch (ex)
	{
		return "";
	} */
};
