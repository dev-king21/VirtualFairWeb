/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/

function Elements()
{

}

Elements.loadedObjectData = [];

Elements.list = [];

this.elementMeshes = [];

this.draggableElement = null;

this.regenerate = true;

Elements.GetElementTypeCount = function (type)
{
	let count = 0;

	for (let i = 0; i < this.list.length; i++)
	{
		if (this.list[i].buttonData.type == type)
			count++;
	}

	return count;
};

/**
 * @function
 * @returns {string} XML Objects Design string
 */
Elements.GetObjectsDesignXMLString = function ()
{
	let elementObjectDataArray, elementsObjectDataArray = [];

	let uniqueElements = [];

	for (let i = 0; i < this.list.length; i++)
	{
		if (uniqueElements.indexOf(this.list[i].buttonData.elem_ID) == -1)
		{
			uniqueElements.push(this.list[i].buttonData.elem_ID);

			elementObjectDataArray = this.list[i].GetObjectsData();

			elementsObjectDataArray = AuxUtilities.MergeArrays(elementsObjectDataArray, elementObjectDataArray);
		}
	}

	elementsObjectDataArray = elementsObjectDataArray.filter(function onlyUnique(value, index, self)
	{
		return self.indexOf(value) === index;
	});

	let strXml = "<OBJECTS_LIST>";

	for (let i = 0; i < elementsObjectDataArray.length; i++)
	{
		strXml += "<OBJECT data=\"";

		elementsObjectDataArray[i] = TextDataUtilities.ReplaceAll(elementsObjectDataArray[i], "\"", TextDataUtilities.INVERTED_COMMA_CODE);
		elementsObjectDataArray[i] = TextDataUtilities.ReplaceAll(elementsObjectDataArray[i], "&", TextDataUtilities.AMPERSAND_CODE);

		strXml += elementsObjectDataArray[i];

		strXml += "\">";
		strXml += "</OBJECT>";
	}

	strXml += "</OBJECTS_LIST>";

	return strXml;
};

/**
 * @function
 * @returns {Object} Objects object for saving
 */
Elements.GetObjectsDesignObject = function ()
{
	designObject = {};
	let elementObjectDataArray, elementsObjectDataArray = [];

	let uniqueElements = [];

	for (let i = 0; i < this.list.length; i++)
	{
		this.list[i].buttonData.elem_id = this.list[i].buttonData.elem_id ? this.list[i].buttonData.elem_id:this.list[i].buttonData.elem_ID;
		if (uniqueElements.indexOf(this.list[i].buttonData.elem_id) == -1)
		{
			uniqueElements.push(this.list[i].buttonData.elem_id);

			elementObjectDataArray = this.list[i].GetObjectsDataObject();

			elementsObjectDataArray = AuxUtilities.MergeArrays(elementsObjectDataArray, elementObjectDataArray);
		}
	}

	elementsObjectDataArray = elementsObjectDataArray.filter(function onlyUnique(value, index, self)
	{
		return self.indexOf(value) === index;
	});

	designObject.OBJECT = elementsObjectDataArray;
	return designObject;
};

/**
 * @method
 * @returns {string} XML Elements Design string
 */
Elements.GetDesignXMLString = function ()
{
	let strXml = "<ELEMENTS_LIST>";

	for (let i = 0; i < this.list.length; i++)
	{
		strXml += this.list[i].GetDesignXMLString();
	}

	strXml += "</ELEMENTS_LIST>";

	return strXml;
};

/**
 * @method
 * @returns {Object} Elements List Object
 */
Elements.GetDesignObject = function ()
{
	let designObject = {};
	designObject.ELEMENT = [];
	for (let i = 0; i < this.list.length; i++)
	{
		designObject.ELEMENT[i] = this.list[i].GetDesignObject();
	}
	return designObject;
};

Elements.LoadObjectsFromXML = function (xmlDesignDoc)
{
	Elements.loadedObjectData = [];

	let nodeObjectsList = xmlDesignDoc.getElementsByTagName("OBJECTS_LIST");

	if (nodeObjectsList.length > 0)
	{
		let nodeObjects = nodeObjectsList[0].getElementsByTagName("OBJECT");

		let objectData;

		for (let i = 0; i < nodeObjects.length; i++)
		{
			objectData = nodeObjects[i].getAttribute("data");

			Elements.loadedObjectData.push(AuxUtilities.JSONDecodeAndParse(objectData));
		}
	}
};

/**
 * @function Elements.LoadObjectsFromObject
 * @param {Object} building savedDesignObject.TDFDESIGN.BUILDING
 */
Elements.LoadObjectsFromObject = function (building)
{
	if (building.OBJECTS_LIST && building.OBJECTS_LIST.OBJECT)
	{
		Elements.loadedObjectData = building.OBJECTS_LIST.OBJECT;
	}
};

Elements.LoadElementsFromXML = function (xmlDesignDoc)
{
	let nodesElementList = xmlDesignDoc.getElementsByTagName("ELEMENTS_LIST");

	if (nodesElementList.length > 0)
	{
		let nodeElements = nodesElementList[0].getElementsByTagName("ELEMENT");

		for (let i = 0; i < nodeElements.length; i++)
		{
			Elements.LoadElementFromXML(nodeElements[i]);
		}
	}

	Elements.draggableElement = null;

	Elements.Initialize();
};

/**
 * @function Elements.LoadElementsFromObject
 * @param {Object} building savedDesignObject.TDFDESIGN.BUILDING
 */
Elements.LoadElementsFromObject = function (building)
{
	for (let i = 0; i < building.ELEMENTS_LIST.ELEMENT.length; i++)
	{
		if (building.ELEMENTS_LIST.ELEMENT[i].buttonData)
		{
			Elements.LoadElementFromObject(building.ELEMENTS_LIST.ELEMENT[i]);
		}
	}
	Elements.draggableElement = null;
	Elements.Initialize();
};

Elements.LoadElementFromXML = function (nodeElement)
{
	let buttonData = nodeElement.getAttribute("buttonData");

	if (buttonData == "undefined" || buttonData == "null")
	{
		buttonData = null;
	}

	if (buttonData)
	{
		buttonData = TextDataUtilities.ReplaceAll(buttonData, TextDataUtilities.INVERTED_COMMA_CODE, "\"");
		buttonData = AuxUtilities.JSONDecodeAndParse(decodeURI(buttonData));
	}

	////let elemType = nodeElement.getAttribute("type");
	////let elem_ID = nodeElement.getAttribute("elem_ID");
	////let object3D_ID = nodeElement.getAttribute("object3D_ID");

	if (LoadingSavingUtilities.loadingDefaultBuilding)
	{
		let elemIndex = Elements.defaultElements.indexOfObject("elemID", buttonData.elem_ID);

		if (elemIndex == -1)
		{
			Elements.defaultElements.push({
				elemID: buttonData.elem_ID,
				count: 1
			});
		}
		else
		{
			Elements.defaultElements[elemIndex].count++;
		}
	}


	let wall = nodeElement.getAttribute("wall");
	let configurationMode = Number(nodeElement.getAttribute("configurationMode"));
	let x = Number(nodeElement.getAttribute("x"));
	let y = Number(nodeElement.getAttribute("y"));
	let z = Number(nodeElement.getAttribute("z"));

	let colorID = nodeElement.getAttribute("colorID");
	let colorFromBarn = nodeElement.getAttribute("color_from_barn");

	if (colorFromBarn == "true")
	{
		colorFromBarn = true;
	}
	else
	{
		if (colorFromBarn == "false")
		{
			colorFromBarn = false;
		}
	}


	let trimColor = nodeElement.getAttribute("trimColor");

	if (trimColor == "undefined" || trimColor == "null")
	{
		trimColor = null;
	}


	let defaultElementData = nodeElement.getAttribute("defaultElementData");

	if (defaultElementData == "undefined" || defaultElementData == "null")
	{
		defaultElementData = null;
	}

	if (defaultElementData)
	{
		defaultElementData = TextDataUtilities.ReplaceAll(defaultElementData, TextDataUtilities.INVERTED_COMMA_CODE, "\"");
		defaultElementData = AuxUtilities.tryParseJSON(decodeURI(defaultElementData));
	}


	let element = null;

	////let buttonData = GuiDataUtilities.GetButtonData(elem_ID);
	// *** TODO: add error reporting for missing elements
	// *** TODO: if elements fail to load for browser saved building create timer to retry after browser has had time to load elements

	switch (ELEM_STRING[buttonData.type])
	{
	case ("Door"):
	{
		element = Door.AddDoor(buttonData, configurationMode);

		if (!element)
		{
			AuxUtilities.sleep(500);
			let count = 0;
			while ((!element) && (count < 20))
			{
				AuxUtilities.sleep(500);
				element = Door.AddDoor(buttonData, configurationMode);
				count++;
			}
		}
		if (!element)
		{
			console.log("Not able to set door element.");
			break;
		}
		element.SetColorID(colorID);

		element.colorFromBarn = colorFromBarn;

		element.trimColor = trimColor;



		let hingeButtonData = nodeElement.getAttribute("hingeButtonData");

		if (hingeButtonData == "undefined" || hingeButtonData == "null")
		{
			hingeButtonData = null;
		}

		if (hingeButtonData)
		{
			hingeButtonData = TextDataUtilities.ReplaceAll(hingeButtonData, TextDataUtilities.INVERTED_COMMA_CODE, "\"");
			hingeButtonData = AuxUtilities.JSONDecodeAndParse(decodeURI(hingeButtonData));

			////let hinge = new Hinge(hingeButtonData);

			////element.SetCurrentHinge(hinge);

			element.CreateHinges(hingeButtonData);
		}

		let rampID = nodeElement.getAttribute("rampID");

		if (rampID)
		{
			element.rampID = rampID;
		}

		break;
	}
	case ("Run-In"): {
		element = Door.AddDoor(buttonData, configurationMode);

		if (!element)
		{
			console.log("Not able to set door element.");
			break;
		}
		element.SetColorID(colorID);

		element.colorFromBarn = colorFromBarn;
		break;
	}

	case ("Window"): {
		element = Window.AddWindow(buttonData);

		if (!element)
		{
			console.log("Not able to set window element.");
			break;
		}
		element.trimColor = trimColor;

		break;
	}

	case ("Option"): {
		element = Option.AddOption(buttonData);
		break;
	}

	case ("Ridge Vent"): {
		element = RidgeVent.AddRidgeVent(buttonData);
		break;
	}

	case ("Ramp"): {
		let rampID = nodeElement.getAttribute("rampID");

		element = Ramp.AddRamp(buttonData);
		if (!element)
		{
			console.log("Not able to set ramp element.");
			break;
		}
		if (rampID)
		{
			element.rampID = rampID;
		}
		break;
	}
	case ("Anchors"): {
		element = Anchors.AddAnchors(buttonData);
		break;
	}

	case ("Coated Floor"):
	case ("Armorthane Floor"): {
		element = CoatedFloor.AddCoatedFloor(buttonData);
		break;
	}

	case ("Wall Extension"): {
		element = WallExtension.AddWallExtension(buttonData);
		break;
	}

	case ("Shelf"):
		element = Shelf.AddShelf(buttonData);
		break;

	case ("Dormer"):
		element = Dormer.AddDormer(buttonData);
		break;

	case ("Hip Roof"):
		element = HipRoof.AddHipRoof(buttonData);
		break;

	case ("Leg Braces"):
		element = LegBraces.AddLegBraces(buttonData);
		break;
	}

	if (element)
	{
		element.defaultElementData = defaultElementData;

		element.buttonData = buttonData;

		if (wall)
		{
			element.SetWall(buildingDesigner.building.walls.GetWall(WALL_STRING.indexOf(wall)));

			element.SetPos(x, y, z);

			/*////if (element.wall.eWall == WALL_RIGHT || element.wall.eWall == WALL_FRONT)
				element.SetPos(x, y, Wall.WALLTHICKNESS);
			else
				element.SetPos(x, y, -Wall.WALLTHICKNESS);
				*/
		}
	}
};

/**
 * @function Elements.LoadElementFromObject
 * @param {Object} element
 */
Elements.LoadElementFromObject = function (elementObj)
{

	if (LoadingSavingUtilities.loadingDefaultBuilding)
	{
		let elemIndex = Elements.defaultElements.indexOfObject("elemID", elementObj.buttonData.elem_id);

		if (elemIndex == -1)
			Elements.defaultElements.push({
				elemID: elementObj.buttonData.elem_id,
				count: 1
			});
		else
			Elements.defaultElements[elemIndex].count++;
	}

	let element = null;

	////let buttonData = GuiDataUtilities.GetButtonData(elem_ID);
	// *** TODO: add error reporting for missing elements
	// *** TODO: if elements fail to load for browser saved building create timer to retry after browser has had time to load elements

	switch (ELEM_STRING[elementObj.buttonData.type])
	{
	case ("Door"):
	{
		element = Door.AddDoor(elementObj.buttonData, elementObj.configurationMode);

		if (!element)
		{
			AuxUtilities.sleep(500);
			let count = 0;
			while ((!element) && (count < 20))
			{
				AuxUtilities.sleep(500);
				element = Door.AddDoor(elementObj.buttonData, elementObj.configurationMode);
				count++;
			}
		}
		if (!element)
		{
			console.log("Not able to set door element.");
			break;
		}
		element.SetColorID(elementObj.colorID);

		element.colorFromBarn = elementObj.colorFromBarn;

		element.trimColor = elementObj.trimColor;

		if (elementObj.hingeButtonData)
		{
			////let hinge = new Hinge(elementObj.hingeButtonData);
			////element.SetCurrentHinge(hinge);
			element.CreateHinges(elementObj.hingeButtonData);
		}

		if (elementObj.rampID)
		{
			element.rampID = elementObj.rampID;
		}

		break;
	}
	case ("Run-In"):
	{
		element = Door.AddDoor(elementObj.buttonData, elementObj.configurationMode);

		if (!element)
		{
			console.log("Not able to set door element.");
			break;
		}
		element.SetColorID(elementObj.colorID);

		element.colorFromBarn = elementObj.colorFromBarn;
		break;
	}
	case ("Window"):
	{
		element = Window.AddWindow(elementObj.buttonData);

		if (!element)
		{
			console.log("Not able to set window element.");
			break;
		}
		element.trimColor = elementObj.trimColor;

		break;
	}
	case ("Option"):
	{
		element = Option.AddOption(elementObj.buttonData);
		break;
	}
	case ("Ridge Vent"):
	{
		element = RidgeVent.AddRidgeVent(elementObj.buttonData);
		break;
	}
	case ("Ramp"):
	{
		element = Ramp.AddRamp(elementObj.buttonData);
		if (!element)
		{
			console.log("Not able to set ramp element.");
			break;
		}
		if (elementObj.rampID)
		{
			element.rampID = elementObj.rampID;
		}
		break;
	}
	case ("Anchors"):
	{
		element = Anchors.AddAnchors(elementObj.buttonData);
		break;
	}
	case ("Armorthane Floor"):
	case ("Coated Floor"):
	{
		element = CoatedFloor.AddCoatedFloor(elementObj.buttonData);
		break;
	}
	case ("Wall Extension"): {
		element = WallExtension.AddWallExtension(elementObj.buttonData);
		break;
	}
	case ("Shelf"):
	{
		element = Shelf.AddShelf(elementObj.buttonData);
		break;
	}
	case ("Dormer"):
	{
		element = Dormer.AddDormer(elementObj.buttonData);
		break;
	}
	case ("Hip Roof"):
	{
		element = HipRoof.AddHipRoof(elementObj.buttonData);
		break;
	}
	case ("Leg Braces"):
	{
		element = LegBraces.AddLegBraces(elementObj.buttonData);
		break;
	}
	}

	if (element)
	{
		element.defaultElementData = elementObj.defaultElementData;

		element.buttonData = elementObj.buttonData;

		if (typeof elementObj.wall !== "undefined")
		{
			if (element.buttonData.type != ELEM_DORMER)
			{
				if (typeof elementObj.facetIndex === "undefined")
				{
					elementObj.facetIndex = 0;
				}

				element.SetWall(buildingDesigner.building.walls.GetWall(elementObj.wall), elementObj.facetIndex);
			}

			element.SetPos(elementObj.x, elementObj.y, elementObj.z);
		}
	}
};

Elements.Initialize = function ()
{
	for (let i = 0; i < this.list.length; i++)
	{
		this.list[i].Initialize();
	}

	buildingDesigner.building.SetRegenerateElementMeshes(true);
};

Elements.AddElement = function (element)
{

	if ((buildingDesigner.xmlDesignDoc == undefined || buildingDesigner.xmlDesignDoc == null ) && buildingDesigner.savedDesignObject == undefined)
	{
		let defaultElementIndex = Elements.defaultElements.indexOfObject("elemID", element.buttonData.elem_id);

		if (defaultElementIndex > -1)
		{
			let defaultElementCount = Elements.defaultElements[defaultElementIndex].count;

			let existingElementCount = Elements.GetElementCount(element.buttonData.elem_ID);

			if (existingElementCount < defaultElementCount && element.buttonData.removal_discount)
				buildingDesigner.building.discount -= element.buttonData.removal_discount;
		}
	}

	this.list.push(element);

	element.SetRegenerate(true);

	////element.regenerate = true;

	Elements.draggableElement = element;

	//buildingDesigner.building.SetRegenerateElementMeshes(true);

	//buildingDesigner.building.SetBuildingModified();

	return this.list.length;
};

Elements.ClearSelections = function ()
{
	$("#selectedElementName").text("");
	$("#editorComponentName").text("");
	$("#editorObjectID").text("");
	if (Elements.editableComponent)
	{
		Elements.editableComponent.selected = false;
		Elements.editableComponent = null;
	}

	for (let i = 0; i < this.list.length; i++)
	{
		this.list[i].ClearSelections();
	}
};

Elements.SelectElement = function (element)
{
	element.selected = true;
	$("#selectedElementName").text(element.buttonData.elem_id);
	if (typeof element.index !== "undefined")
	{
		$(`.element_${element.index}`).addClass("element_selected");
	}
};

Elements.GetSelectedElement = function ()
{
	for (let i = 0; i < this.list.length; i++)
	{
		if (this.list[i].selected)
			return this.list[i];
	}

	return null;
};

Elements.StartDraggingElement = function (element)
{
	buildingDesigner.building.ClearSelections();

	buildingDesigner.building.walls.SetMouseOverTransparency(0.0);

	this.draggableElement = element;

	Elements.SelectElement(element);

	this.draggableElement.StartDragging();
};


Elements.DraggingElement = function (wall, facetIndex, vectorPos)
{
	this.draggableElement.DraggingElement(wall, facetIndex, vectorPos);
};

Elements.SetRegenerate = function (regenerate)
{
	this.regenerate = regenerate;

	for (let i = 0; i < this.list.length; i++)
	{
		if (this.list[i])
			this.list[i].regenerate = this.regenerate;
	}
};

Elements.SetUpdateElementMatrices = function (updateMatrices)
{
	this.updateElementMatrices = updateMatrices;
};

Elements.Generate = function (buildingMeshes)
{
	let elementsMesh = null;

	if (this.regenerate && this.list.length > 0)
	{
		elementsMesh = new THREE.Mesh();
		let elementMesh = null;

		/*////for (let i = 0; i < this.list.length; i++)
		{
			if (!this.list[i].dragging)
			{
				elementMesh = this.list[i].Generate(buildingMeshes);

				if (elementMesh)
					elementsMesh.add(elementMesh);
			}
		}*/


		////let i = this.list.length - 1;
		for (let i = 0; i < this.list.length; i++)
		{
			if (!this.list[i].dragging)
			{
				////elementMesh = this.list[i].Generate(buildingMeshes, this.list[i].dragged ? true : false);
				elementMesh = this.list[i].Generate(buildingMeshes, true);

				this.list[i].dragged = false;

				if (elementMesh)
					elementsMesh.add(elementMesh);
			}
		}

		////elementsMesh = MeshUtilities.MergeMeshGeometry(elementsMesh);

		elementsMesh.castShadow = true;

		if (buildingDesigner.camera.modeCamera == Camera.CAM_MODE_INTERIOR)
			elementsMesh.receiveShadow = false;
		else
			elementsMesh.receiveShadow = true;

		for (let i = 0; i < this.list.length; i++)
		{
			if (this.list[i].dragging)
			{
				elementMesh = this.list[i].Generate(buildingMeshes);


				/*let type = elementMesh.type;

			    let element = elementMesh.element;

			    let castShadow = elementMesh.castShadow;

			    let receiveShadow = elementMesh.receiveShadow;

			    let visible = elementMesh.visible;

			    let originalMtx = elementMesh.matrix.clone();

			    let inverseMtx = new THREE.Matrix4().getInverse(originalMtx);

				elementMesh.matrixAutoUpdate = false;
				elementMesh.applyMatrix4(inverseMtx);

			    elementMesh = MeshUtilities.MergeMeshGeometry(elementMesh);

				elementMesh.matrixAutoUpdate = false;
				elementMesh.applyMatrix4(originalMtx);

			    elementMesh.type = type;

			    MeshUtilities.SetElement(elementMesh, element);

			    elementMesh.castShadow = castShadow;

			    elementMesh.receiveShadow = receiveShadow;

			    elementMesh.visible = visible;
                */


				if (elementMesh)
				{
					elementsMesh.add(elementMesh);
				}
			}
		}

		this.regenerate = false;
	}

	return elementsMesh;
};

Elements.UpdateElementMatrices = function ()
{
	if (this.updateElementMatrices)
	{
		for (let i = 0; i < this.list.length; i++)
		{
			this.list[i].UpdateMatrix();
		}

		this.updateElementMatrices = false;
	}
};

Elements.GetElementData = function (object3D_ID)
{
	for (let i = 0; i < this.list.length; i++)
	{
		if (this.list[i].object3D_ID == object3D_ID)
			return this.list[i];
	}

	return null;
};

Elements.GetElementCount = function (elem_ID)
{
	let count = 0;

	for (let i = 0; i < this.list.length; i++)
	{
		if (this.list[i].buttonData.elem_ID == elem_ID)
			count++;
	}

	return count;
};

Elements.IsElementInCollision = function (element)
{
	let elemPoints1 = element.GetElementPointsOnWall();

	let elemPoints2;

	for (let i = 0; i < this.list.length; i++)
	{
		if (!this.list[i].wall || this.list[i] == element || (this.list[i].wall && element.wall && this.list[i].wall.eWall != element.wall.eWall) || this.list[i].dormer || this.list[i].buttonData.type == ELEM_DORMER || (this.rampID && this.list[i].rampID && this.rampID == this.list[i].rampID) || this.list[i].buttonData.type == ELEM_ANCHORS || element.facetIndex != this.list[i].facetIndex)
			continue;

		elemPoints2 = this.list[i].GetElementPointsOnWall();

		if (GeometryUtilities.IsCollision(elemPoints1, elemPoints2))
			return this.list[i];
	}

	return null;
};

Elements.IsElementInsideWall = function (element)
{
	let elemPoints = element.GetElementPointsOnWall();
	////let wallPoints = element.wall.wallsPtsForElements;

	if (element.buttonData.options && element.buttonData.options.padding_x)
	{
		let addx = element.buttonData.options.padding_x;
		elemPoints[0].x -= addx;
		elemPoints[1].x -= addx;
		elemPoints[2].x += addx;
		elemPoints[3].x += addx;
	}

	if (element.buttonData.options && element.buttonData.options.padding_y)
	{
		let addy = element.buttonData.options.padding_y;
		elemPoints[1].y += addy;
		elemPoints[2].y += addy;
	}

	let wallPoints;

	if (element.facetIndex != undefined && element.wall.wallFacets != undefined && element.wall.wallFacets[element.facetIndex])
	{
		wallPoints = element.wall.wallFacets[element.facetIndex].wallsPtsForElements;
	}
	else
	{
		wallPoints = element.wall.wallsPtsForElements;
	}

	for (let i = 0; i < elemPoints.length; i++)
	{
		if (!GeometryUtilities.IsPointInside(elemPoints[i], wallPoints))
		{
			return false;
		}
	}

	return true;
};

Elements.GetElementsOnWall = function (eWall, type)
{
	if (type == undefined)
		type = null;

	let elementsArray = [];

	for (let i = 0; i < this.list.length; i++)
	{
		if ((this.list[i].buttonData.type == type || type == null) && (this.list[i].wall && this.list[i].wall.eWall == eWall))
		{
			elementsArray.push(this.list[i]);
		}
	}

	return elementsArray;
};

Elements.GetWindowsOnWall = function (eWall)
{
	let windowArray = [];
	for (let i = 0; i < this.list.length; i++)
	{
		if (this.list[i].buttonData.type == ELEM_WINDOW && this.list[i].wall && this.list[i].wall.eWall == eWall)
		{
			windowArray.push(this.list[i]);
		}
	}

	return windowArray;
};

Elements.GetElementsOfType = function (type)
{
	let elementArray = [];

	for (let i = 0; i < this.list.length; i++)
	{
		if (this.list[i].buttonData.type == type)
		{
			elementArray.push(this.list[i]);
		}
	}

	if (elementArray.length > 0)
		return elementArray;

	return null;
};

Elements.GetElementCountOfType = function (type)
{
	let count = 0;

	for (let i = 0; i < this.list.length; i++)
	{
		if (this.list[i].buttonData.type == type)
		{
			count++;
		}
	}

	return count;
};

Elements.ProcessCollisions = function (element)
{
	element.SetCollision(false);

	let collidingObject = Elements.IsElementInCollision(element);

	if (collidingObject || !Elements.IsElementInsideWall(element))
	{
		element.SetCollision(true, collidingObject);
	}
	else
	if (BuildingDesigner.buildingType == BUILDING_CARPORT && element.buttonData.type != ELEM_DOOR)
	{
		let adjRafters = element.GetClosestWallRafterCoords();

		if (adjRafters.rightCoordIndex - adjRafters.leftCoordIndex > 1)
			element.SetCollision(true);
	}

	return element.collision;
};

Elements.SetEditableComponent = function (component)
{
	if (this.editableComponent)
	{
		this.editableComponent.selected = false;
		this.editableComponent = null;
	}

	if (!component.parentObject.parentObject.loadedObjectFromDesign)
	{
		this.editableComponent = component;
		component.selected = true;
		$("#editorComponentName").text(component.objectData.object3D_ID);
		$("#editorObjectID").text(component.objectData.id);
	}
	else
		alert("Elements cannot be modified that were loaded from a saved design, including browser refreshes, since the saved designs contain their own object data and won't update the database.\n\nPlace a new element in order to modify it.");
};

Elements.UpdateModifiedElements3DObjects = function ()
{
	for (let i = 0; i < this.list.length; i++)
	{
		this.list[i].UpdateModifiedElements3DObjects();
	}
};

Elements.RotateComponent = function (mousePos, component)
{
	let vecDelta = new THREE.Vector2().subVectors(mousePos, GUIInput.vecLastMousePos);

	if (vecDelta.x != 0 || vecDelta.y != 0)
	{
		vecDelta.x = vecDelta.x / 1000.0;
		vecDelta.y = vecDelta.y / 1000.0;

		if (buildingDesigner.camera.modeCamera == Camera.CAM_MODE_INTERIOR)
		{
			if (GUIInput.currentEditModeAxis == GUIInput.OBJECT_EDIT_AXIS_MODE.X || GUIInput.currentEditModeAxis == GUIInput.OBJECT_EDIT_AXIS_MODE.Z)
			{
				vecDelta.x *= -1;
				vecDelta.y *= -1;
			}
		}

		component.Rotate(!GUIInput.currentEditModeAxis, GUIInput.OBJECT_EDIT_AXIS_MODE.Y & GUIInput.currentEditModeAxis, GUIInput.OBJECT_EDIT_AXIS_MODE.Z & GUIInput.currentEditModeAxis, GUIInput.currentEditModeAxis ? ((GUIInput.OBJECT_EDIT_AXIS_MODE.Z & GUIInput.currentEditModeAxis) ? -1 * vecDelta.x : vecDelta.x) : vecDelta.y);
	}
};


Elements.TranslateComponent = function (mousePos, component)
{
	let vecDelta = new THREE.Vector2().subVectors(mousePos, GUIInput.vecLastMousePos);

	if (vecDelta.x != 0 || vecDelta.y != 0)
	{

		vecDelta.x /= 10;
		vecDelta.y /= 10;

		if (buildingDesigner.camera.modeCamera == Camera.CAM_MODE_INTERIOR)
		{
			if (GUIInput.currentEditModeAxis == GUIInput.OBJECT_EDIT_AXIS_MODE.X || GUIInput.currentEditModeAxis == GUIInput.OBJECT_EDIT_AXIS_MODE.Z || GUIInput.currentEditModeAxis == GUIInput.OBJECT_EDIT_AXIS_MODE.XY)
			{
				vecDelta.x *= -1;
				vecDelta.y *= -1;
			}
		}

		switch (GUIInput.currentEditModeAxis)
		{
		case (GUIInput.OBJECT_EDIT_AXIS_MODE.X):
			component.Translate(vecDelta.x, 0, 0);
			break;

		case (GUIInput.OBJECT_EDIT_AXIS_MODE.XY):
			component.Translate(vecDelta.x, -vecDelta.y, 0);
			break;

		case (GUIInput.OBJECT_EDIT_AXIS_MODE.Y):
			component.Translate(0, -vecDelta.y, 0);
			break;

		case (GUIInput.OBJECT_EDIT_AXIS_MODE.Z):
			component.Translate(0, 0, vecDelta.y);
			break;
		}
	}
};

Elements.ScaleComponent = function (mousePos, component)
{
	let vecDelta = new THREE.Vector2().subVectors(mousePos, GUIInput.vecLastMousePos);

	if (vecDelta.y != 0)
	{
		vecDelta.y = -vecDelta.y / 1000.0;

		component.Scale(vecDelta.y, vecDelta.y, vecDelta.y);
	}
};

Elements.DeleteElementByIndex = function (index)
{
	if (this.list[index])
	{
		let temp = this.list[index];

		this.list[index] = null;

		temp.Destroy();
	}

	Elements.ClearNulls();
};

Elements.DeleteElement = function (element)
{
	for (let i = 0; i < this.list.length; i++)
	{
		if (this.list[i] == element)
		{
			this.DeleteElementByIndex(i);
			break;
		}
	}
};

Elements.DeleteSelectedElement = function ()
{
	for (let i = 0; i < this.list.length; i++)
	{
		if (this.list[i].selected)
		{
			/*////if (this.list[i].defaultElementData)
				buildingDesigner.building.discount += this.list[i].defaultElementData.removal_discount;
                */

			let defaultElementIndex = Elements.defaultElements.indexOfObject("elemID", this.list[i].buttonData.elem_ID);

			if (defaultElementIndex > -1)
			{
				let existingElementCount = Elements.GetElementCount(this.list[i].buttonData.elem_ID);

				let defaultElementCount = Elements.defaultElements[defaultElementIndex].count;

				if (existingElementCount <= defaultElementCount && this.list[i].buttonData.removal_discount)
					buildingDesigner.building.discount += this.list[i].buttonData.removal_discount;
			}

			let elemType = this.list[i].buttonData.type;
			Elements.DeleteElementByIndex(i);

			if (elemType === ELEM_DORMER)
			{
				buildingDesigner.building.dormer = null;
			}
			break;
		}
	}
};

Elements.DeleteAllElements = function ()
{
	for (let i = this.list.length - 1; i >= 0; i--)
	{
		Elements.DeleteElementByIndex(i);
	}

	Elements.ClearNulls();
};

Elements.ClearNulls = function ()
{
	for (let i = 0; i < this.list.length; i++)
	{
		if (!this.list[i])
		{
			this.list.splice(i, 1);
			i--;
		}
	}
};


Elements.defaultElements = [];
