/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function WoodRafters(thickness, wallRafterWidth)
{
	if (!wallRafterWidth)
	{
		wallRafterWidth = Rafter.WALL_WOOD_RAFTER_WIDTH;
		buildingDesigner.building.roofRafter.data.width = Rafter.WALL_WOOD_RAFTER_WIDTH;
	}

	this.wallRafterHeight = buildingDesigner.building.height - Floor.FLOOR_THICKNESS;

	////if (WoodRafters.framing == WoodRafters.Oak_4ft)
	/*////if (buildingDesigner.building.walls.sidingColorData && buildingDesigner.building.walls.sidingColorData.category_id=="ERPBB")
		max_gap = 4;
		*/

	Rafters.call(this, thickness, wallRafterWidth);

	this.materRafter = new THREE.MeshBasicMaterial({
		color: this.rafterColor,
		map: null
	});

	this.CreateHorizontalWallRafter = function(length)
	{
		let geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(length, this.thickness, this.wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);

		return geomWallRafter;
	}

	this.CreateVerticalWallRafter = function()
	{
		let geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(this.wallRafterWidth, this.wallRafterHeight - this.thickness * 2, this.thickness, TexturesDataUtilities.AssignUVsToGeometryXY);

		return geomWallRafter;
	}

	/**
	 * @method WoodRafters.CreateWallFraming
	 * @param wallSpecification - contains the wall data for generating the framing
	 * @param extraWidth - required when the framing should extend beyond the wall width
	 * to connect with the adjoining wall
	 * @returns {THREE.Mesh} 3D mesh object for the framing
	 */
	this.CreateWallFraming = function(wallSpecification, extraWidth = 0)
	{
		let numberOfRafters = wallSpecification.width / WoodRafters.max_gap;

		let inc = wallSpecification.width / numberOfRafters;

		let geomWallRafter;

		let geomRafters = [];

		let startX = -wallSpecification.width / 2;

		let mesh = new THREE.Mesh();

		let totalGeom = new THREE.Geometry();


		let offs;

		geomWallRafter = buildingDesigner.building.rafters.CreateHorizontalWallRafter(wallSpecification.width + extraWidth);

		geomWallRafter.matrixAutoUpdate = false;
		geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(extraWidth/2, Floor.FLOOR_THICKNESS, 0));

		totalGeom.merge(geomWallRafter);


		let matrix = new THREE.Matrix4().makeRotationY(MathUtilities.PI2);

		for (i = 0; i <= numberOfRafters; i++)
		{
			offs = startX + inc * i;

			geomWallRafter = buildingDesigner.building.rafters.CreateVerticalWallRafter();

			geomWallRafter.matrixAutoUpdate = false;
			geomWallRafter.applyMatrix4(new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(offs, Floor.FLOOR_THICKNESS + this.thickness, 0), matrix));

			totalGeom.merge(geomWallRafter);
		}


		geomWallRafter = buildingDesigner.building.rafters.CreateHorizontalWallRafter(wallSpecification.width + extraWidth);

		geomWallRafter.matrixAutoUpdate = false;
		geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(extraWidth/2, Floor.FLOOR_THICKNESS + this.wallRafterHeight - this.thickness, 0));

		totalGeom.merge(geomWallRafter);

		let zCoord =  wallSpecification.coord.z * (wallSpecification.eWall == WALL_LEFT || wallSpecification.eWall == WALL_BACK ? -1 : 1);

		matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(wallSpecification.coord.x, wallSpecification.coord.y, zCoord), new THREE.Matrix4().makeRotationY(-wallSpecification.angle));


		switch (wallSpecification.eWall)
		{
		case (WALL_FRONT):
			matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 + this.wallRafterWidth/2, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2)), matrix);
			break;

		case (WALL_BACK):
			matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 - this.wallRafterWidth/2, 0.0, 0.0), new THREE.Matrix4().makeRotationY(-MathUtilities.PI2)), matrix);
			break;

		case (WALL_LEFT):
			matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0.0, 0.0, -buildingDesigner.building.length / 2 + this.wallRafterWidth/2 + Wall.WALLTHICKNESS), matrix);
			break;

		case (WALL_RIGHT):
			matrix = new THREE.Matrix4().multiplyMatrices(new THREE.Matrix4().makeTranslation(0.0, 0.0, buildingDesigner.building.length / 2 - this.wallRafterWidth/2 - Wall.WALLTHICKNESS), matrix);
			break;
		}

		totalGeom.matrixAutoUpdate = false;
		totalGeom.applyMatrix4(matrix);

		let meshRafters = new THREE.Mesh(totalGeom, this.materRafter);

		meshRafters.eWall = wallSpecification.eWall;

		return meshRafters;
	}

	this.GenerateWallRafters = function (buildingMeshes)
	{
		let geomWallRafter;

		let backWallHeight = this.wallRafterHeight - buildingDesigner.building.roofRafter.frontBackHeightDifference;

		if (buildingDesigner.building.walls.sidingColorData && buildingDesigner.building.walls.sidingColorData.category_id == "ERPBB")
			WoodRafters.max_gap = 4;
		else
			WoodRafters.max_gap = buildingDesigner.building.roofRafter.data.max_gap;


		let geomRafters = [];

		let i;
		//vertical corner rafters
		//front
		for (i = 0; i < 2; i++)
		{
			geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.wallRafterHeight - this.thickness * 2, this.thickness, TexturesDataUtilities.AssignUVsToGeometryXY);
			geomWallRafter.eWall = WALL_FRONT;

			geomRafters.push(geomWallRafter);
		}

		//back
		for (i = 0; i < 2; i++)
		{
			geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, backWallHeight - this.thickness * 2, this.thickness, TexturesDataUtilities.AssignUVsToGeometryXY);
			geomWallRafter.eWall = WALL_BACK;

			geomRafters.push(geomWallRafter);
		}


		let leftCoord = -buildingDesigner.building.roofRafter.wallWidth / 2 + wallRafterWidth / 2.0;
		let rightCoord = buildingDesigner.building.roofRafter.wallWidth / 2 - wallRafterWidth / 2.0;

		let zOffsetForPorchFrontCornerRafter = 0;
		let zOffsetForPorchBackCornerRafter = 0;

		if (buildingDesigner.building.porch)
		{
			if (buildingDesigner.building.porch.fullLength)
			{
				if (buildingDesigner.building.porch.length != 0)
				{
					zOffsetForPorchFrontCornerRafter = Math.abs(buildingDesigner.building.porch.width);
				}
				else
					zOffsetForPorchFrontCornerRafter = Math.abs(buildingDesigner.building.porch.width) + buildingDesigner.building.porch.innerWallRadius;

				zOffsetForPorchBackCornerRafter = Math.abs(buildingDesigner.building.porch.width);
			}
			else
			{
				if (buildingDesigner.building.porch.length < 0)
					zOffsetForPorchFrontCornerRafter = Math.abs(buildingDesigner.building.porch.width);
				else
					zOffsetForPorchBackCornerRafter = Math.abs(buildingDesigner.building.porch.width);
			}
		}

		let zCoord = buildingDesigner.building.walls.wallLength / 2 - this.thickness / 2 - (buildingDesigner.building.porch && buildingDesigner.building.porch.rightSide ? zOffsetForPorchFrontCornerRafter : 0);
		geomRafters[0].matrixAutoUpdate = false;
		geomRafters[0].applyMatrix4(new THREE.Matrix4().makeTranslation(leftCoord, Floor.FLOOR_THICKNESS + this.thickness, zCoord));

		zCoord = -buildingDesigner.building.walls.wallLength / 2 + this.thickness / 2 + (buildingDesigner.building.porch && !buildingDesigner.building.porch.rightSide ? zOffsetForPorchFrontCornerRafter : 0);
		geomRafters[1].matrixAutoUpdate = false;
		geomRafters[1].applyMatrix4(new THREE.Matrix4().makeTranslation(leftCoord, Floor.FLOOR_THICKNESS + this.thickness, zCoord));

		zCoord =  buildingDesigner.building.walls.wallLength / 2 - this.thickness / 2 - (buildingDesigner.building.porch && buildingDesigner.building.porch.rightSide ? zOffsetForPorchBackCornerRafter : 0);
		geomRafters[2].matrixAutoUpdate = false;
		geomRafters[2].applyMatrix4(new THREE.Matrix4().makeTranslation(rightCoord, Floor.FLOOR_THICKNESS + this.thickness, zCoord));

		zCoord = -buildingDesigner.building.walls.wallLength / 2 + this.thickness / 2 + (buildingDesigner.building.porch && !buildingDesigner.building.porch.rightSide ? zOffsetForPorchBackCornerRafter : 0);
		geomRafters[3].matrixAutoUpdate = false;
		geomRafters[3].applyMatrix4(new THREE.Matrix4().makeTranslation(rightCoord, Floor.FLOOR_THICKNESS + this.thickness, zCoord));


		//front corner stud for left and right walls
		for (i = 0; i < 2; i++)
		{
			geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(this.thickness, ((backWallHeight < this.wallRafterHeight) ? backWallHeight:this.wallRafterHeight) - this.thickness * 2, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryXY);
			geomWallRafter.eWall = WALL_FRONT;

			geomRafters.push(geomWallRafter);
		}

		//back corner stud for left and right walls
		for (i = 0; i < 2; i++)
		{
			geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(this.thickness, ((backWallHeight < this.wallRafterHeight) ? backWallHeight:this.wallRafterHeight) - this.thickness * 2, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryXY);
			geomWallRafter.eWall = WALL_BACK;

			geomRafters.push(geomWallRafter);
		}

		leftCoord = -buildingDesigner.building.roofRafter.wallWidth / 2 + this.thickness / 2 + wallRafterWidth;
		rightCoord = buildingDesigner.building.roofRafter.wallWidth / 2 - this.thickness / 2 - wallRafterWidth;


		zCoord = buildingDesigner.building.walls.wallLength / 2 - wallRafterWidth / 2 - (buildingDesigner.building.porch && buildingDesigner.building.porch.rightSide ? zOffsetForPorchFrontCornerRafter : 0);
		geomRafters[4].matrixAutoUpdate = false;
		geomRafters[4].applyMatrix4(new THREE.Matrix4().makeTranslation(leftCoord, Floor.FLOOR_THICKNESS + this.thickness, zCoord));

		zCoord = -buildingDesigner.building.walls.wallLength / 2 + wallRafterWidth / 2 + (buildingDesigner.building.porch && !buildingDesigner.building.porch.rightSide ? zOffsetForPorchFrontCornerRafter : 0);
		geomRafters[5].matrixAutoUpdate = false;
		geomRafters[5].applyMatrix4(new THREE.Matrix4().makeTranslation(leftCoord, Floor.FLOOR_THICKNESS + this.thickness, zCoord));

		zCoord =  buildingDesigner.building.walls.wallLength / 2 - wallRafterWidth / 2 - (buildingDesigner.building.porch && buildingDesigner.building.porch.rightSide ? zOffsetForPorchBackCornerRafter : 0);
		geomRafters[6].matrixAutoUpdate = false;
		geomRafters[6].applyMatrix4(new THREE.Matrix4().makeTranslation(rightCoord, Floor.FLOOR_THICKNESS + this.thickness, zCoord));

		zCoord = -buildingDesigner.building.walls.wallLength / 2 + wallRafterWidth / 2 + (buildingDesigner.building.porch && !buildingDesigner.building.porch.rightSide ? zOffsetForPorchBackCornerRafter : 0);
		geomRafters[7].matrixAutoUpdate = false;
		geomRafters[7].applyMatrix4(new THREE.Matrix4().makeTranslation(rightCoord, Floor.FLOOR_THICKNESS + this.thickness, zCoord));


		//front back horizontal rafters
		let geomWallRafterFrontLong1 = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.thickness, buildingDesigner.building.walls.wallLength, TexturesDataUtilities.AssignUVsToGeometryXZ);
		geomWallRafterFrontLong1.eWall = WALL_FRONT;

		geomWallRafterFrontLong1.matrixAutoUpdate = false;
		geomWallRafterFrontLong1.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 + wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS + this.wallRafterHeight - this.thickness, 0));
		geomRafters.push(geomWallRafterFrontLong1);
		let geomWallRafterBackLong2;


		if (!buildingDesigner.building.porch || (!buildingDesigner.building.porch.fullLength && buildingDesigner.building.porch.length > 0))
		{
			geomWallRafterFrontLong2 = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.thickness, buildingDesigner.building.walls.wallLength, TexturesDataUtilities.AssignUVsToGeometryXZ);
			geomWallRafterFrontLong2.eWall = WALL_FRONT;
			geomWallRafterFrontLong2.matrixAutoUpdate = false;
			geomWallRafterFrontLong2.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 + wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.frontWallLength / 2 + buildingDesigner.building.walls.leftFrontWallCoord));
			geomRafters.push(geomWallRafterFrontLong2);

			if (buildingDesigner.building.crossMember)
			{
				let geomWallRafterFrontLong3 = geomWallRafterFrontLong2.clone();
				geomWallRafterFrontLong3.eWall = WALL_FRONT;
				geomWallRafterFrontLong3.type = ELEM_WALL_RAFTER;
				geomWallRafterFrontLong3.matrixAutoUpdate = false;
				geomWallRafterFrontLong3.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.wallRafterHeight/2 - this.thickness/2, 0));
				geomRafters.push(geomWallRafterFrontLong3);
			}
		}
		else
		{
			let porchRafterLongLen;

			if (buildingDesigner.building.porch.length != 0)
				porchRafterLongLen = buildingDesigner.building.walls.wallLength - wallRafterWidth - Math.abs(buildingDesigner.building.porch.width);
			else
				porchRafterLongLen = buildingDesigner.building.walls.frontWallLength - wallRafterWidth;

			geomWallRafterFrontLong2 = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.thickness, porchRafterLongLen, TexturesDataUtilities.AssignUVsToGeometryXZ);
			geomWallRafterFrontLong2.eWall = WALL_FRONT;
			geomWallRafterFrontLong2.matrixAutoUpdate = false;
			geomWallRafterFrontLong2.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 + wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS, porchRafterLongLen / 2 + buildingDesigner.building.walls.leftFrontWallCoord + wallRafterWidth));

			if (buildingDesigner.building.crossMember)
			{
				let geomWallRafterFrontLongCrossMember = geomWallRafterFrontLong2.clone();
				geomWallRafterFrontLongCrossMember.eWall = WALL_FRONT;
				geomWallRafterFrontLongCrossMember.type = ELEM_WALL_RAFTER;
				geomWallRafterFrontLongCrossMember.matrixAutoUpdate = false;
				geomWallRafterFrontLongCrossMember.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.wallRafterHeight/2 - this.thickness/2, 0));
				geomRafters.push(geomWallRafterFrontLongCrossMember);
			}


			if (!buildingDesigner.building.porch.fullLength)
			{
				let porchRafterShortLen = Math.abs(buildingDesigner.building.porch.width);

				let geomWallRafterShort1 = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.thickness, porchRafterShortLen, TexturesDataUtilities.AssignUVsToGeometryXZ);
				geomWallRafterShort1.eWall = WALL_FRONT;

				let geomWallRafterShort2 = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.thickness, porchRafterShortLen, TexturesDataUtilities.AssignUVsToGeometryXZ);
				geomWallRafterShort2.eWall = WALL_FRONT;


				if (buildingDesigner.building.porch.rightSide)
				{
					geomWallRafterShort1.matrixAutoUpdate = false;
					geomWallRafterShort1.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.leftRightWallCoord + wallRafterWidth / 2.0 + Wall.WALLTHICKNESS, Floor.FLOOR_THICKNESS, porchRafterShortLen / 2 + buildingDesigner.building.walls.leftFrontWallCoord + porchRafterLongLen));

					geomWallRafterShort2.matrixAutoUpdate = false;
					geomWallRafterShort2.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.leftRightWallCoord + wallRafterWidth / 2.0 + Wall.WALLTHICKNESS, Floor.FLOOR_THICKNESS + this.wallRafterHeight - this.thickness, porchRafterShortLen / 2 + buildingDesigner.building.walls.leftFrontWallCoord + porchRafterLongLen));
				}
				else
				{
					if (buildingDesigner.building.porch.length<0)
					{
						geomWallRafterShort1.matrixAutoUpdate = false;
						geomWallRafterShort1.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.leftRightWallCoord + wallRafterWidth / 2.0 + Wall.WALLTHICKNESS, Floor.FLOOR_THICKNESS, porchRafterShortLen / 2 + buildingDesigner.building.walls.leftBackWallCoord + wallRafterWidth));

						geomWallRafterShort2.matrixAutoUpdate = false;
						geomWallRafterShort2.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.leftRightWallCoord + wallRafterWidth / 2.0 + Wall.WALLTHICKNESS, Floor.FLOOR_THICKNESS + this.wallRafterHeight - this.thickness, porchRafterShortLen / 2 + buildingDesigner.building.walls.leftBackWallCoord + wallRafterWidth));
					}
				}


				geomRafters.push(geomWallRafterShort1);
				geomRafters.push(geomWallRafterShort2);


				if (buildingDesigner.building.crossMember)
				{
					let geomWallRafterShort3 = geomWallRafterShort1.clone();
					geomWallRafterShort3.eWall = WALL_FRONT;
					geomWallRafterShort3.type = ELEM_WALL_RAFTER;
					geomWallRafterShort3.matrixAutoUpdate = false;
					geomWallRafterShort3.applyMatrix4(new THREE.Matrix4().makeTranslation(0,  this.wallRafterHeight/2 - this.thickness/2, 0));

					geomRafters.push(geomWallRafterShort3);
				}
			}
		}

		geomRafters.push(geomWallRafterFrontLong2);


		let geomWallRafterBackLong1 = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.thickness, buildingDesigner.building.walls.wallLength, TexturesDataUtilities.AssignUVsToGeometryXZ);
		geomWallRafterBackLong1.eWall = WALL_BACK;
		geomWallRafterBackLong1.matrixAutoUpdate = false;
		geomWallRafterBackLong1.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 - wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS + backWallHeight - this.thickness, 0));
		geomRafters.push(geomWallRafterBackLong1);

		if (!buildingDesigner.building.porch || (!buildingDesigner.building.porch.fullLength && buildingDesigner.building.porch.length < 0))
		{
			geomWallRafterBackLong2 = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.thickness, buildingDesigner.building.walls.wallLength, TexturesDataUtilities.AssignUVsToGeometryXZ);
			geomWallRafterBackLong2.eWall = WALL_BACK;
			geomWallRafterBackLong2.matrixAutoUpdate = false;
			geomWallRafterBackLong2.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 - wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS, 0));
			geomRafters.push(geomWallRafterBackLong2);

			if (buildingDesigner.building.crossMember)
			{
				let geomWallRafterBackLong3 = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.thickness, buildingDesigner.building.walls.wallLength, TexturesDataUtilities.AssignUVsToGeometryXZ);
				geomWallRafterBackLong3.eWall = WALL_BACK;
				geomWallRafterBackLong3.type = ELEM_WALL_RAFTER;
				geomWallRafterBackLong3.matrixAutoUpdate = false;
				geomWallRafterBackLong3.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 - wallRafterWidth / 2.0, this.wallRafterHeight/2 + Floor.FLOOR_THICKNESS - this.thickness/2, buildingDesigner.building.walls.backWallLength / 2 + buildingDesigner.building.walls.leftBackWallCoord));
				geomRafters.push(geomWallRafterBackLong3);
			}
		}
		else
		{
			let porchRafterLongLen = buildingDesigner.building.walls.wallLength - Math.abs(buildingDesigner.building.porch.width);

			geomWallRafterBackLong2 = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.thickness, porchRafterLongLen, TexturesDataUtilities.AssignUVsToGeometryXZ);
			geomWallRafterBackLong2.eWall = WALL_BACK;
			geomWallRafterBackLong2.matrixAutoUpdate = false;
			geomWallRafterBackLong2.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 - wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS, porchRafterLongLen / 2 + buildingDesigner.building.walls.leftBackWallCoord));

			if (buildingDesigner.building.crossMember)
			{
				let geomWallRafterBackLongCrossMember = geomWallRafterBackLong2.clone();
				geomWallRafterBackLongCrossMember.eWall = WALL_FRONT;
				geomWallRafterBackLongCrossMember.type = ELEM_WALL_RAFTER;
				geomWallRafterBackLongCrossMember.matrixAutoUpdate = false;
				geomWallRafterBackLongCrossMember.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.wallRafterHeight/2 - this.thickness/2, 0));
				geomRafters.push(geomWallRafterBackLongCrossMember);
			}

			if (!buildingDesigner.building.porch.fullLength)
			{
				let porchRafterShortLen = Math.abs(buildingDesigner.building.porch.width) - wallRafterWidth;

				let geomWallRafterShort1 = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.thickness, porchRafterShortLen, TexturesDataUtilities.AssignUVsToGeometryXZ);
				geomWallRafterShort1.eWall = WALL_BACK;


				if (buildingDesigner.building.crossMember)
				{
					let geomWallRafterShortCrossMember = geomWallRafterShort1.clone();
					geomWallRafterShortCrossMember.eWall = WALL_FRONT;
					geomWallRafterShortCrossMember.type = ELEM_WALL_RAFTER;
					geomWallRafterShortCrossMember.matrixAutoUpdate = false;
					geomWallRafterShortCrossMember.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.wallRafterHeight/2 - this.thickness/2, 0));
					geomRafters.push(geomWallRafterShortCrossMember);
				}


				let geomWallRafterShort2 = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.thickness, porchRafterShortLen, TexturesDataUtilities.AssignUVsToGeometryXZ);
				geomWallRafterShort2.eWall = WALL_BACK;


				if (buildingDesigner.building.porch.rightSide)
				{
					geomWallRafterShort1.matrixAutoUpdate = false;
					geomWallRafterShort1.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.rightRightWallCoord - wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS, porchRafterShortLen / 2 + buildingDesigner.building.walls.leftBackWallCoord + porchRafterLongLen));
					geomWallRafterShort2.matrixAutoUpdate = false;
					geomWallRafterShort2.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.rightRightWallCoord - wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS + this.wallRafterHeight - this.thickness, porchRafterShortLen / 2 + buildingDesigner.building.walls.leftBackWallCoord + porchRafterLongLen));
				}
				else
				{
					if (buildingDesigner.building.porch.length<0)
					{
						geomWallRafterShort1.matrixAutoUpdate = false;
						geomWallRafterShort1.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.rightLeftWallCoord - wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS, porchRafterShortLen / 2 + buildingDesigner.building.walls.leftBackWallCoord + wallRafterWidth));
						geomWallRafterShort2.matrixAutoUpdate = false;
						geomWallRafterShort2.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.rightLeftWallCoord - wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS + this.wallRafterHeight - this.thickness, porchRafterShortLen / 2 + buildingDesigner.building.walls.leftBackWallCoord + wallRafterWidth));
					}
					else
					{
						geomWallRafterShort1.matrixAutoUpdate = false;
						geomWallRafterShort1.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.rightLeftWallCoord - wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.leftFrontWallCoord + wallRafterWidth + porchRafterShortLen / 2));
						geomWallRafterShort2.matrixAutoUpdate = false;
						geomWallRafterShort2.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.rightLeftWallCoord - wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS + this.wallRafterHeight - this.thickness, buildingDesigner.building.walls.leftFrontWallCoord + wallRafterWidth + porchRafterShortLen / 2));
					}
				}



				geomRafters.push(geomWallRafterShort1);
				geomRafters.push(geomWallRafterShort2);
			}
		}

		geomRafters.push(geomWallRafterBackLong2);


		//left right horizontal rafters
		let fRaftLen = buildingDesigner.building.roofRafter.wallWidth;

		if (buildingDesigner.building.porch && !buildingDesigner.building.porch.rightSide)
			fRaftLen -= (Math.abs(buildingDesigner.building.porch.length) + Wall.WALLTHICKNESS);

		if (!buildingDesigner.building.porch || (buildingDesigner.building.porch && buildingDesigner.building.porch.length!=0) || buildingDesigner.building.porch.rightSide)
		{
			geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(fRaftLen, this.thickness, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);
			geomWallRafter.eWall = WALL_LEFT;

			if (buildingDesigner.building.porch && !buildingDesigner.building.porch.rightSide)
			{
				if (buildingDesigner.building.porch.length>0)
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.rightLeftWallCoord - fRaftLen/2, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.leftFrontWallCoord + wallRafterWidth / 2));
				}
				else
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.rightLeftWallCoord - fRaftLen/2, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.leftBackWallCoord + wallRafterWidth / 2));
				}
			}
			else
			{
				geomWallRafter.matrixAutoUpdate = false;
				geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(0, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.leftFrontWallCoord + wallRafterWidth / 2));
			}

			geomRafters.push(geomWallRafter);


			if (buildingDesigner.building.crossMember)
			{
				geomWallRafterCrossMember = geomWallRafter.clone();
				geomWallRafterCrossMember.eWall = WALL_LEFT;
				geomWallRafterCrossMember.type = ELEM_WALL_RAFTER;
				geomWallRafterCrossMember.matrixAutoUpdate = false;
				geomWallRafterCrossMember.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.wallRafterHeight/2 - this.thickness/2, 0));
				geomRafters.push(geomWallRafterCrossMember);
			}
		}

		fRaftLen = buildingDesigner.building.roofRafter.wallWidth - wallRafterWidth;

		geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(fRaftLen, this.thickness, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);
		geomWallRafter.eWall = WALL_LEFT;
		geomWallRafter.matrixAutoUpdate = false;
		geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(0, Floor.FLOOR_THICKNESS + ((backWallHeight < this.wallRafterHeight) ? backWallHeight:this.wallRafterHeight) - this.thickness, -buildingDesigner.building.length/2 + wallRafterWidth / 2 + Wall.WALLTHICKNESS));

		geomRafters.push(geomWallRafter);

		if (!buildingDesigner.building.porch || (buildingDesigner.building.porch && buildingDesigner.building.porch.length!=0) || !buildingDesigner.building.porch.rightSide)
		{
			let porchRafterLen1 = 0;

			if (buildingDesigner.building.porch && !buildingDesigner.building.porch.fullLength)
			{
				porchRafterLen1 = buildingDesigner.building.roofRafter.wallWidth - wallRafterWidth - Math.abs(buildingDesigner.building.porch.length);

				geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(porchRafterLen1, this.thickness, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);
				geomWallRafter.eWall = WALL_RIGHT;

				if (buildingDesigner.building.porch.length > 0)
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen1 / 2 + buildingDesigner.building.walls.leftRightWallCoord + wallRafterWidth, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.rightFrontWallCoord - wallRafterWidth / 2));
				}
				else
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen1 / 2 + buildingDesigner.building.walls.leftRightWallCoord, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.rightBackWallCoord - wallRafterWidth / 2));
				}

				geomRafters.push(geomWallRafter);

				if (buildingDesigner.building.crossMember)
				{
					let geomWallRafterCrossMember = geomWallRafter.clone();
					geomWallRafterCrossMember.eWall = WALL_RIGHT;
					geomWallRafterCrossMember.type = ELEM_WALL_RAFTER;
					geomWallRafterCrossMember.matrixAutoUpdate = false;
					geomWallRafterCrossMember.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.wallRafterHeight/2 - this.thickness/2, 0));

					geomRafters.push(geomWallRafterCrossMember);
				}

				let porchRafterLen2 = Math.abs(buildingDesigner.building.porch.length) + wallRafterWidth;
				let geomWallRafterShort1 = GeometryUtilities.CreateGeomYSymmetricBox(porchRafterLen2, this.thickness, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);
				geomWallRafterShort1.eWall = WALL_RIGHT;

				let porchRafterRight = !buildingDesigner.building.porch.fullLength && buildingDesigner.building.porch.length > 0;

				geomRafters.push(geomWallRafterShort1);

				if (buildingDesigner.building.crossMember)
				{
					let geomWallRafterCrossMember = geomWallRafter.clone();
					geomWallRafterCrossMember.eWall = WALL_RIGHT;
					geomWallRafterCrossMember.type = ELEM_WALL_RAFTER;
					geomWallRafterCrossMember.matrixAutoUpdate = false;
					geomWallRafterCrossMember.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.wallRafterHeight/2 - this.thickness/2, 0));

					geomRafters.push(geomWallRafterCrossMember);
				}

				let geomWallRafterShort2 = GeometryUtilities.CreateGeomYSymmetricBox(porchRafterLen2, this.thickness, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);
				geomWallRafterShort2.eWall = WALL_RIGHT;

				if (buildingDesigner.building.porch.fullLength)
				{
					geomWallRafterShort1.matrixAutoUpdate = false;
					geomWallRafterShort1.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.leftRightWallCoord, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.rightFrontWallCoord - wallRafterWidth / 2));
					geomWallRafterShort2.matrixAutoUpdate = false;
					geomWallRafterShort2.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.leftRightWallCoord, Floor.FLOOR_THICKNESS + backWallHeight - this.thickness, buildingDesigner.building.walls.rightFrontWallCoord - wallRafterWidth / 2));
				}
				else
				if (porchRafterRight)
				{
					if (buildingDesigner.building.porch.rightSide)
					{
						geomWallRafterShort1.matrixAutoUpdate = false;
						geomWallRafterShort1.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.rightRightWallCoord - wallRafterWidth, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.rightBackWallCoord - wallRafterWidth / 2));
						geomWallRafterShort2.matrixAutoUpdate = false;
						geomWallRafterShort2.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.rightRightWallCoord - wallRafterWidth, Floor.FLOOR_THICKNESS + backWallHeight - this.thickness, buildingDesigner.building.walls.rightBackWallCoord - wallRafterWidth / 2));
					}
					else
					{
						geomWallRafterShort1.matrixAutoUpdate = false;
						geomWallRafterShort1.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.rightLeftWallCoord - wallRafterWidth, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.leftBackWallCoord + wallRafterWidth / 2));
						geomWallRafterShort2.matrixAutoUpdate = false;
						geomWallRafterShort2.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.rightLeftWallCoord - wallRafterWidth, Floor.FLOOR_THICKNESS + backWallHeight - this.thickness, buildingDesigner.building.walls.leftBackWallCoord + wallRafterWidth / 2));

						geomWallRafterShort1.eWall = WALL_LEFT;
						geomWallRafterShort2.eWall = WALL_LEFT;
					}
				}
				else
				{
					if (buildingDesigner.building.porch.rightSide)
					{
						geomWallRafterShort1.matrixAutoUpdate = false;
						geomWallRafterShort1.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.leftRightWallCoord - porchRafterLen2/2 + wallRafterWidth, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.rightFrontWallCoord - wallRafterWidth / 2));
						geomWallRafterShort2.matrixAutoUpdate = false;
						geomWallRafterShort2.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.leftRightWallCoord - porchRafterLen2/2 + wallRafterWidth, Floor.FLOOR_THICKNESS + backWallHeight - this.thickness, buildingDesigner.building.walls.rightFrontWallCoord - wallRafterWidth / 2));
					}
					else
					{
						geomWallRafterShort1.matrixAutoUpdate = false;
						geomWallRafterShort1.applyMatrix4(new THREE.Matrix4().makeTranslation(-porchRafterLen2 / 2 + buildingDesigner.building.walls.leftLeftWallCoord + wallRafterWidth, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.leftFrontWallCoord + wallRafterWidth / 2));
						geomWallRafterShort2.matrixAutoUpdate = false;
						geomWallRafterShort2.applyMatrix4(new THREE.Matrix4().makeTranslation(-porchRafterLen2 / 2 + buildingDesigner.building.walls.leftLeftWallCoord + wallRafterWidth, Floor.FLOOR_THICKNESS + backWallHeight - this.thickness, buildingDesigner.building.walls.leftFrontWallCoord + wallRafterWidth / 2));

						geomWallRafterShort1.eWall = WALL_LEFT;
						geomWallRafterShort2.eWall = WALL_LEFT;
					}
				}

				geomRafters.push(geomWallRafterShort2);
			}
			else
			if (buildingDesigner.building.porch && buildingDesigner.building.porch.length != 0)
			{
				porchRafterLen2 = Math.abs(buildingDesigner.building.porch.length) - wallRafterWidth;
				geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(porchRafterLen2, this.thickness, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);
				geomWallRafter.eWall = WALL_RIGHT;

				porchRafterRight = !buildingDesigner.building.porch.fullLength && buildingDesigner.building.porch.length > 0;

				if (buildingDesigner.building.porch.fullLength)
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.leftRightWallCoord, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.rightFrontWallCoord - wallRafterWidth / 2));
				}
				else
				{
					if (porchRafterRight)
					{
						geomWallRafter.matrixAutoUpdate = false;
						geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.rightRightWallCoord, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.rightBackWallCoord - wallRafterWidth / 2));
					}
					else
					{
						geomWallRafter.matrixAutoUpdate = false;
						geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.leftRightWallCoord - porchRafterLen2, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.rightFrontWallCoord - wallRafterWidth / 2));
					}
				}
				geomRafters.push(geomWallRafter);

				if (buildingDesigner.building.crossMember)
				{
					let geomWallRafterCrossMember = geomWallRafter.clone();
					geomWallRafterCrossMember.eWall = WALL_RIGHT;
					geomWallRafterCrossMember.type = ELEM_WALL_RAFTER;
					geomWallRafterCrossMember.matrixAutoUpdate = false;
					geomWallRafterCrossMember.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.wallRafterHeight/2 - this.thickness/2, 0));

					geomRafters.push(geomWallRafterCrossMember);
				}

				geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(porchRafterLen2, this.thickness, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);
				geomWallRafter.eWall = WALL_RIGHT;

				if (buildingDesigner.building.porch.fullLength)
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.leftRightWallCoord, Floor.FLOOR_THICKNESS + backWallHeight - this.thickness, buildingDesigner.building.walls.rightFrontWallCoord - wallRafterWidth / 2));
				}
				else
				{
					if (porchRafterRight)
					{
						geomWallRafter.matrixAutoUpdate = false;
						geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.rightRightWallCoord, Floor.FLOOR_THICKNESS + backWallHeight - this.thickness, buildingDesigner.building.walls.rightBackWallCoord - wallRafterWidth / 2));
					}
					else
					{
						geomWallRafter.matrixAutoUpdate = false;
						geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(porchRafterLen2 / 2 + buildingDesigner.building.walls.leftRightWallCoord - porchRafterLen2, Floor.FLOOR_THICKNESS + backWallHeight - this.thickness, buildingDesigner.building.walls.rightFrontWallCoord - wallRafterWidth / 2));
					}
				}
				geomRafters.push(geomWallRafter);

			}
		}

		if (!buildingDesigner.building.porch || (buildingDesigner.building.porch && !buildingDesigner.building.porch.rightSide))
		{
			let fRaftLen = buildingDesigner.building.roofRafter.wallWidth - wallRafterWidth * 2;

			geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(fRaftLen, this.thickness, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);
			geomWallRafter.eWall = WALL_RIGHT;
			geomWallRafter.matrixAutoUpdate = false;
			geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(0, Floor.FLOOR_THICKNESS, buildingDesigner.building.walls.rightFrontWallCoord - wallRafterWidth / 2));
			geomRafters.push(geomWallRafter);


			if (buildingDesigner.building.crossMember)
			{
				let geomWallRafterCrossMember = geomWallRafter.clone();
				geomWallRafterCrossMember.eWall = WALL_RIGHT;
				geomWallRafterCrossMember.type = ELEM_WALL_RAFTER;
				geomWallRafterCrossMember.matrixAutoUpdate = false;
				geomWallRafterCrossMember.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.wallRafterHeight/2 - this.thickness/2, 0));
				geomRafters.push(geomWallRafterCrossMember);
			}

			geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(fRaftLen, this.thickness, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);
			geomWallRafter.eWall = WALL_RIGHT;
			geomWallRafter.type = ELEM_WALL_RAFTER;
			geomWallRafter.matrixAutoUpdate = false;
			geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(0, Floor.FLOOR_THICKNESS + ((backWallHeight < this.wallRafterHeight) ? backWallHeight:this.wallRafterHeight) - this.thickness, buildingDesigner.building.walls.rightFrontWallCoord - wallRafterWidth / 2));
			geomRafters.push(geomWallRafter);
		}

		geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(fRaftLen, this.thickness, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryZX);
		geomWallRafter.eWall = WALL_RIGHT;
		geomWallRafter.type = ELEM_WALL_RAFTER;
		geomWallRafter.matrixAutoUpdate = false;
		geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(0, Floor.FLOOR_THICKNESS + ((backWallHeight < this.wallRafterHeight) ? backWallHeight:this.wallRafterHeight) - this.thickness, buildingDesigner.building.length/2 - wallRafterWidth / 2 - Wall.WALLTHICKNESS));
		geomRafters.push(geomWallRafter);


		//front back vertical rafters
		let numberOfRafters = (buildingDesigner.building.walls.wallLength - this.thickness) / WoodRafters.max_gap;

		let frontNumberOfRafters = (buildingDesigner.building.walls.frontWallLength - this.thickness) / WoodRafters.max_gap;
		frontNumberOfRafters = Math.ceil(frontNumberOfRafters);

		let backNumberOfRafters = (buildingDesigner.building.walls.backWallLength - this.thickness) / WoodRafters.max_gap;
		backNumberOfRafters = Math.ceil(backNumberOfRafters);


		let fFrontSideStep = (buildingDesigner.building.walls.frontWallLength - this.thickness) / frontNumberOfRafters;

		let fBackSideStep = (buildingDesigner.building.walls.backWallLength - this.thickness) / backNumberOfRafters;

		let cutInfo, ivalRafter, geomWallRafterCurr;

		this.frontBackRafterCoords[0] = buildingDesigner.building.walls.leftFrontWallCoord;

		for (i = 1; i < numberOfRafters; i++)
		{
			let fOffsZ = -buildingDesigner.building.length/2 + fFrontSideStep * i;

			let withinFrontFacet = (fOffsZ >= buildingDesigner.building.walls.leftFrontWallCoord && fOffsZ <= buildingDesigner.building.walls.rightFrontWallCoord);

			if (withinFrontFacet || (!(buildingDesigner.building.porch && buildingDesigner.building.porch.fullLength)))
			{
				this.frontBackRafterCoords[i] = fOffsZ;

				geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, this.wallRafterHeight - this.thickness * 2, this.thickness, TexturesDataUtilities.AssignUVsToGeometryXY);


				if (withinFrontFacet)
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 + wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS + this.thickness, fOffsZ));
				}
				else
				{
					if (!(buildingDesigner.building.porch && buildingDesigner.building.porch.fullLength))
					{
						geomWallRafter.matrixAutoUpdate = false;
						geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.leftRightWallCoord + wallRafterWidth / 2.0 + Wall.WALLTHICKNESS, Floor.FLOOR_THICKNESS + this.thickness, fOffsZ));
					}
				}

				geomRafters.push(geomWallRafter);

				geomWallRafter.eWall = WALL_FRONT;
			}
		}


		for (i = 1; i < numberOfRafters; i++)
		{
			let fOffsZ = -buildingDesigner.building.length/2 + fBackSideStep * i;

			let withinBackFacet = (fOffsZ >= buildingDesigner.building.walls.leftBackWallCoord && fOffsZ <= buildingDesigner.building.walls.rightBackWallCoord);

			if (withinBackFacet || (!(buildingDesigner.building.porch && buildingDesigner.building.porch.fullLength)))
			{
				geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(wallRafterWidth, backWallHeight - this.thickness * 2, this.thickness, TexturesDataUtilities.AssignUVsToGeometryXY);

				if (withinBackFacet)
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 - wallRafterWidth / 2.0, Floor.FLOOR_THICKNESS + this.thickness, fOffsZ));
				}
				else
				{
					if (!(buildingDesigner.building.porch && buildingDesigner.building.porch.fullLength))
					{
						if (buildingDesigner.building.porch.width>0)
						{
							geomWallRafter.matrixAutoUpdate = false;
							geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.rightRightWallCoord - wallRafterWidth / 2, Floor.FLOOR_THICKNESS + this.thickness, fOffsZ));
						}
						else
						{
							geomWallRafter.matrixAutoUpdate = false;
							geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.walls.rightLeftWallCoord - wallRafterWidth / 2, Floor.FLOOR_THICKNESS + this.thickness, fOffsZ));
						}
					}
				}

				geomRafters.push(geomWallRafter);

				geomWallRafter.eWall = WALL_BACK;
			}
		}



		this.frontBackRafterCoords[frontNumberOfRafters] = buildingDesigner.building.walls.rightFrontWallCoord;

		//left right vertical studs (framing)
		numberOfRafters = (buildingDesigner.building.roofRafter.wallWidth - this.thickness) / WoodRafters.max_gap;
		numberOfRafters = Math.ceil(numberOfRafters);
		let xInc = (buildingDesigner.building.roofRafter.wallWidth - this.thickness) / numberOfRafters;

		let leftRightWallHeight = ((backWallHeight < this.wallRafterHeight) ? backWallHeight:this.wallRafterHeight) - this.thickness * 2;

		this.leftRightRafterCoords[0] = -buildingDesigner.building.roofRafter.wallWidth / 2;

		let fOffsX;

		for (i = 1; i < numberOfRafters; i++)
		{
			fOffsX = -buildingDesigner.building.roofRafter.wallWidth / 2 + this.thickness / 2.0 + xInc * i;

			this.leftRightRafterCoords[i] = fOffsX;

			if (!buildingDesigner.building.porch || (buildingDesigner.building.porch && buildingDesigner.building.porch.length!=0) || !buildingDesigner.building.porch.rightSide)
			{
				geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(this.thickness, leftRightWallHeight, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryXY);

				if (!buildingDesigner.building.porch || (fOffsX >= buildingDesigner.building.walls.leftRightWallCoord && fOffsX <= buildingDesigner.building.walls.rightRightWallCoord && !buildingDesigner.building.porch.fullLength))
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(fOffsX, Floor.FLOOR_THICKNESS + this.thickness, buildingDesigner.building.walls.wallLength / 2 - wallRafterWidth / 2));
				}
				else
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(fOffsX, Floor.FLOOR_THICKNESS + this.thickness, buildingDesigner.building.walls.wallLength / 2 - wallRafterWidth / 2 - (buildingDesigner.building.porch.rightSide ? buildingDesigner.building.porch.width : 0)));
				}


				geomRafters.push(geomWallRafter);

				geomWallRafter.eWall = WALL_RIGHT;
			}

			if (!buildingDesigner.building.porch || (buildingDesigner.building.porch && buildingDesigner.building.porch.length!=0) || buildingDesigner.building.porch.rightSide)
			{
				geomWallRafter = GeometryUtilities.CreateGeomYSymmetricBox(this.thickness, leftRightWallHeight, wallRafterWidth, TexturesDataUtilities.AssignUVsToGeometryXY);


				if (!buildingDesigner.building.porch || (fOffsX >= buildingDesigner.building.walls.leftLeftWallCoord && fOffsX <= buildingDesigner.building.walls.rightLeftWallCoord && !buildingDesigner.building.porch.fullLength))
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(fOffsX, Floor.FLOOR_THICKNESS + this.thickness, -buildingDesigner.building.walls.wallLength / 2 + wallRafterWidth / 2));
				}
				else
				{
					geomWallRafter.matrixAutoUpdate = false;
					geomWallRafter.applyMatrix4(new THREE.Matrix4().makeTranslation(fOffsX, Floor.FLOOR_THICKNESS + this.thickness, -buildingDesigner.building.walls.wallLength / 2 + wallRafterWidth / 2 + (!buildingDesigner.building.porch.rightSide ? -buildingDesigner.building.porch.width : 0)));
				}


				geomRafters.push(geomWallRafter);

				geomWallRafter.eWall = WALL_LEFT;
			}
		}

		this.leftRightRafterCoords[numberOfRafters] = buildingDesigner.building.roofRafter.wallWidth / 2;

		for (i = 0; i < geomRafters.length; i++)
		{
			let meshRafter = new THREE.Mesh(geomRafters[i], this.materRafter);

			meshRafter.eWall = geomRafters[i].eWall;

			// These are not rafters, this is the wall framing ( studs and plates )
			buildingMeshes.push(meshRafter);
		}


		if (buildingDesigner.building.porch && buildingDesigner.building.porch.length == 0)
		{
			let wallRafterMesh;

			let extraLength = 0;


			for (let i = 0; i<buildingDesigner.building.porch.porchWallSpecifications.length; i++)
			{
				extraLength = 0;

				if (buildingDesigner.building.porch.length == 0)
					if (i == buildingDesigner.building.porch.porchWallSpecifications.length-1)
						extraLength = this.wallRafterWidth + Wall.WALLTHICKNESS;
					else
					if (i == 0)
						extraLength = -Wall.WALLTHICKNESS;

				wallRafterMesh = this.CreateWallFraming(buildingDesigner.building.porch.porchWallSpecifications[i], extraLength);

				buildingMeshes.push(wallRafterMesh);
			}
		}


	};

	this.GenerateRoofRafters = function (buildingMeshes1, buildingMeshes2, buildingMeshes3)
	{
		this.GenerateRoofRaftersCSG(null, buildingMeshes1, buildingMeshes2, buildingMeshes3);
	};

	this.GenerateRoofRaftersCSG = function (subtractGeom, buildingMeshes1, buildingMeshes2, buildingMeshes3)
	{
		let cornerx = -buildingDesigner.building.roofRafter.wallWidth / 2;
		let cornerz = -buildingDesigner.building.walls.wallLength / 2;

		let rafters = [];

		let extrudeSettings = {
			depth: this.thickness,
			steps: 1,
			material: 1,
			extrudeMaterial: 0,
			bevelEnabled: false,
		};

		let numberOfRafters = (buildingDesigner.building.walls.wallLength - this.thickness) / WoodRafters.max_gap;
		numberOfRafters = Math.ceil(numberOfRafters);
		let rafterSpacing = (buildingDesigner.building.walls.wallLength - this.thickness) / numberOfRafters;

		numberOfRafters++; //for the end rafter

		let rafterMaterial1 = new THREE.MeshBasicMaterial({
			color: 0xdddddd,
			map: null
		});
		let rafterMaterial2 = new THREE.MeshBasicMaterial({
			color: 0xdddddd,
			map: null
		});

		let apexCoordsIndices = buildingDesigner.building.roofRafter.GetApexCoordIndices();

		let rafteroffsetx = 0;
		let rafterOffsetY = 0;

		let frontRoofAngle = Math.atan(buildingDesigner.building.roofRafter.frontTanAngleRatio);

		let baseAndStrutCoords = null;

		if ((buildingDesigner.building.roofRafter.data.truss_strut_ratio_coords && buildingDesigner.building.roofRafter.data.truss_strut_ratio_coords.length > 0) || (buildingDesigner.building.roofRafter.data.truss_base_height_from_wall_height > 0))
		{
			baseAndStrutCoords = this.GenerateBaseAndStrutCoords();
		}

		if (!buildingDesigner.building.roofRafter.leanToRafter)
		{
			if (buildingDesigner.building.roofRafter.data.front_wall_attach_coord != "")
			{
				rafteroffsetx = -buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0];
				rafterOffsetY = -buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1];

				if (rafterOffsetY > 0)
					rafterOffsetY = 0;
			}

			let rafter_sh_1 = new THREE.Shape();

			rafter_sh_1.moveTo(buildingDesigner.building.roofRafter.data.rafter_spec[0][0], buildingDesigner.building.roofRafter.data.rafter_spec[0][1]);

			let ignore = false;
			for (let i = 1; i < buildingDesigner.building.roofRafter.data.rafter_spec.length; i++)
			{
				rafter_sh_1.lineTo(buildingDesigner.building.roofRafter.data.rafter_spec[i][0], buildingDesigner.building.roofRafter.data.rafter_spec[i][1]);

				if (i == apexCoordsIndices[0])
					i = apexCoordsIndices[1] - 1;
			}

			buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_1, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, cornerz, rafterMaterial1, null, buildingMeshes1);

			for (let i = 1; i < (numberOfRafters - 1); i++)
			{
				buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_1, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, (i * rafterSpacing) - (this.thickness / 2) + cornerz, rafterMaterial1, null, buildingMeshes1);
			}

			buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_1, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, buildingDesigner.building.walls.wallLength / 2 - this.thickness, rafterMaterial1, null, buildingMeshes1);


			if (baseAndStrutCoords)
			{
				this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, cornerz, rafterMaterial1, buildingMeshes1, buildingMeshes2);

				this.GenerateRafterBase(baseAndStrutCoords.baseCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, cornerz, rafterMaterial1, buildingMeshes3);


				for (let i = 1; i < (numberOfRafters - 1); i++)
				{
					this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, (i * rafterSpacing) - (this.thickness / 2) + cornerz, rafterMaterial1, buildingMeshes1, buildingMeshes2);

					this.GenerateRafterBase(baseAndStrutCoords.baseCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, (i * rafterSpacing) - (this.thickness / 2) + cornerz, rafterMaterial1, buildingMeshes3);
				}

				this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, buildingDesigner.building.walls.wallLength / 2 - this.thickness, rafterMaterial1, buildingMeshes1, buildingMeshes2);

				this.GenerateRafterBase(baseAndStrutCoords.baseCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, buildingDesigner.building.walls.wallLength / 2 - this.thickness, rafterMaterial1, buildingMeshes3);
			}
		}
		else
		{
			if (buildingDesigner.building.roofRafter.data.front_wall_attach_coord != "")
			{
				rafteroffsetx = -buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0] + buildingDesigner.building.roofRafter.data.width;
				rafterOffsetY = -buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1];
			}
		}


		let rafter_sh_2 = new THREE.Shape();

		let i = apexCoordsIndices[0];
		rafter_sh_2.moveTo(buildingDesigner.building.roofRafter.data.rafter_spec[i][0], buildingDesigner.building.roofRafter.data.rafter_spec[i][1]);

		i++;

		for (; i < buildingDesigner.building.roofRafter.data.rafter_spec.length; i++)
		{
			if (i == apexCoordsIndices[1] + 1)
				break;

			rafter_sh_2.lineTo(buildingDesigner.building.roofRafter.data.rafter_spec[i][0], buildingDesigner.building.roofRafter.data.rafter_spec[i][1]);
		}

		if (buildingDesigner.building.roofRafter.leanToRafter)
			rafter_sh_2.lineTo(buildingDesigner.building.roofRafter.data.rafter_spec[0][0], buildingDesigner.building.roofRafter.data.rafter_spec[0][1]);

		buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_2, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, cornerz, rafterMaterial2, subtractGeom, buildingMeshes2);

		for (let i = 1; i < (numberOfRafters - 1); i++)
		{
			buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_2, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, (i * rafterSpacing) - (this.thickness / 2) + cornerz, rafterMaterial2, subtractGeom, buildingMeshes2);
		}

		buildingDesigner.building.roofRafter.GenerateRafter(rafter_sh_2, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, buildingDesigner.building.walls.wallLength / 2 - this.thickness, rafterMaterial2, subtractGeom, buildingMeshes2);


		if (buildingDesigner.building.roofRafter.data.truss_strut_ratio_coords && buildingDesigner.building.roofRafter.data.truss_strut_ratio_coords.length > 0)
		{
			this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, cornerz, rafterMaterial1, buildingMeshes1, buildingMeshes2, true);

			for (let i = 1; i < (numberOfRafters - 1); i++)
			{
				this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, (i * rafterSpacing) - (this.thickness / 2) + cornerz, rafterMaterial1, buildingMeshes1, buildingMeshes2, true);
			}

			this.GenerateStruts(baseAndStrutCoords.strutCoords, extrudeSettings, cornerx + rafteroffsetx, buildingDesigner.building.height + rafterOffsetY, buildingDesigner.building.walls.wallLength / 2 - this.thickness, rafterMaterial1, buildingMeshes1, buildingMeshes2, true);
		}

	};

	this.GenerateLeanToPosts = function (leanToMeshes, texture)
	{
		let matterPost = Material.CreateMaterial(0xFFFFFF, TexturesDataUtilities.TextureLoaded(texture));

		let postGeom;
		let postMesh;

		let posZ = -buildingDesigner.building.walls.wallLength / 2;
		let zInc = buildingDesigner.building.walls.wallLength / buildingDesigner.building.stallCount;

		for (let i = 0; i < buildingDesigner.building.stallCount + 1; i++)
		{
			postGeom = GeometryUtilities.CreateGeomYSymmetricBox(LEAN_TO_POST_WIDTH, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontLeanToHeightDifference + HorseBarnBase.BASEWIDTH, LEAN_TO_POST_WIDTH, TexturesDataUtilities.AssignUVsToGeometryXY);

			postGeom.matrixAutoUpdate = false;
			postGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 - buildingDesigner.building.roofRafter.leanToWidth + LEAN_TO_POST_WIDTH / 2, -HorseBarnBase.BASEWIDTH, posZ));

			postMesh = new THREE.Mesh(postGeom, matterPost);

			leanToMeshes.push(postMesh);

			if (i == 0)
				posZ -= LEAN_TO_POST_WIDTH / 2;

			posZ += zInc;

			if (i == buildingDesigner.building.stallCount - 1)
				posZ -= LEAN_TO_POST_WIDTH / 2;
		}
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			let texture1 = TexturesDataUtilities.GetRealWorldSizedTexture("Southern_yellowpine_vertical", wallRafterWidth, 1.0);

			let texture2 = TexturesDataUtilities.SelectTexture("Southern_yellowpine_rafterleft", THREE.MirroredRepeatWrapping, THREE.MirroredRepeatWrapping);
			let texture3 = TexturesDataUtilities.SelectTexture("Southern_yellowpine_rafterright", THREE.MirroredRepeatWrapping, THREE.MirroredRepeatWrapping);

			let texture4 = TexturesDataUtilities.SelectTexture("Southern_yellowpine_horizontal", THREE.MirroredRepeatWrapping, THREE.MirroredRepeatWrapping);


			if (buildingDesigner.building.roofRafter.data.lean_to)
			{
				texture4 = TexturesDataUtilities.GetRealWorldSizedTexture("LeanToPost", LEAN_TO_POST_WIDTH, buildingDesigner.building.height - buildingDesigner.building.roofRafter.frontLeanToHeightDifference - HorseBarnBase.BASEWIDTH);
			}

			let wallMeshes = [];
			let roofMeshes2 = [];
			let roofMeshes3 = [];
			let roofMeshes4 = [];

			let leanToMeshes = [];

			this.GenerateWallRafters(wallMeshes);
			if (tdf.displayRafters)
			{
				this.GenerateRoofRafters(roofMeshes2, roofMeshes3, roofMeshes4);
			}

			if (buildingDesigner.building.roofRafter.data.lean_to)
			{
				this.GenerateLeanToPosts(leanToMeshes, texture4);
			}

			let totalGeom, totalGeomFront, totalGeomBack, totalGeomRight, totalGeomLeft;

			if (!RUN_IN_OPTIMISED)
			{
				totalGeom = new THREE.Geometry();

				for (i = 0; i < wallMeshes.length; i++)
				{
					totalGeom.merge(wallMeshes[i].geometry);
				}
			}
			else
			{
				totalGeomFront = new THREE.Geometry();
				totalGeomBack = new THREE.Geometry();
				totalGeomRight = new THREE.Geometry();
				totalGeomLeft = new THREE.Geometry();

				for (i = 0; i < wallMeshes.length; i++)
				{
					switch (wallMeshes[i].eWall)
					{
					case (WALL_FRONT):
						totalGeomFront.merge(wallMeshes[i].geometry);
						break;

					case (WALL_BACK):
						totalGeomBack.merge(wallMeshes[i].geometry);
						break;

					case (WALL_RIGHT):
						totalGeomRight.merge(wallMeshes[i].geometry);
						break;

					case (WALL_LEFT):
						totalGeomLeft.merge(wallMeshes[i].geometry);
						break;
					}
				}
			}

			let totalGeom2 = new THREE.Geometry();

			for (i = 0; i < roofMeshes2.length; i++)
			{
				totalGeom2.merge(roofMeshes2[i].geometry);
			}

			let totalGeom3 = new THREE.Geometry();

			for (i = 0; i < roofMeshes3.length; i++)
			{
				totalGeom3.merge(roofMeshes3[i].geometry);
			}


			if (!RUN_IN_OPTIMISED)
			{
				let mesh = GeometryUtilities.CreateMeshFromGeometry(totalGeom, this.rafterColor, texture1);
				mesh.type = ELEM_WALL_RAFTER;

				buildingMeshes.push(mesh);
			}
			else
			{
				let mesh;

				mesh = GeometryUtilities.CreateMeshFromGeometry(totalGeomFront, this.rafterColor, texture1);
				mesh.type = ELEM_WALL_RAFTER;
				mesh.eWall = WALL_FRONT;
				buildingMeshes.push(mesh);

				mesh = GeometryUtilities.CreateMeshFromGeometry(totalGeomBack, this.rafterColor, texture1);
				mesh.type = ELEM_WALL_RAFTER;
				mesh.eWall = WALL_BACK;
				buildingMeshes.push(mesh);

				mesh = GeometryUtilities.CreateMeshFromGeometry(totalGeomRight, this.rafterColor, texture1);
				mesh.type = ELEM_WALL_RAFTER;
				mesh.eWall = WALL_RIGHT;
				buildingMeshes.push(mesh);

				mesh = GeometryUtilities.CreateMeshFromGeometry(totalGeomLeft, this.rafterColor, texture1);
				mesh.type = ELEM_WALL_RAFTER;
				mesh.eWall = WALL_LEFT;
				buildingMeshes.push(mesh);
			}

			let roofRaftersMesh1 = GeometryUtilities.CreateMeshFromGeometry(totalGeom2, this.rafterColor, texture2);

			let roofRaftersMesh2 = GeometryUtilities.CreateMeshFromGeometry(totalGeom3, this.rafterColor, texture3);



			roofRaftersMesh1.type = ELEM_ROOF_RAFTER;
			roofRaftersMesh2.type = ELEM_ROOF_RAFTER;


			buildingMeshes.push(roofRaftersMesh1);
			buildingMeshes.push(roofRaftersMesh2);


			if (roofMeshes4.length > 0)
			{
				let totalGeom4 = new THREE.Geometry();

				for (i = 0; i < roofMeshes4.length; i++)
				{
					totalGeom4.merge(roofMeshes4[i].geometry);
				}

				let roofRaftersMesh3 = GeometryUtilities.CreateMeshFromGeometry(totalGeom4, this.rafterColor, texture4);
				roofRaftersMesh3.type = ELEM_ROOF_RAFTER;
				buildingMeshes.push(roofRaftersMesh3);
			}

			if (buildingDesigner.building.roofRafter.data.lean_to)
			{
				let totalPostGeom = new THREE.Geometry();

				for (i = 0; i < leanToMeshes.length; i++)
				{
					totalPostGeom.merge(leanToMeshes[i].geometry);
				}

				let postsMesh = GeometryUtilities.CreateMeshFromGeometry(totalPostGeom, this.rafterColor, texture4);

				postsMesh.castShadow = true;
				buildingMeshes.push(postsMesh);
			}

			this.regenerate = false;
		}
	};


	this.ModifyWallRafterHeight = function (extendHeight)
	{
		this.wallRafterHeight += extendHeight;
	};
}

WoodRafters.Pine = 0;
WoodRafters.Oak_4ft = 1;

////WoodRafters.framing = WoodRafters.Oak_4ft;
WoodRafters.framing = WoodRafters.Pine;

WoodRafters.max_gap = 4;
