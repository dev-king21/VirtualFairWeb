/*eslint-env jquery, browser, es6*/
/*eslint-parserOptions ecmaVersion:2018*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/
function ColorsDataUtilities()
{
}

ColorsDataUtilities.GetColorFromString = function(color)
{
	try
	{
		if (typeof color === "string")
		{
			let r, g, b, a = 1.0;

			color = color.toLowerCase();

			if ( /^rgb\((\d+),(\d+),(\d+)\)$/i.test( color ) )
			{
				let colorArray = /^rgb\((\d+),(\d+),(\d+)\)$/i.exec( color );

				r = colorArray[ 1 ] / 255;
				g = colorArray[ 2 ] / 255;
				b = colorArray[ 3 ] / 255;
			}
			else
			if ( /^rgb\((\d+), ?(\d+), ?(\d+), ?(\d+)\)$/i.test( color ) )
			{
				let colorArray = /^rgb\((\d+), ?(\d+), ?(\d+), ?(\d+)\)$/i.exec( color );

				r = colorArray[ 1 ] / 255;
				g = colorArray[ 2 ] / 255;
				b = colorArray[ 3 ] / 255;
				a = colorArray[ 4 ] / 255;
			}

			//let colorVector = new THREE.Color( r, g, b, a);
			let colorVector = {r: r, g: g, b: b, a: a};

			return colorVector;
		}
		else
			return null;
	}
	catch (exception)
	{
		return null;
	}
};

ColorsDataUtilities.FindColor = function(colorID)
{
	for ( let i = 0; i < ColorsDataUtilities.colorsData.length; i++ )
	{
		if (ColorsDataUtilities.colorsData[i].color_id == colorID)
		{
			return ColorsDataUtilities.colorsData[i];
		}
	}
	if (DEBUG) {
		console.log("Cannot find color data for: ",colorID);
	}
	return null;
};


ColorsDataUtilities.GetDoorColorData = function(elem_ID, colorID)
{
	let availableColors = [];

	let colorData;

	for (let i=0; i<ColorsDataUtilities.doorColorsData.length;i++)
	{
		if (ColorsDataUtilities.doorColorsData[i].door_id == elem_ID && ColorsDataUtilities.doorColorsData[i].color_id == colorID)
		{
			return ColorsDataUtilities.doorColorsData[i];
		}
	}

	if (DEBUG) {
		console.log("Cannot find door color data for: ",colorID);
	}
	return null;
};


ColorsDataUtilities.GetColorsDataFromServer = async function()
{
	let err;
	let params = {
		subscriber_id: SubscriberDataUtilities.subscriber,
		series_code: SubscriberDataUtilities.series_code
	};
	[err,ColorsDataUtilities.colorsData] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getColors", ...params}));
	if (err) {
		throw err;
	}

	//ColorsDataUtilities.colorsData = JSON.parse(colorsDataStr);


	for ( let i = 0; i < ColorsDataUtilities.colorsData.length; i++ )
	{
		ColorsDataUtilities.colorsData[i].color = ColorsDataUtilities.colorsData[i].color.toLowerCase();
	}


	return ColorsDataUtilities.colorsData;
};

ColorsDataUtilities.GetDoorColorsDataFromServer = async function()
{
	params = {
		subscriber_id: SubscriberDataUtilities.subscriber,
		series_code: SubscriberDataUtilities.series_code
	};
	let err;
	[err, ColorsDataUtilities.doorColorsData] = await to(NodeJSUtilities.UQuery("dataRequest", {request: "getDoorColors", ...params}));
	if (err) {
		throw err;
	}

	return ColorsDataUtilities.doorColorsData;
};


ColorsDataUtilities.GetAvailableDoorColors = function(elem_ID)
{
	let availableColors = [];

	let colorData;

	for (let i=0; i<ColorsDataUtilities.doorColorsData.length;i++)
	{
		if (ColorsDataUtilities.doorColorsData[i].door_id == elem_ID)
		{
			colorData = ColorsDataUtilities.FindColor(ColorsDataUtilities.doorColorsData[i].color_id);

			if (colorData)
			{
				availableColors.push(colorData);
			}
		}
	}

	return availableColors;
};

ColorsDataUtilities.GetColorMatch = function(colors, colorID)
{
	let index = -1;

	let colorData = ColorsDataUtilities.FindColor(colorID);

	for (let i=0; i<colors.length;i++)
	{
		if (colors[i].color_id == colorID)
		{
			index = i;
			break;
		}
	}

	return index;
};

ColorsDataUtilities.GetClosestColor = function(colors, color)
{
	let colorData;
	let arrayColorVector;

	color = ColorsDataUtilities.GetColorFromString(color);

	for (let i=0; i<colors.length;i++)
	{
		colorData = ColorsDataUtilities.FindColor(colors[i].color_id);

		arrayColorVector = ColorsDataUtilities.GetColorFromString(colorData.color);

		if (arrayColorVector.r == color.r && arrayColorVector.g == color.g &&arrayColorVector.b == color.b)
		{
			return i; //exact match
		}
	}


	let brightnessAdjustedColor;
	let weighting1 = 20;

	let colorIndex = -1;
	let minDistance = 9999;
	let exit = false;

	for (let i=0; i<colors.length;i++)
	{
		colorData = ColorsDataUtilities.FindColor(colors[i].color_id);

		arrayColorVector = ColorsDataUtilities.GetColorFromString(colorData.color);

		vecDelta1 = new THREE.Vector3().subVectors( new THREE.Vector3(arrayColorVector.r, arrayColorVector.g, arrayColorVector.b), new THREE.Vector3(color.r, color.g, color.b));
		let vecDelta1Mag = (vecDelta1.x * vecDelta1.x) + (vecDelta1.y * vecDelta1.y) + (vecDelta1.z * vecDelta1.z);

		brightnessAdjustedColor = new THREE.Color(color.r, color.g, color.b);

		exit = false;

		while (!exit)
		{
			if (brightnessAdjustedColor.r - 0.01 < 0 || brightnessAdjustedColor.g - 0.01 < 0 || brightnessAdjustedColor.b - 0.01 < 0)
				exit = true;
			else
			{
				brightnessAdjustedColor.r-=0.01;
				brightnessAdjustedColor.g-=0.01;
				brightnessAdjustedColor.b-=0.01;
			}
		}

		exit = false;

		while (!exit)
		{
			let vecDelta2 = new THREE.Vector3().subVectors( new THREE.Vector3(arrayColorVector.r, arrayColorVector.g, arrayColorVector.b), new THREE.Vector3(brightnessAdjustedColor.r, brightnessAdjustedColor.g, brightnessAdjustedColor.b));
			let vecDelta2Mag = (vecDelta2.x * vecDelta2.x) + (vecDelta2.y * vecDelta2.y) + (vecDelta2.z * vecDelta2.z);

			let vecDelta = vecDelta1Mag + vecDelta2Mag * weighting1;

			if (vecDelta < minDistance)
			{
				minDistance = vecDelta;
				colorIndex = i;
			}

			brightnessAdjustedColor.r+=0.01;
			brightnessAdjustedColor.g+=0.01;
			brightnessAdjustedColor.b+=0.01;

			if (brightnessAdjustedColor.r > 1 || brightnessAdjustedColor.g > 1 || brightnessAdjustedColor.b > 1)
				exit = true;
		}
	}

	return colorIndex;
};


ColorsDataUtilities.colorsData = [];
ColorsDataUtilities.doorColorsData = [];

ColorsDataUtilities.DOOR_COLORS_PER_ROW = 5;
ColorsDataUtilities.TRIM_COLORS_PER_ROW = 5;
ColorsDataUtilities.SIDING_COLORS_PER_ROW = 10;
ColorsDataUtilities.ROOFING_COLORS_PER_ROW = 10;

