/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

/**
 *
 *
 */
function Diagram()
{

}

/**
 * creates an SVG diagram of the floor plan of the building
 * param (object) building building object
*/
Diagram.createDiagram = function (building)
{
	let diagramSVG = $($.parseHTML("<svg></svg>"));
}
