/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function ShedBuilding(buildingID, roofRafter, sizeData)
{
	// eslint-disable-next-line no-undef
	Building.call(this, buildingID, roofRafter, sizeData);

	this.Initialize = async function ()
	{
		this.SetSizeData(this.sizeData);

		this.base = new Base();

		this.floor = new Floor();

		if (this.sizeData.porch_dimensions[1] != 0)
		{
			this.porch = new Porch();

			this.porch.Initialize(this.sizeData.porch_dimensions[1], this.sizeData.porch_dimensions[0]);
		}
		else
			this.porch = null;

		this.walls = new Walls();

		if (buildingDesigner.building.metalFraming)
			this.roof = new MetalBuildingRoof();
		else
			this.roof = new Roof();

		await this.walls.Initialize();

		/*////if (buildingDesigner.defaultSettings)
		{
			await this.walls.SetSidingData(GuiDataUtilities.GetSidingColorButtonData(buildingDesigner.defaultSettings.siding_id));

			await this.roof.SetRoofingData(GuiDataUtilities.GetRoofingButtonData(buildingDesigner.defaultSettings.roofing_id));

			this.SetTrimColor(buildingDesigner.defaultSettings.trim_color_id);

			if (buildingDesigner.defaultSettings.default_elements)
				this.AddElements(buildingDesigner.defaultSettings.default_elements);
		}
		else
		{
			await this.walls.SetSidingData(GuiDataUtilities.sidingColorButtonData[0]);

			await this.roof.SetRoofingData(GuiDataUtilities.roofingButtonData[0]);
		}*/

		await this.InitializeSidingRoofingTrimAndDefaultElements();


		if (buildingDesigner.building.metalFraming)
		{
			// This is scheduled to be changed to this.framing, as it is actually framing and not rafters
			this.rafters = new MetalRafters(this.roofRafter.data.thickness, buildingDesigner.building.roofRafter.data.width);
		}
		else
		{
			// This is scheduled to be changed to this.framing, as it is actually framing and not rafters
			this.rafters = new WoodRafters(this.roofRafter.data.thickness, buildingDesigner.building.roofRafter.data.width);
		}

		////this.SetBuildingModified();

		ElementsMenu.ElementsListPricingUpdate();

		this.InitializeRulersAndLogo();

		this.initialized = true;
	};

	this.SetRafterAndSizeData = async function (roofRafter, sizeData)
	{
		this.roofRafter = roofRafter;

		await this.SetSizeData(sizeData);

		this.base = new Base();

		this.floor = new Floor();

		if (buildingDesigner.building.metalFraming)
		{
			// This is scheduled to be changed to this.framing, as it is actually framing and not rafters
			this.rafters = new MetalRafters(this.roofRafter.data.thickness, this.roofRafter.data.width);
		}
		else
		{
			// This is scheduled to be changed to this.framing, as it is actually framing and not rafters
			this.rafters = new WoodRafters(this.roofRafter.data.thickness, this.roofRafter.data.width);
		}

		if (this.porch)
		{
			this.porch.Initialize(this.sizeData.porch_dimensions[1], this.sizeData.porch_dimensions[0]);
		}

		await this.walls.Initialize();

		ElementsMenu.ElementsListPricingUpdate();

		this.SetBuildingModified();

		this.InitializeRulersAndLogo();

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		buildingDesigner.Draw();
	};
}
