/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2 */
/*eslint-disable no-console, no-unused-vars, no-undef*/

/**
 * A utility class to set lighting
 * @constructor
 *
 */
function Lights()
{
	this.light1Pos = new THREE.Vector3(-20, 20, 20.0);

	this.reflectedLight1 = new THREE.DirectionalLight(Lights.LIGHT_COLOR, Lights.REFLECTED_LIGHT_INTENSITY_EXTERIOR);

	this.reflectedLight1Pos = new THREE.Vector3(20, 20, -30.0);

	this.reflectedLight1.position.copy(this.reflectedLight1Pos);
	this.reflectedLight1.intensity = Lights.REFLECTED_LIGHT_INTENSITY;

	this.reflectedLight1.castShadow = false;

	threeScene.add(this.reflectedLight1);
	threeRenderer.shadowMap.needsUpdate = true;

	this.reflectedLight2 = new THREE.DirectionalLight(Lights.LIGHT_COLOR, Lights.REFLECTED_LIGHT2_INTENSITY_EXTERIOR);

	this.reflectedLight2Pos = new THREE.Vector3(-20, 20, -30.0);

	this.reflectedLight2.position.copy(this.reflectedLight2Pos);
	this.reflectedLight2.intensity = Lights.REFLECTED_LIGHT_INTENSITY;

	this.reflectedLight2.castShadow = false;

	threeScene.add(this.reflectedLight2);
	threeRenderer.shadowMap.needsUpdate = true;

	if (!AuxUtilities.IsMobileOrTablet())
	{
		this.mainLight = new THREE.DirectionalLight(Lights.LIGHT_COLOR, Lights.MAIN_LIGHT_INTENSITY);

		this.mainLight.position.copy(this.light1Pos);
		this.mainLight.intensity = Lights.MAIN_LIGHT_INTENSITY;

		this.mainLight.castShadow = true;

		this.mainLight.shadow.mapSize.width = 4096;
		this.mainLight.shadow.mapSize.height = 4096;
		this.mainLight.shadow.radius = 2;

		this.mainLight.shadow.camera.near = 0;
		this.mainLight.shadow.camera.far = 100;

		this.mainLight.shadow.camera.left = -40;
		this.mainLight.shadow.camera.right = 40;
		this.mainLight.shadow.camera.top = 25;
		this.mainLight.shadow.camera.bottom = -25;

		this.mainLight.shadow.bias = -0.0005;

		threeScene.add(this.mainLight);
		threeRenderer.shadowMap.needsUpdate = true;
	}

	this.light = new THREE.AmbientLight(0xffffff);

	if (AuxUtilities.IsMobile())
		this.light.intensity = Lights.MOBILE_AMBIENT_LIGHT_INTENSITY;
	else
		this.light.intensity = Lights.AMBIENT_LIGHT_INTENSITY_EXTERIOR;

	threeScene.add(this.light);
	threeRenderer.shadowMap.needsUpdate = true;

	threeRenderer.shadowMap.enabled = true;
	threeRenderer.shadowMap.autoUpdate = true;
}

Lights.LIGHT_COLOR = 0xFFFFFF;
////Lights.MAIN_LIGHT_INTENSITY = 1.0;
Lights.MAIN_LIGHT_INTENSITY = 1.2;

Lights.REFLECTED_LIGHT_INTENSITY_EXTERIOR = 0.5;
Lights.REFLECTED_LIGHT2_INTENSITY_EXTERIOR = 0.2;

Lights.REFLECTED_LIGHT_INTENSITY_INTERIOR = 0.4;

////Lights.AMBIENT_LIGHT_INTENSITY_EXTERIOR = 1.2;
Lights.AMBIENT_LIGHT_INTENSITY_EXTERIOR = 0.8;

Lights.AMBIENT_LIGHT_INTENSITY_INTERIOR = 1.3;

Lights.MOBILE_AMBIENT_LIGHT_INTENSITY = Lights.AMBIENT_LIGHT_INTENSITY_EXTERIOR * 1.4;

Lights.prototype.update = function() {
	if (!threeDFishBuildingDesigner().building) {
		this._updateForEmpty();
		return;
	}

	if (threeDFishBuildingDesignerCamera().modeCamera === Camera.CAM_MODE_EXTERIOR)
		this._updateForBuildingExterior();
	else
		this._updateForBuildingInterior()
};

Lights.prototype._updateForEmpty = function() {
	this.reflectedLight1.intensity = Lights.REFLECTED_LIGHT_INTENSITY_EXTERIOR;

	this.reflectedLight1.position.copy(this.reflectedLight1Pos);

	this.reflectedLight2.intensity = Lights.REFLECTED_LIGHT2_INTENSITY_EXTERIOR;

	this.reflectedLight2.position.copy(this.reflectedLight2Pos);

	if (!AuxUtilities.IsMobileOrTablet())
	{
		this.mainLight.intensity = Lights.MAIN_LIGHT_INTENSITY;
	}

	if (AuxUtilities.IsMobile())
	{
		this.light.intensity = Lights.MOBILE_AMBIENT_LIGHT_INTENSITY;
	}
	else
	{
		this.light.intensity = Lights.AMBIENT_LIGHT_INTENSITY_EXTERIOR;
	}
};

Lights.prototype._updateForBuildingInterior = function() {
	this.reflectedLight1.intensity = Lights.REFLECTED_LIGHT_INTENSITY_INTERIOR;

	this.reflectedLight2.intensity = Lights.REFLECTED_LIGHT_INTENSITY_INTERIOR;
};

Lights.prototype._updateForBuildingExterior = function() {
	this.reflectedLight1.intensity = Lights.REFLECTED_LIGHT_INTENSITY_EXTERIOR;

	this.reflectedLight1.position.copy(this.reflectedLight1Pos);

	this.reflectedLight2.intensity = Lights.REFLECTED_LIGHT2_INTENSITY_EXTERIOR;

	this.reflectedLight2.position.copy(this.reflectedLight2Pos);

	if (!AuxUtilities.IsMobileOrTablet())
	{
		if (this.mainLight)
		{
			this.mainLight.intensity = Lights.MAIN_LIGHT_INTENSITY;
		}
	}

	if (AuxUtilities.IsMobile())
	{
		this.light.intensity = Lights.MOBILE_AMBIENT_LIGHT_INTENSITY;
	}
	else
	{
		this.light.intensity = Lights.AMBIENT_LIGHT_INTENSITY_EXTERIOR;
	}
};


