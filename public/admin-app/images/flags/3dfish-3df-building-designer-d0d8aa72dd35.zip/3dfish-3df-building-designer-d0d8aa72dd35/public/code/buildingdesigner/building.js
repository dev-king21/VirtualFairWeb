/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef*/

/**
 *
 *
 * @param {*} buildingID
 * @param {*} roofRafter
 * @param {*} sizeData
 * @param {*} stallCount
 */
function Building(buildingID, roofRafter, sizeData, stallCount)
{
	this.mesh = null;
	this.regenerate = true;

	this.ID = buildingID;

	this.designID = "";
	if (LoadingSavingUtilities.designID) {
		this.designID = LoadingSavingUtilities.designID;
		LoadingSavingUtilities.designID = "";
	}
	GuiDataUtilities.displayDesignID(this.designID);

	this.roofRafter = roofRafter;

	this.type = ELEM_BUILDING;

	this.detailListText = "";

	this.detailList = [];

	this.sizeData = sizeData;

	this.stallCount = stallCount;

	this.buildingMeshes = [];
	this.tempBuildingMeshes = [];

	this.elementsMesh = new THREE.Mesh();

	this.regenerateBuildingMeshes = true;
	this.regenerateElementMeshes = true;
	this.elementRequiresAdditionalRegenerate = false;

	this.updateElementMatrices = false;

	////this.logo = new Logo();

	this.horizLengthRuler = new Ruler(this, Ruler.HORIZ_RULER);
	this.horizLengthRuler.GetTextures();

	this.horizLengthRuler.SetDescriptionText("Front");

	this.horizLengthRuler2 = new Ruler(this, Ruler.HORIZ_RULER);
	this.horizLengthRuler2.GetTextures();

	this.horizLengthRuler2.SetDescriptionText("Back");

	this.horizWidthRuler = new Ruler(this, Ruler.HORIZ_RULER);
	this.horizWidthRuler.GetTextures();

	this.horizWidthRuler.SetDescriptionText("Right");

	this.horizWidthRuler2 = new Ruler(this, Ruler.HORIZ_RULER);
	this.horizWidthRuler2.GetTextures();

	this.horizWidthRuler2.SetDescriptionText("Left");

	this.vertHeightRuler = new Ruler(this, Ruler.VERT_RULER);
	this.vertHeightRuler.GetTextures();

	this.vertHeightRuler2 = new Ruler(this, Ruler.VERT_RULER);
	this.vertHeightRuler2.GetTextures();

	this.floorHeight = Floor.JOIST_HEIGHT + Floor.FLOOR_PANEL_THICKNESS;

	this.lineGuides = [];

	let buildingButtonData = GuiDataUtilities.GetButtonData(buildingID);

	this.sidingSetsEveTrimColor = buildingButtonData.siding_always_sets_eve_trim_color;
	this.sidingSetsCornerTrimColor = buildingButtonData.siding_always_sets_corner_trim_color;

	this.eveTrimUsesSidingColorSetting = buildingButtonData.eve_trim_uses_siding_color_setting;
	this.cornerTrimUsesSidingColorSetting = buildingButtonData.corner_trim_uses_siding_color_setting;

	this.user_can_override_trim_color = buildingButtonData.user_can_override_trim_color;

	this.metalFraming = buildingButtonData.metal_framing;

	this.crossMember = buildingButtonData.cross_member;

	this.options = buildingButtonData.options;

	this.discount = 0;

	this.designLoaded = false;

	this.initialized = false;

	this.Initialize = async function ()
	{
		await this.SetSizeData(this.sizeData);

		this.base = new Base(this.width, this.length);

		this.floor = new Floor(this.width, this.length);

		this.walls = new Walls();

		await this.walls.Initialize();

		this.walls.SetSidingData(GuiDataUtilities.sidingColorButtonData[0]);

		this.roof = new Roof();

		this.roof.SetRoofingData(GuiDataUtilities.roofingButtonData[0]);

		this.rafters = new Rafters(this.roofRafter, this.length, this.height, this.roofRafter.data.thickness, this.roofRafter.data.thickness);

		ElementsMenu.ElementsListPricingUpdate();

		this.InitializeRulersAndLogo();

		this.initialized = true;
	};

	this.InitializeSidingRoofingTrimAndDefaultElements = async function()
	{
		if (BuildingDesigner.buildingChangedbyUser)
		{
			await this.walls.SetSidingData(GuiDataUtilities.GetSidingColorButtonData(BuildingDesigner.previousSiding));
			await this.roof.SetRoofingData(GuiDataUtilities.GetRoofingButtonData(BuildingDesigner.previousRoofing));
			this.SetTrimColor(BuildingDesigner.previousTrim);

		}
		else if (BuildingDesigner.buildingLoadedFromDesign != true && buildingDesigner.defaultSettings && buildingDesigner.defaultSettings != "" && buildingDesigner.defaultSettings.siding_id && buildingDesigner.defaultSettings.roofing_id && buildingDesigner.defaultSettings.trim_color_id)
		{
			//if (buildingDesigner.defaultSettings.siding_id)
			await this.walls.SetSidingData(GuiDataUtilities.GetSidingColorButtonData(buildingDesigner.defaultSettings.siding_id)||GuiDataUtilities.sidingColorButtonData[0]);

			//if (buildingDesigner.defaultSettings.roofing_id)
			await this.roof.SetRoofingData(GuiDataUtilities.GetRoofingButtonData(buildingDesigner.defaultSettings.roofing_id));
			let roofingIndex = GuiDataUtilities.roofingButtonData.findIndex(element => element.category_id == buildingDesigner.building.roof.categoryID);
			ElementsMenu.OnClickShowRoofingColorsForCategory(roofingIndex);

			//if (buildingDesigner.defaultSettings.trim_color_id)
			this.SetTrimColor(buildingDesigner.defaultSettings.trim_color_id);
			$(`#trim_${buildingDesigner.defaultSettings.trim_color_id}`).prop("checked",true);

			if (buildingDesigner.defaultSettings.default_elements && buildingDesigner.buildingType != BUILDING_HORSEBARN)
			{
				this.AddElements(buildingDesigner.defaultSettings.default_elements);
			}
		}
		else
		{
			await this.walls.SetSidingData(GuiDataUtilities.sidingColorButtonData[0]);

			await this.roof.SetRoofingData(GuiDataUtilities.roofingButtonData[0]);
			if (interfaceNumber > 2)
			{
				if (!BuildingDesigner.buildingLoadedFromDesign)
				{
					ElementsMenu.OnClickShowSidingColorsForCategory(0);
					ElementsMenu.OnClickShowRoofingColorsForCategory(0);
				}
				else
				{
					if (buildingDesigner.savedDesignObject)
					{
						$("[name=\"trimSelection\"]").removeAttr("checked");
						$(`#trim_${buildingDesigner.savedDesignObject.TDFDESIGN.BUILDING.TRIM.cornerTrimColor}`).prop("checked",true);
						//$(`#trim_${buildingDesigner.building.roof.cornerTrimColorID}`).prop('checked',true);
						$("[name=\"sidingSelection\"]").removeAttr("checked");
						ElementsMenu.OnClickShowSidingColorsForCategory(GuiDataUtilities.GetSidingCategoryIndex(buildingDesigner.savedDesignObject.TDFDESIGN.BUILDING.WALLS_LIST.WALL[0].sidingCategoryData.category_id),true);
						//ElementsMenu.OnClickShowSidingColorsForCategory(GuiDataUtilities.GetSidingCategoryIndex(buildingDesigner.building.walls.sidingCategoryData.category_id),true);
						$(`#${buildingDesigner.savedDesignObject.TDFDESIGN.BUILDING.WALLS_LIST.WALL[0].sidingColorData.color_id}`).prop("checked",true);
						//$(`#${buildingDesigner.building.walls.sidingCategoryData.color_id}`).prop('checked',true);
						ElementsMenu.OnClickShowRoofingColorsForCategory(GuiDataUtilities.GetRoofingCategoryIndex(buildingDesigner.savedDesignObject.TDFDESIGN.BUILDING.ROOFING.roofingButtonData.category_id),true);
						//ElementsMenu.OnClickShowRoofingColorsForCategory(GuiDataUtilities.GetRoofingCategoryIndex(buildingDesigner.building.roof.categoryID),true);
						$("[name=\"roofingSelection\"]").removeAttr("checked");
						$(`#${buildingDesigner.savedDesignObject.TDFDESIGN.BUILDING.ROOFING.roofingButtonData.roofing_id}`).prop("checked",true);
						//if (DEBUG) console.log($(`${buildingDesigner.savedDesignObject.TDFDESIGN.BUILDING.ROOFING.roofingButtonData.roofing_id}`).prop('checked'));
						//$(`${buildingDesigner.building.roof.data.roofing_id}`).prop('checked',true);
					}
				}
			}
		}
	};

	/**
	 * @method
	 * @returns {string} XML Design String
	 */
	this.GetDesignXMLString = function ()
	{
		let strXml = "<SHED id=\"" + this.ID +
			"\" width=\"" + this.width +
			"\" length=\"" + this.length +
			"\" height=\"" + this.height +
			"\">";

		strXml += "<RAFTER data=\"" + AuxUtilities.JSONStringifyAndEncode(Rafters.rafterData) + "\"/>";

		strXml += "<DISCOUNTS value=\"" + this.discount + "\"/>";

		strXml += "<ROOFING roofingButtonData=\"" + AuxUtilities.JSONStringifyAndEncode(this.roof.data) + "\" horizontalProfilePts=\"" + AuxUtilities.JSONStringifyAndEncode(this.roof.horizontalProfilePts) + "\" verticalProfilePts=\"" + AuxUtilities.JSONStringifyAndEncode(this.roof.verticalProfilePts) + "\" />";

		strXml += "<TRIM eveTrimColor=\"" + this.roof.eveTrimColorID + "\" cornerTrimColor=\"" + this.roof.cornerTrimColorID + "\"/>";

		strXml += this.walls.GetDesignXMLString();

		strXml += Elements.GetObjectsDesignXMLString();

		strXml += Elements.GetDesignXMLString();

		strXml += "</SHED>";
		return strXml;
	};

	this.GetDesignObject = function ()
	{
		let designObject = {
			id: this.ID,
			width: this.width,
			length: this.length,
			height: this.height,
			RAFTER: {
				data: Rafters.rafterData
			},
			DISCOUNTS: {
				value: this.discount},
			ROOFING: {
				roofingButtonData: this.roof.data,
				horizontalProfilePts: this.roof.horizontalProfilePts,
				verticalProfilePts: this.roof.verticalProfilePts
			},
			TRIM: {
				eveTrimColor: this.roof.eveTrimColorID,
				cornerTrimColor: this.roof.cornerTrimColorID
			},
			WALLS_LIST: this.walls.GetDesignObject(),
			OBJECTS_LIST: Elements.GetObjectsDesignObject(),
			ELEMENTS_LIST: Elements.GetDesignObject()
		};
		return designObject;
	};

	this.LoadTDFDesignerFileVersion10 = async function (xmlDesignDoc)
	{
		this.LoadDiscountFromXML(xmlDesignDoc);
		await this.walls.LoadWallsFromXML(xmlDesignDoc);
		this.LoadTrimFromXML(xmlDesignDoc);
		this.LoadRoofingFromXML(xmlDesignDoc);
		Elements.LoadObjectsFromXML(xmlDesignDoc);
		Elements.LoadElementsFromXML(xmlDesignDoc);

		LoadingSavingUtilities.loadingDefaultBuilding = false;

		this.designLoaded = true;

		this.SetBuildingModified();
	};

	/**
	 * @method Building.LoadTDFDesignerObject
	 * @async
	 * @param {Object} savedDesignObject
	 */
	this.LoadTDFDesignerObject = async function (savedDesignObject)
	{
		this.LoadDiscountFromObject(savedDesignObject.TDFDESIGN.BUILDING);
		await this.walls.LoadWallsFromObject(savedDesignObject.TDFDESIGN.BUILDING);
		this.LoadTrimFromObject(savedDesignObject.TDFDESIGN.BUILDING);
		this.LoadRoofingFromObject(savedDesignObject.TDFDESIGN.BUILDING);
		Elements.LoadObjectsFromObject(savedDesignObject.TDFDESIGN.BUILDING);
		Elements.LoadElementsFromObject(savedDesignObject.TDFDESIGN.BUILDING);

		LoadingSavingUtilities.loadingDefaultBuilding = false;

		this.SetBuildingModified();
	};

	this.LoadDiscountFromXML = function (xmlDesignDoc)
	{
		let nodeDiscounts = xmlDesignDoc.getElementsByTagName("DISCOUNTS")[0];

		if (nodeDiscounts)
		{
			this.discount = Number(nodeDiscounts.getAttribute("value"));

			if (isNaN(this.discount))
			{
				this.discount = 0;
			}

		}
		else
			this.discount = 0;
	};

	/**
	 * @method Building.LoadDiscountFromObject
	 * @param {Object} building BUILDING object from savedDesignObject.TDFDESIGN
	 */
	this.LoadDiscountFromObject = function(building)
	{
		if (building.DISCOUNTS && building.DISCOUNTS.value)
		{
			this.discount = building.DISCOUNTS.value;
		}
		else
		{
			this.discount = 0;
		}
	};

	this.LoadRoofingFromXML = function (xmlDesignDoc)
	{
		let nodeRoofing = xmlDesignDoc.getElementsByTagName("ROOFING")[0];

		let roofingButtonData = nodeRoofing.getAttribute("roofingButtonData");

		let horizontalProfilePts = nodeRoofing.getAttribute("horizontalProfilePts");

		let verticalProfilePts = nodeRoofing.getAttribute("verticalProfilePts");


		roofingButtonData = AuxUtilities.JSONDecodeAndParse(roofingButtonData);

		horizontalProfilePts = AuxUtilities.JSONDecodeAndParse(horizontalProfilePts);

		verticalProfilePts = AuxUtilities.JSONDecodeAndParse(verticalProfilePts);

		if (roofingButtonData && (horizontalProfilePts || verticalProfilePts))
		{
			this.roof.SetRoofingData(roofingButtonData, horizontalProfilePts, verticalProfilePts);
		}
		else
		{
			let roofingID = nodeRoofing.getAttribute("roofingID");

			this.roof.SetRoofingData(GuiDataUtilities.GetRoofingButtonData(roofingID));
		}
	};

	/**
	 * @method Building.LoadRoofingfromObject
	 * @param {Object} building savedDesignObject.TDFDESIGN.BUILDING
	 */
	this.LoadRoofingFromObject = function (building)
	{
		if (building.ROOFING && building.ROOFING.roofingButtonData && (building.ROOFING.horizontalProfilePts || building.ROOFING.verticalProfilePts))
		{
			this.roof.SetRoofingData(building.ROOFING.roofingButtonData, building.ROOFING.horizontalProfilePts, building.ROOFING.verticalProfilePts);
		}
		else
		{
			if (building.ROOFING.roofing_id)
			{
				// TODO: check for validity of roofing_id and set to default if not valid
				this.roof.SetRoofingData(GuiDataUtilities.GetRoofingButtonData(building.ROOFING.roofing_id));
			}
			else
			{
				// TODO: set to default roofing if roofing_id doesn't exist
			}
		}
	};

	this.LoadTrimFromXML = function (xmlDesignDoc)
	{
		let nodeTrim = xmlDesignDoc.getElementsByTagName("TRIM")[0];

		let colorID = nodeTrim.getAttribute("eveTrimColor");

		if (colorID != "null" && colorID != null) {
			this.SetEveTrimColor(colorID);
		}

		colorID = nodeTrim.getAttribute("cornerTrimColor");

		if (colorID != "null" && colorID != null) {
			this.SetCornerTrimColor(colorID);
		}
	};

	/**
	 * @method Building.LoadTrimFromObject
	 * @param {Object} building savedDesignObject.TDFDESIGN.BUILDING
	 */
	this.LoadTrimFromObject = function (building)
	{
		if (building.TRIM)
		{
			if (building.TRIM.eveTrimColor)
			{
				this.SetEveTrimColor(building.TRIM.eveTrimColor);
			}
			if (building.TRIM.cornerTrimColor)
			{
				this.SetCornerTrimColor(building.TRIM.cornerTrimColor);
			}
		}
	};

	this.AddElements = function (elements)
	{
		for (let i = 0; i < elements.length; i++)
		{
			this.AddDefaultElement(elements[i]);
		}
	};


	this.AddDefaultElement = function (defaultElementData)
	{
		if (!defaultElementData) {
			return;
		}
		let elementID = defaultElementData.elem_id;

		let elemData = GuiDataUtilities.GetButtonData(elementID);

		let element = {};
		if (!elemData) {
			console.warn("Requested default building element not found.");
			return;
		}

		switch (defaultElementData.object_type)
		{
		case ("door"):
			element = Door.AddDoor(elemData, Door.LEFT_OPENING);
			break;

		case ("window"):
			element = Window.AddWindow(elemData);
			break;

		case ("option"):
			if (this.height >= 9)
				elemData.width = 3;
			else
				elemData.width = 2;

			element = LegBraces.AddLegBraces(elemData);
			break;
		}

		if (defaultElementData.no_extra_cost) {
			element.price = 0;
		}

		element.defaultElementData = defaultElementData;

		element.colorFromBarn = true;

		let wall = this.walls.GetWall(defaultElementData.placement_wall);

		element.SetWall(wall);

		let x = 0;

		if (defaultElementData.placement_location == "center") {
			x = 0;
		} else if (defaultElementData.placement_location == "right")
		{
			x = wall.length * 4.07 / 5 - wall.length / 2;
		}
		else if (defaultElementData.placement_location == "left") {
			x = wall.length * 0.93 / 5 - wall.length / 2;
		}


		let y = 0;

		if (defaultElementData.object_type == "window") {
			y = this.height * 2 / 3;
		}

		if (defaultElementData.elem_id.indexOf("LegBraces") == -1) {
			element.SetPos(x, y, Wall.WALLTHICKNESS);
		}
	};

	this.SetRafter = function (roofRafter)
	{
		this.roofRafter = roofRafter;

		this.SetRegenerateBuildingAndElementMeshes(true);
		buildingDesigner.Draw();

		ElementsMenu.ElementsListPricingUpdate();
	};

	this.GetClosestSideWallRafterCoord = function (x)
	{
		let rafterCoord = -1;
		let rafterIndex = -1;

		let min = 9999;
		let dist;

		for (let i = 1; i < buildingDesigner.building.rafters.frontBackRafterCoords.length; i++)
		{
			dist = Math.abs((buildingDesigner.building.rafters.frontBackRafterCoords[i] + buildingDesigner.building.length / 2) - x);

			if (dist < min)
			{
				min = dist;

				rafterCoord = buildingDesigner.building.rafters.frontBackRafterCoords[i];
				rafterIndex = i;
			}
		}

		return {
			coord: rafterCoord,
			index: rafterIndex
		};
	};

	this.SetSizeData = async function (sizeData)
	{
		this.sizeData = sizeData;

		if (this.roof)
		{
			let roofingPrice = await this.roof.GetRoofPrice(this.sizeData.product_id, this.roof.data.category_id);

			this.roof.SetPrice(roofingPrice);
		}

		this.width = this.sizeData.width;
		this.length = this.sizeData.length;
		this.height = this.sizeData.height;
		if ((! (typeof WallExtension === "undefined")) && WallExtension) {
			this.height += WallExtension.height;
		}

		this.backWallHeight = this.height - this.roofRafter.frontBackHeightDifference;

		if (buildingDesigner.building.walls)
		{
			buildingDesigner.building.walls.wallLength = buildingDesigner.building.length - Wall.WALLTHICKNESS * 2;
		}
	};

	this.SetBuildingModified = function ()
	{
		// hopefully XML persistance storage will be depricated and replaced by Object storage
		// as soon as we can deal with size issues
		//IndexDB.AddPersistentDesignToStorage(LoadingSavingUtilities.GetDesignXMLString());
		if (!BuildingDesigner.creatingBuilding)
		{
			if (!((featureData && featureData.interface && featureData.interface.persistent_design_off) || DEBUG))
			{
				IndexDB.AddPersistentDesignToStorage(LoadingSavingUtilities.GetDesignObject());
			}


			buildingDesigner.Draw();

			ElementsMenu.ElementsListPricingUpdate();
		}
	};

	this.SetDesignModified = function () {
		if (this.designID) {
			LoadingSavingUtilities.lastDesignID = this.designID;
			this.designID = "";
			GuiDataUtilities.displayDesignID("");
		}
	}

	this.SetRafterAndSizeData = async function (roofRafter, sizeData)
	{
		this.roofRafter = roofRafter;

		await this.SetSizeData(sizeData);

		this.base = new Base();

		this.floor = new Floor();

		if (buildingDesigner.building.metalFraming) {
			this.rafters = new MetalRafters(this.roofRafter.data.thickness, this.roofRafter.data.thickness);
		} else {
			this.rafters = new WoodRafters(this.roofRafter.data.thickness, this.roofRafter.data.thickness);
		}

		await this.walls.Initialize();

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		buildingDesigner.Draw();

		ElementsMenu.ElementsListPricingUpdate();

		this.SetBuildingModified();
	};

	this.GetWindowsOnWall = function (eWall)
	{
		return Elements.GetWindowsOnWall(eWall);
	};

	this.SetSidingData = async function (colorData)
	{
		await this.walls.SetSidingData(colorData);
	};

	this.SetRoofingData = async function (data)
	{
		await this.roof.SetRoofingData(data);
	};


	this.SetEveTrimColor = function (color)
	{
		this.roof.SetEveTrimColor(color);
	};

	this.SetCornerTrimColor = function (color)
	{
		this.roof.SetCornerTrimColor(color);
	};

	this.SetTrimColor = function (color)
	{
		this.roof.SetTrimColor(color);
	};


	this.AddFloorHeightAboveGround = function (meshes)
	{
		for (i = 0; i < meshes.length; i++)
		{
			meshes[i].matrixAutoUpdate = false;
			meshes[i].applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.floorHeight, 0));
		}
	};


	this.OnClickChangeSidingColor = async function (elementButton)
	{
		await this.SetSidingData(GuiDataUtilities.sidingColorButtonData[elementButton.btnIndex]);

		this.SetRegenerateBuildingAndElementMeshes(true);

		this.SetBuildingModified();
	};

	this.OnClickChangeRoofingColor = async function (elementButton)
	{
		await this.SetRoofingData(GuiDataUtilities.roofingButtonData[elementButton.btnIndex]);

		this.SetRegenerateBuildingAndElementMeshes(true);

		this.SetBuildingModified();
	};

	this.OnClickChangeTrimColor = function (color)
	{
		if (this.user_can_override_trim_color) {
			this.SetTrimColor(color);
		} else {
			if ((!this.eveTrimUsesSidingColorSetting || !this.walls.setEveTrimColor) && !this.sidingSetsEveTrimColor)
			{
				this.SetEveTrimColor(color);
			}

			if ((!this.cornerTrimUsesSidingColorSetting || !this.walls.setCornerTrimColor) && !this.sidingSetsCornerTrimColor)
			{
				this.SetCornerTrimColor(color);
			}
		}

		this.SetRegenerateBuildingAndElementMeshes(true);

		this.SetBuildingModified();
	};

	this.SetSelected = function (selected)
	{
		this.selected = selected;

		this.horizLengthRuler.SetVisibility(this.selected);
		this.horizLengthRuler2.SetVisibility(this.selected);
		this.horizWidthRuler.SetVisibility(this.selected);
		this.horizWidthRuler2.SetVisibility(this.selected);
		this.vertHeightRuler.SetVisibility(this.selected);
		this.vertHeightRuler2.SetVisibility(this.selected);
	};

	this.AddDefaultElements = function ()
	{
		//this.stalls.AddDefaultElements();
	};

	this.SetRegenerateBuildingAndElementMeshes = function (regenerate)
	{
		buildingDesigner.environment.SetRegenerate(regenerate);

		this.SetRegenerateBuildingMeshes(regenerate);
		this.SetRegenerateElementMeshes(regenerate);
	};

	this.SetRegenerateBuildingMeshes = function (regenerate)
	{
		this.regenerateBuildingMeshes = regenerate;

		this.base.SetRegenerate(regenerate);

		if (this.floor) {
			this.floor.SetRegenerate(regenerate);
		}

		if (this.porch) {
			this.porch.SetRegenerate(regenerate);
		}

		if (this.rafters) {
			this.rafters.SetRegenerate(regenerate);
		}

		if (this.walls) {
			this.walls.SetRegenerate(regenerate);
		}

		if (this.roof) {
			this.roof.SetRegenerate(regenerate);
		}
	};

	this.SetRegenerateElementMeshes = function (regenerate)
	{
		this.regenerateElementMeshes = regenerate;


		Elements.SetRegenerate(regenerate);
		////Elements.regenerate = true;
	};


	this.SetUpdateElementMatrices = function (updateMatrices)
	{
		this.updateElementMatrices = updateMatrices;

		Elements.SetUpdateElementMatrices(updateMatrices);
	};

	this.SetShowRoof = function (value)
	{
		showRoof = value;
	};

	this.GenerateSelectedBoxes = function (parentMesh, matrix, boxSize)
	{
		let box_size2 = boxSize / 2.0;

		let width = this.width + this.roofRafter.leanToWidth;

		let box_offs_x = width + box_size2;
		let box_offs_y = this.height + boxSize;

		let box_offs_z = box_size2;

		let geomSelBox;
		let boxMatrix;

		let vecOffs = [{
			x: 0,
			y: 0,
			z: box_offs_z
		},
		{
			x: 0,
			y: box_offs_y / 2,
			z: box_offs_z
		},
		{
			x: 0,
			y: box_offs_y,
			z: box_offs_z
		},
		{
			x: box_offs_x,
			y: 0,
			z: box_offs_z
		},
		{
			x: box_offs_x,
			y: box_offs_y / 2,
			z: box_offs_z
		},
		{
			x: box_offs_x,
			y: box_offs_y,
			z: box_offs_z
		},
		{
			x: box_offs_x / 2,
			y: box_offs_y,
			z: box_offs_z
		},
		{
			x: box_offs_x / 2,
			y: 0,
			z: box_offs_z
		}
		];

		let materSelBox = Material.CreateMaterial(SEL_BOX_COLOR, null);

		let totalGeometry = new THREE.Geometry();

		for (let i = 0; i < 8; i++)
		{
			geomSelBox = new THREE.BoxGeometry(boxSize, boxSize, boxSize);
			boxMatrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(vecOffs[i].x, vecOffs[i].y, vecOffs[i].z));

			totalGeometry.merge(geomSelBox, boxMatrix);
		}

		for (let i = 0; i < 8; i++)
		{
			geomSelBox = new THREE.BoxGeometry(boxSize, boxSize, boxSize);
			boxMatrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(vecOffs[i].x, vecOffs[i].y, vecOffs[i].z - this.length - boxSize));

			totalGeometry.merge(geomSelBox, boxMatrix);
		}

		vecOffs = [{
			x: 0,
			y: 0,
			z: -this.length / 2
		},
		{
			x: 0,
			y: box_offs_y,
			z: -this.length / 2
		},
		{
			x: box_offs_x,
			y: box_offs_y,
			z: -this.length / 2
		},
		{
			x: box_offs_x,
			y: 0,
			z: -this.length / 2
		},

		];

		for (let i = 0; i < 4; i++)
		{
			geomSelBox = new THREE.BoxGeometry(boxSize, boxSize, boxSize);
			boxMatrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(vecOffs[i].x, vecOffs[i].y, vecOffs[i].z));

			totalGeometry.merge(geomSelBox, boxMatrix);
		}

		let meshSelBox = new THREE.Mesh(totalGeometry, materSelBox);
		parentMesh.add(meshSelBox);
	};

	this.InitializeRulersAndLogo = function()
	{
		if (buildingDesigner.logo) {
			buildingDesigner.logo.Generate();
		}

		this.InitializeRulers();
	}


	this.InitializeRulers = function ()
	{
		if (!(features.indexOf("NORULERS") > -1))
		{
			let pos;

			if (this.horizLengthRuler.SetWall(this.walls.GetWall(WALL_FRONT)))
			{
				this.horizLengthRuler.SetLength(this.horizLengthRuler.wall.length + Trim.CORNER_TRIM_THICKNESS*2);

				pos = new THREE.Vector3(0, Ruler.RULER_THICKNESS / 2, Ruler.RULER_IN_FRONT_WALL_DISTANCE);
				this.horizLengthRuler.SetPos(pos);

				this.horizLengthRuler.yRot = 0;
			}

			if (this.horizLengthRuler2.SetWall(this.walls.GetWall(WALL_BACK)))
			{
				this.horizLengthRuler2.SetLength(this.horizLengthRuler2.wall.length + Trim.CORNER_TRIM_THICKNESS*2);

				pos = new THREE.Vector3(0, Ruler.RULER_THICKNESS / 2, -Ruler.RULER_IN_FRONT_WALL_DISTANCE);
				this.horizLengthRuler2.SetPos(pos);

				this.horizLengthRuler2.yRot = Math.PI;
			}

			if (this.horizWidthRuler.SetWall(this.walls.GetWall(WALL_RIGHT)))
			{
				this.horizWidthRuler.SetLength(this.horizWidthRuler.wall.length + this.roofRafter.leanToWidth);

				pos = new THREE.Vector3(-this.roofRafter.leanToWidth / 2, Ruler.RULER_THICKNESS / 2, Ruler.RULER_IN_FRONT_WALL_DISTANCE);
				this.horizWidthRuler.SetPos(pos);

				this.horizWidthRuler.yRot = 0;
			}

			if (this.horizWidthRuler2.SetWall(this.walls.GetWall(WALL_LEFT)))
			{
				this.horizWidthRuler2.SetLength(this.horizWidthRuler2.wall.length + this.roofRafter.leanToWidth);

				pos = new THREE.Vector3(-this.roofRafter.leanToWidth / 2, Ruler.RULER_THICKNESS / 2, -Ruler.RULER_IN_FRONT_WALL_DISTANCE);
				this.horizWidthRuler2.SetPos(pos);

				this.horizWidthRuler2.yRot = Math.PI;
			}

			if (this.vertHeightRuler.SetWall(this.walls.GetWall(WALL_FRONT)))
			{
				this.vertHeightRuler.SetLength(this.walls.GetWall(WALL_FRONT).height);

				pos = new THREE.Vector3(this.vertHeightRuler.wall.length / 2 + Ruler.RULER_SIDE_WALL_DISTANCE, this.floorHeight, Ruler.VERTICAL_RULER_IN_FRONT_WALL_DISTANCE);
				this.vertHeightRuler.SetPos(pos);
			}

			if (this.vertHeightRuler2.SetWall(this.walls.GetWall(WALL_BACK)))
			{
				this.vertHeightRuler2.SetLength(this.walls.GetWall(WALL_BACK).height);

				pos = new THREE.Vector3(-this.vertHeightRuler2.wall.length / 2 - Ruler.RULER_SIDE_WALL_DISTANCE, this.floorHeight, -Ruler.VERTICAL_RULER_IN_FRONT_WALL_DISTANCE);
				this.vertHeightRuler2.SetPos(pos);
			}
		}
	};

	this.SetRulerOrientation = function(cameraSubQuad)
	{
		this.vertHeightRuler.SetOrientation(cameraSubQuad);
		this.vertHeightRuler2.SetOrientation(cameraSubQuad);
	}

	this.SetRegenerateRulers = function(regenerate)
	{
		if (!(features.indexOf("NORULERS") > -1))
		{
			this.horizLengthRuler.SetRegenerate(regenerate);
			this.horizLengthRuler2.SetRegenerate(regenerate);
			this.horizWidthRuler.SetRegenerate(regenerate);
			this.horizWidthRuler2.SetRegenerate(regenerate);
			this.vertHeightRuler.SetRegenerate(regenerate);
			this.vertHeightRuler2.SetRegenerate(regenerate);
		}
	};

	this.GenerateRulers = function ()
	{
		if (!(features.indexOf("NORULERS") > -1))
		{
			this.horizLengthRuler.Generate();
			this.horizLengthRuler2.Generate();
			this.horizWidthRuler.Generate();
			this.horizWidthRuler2.Generate();
			this.vertHeightRuler.Generate();
			this.vertHeightRuler2.Generate();
		}
	};

	this.Refresh = function ()
	{
		this.SetRegenerateBuildingAndElementMeshes(true);
		this.SetBuildingModified();
	};

	this.Regenerate = function ()
	{
		if (this.initialized)
		{
			if (this.roof.hipRoof && !this.regenerateBuildingMeshes) {
				buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
			}

			if (this.regenerateBuildingMeshes || this.regenerateElementMeshes) {
				this.RemoveThreeJSSceneMeshes();
			}

			if (this.regenerateBuildingMeshes && this.regenerateElementMeshes)
			{
				this.buildingMeshes = [];

				this.base.Generate(this.buildingMeshes);

				this.floor.Generate(this.buildingMeshes);

				this.rafters.Generate(this.buildingMeshes);

				if (showRoof)
				{
					this.roof.Generate(this.buildingMeshes);
				}

				this.walls.Generate(this.buildingMeshes);

				if (this.porch)
				{
					this.porch.Generate(this.buildingMeshes);
				}

				this.AddFloorHeightAboveGround(this.buildingMeshes);

				this.SetRegenerateRulers(true);

				this.GenerateRulers();

				this.regenerateBuildingMeshes = false;
			}

			this.tempBuildingMeshes = [];

			if (this.regenerateElementMeshes)
			{
				MeshUtilities.CloneMeshes(this.buildingMeshes, this.tempBuildingMeshes);

				this.elementsMesh = Elements.Generate(this.tempBuildingMeshes);

				if (this.elementsMesh)
				{
					this.elementsMesh.matrixAutoUpdate = false;
					this.elementsMesh.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.floorHeight, 0));
				}

				this.regenerateElementMeshes = false;
			}
			else
			{
				MeshUtilities.CloneMeshes(this.buildingMeshes, this.tempBuildingMeshes);
			}

			if (buildingDesigner.logo) {
				buildingDesigner.logo.Generate();
			}
		}
	};


	this.Draw = function ()
	{
		if (this.regenerateBuildingMeshes || this.regenerateElementMeshes)
		{
			do
			{
				if (this.elementRequiresAdditionalRegenerate)
				{
					this.SetRegenerateBuildingAndElementMeshes(true);
					this.elementRequiresAdditionalRegenerate = false;
				}

				this.RemoveThreeJSSceneMeshes();

				this.Regenerate();

				this.AddMeshesToScene();
			}
			while (this.elementRequiresAdditionalRegenerate);
		}
	};

	this.GetSelectedObjects = function (vecPosCanv, meshes)
	{
		if (meshes && meshes.length > 0 && meshes[0] != undefined)
		{
			let rayCaster = buildingDesigner.camera.GetRayCaster(vecPosCanv);

			if (RAYCASTER_DEBUG)
			{
				let material = new THREE.LineBasicMaterial({
					color: 0x0000ff
				});

				let geometry = new THREE.Geometry();
				geometry.vertices.push(new THREE.Vector3(rayCaster.ray.origin.x, rayCaster.ray.origin.y, rayCaster.ray.origin.z));
				geometry.vertices.push(new THREE.Vector3(rayCaster.ray.origin.x + (rayCaster.ray.direction.x * 100000), rayCaster.ray.origin.y + (rayCaster.ray.direction.y * 100000), rayCaster.ray.origin.z + (rayCaster.ray.direction.z * 100000)));
				let line = new THREE.Line(geometry, material);
				threeScene.add(line);
				threeRenderer.shadowMap.needsUpdate = true;
			}

			let interObjs = rayCaster.intersectObjects(meshes, true);

			return interObjs;
		}
		else
			return null;

	};

	this.IsBuildingSelected = function (vecPosCanv)
	{
		let wallAndPosOnWall = this.GetWallMouseOver(vecPosCanv, false);

		if (wallAndPosOnWall != null)
		{
			return wallAndPosOnWall.distance;
		}

		return -1;
	};

	this.GetSelectedElement = function (vecPosCanv)
	{
		let meshArray = [];
		meshArray.push(this.elementsMesh);

		let interObjs = null;

		interObjs = this.GetSelectedObjects(vecPosCanv, meshArray);

		if (interObjs)
		{
			let elemIndex = -1;

			for (let i = 0; i < interObjs.length; i++)
			{
				if (interObjs[i].object.material.length > 0)
				{
					if (interObjs[i].object.material[interObjs[i].face.materialIndex].element != null && interObjs[i].object.material[interObjs[i].face.materialIndex].element.type != ELEM_WALL)
					{
						let vecPickPoint = interObjs[i].point.clone();

						if (interObjs[i].object.component3DObject && GUIInput.currentGuiMode == GUIInput.GUI_MODE.OBJECT_EDITOR) {
							Elements.SetEditableComponent(interObjs[i].object.component3DObject);
						}

						return {
							element: interObjs[i].object.material[interObjs[i].face.materialIndex].element,
							vectorPos: vecPickPoint,
							distance: interObjs[i].distance
						};
					}
				}
				else
				{
					if (interObjs[i].object.material.length > 0 && interObjs[i].object.material[interObjs[i].face.materialIndex].element != null && interObjs[i].object.material[interObjs[i].face.materialIndex].element.type != ELEM_WALL)
					{
						let vecPickPoint = interObjs[i].point.clone();

						if (interObjs[i].object.component3DObject && GUIInput.currentGuiMode == GUIInput.GUI_MODE.OBJECT_EDITOR) {
							Elements.SetEditableComponent(interObjs[i].object.component3DObject);
						}

						return {
							element: interObjs[i].object.element,
							vectorPos: vecPickPoint,
							distance: interObjs[i].distance
						};
					}
					else
					{
						let component3DObject = interObjs[i].object.component3DObject;

						interObjs[i].object = MeshUtilities.GetElementParentObject(interObjs[i].object);

						if (interObjs[i].object && interObjs[i].object.element != null && interObjs[i].object.element.type != ELEM_WALL)
						{
							let vecPickPoint = interObjs[i].point.clone();

							if (component3DObject && GUIInput.currentGuiMode == GUIInput.GUI_MODE.OBJECT_EDITOR) {
								Elements.SetEditableComponent(component3DObject);
							}

							return {
								element: interObjs[i].object.element,
								vectorPos: vecPickPoint,
								distance: interObjs[i].distance
							};
						}
					}
				}
			}
		}

		return null;
	};

	this.GetWallMouseOver = function (vecPosCanv, useWallTransparencies)
	{
		let interObjs = this.GetSelectedObjects(vecPosCanv, this.buildingMeshes);

		if (interObjs)
		{
			let wallIndex = -1;

			if (useWallTransparencies == undefined || useWallTransparencies == null) {
				useWallTransparencies = true;
			}


			for (let i = 0; i < interObjs.length; i++)
			{
				if (interObjs[i].object.element != null)
				{
					if (interObjs[i].object.element.type == ELEM_WALL && interObjs[i].object.type != ELEM_WALL_TRANSPARENCY)
					{
						wallIndex = i;
						break;
					}
					else
					if (useWallTransparencies && interObjs[i].object.type == ELEM_WALL_TRANSPARENCY)
					{
						wallIndex = i;
						break;
					}
				}
			}

			if (wallIndex > -1)
			{
				let vecPickPoint = interObjs[wallIndex].point.clone();

				return {
					wall: interObjs[wallIndex].object.element,
					wallFacetIndex: interObjs[wallIndex].object.wallFacetIndex,
					vectorPos: vecPickPoint,
					distance: interObjs[wallIndex].distance
				};
			}
		}

		return null;
	};


	this.GetSelectedPartitionAtMouseCoord = function (vecPosCanv)
	{
		let interObjs = this.GetSelectedObjects(vecPosCanv, this.tempBuildingMeshes);

		if (interObjs)
		{
			let elemIndex = -1;

			for (let i = 0; i < interObjs.length; i++)
			{
				if (interObjs[i].object.element != null && interObjs[i].object.element.type == ELEM_PARTITION && interObjs[i].object.stallIndex != undefined)
				{
					return {
						element: this.stalls.stallsList[interObjs[i].object.stallIndex].partition,
						distance: interObjs[i].distance
					};
				}
				else if (interObjs[i].object.parent != null && interObjs[i].object.parent.element != null && interObjs[i].object.parent.element.type == ELEM_PARTITION && interObjs[i].object.parent.stallIndex != undefined)
				{
					return {
						element: this.stalls.stallsList[interObjs[i].object.parent.stallIndex].partition,
						distance: interObjs[i].distance
					};
				}
				else if (interObjs[i].object.material.length > 0 && interObjs[i].object.material[interObjs[i].face.materialIndex].element != null && interObjs[i].object.material[interObjs[i].face.materialIndex].element.type == ELEM_PARTITION)
				{
					return {
						element: interObjs[i].object.material[interObjs[i].face.materialIndex].element,
						distance: interObjs[i].distance
					};
				}
			}
		}

		return null;
	};

	this.DraggingElement = function (wall, facetIndex, vecPosCanv)
	{
		Elements.DraggingElement(wall, facetIndex, vecPosCanv);
	};

	this.AddDefaultGeometryToMeshesWithout = function (meshes)
	{
		if (meshes != "undefined" && meshes != null)
		{
			if (meshes.length == "undefined" || !meshes.length)
			{
				let meshArray = [];

				meshArray.push(meshes);

				this.AddDefaultGeometryToMeshesWithout(meshArray);
			}
			else
			{
				let geom = new THREE.Geometry();
				let v1 = new THREE.Vector3(0, 0, 0);

				geom.vertices.push(v1);

				geom.faces.push(new THREE.Face3(0, 0, 0));

				for (let i = 0; i < meshes.length; i++)
				{
					if (DEBUG && !meshes[i])
					{
						console.warn("null mesh detected.");
					}
					if (meshes[i] && meshes[i].children && meshes[i].children.length > 0)
					{
						this.AddDefaultGeometryToMeshesWithout(meshes[i].children);
					}

					if (meshes[i] && (!meshes[i].geometry || meshes[i].geometry.type == "BufferGeometry")) {
						meshes[i].geometry = geom;
					}
				}
			}
		}
	};

	this.AddMeshesToScene = function ()
	{
		this.AddDefaultGeometryToMeshesWithout(this.tempBuildingMeshes);
		this.AddDefaultGeometryToMeshesWithout(this.elementsMesh);

		for (i = 0; i < this.tempBuildingMeshes.length; i++)
		{
			if (this.tempBuildingMeshes[i]) {
				threeScene.add(this.tempBuildingMeshes[i]);
			}
			threeRenderer.shadowMap.needsUpdate = true;
		}

		if (this.elementsMesh) {
			threeScene.add(this.elementsMesh);
		}
		threeRenderer.shadowMap.needsUpdate = true;
	};

	this.GetSelectedPartition = function ()
	{
		if (this.stalls) {
			return this.stalls.GetSelectedPartition();
		} else {
			return null;
		}
	};

	this.ElementsListPricingUpdate = function ()
	{
		let featureData = SubscriberDataUtilities.featureData;
		let elementsList = document.getElementById("elementsList");
		if (elementsList && SubscriberDataUtilities.subscriberData)
		{
			tdf.display_prices = SubscriberDataUtilities.subscriberData.display_prices;
			tdf.display_totals = SubscriberDataUtilities.subscriberData.display_prices;
			if (admin_settings.pricing_override)
			{
				switch (admin_settings.price_setting)
				{
				case "PRICING":
				{
					tdf.display_prices = true;
					tdf.display_totals = true;
					break;
				}
				case "TOTALONLY":
				{
					tdf.display_prices = false;
					tdf.display_totals = true;
					break;
				}
				case "NOPRICING":
				{
					tdf.display_prices = false;
					tdf.display_totals = false;
					break;
				}
				}
			}
			let sizeData = this.sizeData;
			if ((this.options && this.options.pricing_off) || (sizeData.price === 0)) {
				tdf.display_prices = false;
				tdf.display_totals = false;
			}

			$(elementsList).empty();
			building.detailListText = "";
			building.detailListHTML = "";
			building.detailList = [];
			building.subTotal = "";

			let fTotalPrice = currency(sizeData.price);
			let fTotalCost = currency(0.00);
			if (sizeData.size_options && sizeData.size_options.cost) {
				fTotalCost = currency(sizeData.size_options.cost);
			}
			let calcWidth = Number(sizeData.width_display);
			let calcLength = Number(sizeData.length_display);
			let calcSqFt = calcWidth * calcLength;
			let calcParameterFt = (calcWidth * 2) + (calcLength * 2);
			let calcWindowCount = 0;
			let calcDoorCount = 0;

			if (this.roofRafter.data.extra_charge) {
				fTotalPrice += this.roofRafter.data.extra_charge;
			}

			let addItem = function (item, price, element,index,price_display,extraData)
			{
				if (price_display)
				{
					tdf.liTemplate = "<li ${attr}>${item} ${price}</li>";
					tdf.htmlTemplate = "<p>${item} ${price}</p>";
					tdf.textTemplate = "${item} ${price}\n";
				}
				else
				{
					tdf.liTemplate = "<li ${attr}>${item}</li>";
					tdf.htmlTemplate = "<p>${item}</p>";
					tdf.textTemplate = "${item}\n";
				}
				if (!price)
				{
					price = "";
				}
				if (element)
				{
					let selected = "";
					let linked_product_id = "";
					if (element.buttonData.linked_product_id)
					{
						linked_product_id = element.buttonData.linked_product_id;
					}
					if (element.selected)
					{
						selected = " element_selected";
					}
					$("#elementsList").append(fillTemplate(tdf.liTemplate,{item: item, price: "$" + price, attr: `class="selectable_element element_${index}${selected}"`}));
					$(`#elementsList li.element_${index}`).prop("element",element).click(function()
					{
						ElementsMenu.OnClickElementsList(this);
					});
					$(element).prop("index",index);
					building.detailListText += fillTemplate(tdf.textTemplate,{item: item, price: "$" + price, attr: ""});
					building.detailListHTML += fillTemplate(tdf.htmlTemplate,{item: item, price: "$" + price, attr: ""});
					if (typeof extraData === "undefined") {
						building.detailList.push({item: item, price: price, linked_product_id: linked_product_id});
					} else {
						building.detailList.push({item: item, price: price, linked_product_id: linked_product_id, ...extraData});
					}
				}
				else
				{
					$("#elementsList").append(fillTemplate(tdf.liTemplate,{item: item, price: "$" + price, attr: ""}));
					building.detailListText += fillTemplate(tdf.textTemplate,{item: item, price: "$" + price, attr: ""});
					building.detailListHTML += fillTemplate(tdf.htmlTemplate,{item: item, price: "$" + price, attr: ""});
					if (typeof extraData === "undefined") {
						building.detailList.push({item: item, price: price});
					} else {
						building.detailList.push({item: item, price: price, ...extraData});
					}
				}
			};

			{
				let extraData = {
					linked_product_id: sizeData.linked_product_id,
					class: "building",
					size: sizeData.width_display + "x" + sizeData.length_display,
					style: sizeData.building_display_name,
					height_display: sizeData.height_display,
					cost: fTotalCost
				}
				addItem(`${sizeData.building_display_name}: ${sizeData.width_display}x${sizeData.length_display} `,`${currency(fTotalPrice)}`,null,null,tdf.display_prices,extraData);
			}
			let basePrice = currency(fTotalPrice);
			let baseCost = currency(fTotalCost);

			building.baseDescription = sizeData.width_display + "x" + sizeData.length_display + " " + sizeData.building_display_name;
			if (interfaceNumber > 2)
			{
				$("#info_display").show();
				$("#building_style").text(sizeData.building_display_name);
				$("#width_display").text(sizeData.width_display);
				$("#length_display").text(sizeData.length_display);
				$("#height_display").text(sizeData.height_display);
				$(`#size${sizeData.width_display}x${sizeData.length_display}`).prop("checked",true);
			}

			if (this.discount && this.discount > 0)
			{
				fTotalPrice = currency(fTotalPrice).subtract(this.discount);

				if (tdf.display_prices)
				{
					addItem("Less Discount: -",currency(this.discount),null,null,tdf.display_prices);
				}
			}

			let totalRoofPrice = currency(this.roof.price);
			let totalRoofCost = currency(0);
			if (this.roof.data)
			{
				if (this.roof.data.options && this.roof.data.options.cost) {
					totalRoofCost = currency(totalRoofCost);
				}
				if (this.roof.data.building_type === "CARPORT") {
					if (this.roof.data.category_name.indexOf("Vertical")>-1) {
						$("#roofing_display").text("Vertical");
					} else {
						$("#roofing_display").text("Horizontal");
					}
				}
				if (this.options && this.options.roofing && this.options.roofing[this.roof.data.category_id])
				{
					if (this.options.roofing[this.roof.data.category_id].sqft_price)
					{
						totalRoofPrice = currency(totalRoofPrice).add(this.options.roofing[this.roof.data.category_id].sqft_price * Number(this.sizeData.length_display) * Number(this.sizeData.width_display));
					}
					if (this.options.roofing[this.roof.data.category_id].sqft_cost) {
						totalRoofCost = currency(totalRoofCost).add(this.options.roofing[this.roof.data.category_id].sqft_cost * Number(this.sizeData.length_display) * Number(this.sizeData.width_display));
					}
				}
				else if (this.roof.data.options && this.roof.data.options.sqft_price)
				{
					totalRoofPrice = currency(totalRoofPrice).add(this.roof.data.options.sqft_price * Number(this.sizeData.length_display) * Number(this.sizeData.width_display));
					if (this.roof.data.options.sqft_cost) {
						totalRoofCost = currency(totalRoofCost).add(this.roof.data.options.sqft_cost * Number(this.sizeData.length_display) * Number(this.sizeData.width_display));
					}
				} else if (nestedObj(this.roof.data,"options.fixedPriceByWidth")) {
					let widthIndex = this.roof.data.options.fixedPriceByWidth.width.indexOf(calcWidth);
					if (widthIndex > -1) {
						totalRoofPrice = currency(totalRoofPrice).add(this.roof.data.options.fixedPriceByWidth.price[widthIndex]);
						fTotalPrice = currency(fTotalPrice).add(this.roof.data.options.fixedPriceByWidth.price[widthIndex]);
					}
				}
				if (this.roof.data.linked_product_id) {
					addItem(this.roof.data.display_name + ": ",currency(totalRoofPrice),null,null,tdf.display_prices,{class: "roofing", category_id: this.roof.data.category_id, linked_product_id:this.roof.data.linked_product_id,material: this.roof.data.name, color: this.roof.data.color_name, cost: totalRoofCost});
				} else {
					addItem(this.roof.data.display_name + ": ",currency(totalRoofPrice),null,null,tdf.display_prices,{class: "roofing",material: this.roof.data.name, color: this.roof.data.color_name, cost: totalRoofCost});
				}
			}

			fTotalPrice = currency(fTotalPrice).add(totalRoofPrice);
			fTotalCost = currency(fTotalCost).add(totalRoofCost);

			let trimColorString = "";
			let trimColor = "";

			if (this.roof.cornerTrimColorID)
			{
				let colorData = ColorsDataUtilities.FindColor(this.roof.cornerTrimColorID);

				if (!colorData)
				    colorData = ColorsDataUtilities.FindColor("ECBR");

				trimColor = colorData.color_name;
				//trimColorString = " with " + colorData.color_name + " trim";
				if (colorData.color_name == this.roof.cornerTrimColorID)
				{
					trimColorString = colorData.color_name + " Trim: ";
				}
				else
				{
					trimColorString = colorData.color_name + " (" + this.roof.cornerTrimColorID + ") Trim: ";
				}
			}


			//if (tdf.display_prices)
			//	optNew = new Option(this.walls.walls[0].sidingColorData.display_name + " Siding" + trimColorString + ": $" + currency(this.walls.walls[0].price));
			let siding_id = this.walls.walls[0].categoryID;
			let sidingPrice = currency(this.walls.price);
			if (nestedObj(this.options,`siding.${siding_id}.percent_of_base`)) {
				let addon = currency(basePrice).multiply(this.options.siding[siding_id].percent_of_base);
				sidingPrice = currency(sidingPrice).add(addon);
			}
			let sidingCost = currency(0);
			let sidingBasePrice = currency(basePrice).add(sidingPrice);
			let sidingBaseCost = currency(0);
			if (this.walls.walls[0].sidingColorData.color_options)
			{
				if (this.walls.walls[0].sidingColorData.color_options.sqft_price)
				{
					sidingPrice = currency(sidingPrice).add(this.walls.walls[0].sidingColorData.color_options.sqft_price * calcSqFt);
				}
				if (this.walls.walls[0].sidingColorData.color_options.upcharge_multiplier)
				{
					sidingPrice = currency(sidingPrice).add(currency(sidingBasePrice).multiply(this.walls.walls[0].sidingColorData.color_options.upcharge_multiplier));
				}
			}
			if (this.walls.walls[0].sidingColorData.price > 0) {
				sidingPrice = currency(sidingPrice.add(this.walls.walls[0].sidingColorData.price));
			}
			let sidingColorName = this.walls.walls[0].sidingColorData.display_name;
			if (this.walls.walls[0].sidingColorData.color_options && this.walls.walls[0].sidingColorData.color_options.color_name)
			{
				sidingColorName = this.walls.walls[0].sidingColorData.color_options.color_name;
			}
			//addItem(sidingColorName + " Siding" + trimColorString + ": ","$" + sidingPrice);
			{
				let extraData = {
					class: "siding",
					color: sidingColorName,
					cost: sidingCost
				};
				if (this.walls.walls[0].sidingColorData.linked_product_id) {
						extraData = {...extraData,
						linked_product_id: this.walls.walls[0].sidingColorData.linked_product_id
					}
					addItem(sidingColorName + " Siding: ",sidingPrice,null,null,tdf.display_prices,extraData);
				} else {
					addItem(sidingColorName + " Siding: ",sidingPrice,null,null,tdf.display_prices,extraData);
				}
			}

			let trimPrice = currency(0);
			let trimCost = currency(0);

			if (this.options && this.options.trim && this.options.trim.charge)
			{
				if (this.roof.cornerTrimColorID !== this.walls.walls[0].sidingColorData.color_id)
				{
					if (this.options.trim.fixed_price)
					{
						trimPrice = currency(this.options.trim.fixed_price);
					}
					if (this.options.trim.param_ft_price)
					{
						trimPrice = currency(this.options.trim.param_ft_price * calcParameterFt);
					}
					if (this.sizeData.size_options && this.sizeData.size_options.trim_price)
					{
						trimPrice = currency(this.sizeData.size_options.trim_price);
					}
				}
			}

			{
				//let trimData = GuiDataUtilities.trimColorButtonData.find(function(element) { return element.color_id === buildingDesigner.building.roof.cornerTrimColorID});
				let trimData = GuiDataUtilities.trimColorButtonData.find(element => element.color_id === this.roof.cornerTrimColorID);
				let extraData = {
					class: "trim_color",
					color: trimColor,
					cost: trimCost
				}
				if (trimData && trimData.linked_product_id) {
					extraData = {
						...extraData,
						linked_product_id: trimData.linked_product_id
					};
					addItem(trimColorString,trimPrice,null,null,tdf.display_prices,extraData);
				} else {
					addItem(trimColorString,trimPrice,null,null,tdf.display_prices,extraData);
				}
			}

			//else
			//	optNew = new Option(this.walls.walls[0].sidingColorData.display_name + " Siding" + trimColorString);

			//elementsList.options.add(optNew);

			fTotalPrice = currency(fTotalPrice).add(sidingPrice);
			fTotalCost = currency(fTotalCost).add(sidingCost);  // Siding cost not yet calculated
			fTotalPrice = currency(fTotalPrice).add(trimPrice);
			fTotalCost = currency(fTotalCost).add(trimCost); // Trim cost not yet calculated

			if (buildingDesigner.defaultSettings && buildingDesigner.defaultSettings.default_elements && (Elements.defaultElements.length === 0))
			{
				Elements.defaultElements = buildingDesigner.defaultSettings.default_elements;
			}
			for (let i = 0; i < Elements.defaultElements.length; i++) {
				Elements.defaultElements[i].usedCountInPricing = 0;
			}

			let elementStr, elementPrice, elementCost;
			let extraData = {};
			for (let i = 0; i < Elements.list.length; i++)
			{
				if (!Elements.list[i].isAttached)
				{
					elementStr = "";

					if (Elements.list[i].buttonData.type)
					{
						elementStr += ELEM_STRING[Elements.list[i].buttonData.type];
						switch (Elements.list[i].buttonData.type)
						{
						case 5: // Door
							calcDoorCount++;
							extraData = {class: "door"};
							break;
						case 6: // Window
							calcWindowCount++;
							extraData = {class: "window"};
							break;
						case 16: // Shelf
							extraData  = {class: "shelf"};
							break;
						default:
							extraData = {class: "option"};
						}
					}

					if (!Elements.list[i].attachedElement)
					{
						if (Elements.list[i].buttonData.type && Elements.list[i].buttonData.element_name.length > 0) {
							elementStr += ": ";
						}

						let defaultElementIndex = Elements.defaultElements.indexOfObject("elem_id", Elements.list[i].buttonData.elem_id);

						let available_for_siding = true;
						if (defaultElementIndex > -1 && (Elements.defaultElements[defaultElementIndex].siding_id)) {
							if (!Elements.defaultElements[defaultElementIndex].siding_id.includes(siding_id)) {
								available_for_siding = false;
							}
						}

						let noExtraCharge = false;
						if ((defaultElementIndex > -1) && available_for_siding)
						{
							Elements.defaultElements[defaultElementIndex].usedCountInPricing++;
							if (Elements.defaultElements[defaultElementIndex].no_extra_cost)
							{
								noExtraCharge = true;
							}
						}

						noExtraCharge = ((Elements.list[i].buttonData.no_extra_cost || noExtraCharge) && ((defaultElementIndex > -1) && (Elements.defaultElements[defaultElementIndex].usedCountInPricing <= Elements.defaultElements[defaultElementIndex].no_extra_cost)) && available_for_siding);

						//if (tdf.display_prices)
						{
							if (!noExtraCharge)
							{
								let altPrice = false;
								let altCost = false;
								elementStr += Elements.list[i].buttonData.element_name;
								elementPrice = currency(0);
								elementCost = currency(0);
								let options = Elements.list[i].buttonData.options || {};
								if (options.pricePerSqFt)
								{
									elementPrice = currency(elementPrice).add(Elements.list[i].buttonData.price*calcSqFt);
									fTotalPrice = currency(fTotalPrice).add(Elements.list[i].buttonData.price*calcSqFt);
									altPrice = true;
								}
								if (options.costPerSqFt && options.cost) {
									elementCost = currency(elementCost).add(options.cost*calcSqFt);
									fTotalCost = currency(fTotalCost).add(options.cost*calcSqFt);
									altCost = true;
								}
								if (options.priceByLength)
								{
									elementPrice = currency(elementPrice).add(Elements.list[i].buttonData.price*calcLength);
									fTotalPrice = currency(fTotalPrice).add(Elements.list[i].buttonData.price*calcLength);
									altPrice = true;
								}
								if (options.costByLength && options.cost)
								{
									elementCost = currency(elementCost).add(options.cost*calcLength);
									fTotalCost = currency(fTotalCost).add(options.cost*calcLength);
									altCost = true;
								}
								if (options.priceByWidth)
								{
									elementPrice = currency(elementPrice).add(Elements.list[i].buttonData.price*calcWidth);
									fTotalPrice = currency(fTotalPrice).add(Elements.list[i].buttonData.price*calcWidth);
									altPrice = true;
								}
								if (options.costByWidth && options.cost)
								{
									elementCost = currency(elementCost).add(options.cost*calcWidth);
									fTotalCost = currency(fTotalCost).add(options.cost*calcWidth);
									altCost = true;
								}
								if (options.priceByParameterFt)
								{
									elementPrice = currency(elementPrice).add(Elements.list[i].buttonData.price*calcParameterFt);
									fTotalPrice = currency(fTotalPrice).add(Elements.list[i].buttonData.price*calcParameterFt);
									altPrice = true;
								}
								if (options.costByParameterFt && options.cost)
								{
									elementCost = currency(elementCost).add(options.cost*calcParameterFt);
									fTotalCost = currency(fTotalCost).add(options.cost*calcParameterFt);
									altCost = true;
								}
								if (options.fixedPriceByWidth) {
									let widthIndex = options.fixedPriceByWidth.width.indexOf(calcWidth);
									if (widthIndex > -1) {
										elementPrice = currency(elementPrice).add(options.fixedPriceByWidth.price[widthIndex]);
										fTotalPrice = currency(fTotalPrice).add(options.fixedPriceByWidth.price[widthIndex]);
										altPrice = true;
									}
								}
								if (options.fixedCostByWidth) {
									let widthIndex = options.fixedCostByWidth.width.indexOf(calcWidth);
									if (widthIndex > -1) {
										elementCost = currency(elementCost).add(options.fixedCostByWidth.cost[widthIndex]);
										fTotalCost = currency(fTotalCost).add(options.fixedCostByWidth.cost[widthIndex]);
										altCost = true;
									}
								}
								if (options.priceAddOn)
								{
									elementPrice = currency(elementPrice).add(options.priceAddOn);
									fTotalPrice = currency(fTotalPrice).add(options.priceAddOn);
									//altPrice = true;
								}
								if (options.costAddOn)
								{
									elementCost = currency(elementCost).add(options.costAddOn);
									fTotalCost = currency(fTotalCost).add(options.costAddOn);
									//altCost = true;
								}
								if (!altPrice)
								{
									elementPrice = currency(elementPrice).add(Elements.list[i].buttonData.price);
									fTotalPrice = currency(fTotalPrice).add(Elements.list[i].buttonData.price);
								}
								if (!altCost)
								{
									if (!options.cost) {
										options.cost = currency(0);
									}
									elementCost = currency(options.cost).add(elementCost);
									fTotalCost = currency(fTotalCost).add(options.cost);
								}
							}
							else
							{
								elementStr += Elements.list[i].buttonData.element_name + "(default item, no extra charge)";
								elementPrice = currency("0.00");
							}
						}
						/*else
						{
							elementStr += Elements.list[i].buttonData.element_name;
							elementPrice = "";

							if (!noExtraCharge)
							{
								elementPrice = currency(fTotalPrice).add(Elements.list[i].buttonData.price);
								fTotalPrice = currency(fTotalPrice).add(Elements.list[i].buttonData.price);
							}
						}*/

						if (Elements.list[i].colorID && Elements.list[i].colorID != "undefined" && Elements.list[i].colorID != "null")
						{
							let shedColor = this.walls.walls[0].sidingColorData.color_id;
							let trimColor = this.roof.cornerTrimColorID;
							let colorData = ColorsDataUtilities.FindColor(Elements.list[i].colorID);

							let doorColorData = ColorsDataUtilities.GetDoorColorData(Elements.list[i].buttonData.available_colors_elem_id, Elements.list[i].colorID);

							let doorColorPrice = 0;

							if (!doorColorData)
							{
								doorColorData = ColorsDataUtilities.GetDoorColorData(Elements.list[i].object3D_ID, Elements.list[i].colorID);
							}
							if (doorColorData)
							{
								if (Elements.list[i].buttonData.double_door)
								{
									if (featureData.pricing && featureData.pricing.double_door_color_double)
									{
										doorColorPrice = currency(doorColorData.price).multiply(2);
									}
									else
									{
										doorColorPrice = currency(doorColorData.price);
									}
								}
								else
								{
									doorColorPrice = currency(doorColorData.price);
								}
							}

							if (Elements.list[i].buttonData.options && Elements.list[i].buttonData.options.color_charge) {
								if (Elements.list[i].colorID !== shedColor) {
									doorColorPrice = currency(doorColorPrice).add(Elements.list[i].buttonData.options.color_charge);
								}
							}

							//TODO: add cost
							elementPrice = currency(elementPrice).add(doorColorPrice);

							if (doorColorData)
							{
								if ((tdf.display_prices) && (doorColorPrice > 0))
								{
									elementStr += " in " + colorData.color_name + "($" + doorColorPrice + ")";
								}
								else
								{
									elementStr += " in " + colorData.color_name;
								}

								fTotalPrice = currency(fTotalPrice).add(doorColorPrice);
							}
						}


						if (Elements.list[i].hingeButtonData)
						{
							let hingesPrice = 0;


							if (!Elements.list[i].buttonData.double_door_from_single_door)
								hingesPrice = currency(Elements.list[i].hingeButtonData.price).multiply(Elements.list[i].buttonData.left_hinge_coords.length);
							else
								hingesPrice = currency(Elements.list[i].hingeButtonData.price).multiply(Elements.list[i].buttonData.left_hinge_coords.length + Elements.list[i].buttonData.right_hinge_coords.length);

							if (tdf.display_prices)
							{
								if (!noExtraCharge)
								{
									elementStr += " " + Elements.list[i].hingeButtonData.element_name + "($" + hingesPrice + ")";
									//TODO: add cost
									elementPrice = currency(elementPrice).add(hingesPrice);
									fTotalPrice = currency(fTotalPrice).add(hingesPrice);

								}
								else
									elementStr += " " + Elements.list[i].hingeButtonData.element_name;
							}
							else
							{
								elementStr += " " + Elements.list[i].hingeButtonData.element_name;

								if (!noExtraCharge)
								{
									//TODO: add cost
									elementPrice = currency(elementPrice).add(hingesPrice);
									fTotalPrice = currency(fTotalPrice).add(hingesPrice);
								}
							}
						}
					}
					else
					{
						attachmentPrice = currency(Elements.list[i].buttonData.price).add(Elements.list[i].attachedElement.price);

						if (Elements.list[i].buttonData.type && Elements.list[i].buttonData.element_name.length > 0) {
							elementStr += ": ";
						}

						elementStr += Elements.list[i].buttonData.element_name;

						if (tdf.display_prices) {
							elementStr += " and " + Elements.list[i].attachedElement.buttonData.element_name + " $" + currency(elementPrice);
						} else {
							elementStr += " and " + Elements.list[i].attachedElement.buttonData.element_name;
						}

						//TODO: add cost
						elementPrice = currency(elementPrice).add(attachmentPrice);
						fTotalPrice = currency(fTotalPrice).add(attachmentPrice);
					}

					if (Elements.list[i].trimColor && Elements.list[i].trimColor_name)
					{
						elementStr += `(${Elements.list[i].trimColor_name} trim)`;
					}

					extraData = {
						...extraData,
						cost: elementCost,
						options: Elements.list[i].buttonData.options
					}
					addItem(elementStr, elementPrice, Elements.list[i],i,tdf.display_prices,extraData);
				}
			}

			// check for removal discounts
			if (Elements.defaultElements.length > 0)
			{
				for (let i=0;i < Elements.defaultElements.length; i++)
				{
					let available_for_siding = true;
						if (Elements.defaultElements[i].siding_id) {
							if (!Elements.defaultElements[i].siding_id.includes(siding_id)) {
								available_for_siding = false;
							}
						}
					if (Elements.defaultElements[i].removal_discount && (Elements.defaultElements[i].usedCountInPricing < Elements.defaultElements[i].no_extra_cost) && available_for_siding)
					{
						//TODO: add cost subtraction
						elementPrice = currency(-(Elements.defaultElements[i].removal_discount *(Elements.defaultElements[i].no_extra_cost - Elements.defaultElements[i].usedCountInPricing)));
						fTotalPrice = currency(fTotalPrice).add(elementPrice);
						addItem("Un-used Item Credit:",elementPrice,null,null,tdf.display_prices,{class: "credit"});
					}
				}
			}

			// check for Trim price based on number of doors and windows
			if (this.options && this.options.trim && this.options.trim.charge && this.options.trim.per_item_price)
			{
				if ((calcDoorCount > 0) || (calcWindowCount > 0) )
				{
					//TODO: add cost
					trimPrice = currency((calcWindowCount + calcDoorCount) * this.options.trim.per_item_price);
					addItem("Trim Color Charge: ","$" + trimPrice,null,null,tdf.display_prices);
					fTotalPrice = currency(fTotalPrice).add(trimPrice);
				}
			}

			let subtotaltext = "";
			let totaltext = "";
			if (featureData.pricetext)
			{
				subtotaltext = featureData.pricetext.subtotaltext || "Sub Total Price as Shown";
				totaltext = featureData.pricetext.totaltext || "Total Price with tax";
			}
			else
			{
				subtotaltext = "Sub Total Price as Shown";
				totaltext = "Total Price with tax";
			}
			if (tdf.display_totals)
			{
				addItem(`${subtotaltext}: `,currency(fTotalPrice),null,null,tdf.display_totals,{class: "subtotal1",cost:fTotalCost});
				building.subTotal = String(currency(fTotalPrice));
				if (interfaceNumber > 2)
				{
					$("#price_display").text("Price as Displayed: " + currency(fTotalPrice));
				}

				let tax = SubscriberDataUtilities.subscriberData.tax_percent;

				let taxMultiplier = tax / 100;

				let fPrice = currency(fTotalPrice).multiply(taxMultiplier);

				addItem("Tax (" + tax + "%): ",currency(fPrice),null,null,tdf.display_totals);

				fTotalPrice = currency(fTotalPrice).add(fPrice);
				addItem(`${totaltext}: `,currency(fTotalPrice),null,null,tdf.display_totals);

				if (featureData.pricetext && featureData.pricetext.blurb)
				{
					addItem(`<b>${featureData.pricetext.blurb}</b>`,null,null,false);
				}

				if (Price_Blurb)
				{
					addItem("<b>" + SubscriberDataUtilities.descriptions[Price_Blurb - 1].short_description + "</b>",null,null,false);
				}

				if ((features.indexOf("FINANCING") > -1) && featureData.financing)
				{
					//monthlypayment = roundNumber((fTotalPrice * 0.019893)+.5,0);
					let monthlypayment = AuxUtilities.roundNumber((fTotalPrice * featureData.financing.multiplier) + .5, 0);
					optTmpText = featureData.financing.blurb + " $" + monthlypayment;
					addItem(optTmpText,null,null,null,false);
				}
			}
			else
			{
				addItem("For Price Quote and to Order - Contact " + SubscriberDataUtilities.subscriberData.name,null,null,null,false);
				if (interfaceNumber > 2)
				{
					$("#price_display").text("");
				}
			}

			PrintUtilities.printPagePricing = elementsList.innerHTML;

		}
	};

	this.ClearSelections = function ()
	{
		this.SetSelected(false);

		Elements.ClearSelections();
	};

	this.DestroyElementMeshes = function ()
	{
		for (i = 0; i < this.elementMeshes.length; i++)
		{
			threeScene.remove(this.elementMeshes[i]);
			threeRenderer.shadowMap.needsUpdate = true;
			this.elementMeshes[i] = null;
		}

		this.elementMeshes = [];
	};

	this.RemoveThreeJSSceneMeshes = function ()
	{
		if (this.tempBuildingMeshes)
		{
			for (i = 0; i < this.tempBuildingMeshes.length; i++)
			{
				if (this.tempBuildingMeshes[i])
				{
					MeshUtilities.RemoveAndDestroyMesh(this.tempBuildingMeshes[i]);

					this.tempBuildingMeshes[i] = null;
				}
			}
		}

		this.tempBuildingMeshes = [];

		if (this.elementsMesh)
		{
			MeshUtilities.RemoveAndDestroyMesh(this.elementsMesh);
			////threeScene.remove(this.elementsMesh);
			this.elementsMesh = null;
		}

		threeRenderer.shadowMap.needsUpdate = true;
	};

	this.Destroy = function ()
	{
		this.RemoveThreeJSSceneMeshes();

		Elements.DeleteAllElements();

		/////////this.logo.Destroy();

		this.horizLengthRuler.Destroy();
		this.horizLengthRuler2.Destroy();
		this.horizWidthRuler.Destroy();
		this.horizWidthRuler2.Destroy();
		this.vertHeightRuler.Destroy();
		this.vertHeightRuler2.Destroy();
	};

	this.GetWallString = function (eWall)
	{
		return WALL_STRING[eWall];
	};


	this.Update3DObjects = function ()
	{
		Elements.UpdateModifiedElements3DObjects();
	};
}
