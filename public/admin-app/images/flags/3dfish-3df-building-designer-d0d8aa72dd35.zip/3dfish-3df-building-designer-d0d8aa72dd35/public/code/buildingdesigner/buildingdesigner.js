/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:2018*/
/*eslint-disable no-console, no-unused-vars, no-undef */

/**
 *
 *
 * @param {*} background
 * @param {*} groundTextureName
 */
function BuildingDesigner(background, groundTextureName) {
	"use strict";

	this.environment = null;
	this.building = null;

	this.lights = null;

	this.camera = null;
	let zoomInBtn = null;
	let zoomOutBtn = null;
	this.maxPixelRatio = 3;
	canvasMain = document.getElementById("building_designer_canvas");

	this.createBuildingThreadHandle = null;

	this.selectedBuildingSizeIndex = -1;
	this.selectedStallCountIndex = -1;

	this.selectedLeanToSizeIndex = 0;

	this.prevGUISelectedWidthIndex = 0;
	this.prevGUISelectedLengthIndex = 0;
	this.prevGUISelectedHeightIndex = 0;

	//Add event handlers
	if (canvasMain.addEventListener) {
		//$("#building_designer_canvas").bind("touchy-pinch", GUIInput.OnTouchyPinch);

		canvasMain.addEventListener("DOMMouseScroll", GUIInput.OnMouseWheel, false);

		canvasMain.addEventListener("touchstart", GUIInput.OnTouchStart, false);
		canvasMain.addEventListener("touchmove", GUIInput.onTouchMove, false);
		canvasMain.addEventListener("touchend", GUIInput.onTouchEnd, false);

		canvasMain.addEventListener("dblclick", GUIInput.OnDblClick);

		canvasMain.addEventListener("onresize", BuildingDesigner.OnWindowResize);

		canvasMain.addEventListener("onkeydown", GUIInput.OnKeyDown);
		canvasMain.addEventListener("onkeyup", GUIInput.OnKeyUp);

		canvasMain.addEventListener("oncontextmenu", GUIInput.OnContextMenu);

		UserDataUtilities.AddFormHandler();
	}

	if (AuxUtilities.IsMobile()) {
		let infobarHTML = document.getElementById("infoBarDiv");

		if (infobarHTML !== null) {
			infobarHTML.style.visibility = "hidden";
		}
	}

	//Initialize three.js
	try {
		threeRenderer = new THREE.WebGLRenderer({
			canvas: canvasMain,
			antialias: true,
			alpha: false,
			powerPreference: 'high-performance'
		});

		// WebGLRenderer.debug introduced in R104
		if (threeRenderer.debug) {
			threeRenderer.debug.checkShaderErrors = true;
		}

		threeRenderer.setPixelRatio( Math.min( window.devicePixelRatio, this.maxPixelRatio ) );

		threeRenderer.sortObjects = false;

		threeRenderer.setClearColor(COLOR_SKY, 1);

		threeScene = new THREE.Scene();

		this.lights = new Lights();

		this.camera = new Camera();

		if (DEBUG) {
			stats = new Stats();
			document.body.appendChild(stats.dom);
		}

		const self = this;

		requestAnimationFrame( function loop()  {
			self._render();

			requestAnimationFrame(loop);
		});
	} catch (err) {
		if (DEBUG) {
			console.error(err);
		}
		reportError("3DF-RenderInitFail-01",err);
		alert("Error initializing renderer.");
	}

	if (threeScene === null || threeRenderer === null)
		alert("Could not initialise renderer.");


	//Create the 3D environment
	this.environment = new Environment(background, groundTextureName);


	//BuildingDesigner functions
	//---------------------------
	/**
	 * @method
	 * @returns {string} XML building design string
	 */
	this.GetDesignXMLString = function () {
		return this.building.GetDesignXMLString();
	};

	/**
	 * @method
	 * @returns {Object} building object for storing building
	 */
	this.GetDesignObject = function () {
		return this.building.GetDesignObject();
	};

	this.SetRegenerate = function (regenerate) {
		this.environment.SetRegenerate(regenerate);

		if (this.building) {
			this.building.SetRegenerateBuildingAndElementMeshes(regenerate);
		}

		this._doRender();
	};

	this.Draw = function () {
		this.environment.Draw();

		if (this.building)
			this.building.Draw();

		this._doRender();
	};

	this.InitializeCameraAndRender = function()
	{
		this.camera.InitializeViews();
		this.lights.update();
		this.Draw();
	};

	/**
	 * This is just a placeholder that gets overridden by the specific building type
	 */
	this.CreateBuilding = function (buildingID, sizeData, rafter) {};

	/**
	 * @function
	 * @async
	 * @alias buildingDesigner.GetBuildingSizeIndex
	 * @param {string} buildingID
	 * @param {number} selectedWidth
	 * @param {number} selectedHeight
	 * @returns {number} sizeIndex
	 */
	this.GetBuildingSizeIndex = async function (buildingID, selectedWidth, selectedHeight) {
		let sizeIndex = -1;

		buildingDesigner.defaultSettings = await buildingDesigner.GetDefaultSettings(buildingID, selectedWidth, SubscriberDataUtilities.subscriber);

		if (buildingDesigner.defaultSettings != null && buildingDesigner.defaultSettings != undefined) {
			if (!buildingDesigner.defaultSettings.default_length || buildingDesigner.defaultSettings.default_length == undefined || buildingDesigner.defaultSettings.default_length == "null" || buildingDesigner.defaultSettings.default_length == "") {
				sizeIndex = buildingDesigner.GetShortestBuildingIndexForWidthHeightDisplay(selectedWidth, selectedHeight);
			} else {
				switch (buildingDesigner.defaultSettings.default_length) {
				case ("SHORTEST"):
					sizeIndex = buildingDesigner.GetShortestBuildingIndexForWidthHeightDisplay(selectedWidth, selectedHeight);
					break;

				case ("LONGEST"):
					sizeIndex = buildingDesigner.GetLongestBuildingIndexForWidthHeightDisplay(selectedWidth, selectedHeight);
					break;

				default:
					sizeIndex = buildingDesigner.GetBuildingIndexForWidthLengthHeightDisplay(selectedWidth, buildingDesigner.defaultSettings.default_length, selectedHeight);

					break;
				}
			}
		} else {
			if (DEBUG) {
				console.warn("Default settings do not exist for: " + buildingID);
			}
		}

		if (sizeIndex == -1)
			sizeIndex = buildingDesigner.GetShortestBuildingIndexForWidthHeightDisplay(selectedWidth, selectedHeight);

		return sizeIndex;
	};

	this.MouseOver = function (mousepos) {};

	this.OnLeftMouseDownOrTouchDelayed = function () {
		if (!GUIInput.touchStart) {
			if (Elements.draggableElement) {
				GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.IDLE;

				GUIInput.EndDraggingElement();
			} else
				switch (GUIInput.currentDesignEditorMode) {
				case GUIInput.DESIGN_EDIT_MODE.ADD_ELEMENT:

					break;

				case GUIInput.DESIGN_EDIT_MODE.IDLE:
					let vecDelta = new THREE.Vector2().subVectors(GUIInput.vecCurrentMousePos, GUIInput.vecLastMousePos);

					buildingDesigner.building.ClearSelections();

					let selectedObject = null;

					if (vecDelta.length() < 4) {
						let elementAndPos = buildingDesigner.building.GetSelectedElement({
							x: GUIInput.vecCurrentMousePos.x,
							y: GUIInput.vecCurrentMousePos.y
						});

						if (elementAndPos != null && elementAndPos.element != null) {
							selectedObject = elementAndPos;
						}

						let buildingSelectedDistance = buildingDesigner.building.IsBuildingSelected({
							x: GUIInput.vecCurrentMousePos.x,
							y: GUIInput.vecCurrentMousePos.y
						});

						if ((!selectedObject && buildingSelectedDistance >= 0) || (buildingSelectedDistance >= 0 && buildingSelectedDistance < selectedObject.distance)) {
							buildingDesigner.building.SetSelected(true);
							selectedObject = buildingDesigner.building;
						} else
						if (selectedObject) {
							selectedObject.element.SetSelected(true);

							let mtxWorldToElem = new THREE.Matrix4().getInverse(elementAndPos.element.matrix);
							elementAndPos.vectorPos.applyMatrix4(mtxWorldToElem);

							elementAndPos.element.SetMousePosOnElementVector(elementAndPos.vectorPos);

							Elements.StartDraggingElement(elementAndPos.element);

							GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT;
						}
					}

					if (!selectedObject)
						GUIInput.OnRotateMouseOrTouch({
							clientX: GUIInput.vecCurrentMousePos.x,
							clientY: GUIInput.vecCurrentMousePos.y
						});

					buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
					buildingDesigner.Draw();

					break;
				}

			GUIInput.touchStart = true;
		}
	};

	/**
	* @function
	* @alias buildingDesigner.GetDefaultSettings
	* @param {string} buildingID
	* @param {number} width
	* @param {string} subscriber_id
	*/
	this.GetDefaultSettings = async function (buildingID, width, subscriber_id, length=0) {
		if (!subscriber_id) {
			subscriber_id = SubscriberDataUtilities.subscriber;
		}
		if (cache.lastdefaultsettings !== undefined) {
			if ((cache.lastdefaultsettings.buildingID === buildingID) && (cache.lastdefaultsettings.width === width) && (cache.lastdefaultsettings.subscriber === subscriber_id) && (cache.lastdefaultsettings.defaultSettings != undefined))
				return cache.lastdefaultsettings.defaultSettings;
		}

		let params = {
			buildingID: buildingID,
			subscriber_id: subscriber_id,
			series_code: SubscriberDataUtilities.series_code,
			width:width,
			length:length
		};

		let err;
		[err,this.defaultSettings] = await to(NodeJSUtilities.UQuery("dataRequest", {request: "getDefaultSettings", ...params}))
		if (err) {
			console.error("Error retrieving default settings:",err);
			return null;
		}

		this.defaultSettings = this.defaultSettings[this.defaultSettings.length - 1];

		if (this.defaultSettings && this.defaultSettings.default_elements) {
			if (this.defaultSettings.default_elements.length > 0) {
				if (typeof this.defaultSettings.default_elements === "string") {
					this.defaultSettings.default_elements = JSON.parse(this.defaultSettings.default_elements);
				}
				//Elements.defaultElements = this.defaultSettings.default_elements;
			}
			else
				this.defaultSettings.default_elements = null;
				//Elements.defaultElements = [];
		}

		cache.lastdefaultsettings = {
			"buildingID": buildingID,
			"width": width,
			"subscriber": subscriber_id,
			"defaultSettings": this.defaultSettings
		};

		return this.defaultSettings;
	};

	this.GetFloorConstructionDetails = async function (subscriber) {
		let params = {
			subscriber_id: subscriber,
			series_code: SubscriberDataUtilities.series_code
		};
		let [err,result] = await to(NodeJSUtilities.UQuery("dataRequest", {request: "getFloorConstructionDetails", ...params}));
		this.floorConstructionDetails = result[0];

		Floor.Configure(this.floorConstructionDetails);
	};

	this.GetShortestBuildingIndexForWidthHeightDisplay = function (width, height) {
		let minLength = 9999;
		let minIndex = -1;
		for (let i = 0; i < this.buildingSizes.length; i++) {
			if (this.buildingSizes[i].width_display == width && this.buildingSizes[i].height_display == height && this.buildingSizes[i].length < minLength) {
				minLength = this.buildingSizes[i].length;
				minIndex = i;
			}
		}

		return minIndex;
	};

	this.GetLongestBuildingIndexForWidthHeightDisplay = function (width, height) {
		let maxLength = -1;
		let maxIndex = -1;
		for (let i = 0; i < this.buildingSizes.length; i++) {
			if (this.buildingSizes[i].width_display == width && this.buildingSizes[i].height_display == height && this.buildingSizes[i].length > maxLength) {
				maxLength = this.buildingSizes[i].length;
				maxIndex = i;
			}
		}

		return maxIndex;
	};

	this.GetBuildingIndexForWidthLengthHeightDisplay = function (width, length, height) {
		if (!height) {
			height = 0;
		}
		//exact match
		for (let i = 0; i < this.buildingSizes.length; i++) {
			if (this.buildingSizes[i].width == width && this.buildingSizes[i].length == length && ((this.buildingSizes[i].height == height) || (height == 0))) {
				return i;
			}
		}

		//display size match
		for (let i = 0; i < this.buildingSizes.length; i++) {
			if (this.buildingSizes[i].width_display == width && this.buildingSizes[i].length_display == length && ((this.buildingSizes[i].height_display == height) || (height == 0))) {
				return i;
			}
		}

		//rounded
		for (let i = 0; i < this.buildingSizes.length; i++) {
			if (MathUtilities.Round(this.buildingSizes[i].width, 0) == MathUtilities.Round(width, 0) && MathUtilities.Round(this.buildingSizes[i].length, 0) == MathUtilities.Round(length, 0) && ((MathUtilities.Round(this.buildingSizes[i].height, 0) == MathUtilities.Round(height, 0)) || (height == 0))) {
				return i;
			}
		}

		//if no match, check for a default
		for (let i = 0; i < this.buildingSizes.length; i++) {
			if (nestedObj(this.buildingSizes[i],"size_options.default_size")) {
				return i;
			}
		}

		return -1;
	};

	this.GetBuildingSizeIndexForProductID = function (productID) {
		let index = -1;
		for (let i = 0; i < this.buildingSizes.length; i++) {
			if (this.buildingSizes[i].product_id == productID) {
				index = i;
			}
		}

		return index;
	};

	this.DeleteSelectedElement = function () {
		Elements.DeleteSelectedElement();

		buildingDesigner.building.SetRegenerateElementMeshes(true);

		this.building.SetBuildingModified();
	};
}



/**
 * @function BuildingDesigner.LoadRafterDataFromXML
 * @param {string} xmlDesignDoc XML saved building string
 * @returns {Object|null} rafterData object if data exists otherwise null
 */
BuildingDesigner.LoadRafterDataFromXML = function (xmlDesignDoc) {
	let nodeRafter = xmlDesignDoc.getElementsByTagName("RAFTER")[0];

	if (nodeRafter) {
		Rafters.rafterData = nodeRafter.getAttribute("data");

		Rafters.rafterData = AuxUtilities.JSONDecodeAndParse(Rafters.rafterData);

		return Rafters.rafterData;
	}

	return null;
};

/**
 * Returns rafter data from TDFDESIGN object
 * @function BuildingDesigner.LoadRafterDataFromObject
 * @param {Object} savedDesignObject TDFDESIGN object
 * @returns {Object|null} Rafter data if exists or null
 */
BuildingDesigner.LoadRafterDataFromObject = function (savedDesignObject) {
	if(savedDesignObject.BUILDING && savedDesignObject.BUILDING.RAFTER) {
		return savedDesignObject.BUILDING.RAFTER.data;
	} else {
		return null;
	}
};

BuildingDesigner.IsDebugVersion = async function () {
	let [err, isDebugVersionStr] = await to(NodeJSUtilities.UQuery("dataRequest", {request: "isDebugVersion", subscriber_id: SubscriberDataUtilities.subscriber}));
	if (err) {
		throw err;
	}

	if (typeof isDebugVersionStr === 'string' || isDebugVersionStr instanceof String)
	{
		return isDebugVersionStr == "true";
	}
	else
		return isDebugVersionStr;
};

BuildingDesigner.CreateBuildingThread = async function () {
	if (GeometryUtilities.objectsLoaded) {
		clearTimeout(this.createBuildingThreadHandle);

		buildingDesigner.buildingSizes = await GuiDataUtilities.LoadBuildingSizes(buildingDesigner.buildingID); {
			if (buildingDesigner.selectedBuildingSizeIndex == -1)
				buildingDesigner.selectedBuildingSizeIndex = buildingDesigner.buildingSizes.length - 1;

			GuiDataUtilities.LoadStallCount(buildingDesigner.buildingSizes, buildingDesigner.selectedBuildingSizeIndex);

			Rafters.rafterData = GuiDataUtilities.LoadRafterData(buildingDesigner.buildingID, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].width);

			let rafter = null;

			if (Rafters.rafterData.length > 0) {
				rafter = new Rafter(Rafters.rafterData[0]);
				rafter.Process();

				buildingDesigner.leanToSizes = GuiDataUtilities.LoadLeanToSizes(Rafters.rafterData);
			}

			buildingDesigner.CreateBuilding(buildingDesigner.buildingID, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex], rafter);

			ElementsMenu.SetBuildingSizeChecked(buildingDesigner.selectedBuildingSizeIndex);

			let tabbedContentList = document.getElementById("main_tab").getElementsByTagName("li");

			let element = document.getElementById("tabPartitionsButton");

			if (element.className == "selected")
				ElementsMenu.TabPartitions();

			OnWindowResize();
			buildingDesigner.InitializeCameraAndRender();
		}
	} else
		this.createBuildingThreadHandle = setTimeout(BuildingDesigner.CreateBuildingThread, 1000);
};

BuildingDesigner.LoadDataForGUI = async function () {
	let buttonParams = {
		subscriber_id: SubscriberDataUtilities.subscriber,
		series_code: SubscriberDataUtilities.series_code,
		building_type: BUILDING_STRING[BuildingDesigner.buildingType]
	};

	GuiDataUtilities.buildingsButtonData = GuiDataUtilities.LoadButtons("Buildings", {...buttonParams, building_id: buildingDesigner.buildingID});
	GuiDataUtilities.doorsButtonData = GuiDataUtilities.LoadButtons("Doors", buttonParams);

	GuiDataUtilities.hingesButtonData = GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Hinges", buttonParams);

	GuiDataUtilities.partitionsButtonData = GuiDataUtilities.LoadButtons("Partitions", buttonParams);

	GuiDataUtilities.sidingColorButtonData = GuiDataUtilities.LoadButtons("Siding", buttonParams);
	GuiDataUtilities.roofingButtonData = GuiDataUtilities.LoadButtons("Roofing", buttonParams);

	GuiDataUtilities.trimColorButtonData = GuiDataUtilities.LoadButtons("TrimColors", buttonParams);
};

//Initialize the building designer object, set the camera and render
BuildingDesigner.Initialize = async function () {
	if (DEBUG) {console.log("BDI - 1");}
	if (SubscriberDataUtilities.subscriber.length == 0) {
		SubscriberDataUtilities.subscriber = AuxUtilities.GetURLParameter("sc");
	}

	if (SubscriberDataUtilities.subscriber) {
		if (DEBUG) {console.log("BDI - 2");}
		let loader = new THREE.FontLoader();
		if (DEBUG) {console.log("BDI - 3");}
		loader.load(Ruler.RULER_TEXT_FONT, function (font) {
			Ruler.rulerFont = font;
		});
		if (DEBUG) {console.log("BDI - 4");}
		buildingDesigner = new BuildingDesigner();
		if (DEBUG) {console.log("BDI - 5");}
		await buildingDesigner.GetFloorConstructionDetails();
		if (DEBUG) {console.log("BDI - 6");}
		SubscriberDataUtilities.LoadData();
		if (DEBUG) {console.log("BDI - 7");}
		await LoadDataForGUI();
		if (DEBUG) {console.log("BDI - 8");}
		GuiDataUtilities.rampsData = GuiDataUtilities.GetRamps();
		if (DEBUG) {console.log("BDI - 9");}
		await TexturesDataUtilities.GetTextureDataFromServer();
		if (DEBUG) {console.log("BDI - 10");}
		//add siding textures data
		TexturesDataUtilities.AddToData(GuiDataUtilities.sidingColorButtonData);
		if (DEBUG) {console.log("BDI - 11");}
		//add roofing textures data
		TexturesDataUtilities.AddToData(GuiDataUtilities.roofingButtonData);
		if (DEBUG) {console.log("BDI - 12");}
		ObjectDataUtilities.LoadData();
		if (DEBUG) {console.log("BDI - 13");}
		OnWindowResize();
		if (DEBUG) {console.log("BDI - 14");}
		buildingDesigner.InitializeCameraAndRender();
		if (DEBUG) {console.log("BDI - 15");}

		this.createBuildingThreadHandle = setTimeout(BuildingDesigner.CreateBuildingThread, 1000);
	} else {
		window.location.href = "https://sheddesigner2.3dfish.net/";
	}
};

BuildingDesigner.LaunchFullscreen = function (element) {
	if (element.requestFullscreen) {
		element.requestFullscreen();
	} else if (element.mozRequestFullScreen) {
		element.mozRequestFullScreen();
	} else if (element.webkitRequestFullscreen) {
		element.webkitRequestFullscreen();
	} else if (element.msRequestFullscreen) {
		element.msRequestFullscreen();
	}
};

BuildingDesigner.ExitFullscreen = function (element) {
	if (document.exitFullscreen) {
		document.exitFullscreen();
	} else if (document.mozCancelFullScreen) {
		document.mozCancelFullScreen();
	} else if (document.webkitExitFullscreen) {
		document.webkitExitFullscreen();
	}
};

BuildingDesigner.OnWindowResize = function () {
	let elemCanv = document.getElementById("building_designer_canvas");
	if (tdf.printingPage || !buildingDesigner) {
		return;
	}

	if (interfaceNumber > 1) {
		// let the browser do the sizing
		//let MenubarHeight = if2topmenubar.offsetHeight
		let UseableWidth = window.innerWidth;
		let UseableHeight = window.innerHeight;

		if (UseableWidth > screen.availWidth) {
			UseableWidth = screen.availWidth;
		}

		if (UseableHeight > screen.availHeight) {
			UseableHeight = screen.availHeight - 25;
			if (screenfull.isFullscreen) UseableHeight = screen.availHeight;
		}

		////BuildingDesigner.LaunchFullscreen(document.documentElement);
		////screenfull.toggle(document.getElementById('building_designer_canvas'));

		let fNewWidth = UseableWidth - 2 * elemCanv.offsetLeft - SCROLLBAR_WIDTH_ADJ;
		let fNewHeight = UseableHeight - 40 - elemCanv.offsetTop;


		/*////canvasMain.clientWidth = fNewWidth;
		canvasMain.clientHeight = fNewHeight;

		buildingDesigner.camera.SetCanvasDimensions(fNewWidth, fNewHeight);
		*/

		// canvasMain.clientWidth = UseableWidth;
		///canvasMain.style.width = "calc(100vw - (100vw - 100%))";
		//canvasMain.clientHeight = UseableHeight;
		canvasMain.style.height = fNewHeight + "px";

		//buildingDesigner.camera.SetCanvasDimensions(UseableWidth, UseableHeight);

			UseableWidth = $("#canvascontainer").width();
			fNewHeight = $("#canvascontainer").height();
			if (DEBUG) {
				console.log("UseableWidth: ",UseableWidth,"fNewHeight: ",fNewHeight);
			}
		buildingDesigner.camera.SetCanvasDimensions(UseableWidth, fNewHeight);
		buildingDesigner._doRender();
	}

	ControlsMenu.AdjustZoomControlsPosition();
	ControlsMenu.AdjustSpinControlPosition();

	threeRenderer.setPixelRatio( Math.min( window.devicePixelRatio, buildingDesigner.maxPixelRatio ) );
};

BuildingDesigner.GetBuildEngineCode = function (shedCode) {
	if (typeof shedCode !== "number") {
		let shedCodeArray = shedCode.split("_");

		return shedCodeArray[3];
	}

	return null;
};

/**
 * @function
 * @async
 * @param {string} buildingID
 * @param {string} width_display
 * @param {string} height_display
 * @param {string} subscriber_id
 */
BuildingDesigner.CreateOrLoadBuilding = async function (buildingID, width_display, height_display, subscriber_id) {
	ElementsMenu.HideCurrentModal();

	let buildingLoaded = false;

	Elements.defaultElements = [];

	if (buildingID && width_display && height_display && subscriber_id) {
		buildingDesigner.defaultSettings = await buildingDesigner.GetDefaultSettings(buildingID, width_display, subscriber_id);

		if (buildingDesigner.defaultSettings && buildingDesigner.defaultSettings.design_id != "" && buildingDesigner.defaultSettings.design_id != "null") {
			LoadingSavingUtilities.loadingDefaultBuilding = true;

			buildingLoaded = await LoadingSavingUtilities.LoadWebDesign(buildingDesigner.defaultSettings.design_id);
		} else
			buildingDesigner.defaultSettings = null;

		if (!buildingLoaded) {
			let sizeIndex = await buildingDesigner.GetBuildingSizeIndex(buildingID, width_display, height_display);

			await buildingDesigner.LaunchCreateBuildingCode(buildingID, sizeIndex);

			buildingLoaded = true;
		}
	}

	if (!buildingLoaded) {
		if (LoadingSavingUtilities.designID === "") {
			LoadingSavingUtilities.designID = AuxUtilities.GetURLHashParameter("designID");
		}
		if (LoadingSavingUtilities.designID != "") {
			buildingLoaded = await LoadingSavingUtilities.LoadWebDesign(LoadingSavingUtilities.designID);
		} else
		if (IndexDB.persistentDesignXML != undefined && IndexDB.persistentDesignXML != null && IndexDB.persistentDesignXML != "") {
			buildingLoaded = await LoadingSavingUtilities.LoadBuilding(IndexDB.persistentDesignXML);
		} else if(IndexDB.persistentDesignObject && IndexDB.persistentDesignObject.TDFDESIGN && !(featureData && featureData.interface && featureData.interface.persistent_design_off)) {
			buildingLoaded = await LoadingSavingUtilities.LoadBuilding(IndexDB.persistentDesignObject);
		}


		if (!buildingLoaded) {
			if (GuiDataUtilities.buildingsButtonData && GuiDataUtilities.buildingsButtonData.length > 0) {
				buildingID = AuxUtilities.GetURLParameter("buildingID") || GuiDataUtilities.buildingsButtonData[0].building_id;
				let buildingStyleIndex = GuiDataUtilities.buildingsButtonData.findIndex(style => style.building_id === buildingID);
				buildingDesigner.buildingSizes = await GuiDataUtilities.LoadBuildingSizes(buildingID);

				if (buildingDesigner.buildingSizes) {
					let sizeIndex = 0;
					let buildingOptions = GuiDataUtilities.buildingsButtonData[buildingStyleIndex].options;

					let defaultWidth = null;

					if (nestedObj(buildingOptions,"default")) {
						defaultWidth = nestedObj(buildingOptions,"default.width");
					} else {
						defaultWidth = buildingDesigner.buildingSizes[0].width;
					}

					sizeIndex = await buildingDesigner.GetBuildingSizeIndex(buildingID, defaultWidth, 0);
					await buildingDesigner.LaunchCreateBuildingCode(buildingID, sizeIndex);
				}
			} else {
				// TODO: report this error to the server
				alert("Building data does not exist for this subscriber: " + SubscriberDataUtilities.subscriber);
			}
		}
	}
};

BuildingDesigner.getVRDisplays = function (onDisplay) {
	if ("getVRDisplays" in navigator) {

		navigator.getVRDisplays()
			.then(function (displays) {
				onDisplay(displays[0]);
			});

	}
};

BuildingDesigner.vrCheckAvailability = function () {
	return new Promise(function (resolve, reject) {
		if (navigator.getVRDisplays !== undefined) {
			navigator.getVRDisplays().then(function (displays) {
				if (displays.length === 0) {
					if (DEBUG) {
						console.log("No VR Displays");
					}
					reject(false);
				} else {
					if (DEBUG) {
						console.log("VR Display Available");
					}
					resolve(true);
				}
			});
		} else {
			if (DEBUG) {
				console.log("VR Not Supported");
			}
			reject(false);
		}
	});
};

BuildingDesigner.prototype._render = function() {
	if (stats) {
		stats.update();
	}

	const cameraUpdated = this.camera.Update();

	if(cameraUpdated) {
		buildingDesigner.building.SetRulerOrientation(this.cameraSubQuad);

		this._doRender();
	}
};

BuildingDesigner.prototype._doRender = function() {
	const camera = this.camera.getThreeCamera();

	if (this.effect)
		this.effect.render(threeScene, camera);
	else{
		threeRenderer.render(threeScene, camera);
	}
};

BuildingDesigner.buildingSizes = [];
BuildingDesigner.leanToSizes = [];

BuildingDesigner.codeToBeLoadedArray = [];

BuildingDesigner.scriptsLoaded = 0;

BuildingDesigner.onAllCodeLoadedAux = null;

BuildingDesigner.buildingLoadedFromDesign = false;

BuildingDesigner.serverVersion = "";
BuildingDesigner.cachedVersion = "";

BuildingDesigner.currentScriptToBeLoadedIndex = 0;

BuildingDesigner.creatingBuilding = false;

BuildingDesigner.buildingChangedbyUser = false;

BuildingDesigner.previousWidth = "";
BuildingDesigner.previousLength = "";
BuildingDesigner.previousSiding = "";
BuildingDesigner.previousSidingCategory = "";
BuildingDesigner.previousTrim = "";
BuildingDesigner.previousRoofing = "";
BuildingDesigner.previousRoofingCategory = "";