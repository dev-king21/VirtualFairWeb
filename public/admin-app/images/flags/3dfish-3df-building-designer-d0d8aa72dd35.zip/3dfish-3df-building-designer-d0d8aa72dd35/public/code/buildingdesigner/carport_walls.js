/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function CarportWalls()
{
	Walls.call(this);

	this.Initialize = function ()
	{
		this.wallLength = buildingDesigner.building.length - Wall.WALLTHICKNESS * 2;

		for (let i = 0; i < 4; i++)
		{
			this.walls[i] = new CarportWall(this, i);
		}
	};

	this.SetMouseOverTransparency = function (opacity)
	{
		for (let i = 0; i < this.walls.length; i++)
		{
			if (this.walls[i])
				this.walls[i].SetMouseOverTransparency(opacity);
		}
	};

	this.GetAndSetWallPrices = async function ()
	{

		for (let i = 0; i < this.walls.length; i++)
		{
			if (this.walls[i] && this.walls[i].wallData && this.walls[i].wallData.wallID != "WALL_OPEN")
			{
				let sidingPrice = await Walls.GetSidingDimensionPrice(this.walls[i].wallData.wallID, this.walls[i].length, this.walls[i].sidingColorData.category_id, this.walls[i].walltype);

				this.walls[i].SetPrice(sidingPrice);
			}
		}
	};

	this.GetSidingData = function ()
	{
		for (let i = 0; i < this.walls.length; i++)
		{
			if (this.walls[i] && this.walls[i].wallData && this.walls[i].wallData.wallID != "WALL_OPEN")
			{
				return this.walls[i].sidingColorData;
			}
		}

		return null;
	};
}
