/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

/**
 * @class ManorShedBuilding
 * @param {string} buildingID
 * @param {Object} roofRafter
 * @param {Object} sizeData
 */
function ManorShedBuilding(buildingID, roofRafter, sizeData)
{
	Building.call(this, buildingID, roofRafter, sizeData);

	this.Initialize = async function ()
	{
		await this.SetSizeData(this.sizeData);

		this.base = new Base(this.width, this.length);

		this.floor = new Floor(this.width, this.length);

		this.walls = new Walls();

		await this.walls.Initialize();

		this.roof = new Roof();

		this.rafters = new WoodRafters(this.roofRafter.data.thickness, buildingDesigner.building.roofRafter.data.width);

		if (nestedObj(buildingDesigner.defaultSettings,"siding_id"))
		{
			await this.SetSidingData(GuiDataUtilities.GetSidingColorButtonData(buildingDesigner.defaultSettings.siding_id, buildingDesigner.defaultSettings.siding_id));
		}
		else
		{
			await this.walls.SetSidingData(GuiDataUtilities.sidingColorButtonData[0]);
		}

		await this.walls.SetSidingData(GuiDataUtilities.sidingColorButtonData[0]);

		if (nestedObj(buildingDesigner.defaultSettings,"roofing_id"))
		{
			await this.SetRoofingData(GuiDataUtilities.GetRoofingButtonData(buildingDesigner.defaultSettings.roofing_id, buildingDesigner.defaultSettings.roofing_id));
		}
		else
		{
			await this.roof.SetRoofingData(GuiDataUtilities.roofingButtonData[0]);
		}
		if (nestedObj(buildingDesigner.defaultSettings,"siding_id"))
		{
			this.SetTrimColor(buildingDesigner.defaultSettings.trim_color_id);
		}
		else
		{
			//this.SetTrimColor(ColorsDataUtilities.FindColor(buildingDesigner.defaultSettings.trim_color_id).color);
		}

		let elem_ID = "DEFAULT_WIDTH_";

		let objectIDWIdth = "" + MathUtilities.Round(this.width, 0);

		if (objectIDWIdth.length == 1)
		{
			objectIDWIdth = "0" + objectIDWIdth;
		}

		elem_ID += objectIDWIdth;

		let dormerButtonData = GuiDataUtilities.GetDormerButtonData(elem_ID);

		let element = Dormer.AddDormer(dormerButtonData);

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

		ElementsMenu.ElementsListPricingUpdate();

		this.InitializeRulersAndLogo();

		this.initialized = true;
	};

	/*this.LoadSidingFromXML = function(xmlDesignDoc)
    {
        let nodeSiding = xmlDesignDoc.getElementsByTagName("SIDING")[0];

        let sidingID  = nodeSiding.getAttribute("sidingID");
        this.walls.SetSidingData(GuiDataUtilities.GetSidingColorButtonData(sidingID));

        /*let textureName = nodeSiding.getAttribute("textureName");

        let innerWallTextureName = nodeSiding.getAttribute("innerWallTextureName");

        this.walls.SetWallTextureName(textureName);
        this.walls.SetInnerWallTextureName(innerWallTextureName);
        */

	////this.dormer.SetWallTextureFileName(textureName);
	////this.dormer.SetInnerWallTextureFileName(innerWallTextureFileName);
	//}


	this.LoadRoofingFromXML = function (xmlDesignDoc)
	{
		let nodeRoofing = xmlDesignDoc.getElementsByTagName("ROOFING")[0];

		let roofingID = nodeRoofing.getAttribute("roofingID");
		this.roof.SetRoofingData(GuiDataUtilities.GetRoofingButtonData(roofingID));

		/*let tileTextureName = nodeRoofing.getAttribute("tileTextureName");

        let roofTextureName = nodeRoofing.getAttribute("roofTextureName");

        this.roof.SetTileTextureName(tileTextureName);
        this.roof.SetRoofTextureName(roofTextureName);
        */

		////this.dormer.SetTileTextureName(this.roof.tileTextureName);
	};

	/**
	 * @method ManorShedBuilding.LoadRoofingFromObject
	 * @param {Object} building savedDesignObject.TDFDESIGN.BUILDING
	 */
	this.LoadRoofingFromObject = function (building)
	{
		this.roof.SetRoofingData(GuiDataUtilities.GetRoofingButtonData(building.ROOFING.roofingID));
	};

	this.SetSidingData = async function (data)
	{
		await this.walls.SetSidingData(data);

		if (this.dormer)
			this.dormer.SetSidingColorData(data);
	};

	this.SetRoofingData = function (data)
	{
		this.roof.SetRoofingData(data);

		if (this.dormer)
			this.dormer.SetRoofingData(data);
	};

	this.SetTrimColor = function (color)
	{
		this.roof.SetTrimColor(color);

		if (this.dormer)
			this.dormer.SetTrimColor(color);
	};

	this.SetRafterAndSizeData = async function (roofRafter, sizeData)
	{
		this.roofRafter = roofRafter;
		previousWidth = this.sizeData.width_display;

		await this.SetSizeData(sizeData);

		if (this.sizeData.width_display !== previousWidth)
		{
			ElementsMenu.SetDormersTabVisibility(true,this.sizeData.width_display);
			if (this.dormer)
			{
				Dormer.AddDormer(GuiDataUtilities.GetDormerButtonData("DEFAULT_WIDTH_"+this.sizeData.width_display));
			}
		}

		this.base = new Base();

		this.floor = new Floor();

		if (buildingDesigner.building.metalFraming)
			this.rafters = new MetalRafters(this.roofRafter.data.thickness, this.roofRafter.data.thickness);
		else
			this.rafters = new WoodRafters(this.roofRafter.data.thickness, this.roofRafter.data.thickness);

		await this.walls.Initialize();

		ElementsMenu.ElementsListPricingUpdate();

		this.SetBuildingModified();

		this.InitializeRulersAndLogo();

		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		buildingDesigner.Draw();
	};
}
