/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function CustomSinCurve(scale)
{
	THREE.Curve.call(this);

	this.scale = (scale === undefined) ? 1 : scale;

	this.arcLengthDivisions = HorseBarnHook.HOOK_SEGMENTS;
}

CustomSinCurve.prototype = Object.create(THREE.Curve.prototype);
CustomSinCurve.prototype.constructor = CustomSinCurve;


CustomSinCurve.prototype.getPoint = function (t)
{
	let tx = 0;
	let ty = 0;
	let tz = 0;

	let angle = t * Math.PI;

	if (t == 0)
	{
		tx = HorseBarnHook.HOOK_RADIUS;
	}
	else if (t == 1)
	{
		tx = -HorseBarnHook.HOOK_RADIUS;
		ty = 0;
	}
	else
	{
		tx = HorseBarnHook.HOOK_RADIUS * Math.cos(angle);
		ty = HorseBarnHook.HOOK_RADIUS * Math.sin(angle) + HorseBarnHook.HOOK_STRAIGHTLENGTH;
	}

	return new THREE.Vector3(tx, ty, tz).multiplyScalar(this.scale);
};

function HorseBarnHook(x, y, z, rotAngle)
{
	this.pos = new THREE.Vector3(x, y, z);

	this.rotAngle = rotAngle;

	this.path = new CustomSinCurve(1);

	this.material = new THREE.MeshPhongMaterial({
		color: HorseBarnHook.HOOK_COLOR,
		specular: 0xFFFFFF,
		shininess: 100
	});


	this.regenerate = true;

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.Generate = function ()
	{



		let geometry = new THREE.TubeGeometry(this.path, HorseBarnHook.hookSegments, HorseBarnHook.TUBE_RADIUS, HorseBarnHook.TUBE_RADIALSEGMENTS, false);
		this.mesh = new THREE.Mesh(geometry, this.material);

		this.mesh.matrixAutoUpdate = false;
		this.mesh.applyMatrix4(new THREE.Matrix4().makeRotationX(Math.PI / 2));
		this.mesh.applyMatrix4(new THREE.Matrix4().makeRotationY(-Math.PI / 2));

		this.mesh.applyMatrix4(new THREE.Matrix4().makeRotationY(this.rotAngle));

		this.mesh.applyMatrix4(new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z));

		return this.mesh;
	};
}

HorseBarnHook.HOOK_RADIUS = 0.1;
HorseBarnHook.HOOK_SEGMENTS = 12;
HorseBarnHook.HOOK_STRAIGHTLENGTH = 0.1;
HorseBarnHook.HOOK_CORNEROFFSET = HorseBarnHook.HOOK_STRAIGHTLENGTH * 2;

HorseBarnHook.TUBE_RADIUS = 0.03;
HorseBarnHook.TUBE_RADIALSEGMENTS = 8;

HorseBarnHook.HOOK_COLOR = 0x63543D;
