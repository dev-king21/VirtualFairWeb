/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function LegBraces(buttonData)
{
	Element.call(this, buttonData);

	buttonData.type = ELEM_LEG_BRACES;

	this.color = MetalRafters.METAL_RAFTERS_COLOR;

	this.legBracesTextureName = "MetalRafter";

	this.legBracesTexture = null;

	this.draggable = false;

	this.regenerate = true;

	this.mesh = null;

	this.SetPos(0, 0, 0);

	this.count = 0;

	this.GetPrice = function (price)
	{
		return buttonData.price * buttonData.width * this.count;
	};

	this.GetMatrix = function ()
	{
		return this.mesh.matrix;
	};

	this.AddLegBrace = function (x, y, z, angle)
	{
		let geometry = GeometryUtilities.CreateBoxGeometry(buttonData.width, buildingDesigner.building.roofRafter.data.thickness, buildingDesigner.building.roofRafter.data.thickness);

		let legBracesMesh = GeometryUtilities.CreatePhongMeshFromGeometry(geometry, this.color, this.legBracesTexture);

		if (angle < 0)
		{
			legBracesMesh.geometry.matrixAutoUpdate = false;
			legBracesMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-buttonData.width, 0, 0));
		}

		legBracesMesh.geometry.matrixAutoUpdate = false;
		legBracesMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, -buildingDesigner.building.roofRafter.data.thickness / 10, 0));

		legBracesMesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationZ(angle));

		legBracesMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(x, y, z));

		legBracesMesh.castShadow = true;
		legBracesMesh.receiveShadow = true;

		this.mesh.add(legBracesMesh);

		////threeScene.add(legBracesMesh);

		//legBracesMesh;

		this.count++;
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate && buildingDesigner.building.rafters)
		{
			if (this.buttonData.adjust_for_building)
			{
				if (buildingDesigner.building.height >= 9)
					buttonData.width = 3;
				else
					buttonData.width = 2;
			}

			this.legBracesTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.legBracesTextureName, -1, -1);

			////if (TexturesDataUtilities.TextureLoaded(this.legBracesTexture))
			{
				this.Destroy();

				this.mesh = new THREE.Mesh();

				if (this.selected)
				{
					this.color = 0x0000FF;
				}
				else
					this.color = MetalRafters.METAL_RAFTERS_COLOR;

				let roofSideAngle = Math.PI / 2 + Math.atan(buildingDesigner.building.roofRafter.frontTanAngleRatio);

				let sideAngle = Math.PI / 4;

				let roofConnectionAngle = Math.PI - roofSideAngle - sideAngle;

				let heightOffset1 = buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[1][1] - buildingDesigner.building.roofRafter.data.front_height_extension_attach_coord[0][1];

				let heightOffset2 = buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[0][1] - buildingDesigner.building.roofRafter.data.rear_height_extension_attach_coord[1][1];

				let connectionHeight1 = buildingDesigner.building.height + heightOffset1 - (buttonData.width / Math.sin(roofSideAngle) * Math.sin(roofConnectionAngle));

				let connectionHeight2 = connectionHeight1 - buildingDesigner.building.roofRafter.frontBackHeightDifference - heightOffset1 + heightOffset2;

				if (buildingDesigner.building.roofRafter.data.bent_bow)
				{
					// ** TEMPORARY FIX -- placement of leg braces was broken for CDLAMC1 -- added 1 to the height
					// this needs to come from the data, possibly an optional JSON variable added to the rafter record
					connectionHeight1 += buildingDesigner.building.roofRafter.data.front_wall_attach_coord[0][1] + 1;

					connectionHeight2 += buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[0][1] + 1;
				}


				this.count = 0;

				let zOffset = 0;

				let rafterCoord;


				let rightWall = buildingDesigner.building.walls.GetWall(WALL_RIGHT);
				let leftWall = buildingDesigner.building.walls.GetWall(WALL_LEFT);

				if (leftWall.style == CarportWall.OPEN)
				{
					rafterCoord = buildingDesigner.building.rafters.frontBackRafterCoords[0];

					this.AddLegBrace(-buildingDesigner.building.roofRafter.wallWidth / 2 + buildingDesigner.building.roofRafter.data.thickness, connectionHeight1, rafterCoord, sideAngle);

					this.AddLegBrace(buildingDesigner.building.roofRafter.wallWidth / 2 - buildingDesigner.building.roofRafter.data.thickness, connectionHeight2, rafterCoord, -sideAngle);
				}

				if (rightWall.style == CarportWall.OPEN)
				{
					rafterCoord = buildingDesigner.building.rafters.frontBackRafterCoords[buildingDesigner.building.rafters.frontBackRafterCoords.length - 1];

					this.AddLegBrace(-buildingDesigner.building.roofRafter.wallWidth / 2 + buildingDesigner.building.roofRafter.data.thickness, connectionHeight1, rafterCoord, sideAngle);

					this.AddLegBrace(buildingDesigner.building.roofRafter.wallWidth / 2 - buildingDesigner.building.roofRafter.data.thickness, connectionHeight2, rafterCoord, -sideAngle);
				}


				if (buttonData.max_number == -1)
				{
					for (let i = 1; i < buildingDesigner.building.rafters.frontBackRafterCoords.length - 1; i++)
					{
						rafterCoord = buildingDesigner.building.rafters.frontBackRafterCoords[i];

						zOffset = ((i == 0 || i == buildingDesigner.building.rafters.frontBackRafterCoords.length - 1) ? 0 : buildingDesigner.building.roofRafter.data.thickness / 2);

						this.AddLegBrace(-buildingDesigner.building.roofRafter.wallWidth / 2 + buildingDesigner.building.roofRafter.data.thickness, connectionHeight1, rafterCoord - zOffset, sideAngle);

						this.AddLegBrace(buildingDesigner.building.roofRafter.wallWidth / 2 - buildingDesigner.building.roofRafter.data.thickness, connectionHeight2, rafterCoord - zOffset, -sideAngle);
					}
				}

				////this.mesh = MeshUtilities.MergeMeshGeometry(this.mesh);

				this.mesh.castShadow = true;
				this.mesh.receiveShadow = true;

				this.mesh.type = ELEM_LEG_BRACES;

				MeshUtilities.SetElement(this.mesh, this);


				this.regenerate = false;
			}
		}

		return this.mesh;
	};

	this.UpdateMatrix = function ()
	{
		if (this.mesh)
		{
			let matrix = new THREE.Matrix4();

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z));

			this.mesh.matrix = new THREE.Matrix4();
			this.mesh.matrixAutoUpdate = false;
			this.mesh.applyMatrix4(matrix);
		}
	};
}

LegBraces.AddLegBraces = function (buttonData)
{
	let legBraces = new LegBraces(buttonData);

	Elements.AddElement(legBraces);
	
	Elements.draggableElement = null;

	buildingDesigner.building.SetRegenerateElementMeshes(true);

	return legBraces;
};
