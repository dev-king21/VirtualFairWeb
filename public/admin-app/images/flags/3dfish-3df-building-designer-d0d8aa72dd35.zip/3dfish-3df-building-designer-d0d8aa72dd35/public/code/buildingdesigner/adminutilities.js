// Copyrighted 2014-2018 by 3D Fish, LLC
// All rights reserved.
// Un-authorized reproduction prohibited
// Violators will be prosecuted.

/*eslint-env jquery, browser, es6*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, no-unused-vars, no-undef, no-useless-escape*/

async function AdminUtilities()
{

}

AdminUtilities.ParseSessionsData = function(sessions) {
	let dataSet = [];
	// send notification <i class="far fa-comment-alt"></i>
	// chat <i class="far fa-comments"></i>
	// anon user <i class="fas fa-user-secret"></i>
	// t
	if (SubscriberDataUtilities.subscriber.indexOf("MASTER")>-1) {
		let total_user_count = 0;
		Object.entries(sessions).forEach(([key, val]) => {
			let subscriber_id = key;
			let user_count = Object.keys(sessions[subscriber_id]).length;
			dataSet.push({
				subscriber_id: subscriber_id,
				subscriber_id_display: {
					display: `<span class="clickable" onclick="AdminUtilities.Action('display_sub_online_users',{subscriber_id: '${subscriber_id}'});">${subscriber_id}</span>`,
					sort: subscriber_id
				},
				user_count:user_count}
			);
			total_user_count += user_count;
		});
		$("#infobox-onlineusers .infobox-number").text(total_user_count);
		return dataSet;
	} else {
		if (sessions[SubscriberDataUtilities.subscriber]) {
		if (["sadmin", "master"].includes(UserDataUtilities.usertype)) {
			Object.entries(sessions[SubscriberDataUtilities.subscriber]).forEach(([key, val]) => {
				//let rowData = {
				dataSet.push({
					location_number: val.location_number ? val.location_number : 0,
					firstname: val.firstname ? val.firstname : "anon",
					lastname: val.lastname ? val.lastname : "user",
					name: function() { return this.firstname + " " + this.lastname;},
					userid: val.userid ? val.userid : "unknown",
					postal_code: val.postal_code ? val.postal_code : "unknown",
					ip: val.ip ? val.ip : "0.0.0.0",
					appStatus: val.appStatus ? val.appStatus : {visible: true, active: true},
					appStatusDisplay: function () { let visible = this.appStatus.visible ? "":`<i class="fas fa-eye-slash"></i>`;let active = this.appStatus.active ? "":`<i class="fas fa-bed"></i>`;return visible + active; }
				});
				//dataSet.push(rowData);
			});
			return dataSet;
		} else {
			Object.entries(sessions[SubscriberDataUtilities.subscriber]).forEach(([key, val]) => {
				if (val.location_number === SubscriberDataUtilities.location_number) {
					let rowData = {
						location_number: val.location_number ? val.location_number : 0,
						firstname: val.firstname ? val.firstname : "anon",
						lastname: val.lastname ? val.lastname : "user",
						name: function() { return this.firstname + " " + this.lastname;},
						userid: val.userid ? val.userid : "unknown",
						postal_code: val.postal_code ? val.postal_code : "unknown",
						ip: val.ip ? val.ip : "0.0.0.0",
						appStatus: val.appStatus ? val.appStatus : {visible: true, active: true},
						appStatusDisplay: function () { let visible = this.appStatus.visible ? "":`<i class="fas fa-eye-slash"></i>`;let active = this.appStatus.active ? "":`<i class="fas fa-bed"></i>`;return visible + active; }
					}
					dataSet.push(rowData);
				}
			});
			return dataSet;
		}} else {
			return dataSet;
		}
	}
}

AdminUtilities.DisplayAdminView = async function() {
	if(!AdminUtilities.AdminViewMenuLoaded) {
		let err, result;
		[err,result] = await to($.ajax({
			url: "adminui",
			dataType: "html",
			method: "POST",
			data: {subscriber_id: SubscriberDataUtilities.subscriber, loaddata: "admin-view_menu"}
		}));
		if (err) {
			GuiDataUtilities.Alert("Error loading Admin menu.");
			return;
		}
		AdminUtilities.AdminViewMenuLoaded = true;
		$("#admin-tab-menu-placeholder").replaceWith(result);
	}
	if(!AdminUtilities.AdminViewMenuTabPanelsLoaded) {
		let err, result;
		[err,result] = await to($.ajax({
			url: "adminui",
			dataType: "html",
			method: "POST",
			data: {subscriber_id: SubscriberDataUtilities.subscriber, loaddata: "admin-view_menu_tab_panels"}
		}));
		if (err) {
			GuiDataUtilities.Alert("Error loading Admin menu.");
			return;
		}
		AdminUtilities.AdminViewMenuTabPanelsLoaded = true;
		$("#admin-view-tabs").replaceWith(result).foundation();
		//$(document).foundation();
		linkMenuTabs();
		$("#admin-tabs").foundation();
	}
	if(!AdminUtilities.AdminViewLoaded) {
		let err, result;
		[err,result] = await to($.ajax({
			url: "adminui",
			dataType: "html",
			method: "POST",
			data: {subscriber_id: SubscriberDataUtilities.subscriber, loaddata: "admin-view_content"}
		}));
		if (err) {
			GuiDataUtilities.Alert("Error loading Admin content.");
			return;
		}
		AdminUtilities.AdminViewLoaded = true;
		$("#admincontainer").html(result);
		if (UserDataUtilities.usertype === "master") {
			$(".admin-masterui").show();
			$(".admin-sadminui").show();
			$(".admin-adminui").show();
			$(".admin-staffui").show();
			if (SubscriberDataUtilities.subscriber.includes("master")) {
				$(".admin-systemui").show();
			}
		}
		if (UserDataUtilities.usertype === "sadmin") {
			$(".admin-sadminui").show();
			$(".admin-adminui").show();
			$(".admin-staffui").show();
		}
		if (UserDataUtilities.usertype === "admin") {
			$(".admin-adminui").show();
			$(".admin-staffui").show();
		}
		if (UserDataUtilities.usertype === "staff") {
			$(".admin-staffui").show();
		}
	}
	$(".design-view").hide();
	$(".admin-view").show();
	if (AdminUtilities.CurrentView === "") {
		AdminUtilities.DisplayPanel("dashboard");

		//if (SubscriberDataUtilities.subscriber.indexOf("MASTER") > -1) {
			AdminUtilities.OnConnectUpdate = async () => {
				await AuxUtilities.sleep(10000);
				NodeJSUtilities.UQuery("adminDataRequest", {request: "getCurrentUsersList"},null, function (data) {
					if (SubscriberDataUtilities.subscriber.indexOf("MASTER") > -1) {
						AdminUtilities.sessions = data.sessions;
					} else {
						AdminUtilities.sessions[SubscriberDataUtilities.subscriber] = data.sessions;
					}
					let userTable = $("#currentusers").DataTable();
					let userData = AdminUtilities.ParseSessionsData(AdminUtilities.sessions);
					userTable.clear().rows.add(userData).draw();
				});
			};
			AdminUtilities.OnServerLog = async (data) => {
				if (DEBUG) {
					console.log("AdminUtilities.OnServerLog");
				}
				data = data.data;
				if (["admin","sadmin", "master"].includes(UserDataUtilities.usertype) && data.request === "connect") {
					if (typeof AdminUtilities.sessions[data.subscriber_id] !== "object") {
						AdminUtilities.sessions[data.subscriber_id] = {};
					}
					AdminUtilities.sessions[data.subscriber_id][data.socket_id] = data.sessionData;
					let userTable = $("#currentusers").DataTable();
					let userData = AdminUtilities.ParseSessionsData(AdminUtilities.sessions);
					userTable.clear().rows.add(userData).draw();
				}
				if (["admin","sadmin", "master"].includes(UserDataUtilities.usertype) && data.request === "update") {
					if (typeof AdminUtilities.sessions[data.subscriber_id] !== "object") {
						AdminUtilities.sessions[data.subscriber_id] = {};
					}
					AdminUtilities.sessions[data.subscriber_id][data.socket_id] = data.sessionData;
					let userTable = $("#currentusers").DataTable();
					let userData = AdminUtilities.ParseSessionsData(AdminUtilities.sessions);
					userTable.clear().rows.add(userData).draw();
				}
				if (["admin","sadmin", "master"].includes(UserDataUtilities.usertype) && data.request === "disconnect") {
					if (nestedObj(AdminUtilities.sessions,`${data.subscriber_id}.${data.socket_id}`)) {
						delete AdminUtilities.sessions[data.subscriber_id][data.socket_id];
					}
					let userTable = $("#currentusers").DataTable();
					let userData = AdminUtilities.ParseSessionsData(AdminUtilities.sessions);
					userTable.clear().rows.add(userData).draw();
				}
			};
		//}
		AdminUtilities.OnUpdate = async (data) => {
			if (DEBUG) {
				console.log("socket.on(update)");
			}
			if (data[0]) {
				//if (data[0].onlineUserCount && SubscriberDataUtilities.subscriber.indexOf("MASTER") === -1) {
					if (data[0].onlineUserCount) {
					$("#infobox-onlineusers .infobox-number").text(data[0].onlineUserCount);
				}
				if (["admin", "sadmin", "master"].includes(UserDataUtilities.usertype) && data[0].sessions) {
					//if (SubscriberDataUtilities.subscriber.indexOf("MASTER") === -1) {
						AdminUtilities.sessions[data[0].subscriber_id] = data[0].sessions;
						let userTable = $("#currentusers").DataTable();
						let userData = AdminUtilities.ParseSessionsData(AdminUtilities.sessions);
						userTable.clear().rows.add(userData).draw();
					//}
				}
			}
			if (["sadmin", "master"].includes(UserDataUtilities.usertype) && data.type === "add_location") {
				if (SubscriberDataUtilities.locationData.findIndex(obj => obj.location_number == data.location_data.location_number) > -1) {
					return;
				}
				SubscriberDataUtilities.locationData.push(data.location_data);
				AdminUtilities.PopulateLocations.populated = false;
				AdminUtilities.PopulateLocations();
			}
			if (["sadmin", "master"].includes(UserDataUtilities.usertype) && data.type === "update_location") {
				SubscriberDataUtilities.locationData[SubscriberDataUtilities.locationData.findIndex(obj => obj.location_number == data.location_data.location_number)] = data.location_data;
				AdminUtilities.PopulateLocations.populated = false;
				AdminUtilities.PopulateLocations();
			}
			if (["sadmin", "master"].includes(UserDataUtilities.usertype) && data.type === "activate_location") {
				SubscriberDataUtilities.locationData[SubscriberDataUtilities.locationData.findIndex(obj => obj.location_number == data.location_data.location_number)].active = data.location_data.active;
				AdminUtilities.PopulateLocations.populated = false;
				AdminUtilities.PopulateLocations();
			}
			if (["sadmin", "master"].includes(UserDataUtilities.usertype) && data.type === "deactivate_location") {
				SubscriberDataUtilities.locationData[SubscriberDataUtilities.locationData.findIndex(obj => obj.location_number == data.location_data.location_number)].active = data.location_data.active;
				AdminUtilities.PopulateLocations.populated = false;
				AdminUtilities.PopulateLocations();
			}
			if (["sadmin", "master"].includes(UserDataUtilities.usertype) && data.type === "quoteRequest") {
				let ordercount = Number($("#infobox-totalorders .infobox-number").text());
				ordercount++;
				$("#infobox-totalorders .infobox-number").text(ordercount);
			}
			if (["sadmin", "master"].includes(UserDataUtilities.usertype) && (data.type === "autoRegister" || data.type === "register")) {
				let registeredusers = Number($("#infobox-registeredusers .infobox-number").text());
				registeredusers++;
				$("#infobox-registeredusers .infobox-number").text(registeredusers);
			}
			if (["sadmin", "master"].includes(UserDataUtilities.usertype) && data.type === "saveDesignToWeb") {
				let designcount = Number($("#infobox-saveddesigns .infobox-number").text());
				designcount++;
				$("#infobox-saveddesigns .infobox-number").text(designcount);
			}
			if (["sadmin", "master"].includes(UserDataUtilities.usertype) && data.type === "contactRequest") {
				let requestcount = Number($("#infobox-totalcontactrequests .infobox-number").text());
				requestcount++;
				$("#infobox-totalcontactrequests .infobox-number").text(requestcount);
			}
		};
	}
	window.dispatchEvent(new Event('resize'));
};

AdminUtilities.OnAdminActionResponse = async function(data) {
	if (!data) {
		return;
	}
	switch(data.request) {
		case "get_db_design_list": {
			if (!data.design_list) {
				return;
			}
			AdminUtilities.db_design_list = data.design_list;
			$("#admin-designsave").append(`<br>${data.design_list.length} designs listed<br><br><button class="button" onclick="AdminUtilities.Action('process_design_list');this.disabled=true;">Process List<button><br>`);
			break;
		}
		case "save_design": {
			if (data.saved) {
				let nextDesign = AdminUtilities.ProcessDesignList.next();
				if (!nextDesign.done) {
					let designdata = await NodeJSUtilities.UQuery("adminAction", {request: "get_design_data", design_id: nextDesign.value.design_id});
					let data_format = designdata.data_format;
					designdata = AdminUtilities.processDesignData(designdata);
					socket.emit("adminActionWorker",{request: "save_design",design_id: nextDesign.value.design_id, designdata: designdata, data_format: data_format});
					$("#DesignSaveStatus").text(nextDesign.value.design_id);
				} else {
					$("#DesignSaveStatus").text("done");
				}
			} else {
				$("#DesignSaveStatus").text("stopped");
			}
			break;
		}
	}
}

AdminUtilities.DisplayDesignView = async function() {
	$(".admin-view").hide();
	$(".design-view").show();
	window.dispatchEvent(new Event('resize'));
};

AdminUtilities.PriceDisplay = async function(setting) {
	admin_settings.pricing_override = true;
	admin_settings.price_setting = setting;
	if (setting === "NOPRICING") {
		$("#price_display").hide();
	} else {
		$("#price_display").show();
	}
	buildingDesigner.building.Refresh();
};

AdminUtilities.PopulateDash = async function() {
	if (AdminUtilities.PopulateDash.populated) {
		return;
	}
	AdminUtilities.PopulateDash.populated = true;
	if (SubscriberDataUtilities.subscriber.indexOf("MASTER")===-1) {
		NodeJSUtilities.UQuery("adminDataRequest",{request: "getOnlineUserCount"}, null, function(data) {
			$("#infobox-onlineusers .infobox-number").text(data[0].onlineUserCount);
		});
	}
	NodeJSUtilities.UQuery("adminDataRequest",{request: "getRegisteredUserCount"}, null, function(data) {
		$("#infobox-registeredusers .infobox-number").text(data.registered_user_count);
	});
	NodeJSUtilities.UQuery("adminDataRequest",{request: "getSavedDesignCount"}, null, function(data) {
		$("#infobox-saveddesigns .infobox-number").text(data.design_count);
	});
	NodeJSUtilities.UQuery("adminDataRequest",{request: "getTotalContactRequestCount"}, null, function(data) {
		$("#infobox-totalcontactrequests .infobox-number").text(data.contact_request_count);
	});
	NodeJSUtilities.UQuery("adminDataRequest",{request: "getTotalOrdersCount"}, null, function(data) {
		$("#infobox-totalorders .infobox-number").text(data.order_count);
	});

	if (SubscriberDataUtilities.subscriber.indexOf("MASTER")>-1) {
		$("#admin-online_users h4").html("<b>Active Subscribers</b>");
		NodeJSUtilities.UQuery("adminDataRequest", {request: "getCurrentUsersList"}, null, function (data) {
			let dataSet = AdminUtilities.ParseSessionsData(data.sessions);
			AdminUtilities.sessions = data.sessions;

			$("#currentusers").DataTable({
				data: dataSet,
				responsive: true,
				scrollY: "calc(50vh - 125px)",
				scrollCollapse: true,
				paging: false,
				order: [[1, "desc"]],
				columns: [
					{title: "Subscriber ID", data: "subscriber_id_display", render: {_:"display", sort: "sort"}},
					{title: "Online", data: "user_count"}
				]
			});
		});

	} else {
		if (["admin", "sadmin", "master"].includes(UserDataUtilities.usertype)) {
			NodeJSUtilities.UQuery("adminDataRequest", {request: "getCurrentUsersList"}, null, function (data) {
				AdminUtilities.sessions[SubscriberDataUtilities.subscriber] = data.sessions;
				let dataSet = AdminUtilities.ParseSessionsData(AdminUtilities.sessions);

				$("#currentusers").DataTable({
					data: dataSet,
					responsive: true,
					scrollY: "calc(50vh - 125px)",
					scrollCollapse: true,
					paging: false,
					columns: [
						{title: "Office", data: "location_number"},
						{title: "-", data: "appStatusDisplay"},
						{title: "Name", data: "name"},
						{title: "User ID", data: "userid"},
						{title: "Zipcode", data: "postal_code"},
						{title: "IP Address", data: "ip"}
					]
				});
			});
		}
	}

}

AdminUtilities.AddLocation = async function() {
	if (!AdminUtilities.AddLocation.popupLoaded) {
		let err, result;
		[err,result] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getPopup", id_prefix: "addlocation",content_key: "infobox_add_location",open_next: "AddLocationModal"}));
		if (err) {
			return;
		}
		AdminUtilities.AddLocation.popupLoaded = true;
		$('body').append(result.html);
		$("#addlocation_infobox").foundation();
	}
	if (!AdminUtilities.AddLocation.locationFormLoaded) {
		let err, result;
		[err,result] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getPopup", type: "form", state: "add", file:"addlocation_form.ejs"}));
		if (err) {
			return;
		}
		AdminUtilities.AddLocation.locationFormLoaded = true;
		$('body').append(result.html);
		$("#AddLocationModal").foundation();
		initForms();
	}

	$("#addlocation_infobox").foundation("open");

}

AdminUtilities.ProcessForm = async function(formID) {
	let err, result;
	let formData = $("form#"+formID).serializeObject();
	let form = $("#"+formID)[0];
	switch(formID) {
		case "adminAddLocationForm": {
			formData.countrycode = "US";
			formData.city = form.postal_code_data.city;
			formData.region = form.postal_code_data.statecode;
			[err,result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "add_location", ...formData}));
			if (err) {
				return;
			}
			if (SubscriberDataUtilities.locationData.findIndex(obj => obj.location_number === result.location_number) === -1) {
				let dataSet = AdminUtilities.createRowData(result,"locations");
				SubscriberDataUtilities.locationData.push(result);
				$("#locations").DataTable().rows.add(dataSet).draw();
			}
			$("#AddLocationModal").foundation("close");
			form.reset();
			break;
		}
		case "adminEditLocationForm": {
			formData.location_number = form.location_number;
			formData.countrycode = form.countrycode;
			formData.city = form.postal_code_data.city;
			formData.region = form.postal_code_data.statecode;
			formData.display_prices = form.display_prices;
			formData.active = form.active;
			formData.request = "update_location_record";
			[err,result] = await to(NodeJSUtilities.UQuery("adminAction",formData));
			if (err) {
				return;
			}
			// let dataSet = AdminUtilities.createRowData(result,"locations");
			SubscriberDataUtilities.locationData[SubscriberDataUtilities.locationData.findIndex(obj => obj.location_number == formData.location_number)] = result;
			AdminUtilities.PopulateLocations.populated = false;
			AdminUtilities.PopulateLocations();
			$("#EditLocationModal").foundation("close");
			form.reset();
			break;
		}
		case "adminEditUserForm": {
			[err,result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "update_user", user_data: formData}));
			if (err) {
				return;
			}
			$("#EditUserModal").foundation("close");
			form.reset();
			break;
		}
		case "adminAddUserForm": {
			//
			break;
		}
		case "adminBuildingSizePricesForm": {
			//console.log(formData);
			formData.request = "update_building_size_prices";
			[err,result] = await to(NodeJSUtilities.UQuery("adminAction",formData));
			if (err) {
				return;
			}
			$("#alert_infobox").foundation("close");
			break;
		}
		case "adminElementPriceForm": {
			formData.request = "update_element_price";
			[err,result] = await to(NodeJSUtilities.UQuery("adminAction",formData));
			if (err) {
				return;
			}
			$("#alert_infobox").foundation("close");
			AdminUtilities.DisplayPanel(formData.objectType+"s");
			break;
		}
	}
};

AdminUtilities.IsAuthorized = function(acl) {
	if (UserDataUtilities.usertype === "master") {
		return true;
	}
	if (!(UserDataUtilities.userData.data && UserDataUtilities.userData.data.acl)) {
		return false; // No acl data
	}
	if (typeof acl === "string") {
		if (UserDataUtilities.userData.data.acl[acl]) {
			return true;
		}
		return false;
	}
	for (let singleacl of acl) {
		if (UserDataUtilities.userData.data.acl[singleacl]) {
			return true;
		}
	}
	return false;
}

AdminUtilities.Action = async function(action, data) {
	switch(action) {
		case "activate_location": {
			if (!AdminUtilities.IsAuthorized(["sdadmin","edit_location"])) {
				return;
			}
			if (data && data.proceed) {
				if (AdminUtilities.Flags.activating_location) {
					return;
				}
				AdminUtilities.Flags.activating_location = true;
				console.log(data);
				let [err,result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "activate_location", location_number: data.location_number, name: data.name}));
				if (err) {
					console.log("err:",err);
				}
				SubscriberDataUtilities.locationData.find(obj => obj.location_number == data.location_number).active = 1;
				//let LocIndx = SubscriberDataUtilities.locationData.findIndex(obj => obj.location_number == data.location_number);
				//SubscriberDataUtilities.locationData[LocIndx].active = 1;
				$("#activatelocation_infobox").foundation("close");
				AdminUtilities.PopulateLocations.populated = false;
				AdminUtilities.PopulateLocations();
				AdminUtilities.Flags.activating_location = false;
				return;
			}
			if (!AdminUtilities.ActivateLocation_popupLoaded) {
				let [err,result] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getPopup", id_prefix: "activatelocation",content_key: "infobox_activate_location",action: "Activate"}));
				if (err) {
					return;
				}
				AdminUtilities.ActivateLocation_popupLoaded = true;
				$('body').append(result.html);
				$("#activatelocation_infobox").foundation();
			}
			$("#activatelocation_infoboxActionButton").off("click").click(function () {AdminUtilities.Action("activate_location",{proceed: true, location_number: data.location_number})});
			$("#activatelocation_infobox").foundation("open");
			break;
		}
		case "deactivate_location": {
			if (!AdminUtilities.IsAuthorized(["sadmin","edit_location"])) {
				return;
			}
			if (data.location_number === 1) {
				GuiDataUtilities.Alert("Primary location cannot be de-activated.");
				return;
			}
			if (data && data.proceed) {
				if (AdminUtilities.Flags.deactivating_location) {
					return;
				}
				AdminUtilities.Flags.deactivating_location = true;
				console.log(data);
				let [err,result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "deactivate_location", location_number: data.location_number, name: data.name}));
				if (err) {
					console.log("err:",err);
					AdminUtilities.Flags.deactivating_location = false;
					GuiDataUtilities.Alert("Error attempting to de-activate location.");
					return;
				}
				SubscriberDataUtilities.locationData.find(obj => obj.location_number == data.location_number).active = 0;
				//let LocIndx = SubscriberDataUtilities.locationData.findIndex(obj => obj.location_number == data.location_number);
				//SubscriberDataUtilities.locationData[LocIndx].active = 0;
				$("#deactivatelocation_infobox").foundation("close");
				AdminUtilities.PopulateLocations.populated = false;
				AdminUtilities.PopulateLocations();
				AdminUtilities.Flags.deactivating_location = false;
				return;
			}
			if (!AdminUtilities.DeactivateLocation_popupLoaded) {
				let err, result;
				[err,result] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getPopup", id_prefix: "deactivatelocation",content_key: "infobox_deactivate_location",action: "De-Activate"}));
				if (err) {
					return;
				}
				AdminUtilities.DeactivateLocation_popupLoaded = true;
				$('body').append(result.html);
				$("#deactivatelocation_infobox").foundation();
			}
			$("#deactivatelocation_infoboxActionButton").off("click").click(function () {AdminUtilities.Action("deactivate_location",{proceed: true, location_number: data.location_number})});
			$("#deactivatelocation_infobox").foundation("open");
			break;
		}
		case "display_location": {
			let location = SubscriberDataUtilities.locationData.find(obj => obj.location_number == data.location_number);
			[err, result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "get_location_record", location_number: data.location_number}));
			if (err) {
				GuiDataUtilities.Alert(`<h2>Error retrieving data</h2><p>There was an error trying to retrieve this location data from the server. Please check your internet connection and try again later. If the error persists, please contact support.`);
				return;
			}
			location = result[0];
			let edit = AdminUtilities.IsAuthorized(["sadmin","edit_location"]);
			let editLink = `<i class="fas fa-edit clickable" title="Edit Location" style="float: right; margin-right: 15px; font-size: 24px; color: green;" onclick="AdminUtilities.Action('edit_location',{location_number: ${data.location_number}});"></i>`;
			GuiDataUtilities.Alert(`${edit ? editLink:""}<b>Location:${location.active ? "":" <span style='color:red;'>Inactive</span>"}</b><br>${location.name}<br>${location.address}<br>${location.city}, ${location.region}  ${location.postalcode}<br><br><b>Telephone:</b> ${location.phone}<br><b>Fax:</b> ${location.fax}<br><b>Contact Email:</b> ${location.email}<br><b>Notification EMail:</b> ${location.n_email}<br><br><b>Latitude:</b> ${location.latitude}<br><b>Longitude:</b> ${location.longitude}<br><b>Service Range:</b> ${location.service_range} Miles<br><br><b>Sales Tax:</b> ${location.tax_percent}%<br><br><b>Display Prices:</b> ${location.display_prices ? "Yes":"No"}`);
			break;
		}
		case "edit_location": {
			if (!AdminUtilities.Flags.editLocationFormLoaded) {
				let err, result;
				[err,result] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getPopup", type: "form", state: "edit", file:"addlocation_form.ejs"}));
				if (err) {
					return;
				}
				AdminUtilities.Flags.editLocationFormLoaded = true;
				$('body').append(result.html);
				$("#EditLocationModal").foundation();
				initForms();
			}

			let [err, result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "get_location_record", location_number: data.location_number}));
			if (err) {
				GuiDataUtilities.Alert(`<h2>Error retrieving data</h2><p>There was an error trying to retrieve this location data from the server. Please check your internet connection and try again later. If the error persists, please contact support.`);
				return;
			}
			let location = result[0];
			let form = $("#adminEditLocationForm")[0];
			form.name.value = location.name;
			form.address.value = location.address;
			form.postalcode.value = location.postalcode;
			form.phone.value = location.phone;
			form.fax.value = location.fax;
			form.email.value = location.email;
			form.n_email.value = location.n_email;
			form.latitude.value = location.latitude;
			form.longitude.value = location.longitude;
			form.service_range.value = location.service_range;
			form.tax_percent.value = location.tax_percent;
			form.location_number = location.location_number;
			form.postal_code_data = {};
			form.postal_code_data.city = location.city;
			form.postal_code_data.statecode = location.region;
			form.countrycode = location.countrycode;
			form.display_prices = location.display_prices;
			form.active = location.active;
			$('.flinput').prev('label').addClass("show");
			$('#editlocation_postalcode').prev('label').html("Zip code: " + location.city + ", " + location.region);
			$("#EditLocationModal").foundation("open");
			break;
		}
		case "display_request": {
			[err, request] = await to(NodeJSUtilities.UQuery("adminDataRequest",{request: "getContactRequest", ...data}));
			if (err) {
				GuiDataUtilities.Alert(`<h2>Error retrieving data</h2><p>There was an error trying to retrieve this contact request data from the server. Please check your internet connection and try again later. If the error persists, please contact support.`);
				return;
			}
			if (!request.data.postal_code_data) {
				request.data.postal_code_data = {
					city: "",
					statecode: ""
				};
			}
			GuiDataUtilities.Alert(`Name: ${request.data.first_name} ${request.data.last_name}<br>Address: ${request.data.address}<br>${request.data.postal_code_data.city}, ${request.data.postal_code_data.statecode} ${request.data.zipcode}<br><br>Phone: ${request.data.phone}<br>Request:<br>${request.data.request}`);
			break;
		}
		case "load_design": {
			let [err,result] = await to(NodeJSUtilities.UQuery("adminDataRequest",{request: "getDesignData", ...data}));
			if (err) {
				return;
			}
			let details = "";
			if (result.data && result.data.data) {
				let info = result.data.data;
				details = `<h3>Details:</h3>${info.building_detail_list_html}`;
			}
			let info_box = `<a href="?series=${result.series_code}&designID=${result.design_id}${AuxUtilities.GetURLParameter('sc')?'&sc='+AuxUtilities.GetURLParameter('sc'):''}" target="_blank">Click Here to load design in new tab</a><br>${result.in_file_bucket === -1 ? "<b><font color='red'>Design Save NOT confirmed. File likely does not exist.</font></b><br>":""}${details}`;
			GuiDataUtilities.Alert(info_box);
			break;
		}
		case "display_order": {
			let [err, result] = await to(NodeJSUtilities.UQuery("adminDataRequest",{request: "getOrderData", ...data}));
			if (err) {
				return;
			}
			let city_state = result.data.postal_code_data ? `${result.data.postal_code_data.city}, ${result.data.postal_code_data.statecode}`:"";
			let deliveryTo = `<p>${result.data.first_name} ${result.data.last_name}<br>${result.data.delivery_address}<br>${city_state} ${result.data.delivery_zipcode}<br>Phone: ${result.data.phone}<br>Email: ${result.data.email}<br><b>Notes:</b><br>${result.data.request}</p>`;
			let details = result.data ? (result.data.detailListHTML ? `<h4>Product Details:</h4><span class="adm_details">${result.data.detailListHTML}</span>`:""):"";
			let design_id = result.data ? ( result.data.design_id ? result.data.design_id:""): "";
			let series_code = result.data ? (result.data.series_code ? result.data.series_code:""):"";
			let info_box = `<a href="?series=${series_code}&designID=${design_id}${AuxUtilities.GetURLParameter('sc')?'&sc='+AuxUtilities.GetURLParameter('sc'):''}" target="_blank">Click Here to load design in new tab</a><br><h2>Deliver To:</h2><br>${deliveryTo}${details}`;
			GuiDataUtilities.Alert(info_box);
			break;
		}
		case "set_base_siding": {
			if (typeof data.category_id === "undefined") {
				return;
			}
			let [err,result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "set_base_siding", ...data}));
			break;
		}
		case "edit_price": {
			switch (data.objectType) {
				case "building": {
					let [err, result] = await to(NodeJSUtilities.UQuery("adminDataRequest", {
						request: "getBuildingPricing",
						...data
					}));
					if (err) {
						// TODO: Report error to user
						return;
					}
					// check for base siding validity, set automatically if possible or ask user if not set automatically.
					if (result.siding_list.length > 1) {
						if (!result.siding_list.includes(result.building_size_data.base_siding_category_id)) {
							//if (nestedObj(result, "result.series_data.options.base_siding")) {
							if (result.siding_list.includes(nestedObj(result, "series_data.options.base_siding"))) {
								result.building_size_data.base_siding_category_id = nestedObj(result, "series_data.options.base_siding");
							} else {
								// ask user for base siding.
								let siding_selection = "";
								for (let siding of result.siding_prices) {
									siding_selection += `<input type="radio" name="base_siding" value="${siding.category_id}"> ${siding.display_name}<br>`;
								}
								let base_siding_form = {
									msg: `<h2>Base siding type not yet set for this building style. Pricing cannot be set until base siding type has been set for this series of buildings. Please select the base siding type from the list.</h2>${siding_selection}<button type="button" class="button" onclick="AdminUtilities.Action('set_base_siding',{series_code: '${result.series_data.series_code}', category_id:$('input[name=&quot;base_siding&quot;]:checked').val()});">Set Base Siding</button>`
								};
								GuiDataUtilities.Alert(base_siding_form);
								return;
							}
							//}
						}
					} else {
						result.building_size_data.base_siding_category_id = result.siding_list[0];
					}
					let base_siding_display_name = result.siding_prices.find(element => element.category_id === result.building_size_data.base_siding_category_id).display_name;
					let building_price_form = {};
					if (result.siding_list.length > 1) {
						let siding_price_entry = "";
						for (let siding of result.siding_prices) {
							siding_price_entry += `${siding.display_name}<br>Upcharge: <input name="siding[${siding.category_id}]" type="number" value="${siding.price}"><br>`;
						}
						building_price_form = {
							msg: `<form id="adminBuildingSizePricesForm"><input type="hidden" name="product_id" value="${result.building_size_data.product_id}"><input type="hidden" name="series_code" value="${result.building_size_data.series_code}"><h2>${result.building_size_data.width_display}x${result.building_size_data.length_display} ${result.building_size_data.building_display_name}</h2>Product ID:${result.building_size_data.linked_product_id}<br><b>Base Building Price</b> - includes<br>${base_siding_display_name}<br><input name="price" type="number" value="${result.building_size_data.price}"><br>${siding_price_entry}<button type="button" class="button" onclick="AdminUtilities.ProcessForm('adminBuildingSizePricesForm')">Save</button></form>`
						};
					} else {
						building_price_form = {
							msg: `<form id="adminBuildingSizePricesForm"><input type="hidden" name="product_id" value="${result.building_size_data.product_id}"><input type="hidden" name="series_code" value="${result.building_data.series_code}"><h2>${result.building_size_data.width_display}x${result.building_size_data.length_display} ${result.building_size_data.building_display_name}</h2>Product ID:${result.building_size_data.linked_product_id}<br><b>Base Building Price</b> - includes<br>${base_siding_display_name}<br><input name="price" type="number" value="${result.building_size_data.price}"><br><button type="button" class="button" onclick="AdminUtilities.ProcessForm('adminBuildingSizePricesForm')">Save</button></form>`
						};
					}
					GuiDataUtilities.Alert(building_price_form);
					break;
				}
				case "door":
				case "window":
				case "option":
				case "shelve":
				case "element": {
					let [err, element_data] = await to(NodeJSUtilities.UQuery("adminDataRequest", {
						request: "getElementPricing",
						...data
					}));
					if (err) {
						// TODO: Report error to user
						return;
					}
					let element_price_form = {
						msg: `<form id="adminElementPriceForm"><input type="hidden" name="objectType" value="${data.objectType}"><input type="hidden" name="elem_id" value="${element_data.elem_id}"><input type="hidden" name="series_code" value="${element_data.series_code}"><h2>${element_data.element_name}</h2>Product ID:${element_data.linked_product_id}<br>Price<br><input name="price" type="number" value="${element_data.price}"><br>Price Type<br><select name="options"><option value="">Fixed Price</option><option value="pricePerSqFt"${nestedObj(element_data,"options.pricePerSqFt") ? " SELECTED":""}>Per SqFt of Building</option><option value="priceByParameterFt"${nestedObj(element_data,"options.priceByParameterFt") ? " SELECTED":""}>Per Param Ft of Building</option><option value="priceByWidth"${nestedObj(element_data,"options.priceByWidth") ? " SELECTED":""}>Per Ft of Width of Building</option><option value="priceByLength"${nestedObj(element_data,"options.priceByLength") ? " SELECTED":""}>Per Ft of Length of Building</option></select><br>Price Adjustment <span title="Used to add or subtract a fixed amount from a calculated price."><i class="fas fa-question-circle"></i></span><br><input type="number" name="priceAddOn" value=${nestedObj(element_data,"options.priceAddOn") ? element_data.options.priceAddOn:0}><br><button type="button" class="button" onclick="AdminUtilities.ProcessForm('adminElementPriceForm')">Save</button></form>`
					};
					GuiDataUtilities.Alert(element_price_form);
					break;
				}
			}
			break;
		}
		case "edit_style": {
			data.building_id = data.elem_id;
			let [err, result] = await to(NodeJSUtilities.UQuery("adminDataRequest",{request: "getStyleData", ...data}));
			if (err) {
				return;
			}
			//let tableData = [];
			AdminUtilities.currentSizeList = {
				elem_id_map: "product_id"
			};
			AdminUtilities.currentSizeList.data = [];
			for (building of result.building_sizes) {
				let sort = building.width_display.length < 2 ? "0" + building.width_display:building.width_display;
				sort = building.length_display.length < 2 ? sort + "0" + building.length_display:sort + building.length_display;
				//tableData.push([`<span class="admin-sort">${sort}</span>${building.width_display}x${building.length_display}`,building.linked_product_id, building.active ? `<i class="fas fa-toggle-on admin_item_active" onclick="AdminUtilities.Action('activate_product',{category: 'buildingsize',product_id:'{${building.product_id}}',series:'${building.series_code}'});"></i>`:`<i class="fas fa-toggle-off admin_item_inactive" onclick="AdminUtilities.Action('deactivate_product',{category: 'buildingsize',product_id:'{${building.product_id}}',series:'${building.series_code}'});"></i>`,building.admin_only ? `<i class="fas fa-toggle-on admin_only_active" onclick="AdminUtilities.Action('unset_admin_only',{category: 'buildingsize',product_id:'{${building.product_id}}',series:'${building.series_code}'});"></i>`:`<i class="fas fa-toggle-off" onclick="AdminUtilities.Action('set_admin_only',{category: 'buildingsize',product_id:'{${building.product_id}}',series:'${building.series_code}'});"></i>`,building.building_display_name, building.price,""]);
				AdminUtilities.currentSizeList.data.push({
					building_size: `<span class="admin-sort">${sort}</span>${building.width_display}x${building.length_display}`,
					linked_product_id: building.linked_product_id,
					series_code: building.series_code,
					building_id: building.building_id,
					product_id: building.product_id,
					active: building.active,
					active_display: function () { return this.active ? `<i class="fas fa-toggle-on admin_item_active" onclick="AdminUtilities.Action('deactivate_product',{category: 'buildingsize',building_id: '${this.building_id}',product_id:'${this.product_id}',series:'${this.series_code}'});"></i>`:`<i class="fas fa-toggle-off admin_item_inactive" onclick="AdminUtilities.Action('activate_product',{category: 'buildingsize',building_id: '${this.building_id}',product_id:'${this.product_id}',series:'${this.series_code}'});"></i>`;},
					admin_only: building.admin_only,
					admin_only_display: function () { return this.admin_only ? `<i class="fas fa-toggle-on admin_only_active" onclick="AdminUtilities.Action('unset_admin_only_product',{category: 'buildingsize',building_id: '${this.building_id}',product_id:'${this.product_id}',series:'${this.series_code}'});"></i>`:`<i class="fas fa-toggle-off" onclick="AdminUtilities.Action('set_admin_only_product',{category: 'buildingsize',building_id: '${this.building_id}',product_id:'${this.product_id}',series:'${this.series_code}'});"></i>`;},
					display_name: building.building_display_name,
					price: building.price,
					edit_display: function () {return AdminUtilities.IsAuthorized(["sadmin","edit_prices"]) ? `<i class="fas fa-dollar-sign clickable" title="Edit Pricing" style="float: right; margin-right: 15px; font-size: 24px; color: green;" onclick="AdminUtilities.Action('edit_price',{objectType: 'building',product_id: '${this.product_id}',series_code:'${this.series_code}'});"></i>`:"";}
				});
			}
			let tableConfig = {
				data: AdminUtilities.currentSizeList.data,
				responsive: true,
				scrollY: "calc(70vh - 125px)",
				scrollCollapse: true,
				paging: false,
				order: [[0, "asc"]],
				columns: [
					{ title: "Width x Length", data: "building_size"},
					{ title: "Product ID", data: "linked_product_id"},
					{ title: "Active", data: "active_display"},
					{ title: "Admin Only", data: "admin_only_display"},
					{ title: "Display Name", data: "display_name"},
					{ title: "Price", data: "price"},
					{ title: "", data: "edit_display"}
				]
			}
			let info_box = {
				msg: `<div><h4>${data.series_code} ${result.building_data.display_name}<span class="add_btn clickable"><i class="fas fa-plus-circle" title="Add size" onclick="AdminUtilities.Action('add_size',{building_id: '${data.building_id}', series_code: '${data.series_code}'});"></i></span></h4></div><table id="${data.building_id}_sizes"></table>`,
				datatable: {id: `${data.building_id}_sizes`, config: tableConfig},
				onclose: AdminUtilities.setParentData
			};
			GuiDataUtilities.Alert(info_box);
			break;
		}
		case "edit_door": {
			break;
		}
		case "edit_window": {
			break;
		}
		case "edit_option": {
			break;
		}
		case "edit_shelve": {
			break;
		}
		case "add_size": {
			break;
		}
		case "display_user": {
			[err, result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "get_user_record", userid: data.userid}));
			if (err) {
				GuiDataUtilities.Alert(`<h2>Error retrieving data</h2><p>There was an error trying to retrieve the users data from the server. Please check your internet connection and try again later. If the error persists, please contact support.`);
				return;
			}
			user = result[0];
			let edit = AdminUtilities.IsAuthorized(["sadmin","edit_user"]);
			let editLink = `<i class="fas fa-edit clickable" title="Edit User" style="float: right; margin-right: 15px; font-size: 24px; color: green;" onclick="AdminUtilities.Action('edit_user',{userid: '${data.userid}'});"></i>`;
			GuiDataUtilities.Alert(`${edit ? editLink:""}<b>Retail Location: ${user.location_number}</b><br>${user.firstname} ${user.lastname}<br>${user.address ? user.address:"Address not entered."}<br>${user.city ? user.city:""}, ${user.state ? user.state:""}  ${user.zip}<br><br><b>Telephone:</b> ${user.phone1 ? user.phone1:""}<br><b>Email:</b> ${user.email}<br><b>User Type:</b> ${user.usertype}<br>`);
			break;
		}
		case "edit_user": {
			if (!AdminUtilities.Flags.editUserFormLoaded) {
				let err, result;
				[err,result] = await to(NodeJSUtilities.UQuery("dataRequest",{request: "getPopup", type: "form", state: "edit", file:"edituser_form.ejs"}));
				if (err) {
					return;
				}
				AdminUtilities.Flags.editUserFormLoaded = true;
				$('body').append(result.html);
				$("#EditUserModal").foundation();
				initForms();
			}

			[err, result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "get_user_record", userid: data.userid}));
			if (err) {
				GuiDataUtilities.Alert(`<h2>Error retrieving data</h2><p>There was an error trying to retrieve the users data from the server. Please check your internet connection and try again later. If the error persists, please contact support.`);
				return;
			}
			user = result[0];
			let form = $("#adminEditUserForm")[0];
			AuxUtilities.SetFormValues(form,user);
			$('.flinput').prev('label').addClass("show");
			$('#edituser_postalcode').prev('label').html("Zip code: " + user.city + ", " + user.state);
			$(`#edituserusertype option[value='${user.usertype}']`).prop('selected',true);
			UserDataUtilities.AutoFillCheckPostalCode($("#edituserpostalcode")[0]);
			$("#EditUserModal").foundation("open");
			break;
		}
		case "activate_product": {
			data.proceed = true;
			if (data && data.proceed) {
				if (AdminUtilities.Flags.activating_product) {
					return;
				}
				AdminUtilities.Flags.activating_product = true;
				console.log(data);
				let [err,result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "activate_product", category: data.category,product_id: data.product_id, series: data.series}));
				if (err) {
					console.log("err:",err);
					AdminUtilities.Flags.activating_product = false;
					GuiDataUtilities.Alert("Error attempting to activate product.");
					return;
				}
				if (result.success) {
					if (data.category === "buildingsize") {
						AdminUtilities.currentSizeList.data.find(obj => obj.product_id == data.product_id).active = 1;
						$(`#${data.building_id}_sizes`).DataTable().rows().invalidate();
					} else if (data.category === "series") {
						AdminUtilities.currentElementList.data.find(obj => obj.series_code == data.series).active = 1;
						$(`#tbl_series_list`).DataTable().rows().invalidate();
					} else {
						AdminUtilities.currentElementList.data.find(obj => obj.series_code == data.series && obj[AdminUtilities.currentElementList.elem_id_map] == data.product_id).active = 1;
						//AdminUtilities.ElementList(AdminUtilities.currentElementList);
						AdminUtilities.currentElementTableData[data.series].find(obj => obj.product_id == data.product_id).active = 1;
						$(`#tbl_${data.category}_series_${data.series}`).DataTable().rows().invalidate();
					}

				}
				AdminUtilities.Flags.activating_product = false;
			}
			break;
		}
		case "deactivate_product": {
			data.proceed = true;
			if (data && data.proceed) {
				if (AdminUtilities.Flags.deactivating_product) {
					return;
				}
				AdminUtilities.Flags.deactivating_product = true;
				console.log(data);
				let [err,result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "deactivate_product", category: data.category,product_id: data.product_id, series: data.series}));
				if (err) {
					console.log("err:",err);
					AdminUtilities.Flags.deactivating_product = false;
					GuiDataUtilities.Alert("Error attempting to de-activate product.");
					return;
				}
				if (result.success) {
					if (data.category === "buildingsize") {
						AdminUtilities.currentSizeList.data.find(obj => obj.product_id == data.product_id).active = 0;
						$(`#${data.building_id}_sizes`).DataTable().rows().invalidate();
					} else if (data.category === "series") {
						AdminUtilities.currentElementList.data.find(obj => obj.series_code == data.series).active = 0;
						$(`#tbl_series_list`).DataTable().rows().invalidate();
					} else {
						AdminUtilities.currentElementList.data.find(obj => obj.series_code == data.series && obj[AdminUtilities.currentElementList.elem_id_map] == data.product_id).active = 0;
						//AdminUtilities.ElementList(AdminUtilities.currentElementList);
						AdminUtilities.currentElementTableData[data.series].find(obj => obj.product_id == data.product_id).active = 0;
						$(`#tbl_${data.category}_series_${data.series}`).DataTable().rows().invalidate();
					}
				}
				AdminUtilities.Flags.deactivating_product = false;
			}
			break;
		}
		case "set_admin_only_product": {
			data.proceed = true;
			if (data && data.proceed) {
				if (AdminUtilities.Flags.set_product_admin_only) {
					return;
				}
				AdminUtilities.Flags.set_product_admin_only = true;
				console.log(data);
				let [err,result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "set_product_admin_only", category: data.category,product_id: data.product_id, series: data.series}));
				if (err) {
					console.log("err:",err);
					AdminUtilities.Flags.set_product_admin_only = false;
					GuiDataUtilities.Alert("Error attempting to set admin only.");
					return;
				}
				if (result.success) {
					if (data.category === "buildingsize") {
						AdminUtilities.currentSizeList.data.find(obj => obj.product_id == data.product_id).admin_only = 1;
						$(`#${data.building_id}_sizes`).DataTable().rows().invalidate();
					} else if (data.category === "series") {
						AdminUtilities.currentElementList.data.find(obj => obj.series_code == data.series).admin_only = 1;
						$(`#tbl_series_list`).DataTable().rows().invalidate();
					} else {
						AdminUtilities.currentElementList.data.find(obj => obj.series_code == data.series && obj[AdminUtilities.currentElementList.elem_id_map] == data.product_id).admin_only = 1;
						//AdminUtilities.ElementList(AdminUtilities.currentElementList);
						AdminUtilities.currentElementTableData[data.series].find(obj => obj.product_id == data.product_id).admin_only = 1;
						$(`#tbl_${data.category}_series_${data.series}`).DataTable().rows().invalidate();
					}
				}
				AdminUtilities.Flags.set_product_admin_only = false;
			}
			break;
		}
		case "unset_admin_only_product": {
			data.proceed = true;
			if (data && data.proceed) {
				if (AdminUtilities.Flags.unset_product_admin_only) {
					return;
				}
				AdminUtilities.Flags.set_product_admin_only = true;
				console.log(data);
				let [err,result] = await to(NodeJSUtilities.UQuery("adminAction",{request: "unset_product_admin_only", category: data.category,product_id: data.product_id, series: data.series}));
				if (err) {
					console.log("err:",err);
					AdminUtilities.Flags.set_product_admin_only = false;
					GuiDataUtilities.Alert("Error attempting to unset admin only.");
					return;
				}
				if (result.success) {
					if (data.category === "buildingsize") {
						AdminUtilities.currentSizeList.data.find(obj => obj.product_id == data.product_id).admin_only = 0;
						$(`#${data.building_id}_sizes`).DataTable().rows().invalidate();
					} else if (data.category === "series") {
						AdminUtilities.currentElementList.data.find(obj => obj.series_code == data.series).admin_only = 0;
						$(`#tbl_series_list`).DataTable().rows().invalidate();
					} else {
						AdminUtilities.currentElementList.data.find(obj => obj.series_code == data.series && obj[AdminUtilities.currentElementList.elem_id_map] == data.product_id).admin_only = 0;
						//AdminUtilities.ElementList(AdminUtilities.currentElementList);
						AdminUtilities.currentElementTableData[data.series].find(obj => obj.product_id == data.product_id).admin_only = 0;
						$(`#tbl_${data.category}_series_${data.series}`).DataTable().rows().invalidate();
					}
				}
				AdminUtilities.Flags.set_product_admin_only = false;
			}
			break;
		}
		case "display_sub_online_users": {
			//AdminUtilities.sessions[data.subscriber_id]
			let userList = "<table><tr><th>Session ID</th><th>Process ID</th><th>ip</th><th>Zip</th><th>userid</th></tr>";
			let keys = Object.keys(AdminUtilities.sessions[data.subscriber_id]);
			for (let i = 0;i < keys.length;i++) {
				userList += `<tr><td>${keys[i]}</td><td>${AdminUtilities.sessions[data.subscriber_id][keys[i]].processID}</td><td>${AdminUtilities.sessions[data.subscriber_id][keys[i]].ip}</td><td>${AdminUtilities.sessions[data.subscriber_id][keys[i]].postal_code}</td><td>${AdminUtilities.sessions[data.subscriber_id][keys[i]].userid}</td></tr>`;
			}
			userList += "</table>"
			GuiDataUtilities.Alert(userList);
			break;
		}
		case "get_db_design_list": {
			socket.emit("adminActionWorker",{request: "get_db_design_list"},null);
			break;
		}
		case "process_design_list": {
			$("#admin-designsave").append(`<br>Saving <span id="DesignSaveStatus"></span>`);
			AdminUtilities.ProcessDesignList = AdminUtilities.saveDesignFiles();
			AdminUtilities.OnAdminActionResponse({request: "save_design", saved: true});
			/*let nextDesign = AdminUtilities.ProcessDesignList.next();
			if (!nextDesign.done) {
				let designdata = await NodeJSUtilities.UQuery("adminAction", {request: "get_design_data", design_id: nextDesign.value.design_id});
				let data_format = designdata.data_format;
				designdata = AdminUtilities.processDesignData(designdata);
				socket.emit("adminActionWorker",{request: "save_design",design_id: nextDesign.value.design_id, designdata: designdata, data_format: data_format});
				$("#DesignSaveStatus").text(nextDesign.value.design_id);
			} else {
				$("#DesignSaveStatus").text("done");
			}*/
			break;
		}
		default: {
			return null;
		}
	}
};

AdminUtilities.processDesignData = function (data) {
	if (data) {
		if (typeof data.data === "string") {
			let str = ("[object Object]");
			if (data.data.indexOf(str) > -1) {
				data.data = data.data.substr(str.length);
			}
		}
		if (!data.data) {
			return data.data;
		}
		if (data.data.substring(0,1) === "%") {
			data.data = LoadingSavingUtilities.DecompressString(data.data);
		}
		let ra = [
			["PLUS_CODE", "PLUS_C@","+"],
			["INVERTED_COMMA_CODE", "I_C_C@",`&quot;`],
			["AMPERSAND_CODE", "A_C@","&amp;"],
			["NEWLINE_CODE", "N_C@", "\n"],
			["LEFT_BRACKET_CODE", "L_B_C@","["],
			["RIGHT_BRACKET_CODE", "R_B_C@","]"]
		];
		let EscapeRegExp = function (str) {
					return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
				};
		let ReplaceAll = function (str, find, replace) {
				let result = str.replace(new RegExp(EscapeRegExp(find), "g"), replace);
				return result;
				};
		if (data.data_format === "XML") {
			for (let i=0;i < ra.length;i++) {
				data.data = ReplaceAll(data.data,ra[i][1],ra[i][2]);
			}
		}
		return data.data;
	}
};

AdminUtilities.saveDesignFiles = function* () {
	for (Design of AdminUtilities.db_design_list) {
		yield Design;
	}
	return;
}

AdminUtilities.createRowData = function(data, format) {
	if (!Array.isArray(data)) {
		data = [data];
	}
	let dataSet = [];
	switch (format) {
		case "locations": {
			for (let row of data) {
				dataSet.push({
					office: {
						sort: row.location_number,
						display: row.active ? `<i class="fas fa-toggle-on admin_item_active" onclick="AdminUtilities.Action('deactivate_location',{location_number: ${row.location_number},name: '${row.name}'});" title="Location Active"></i> ${row.location_number}`:`<i class="fas fa-toggle-off admin_item_inactive" onclick="AdminUtilities.Action('activate_location',{location_number: ${row.location_number},name: '${row.name}'});" title="Location disabled"></i> ${row.location_number}`
					},
					name: `<span class="clickable link" onclick="AdminUtilities.Action('display_location',{location_number: ${row.location_number},name: '${row.name}'});">${row.name}</span>`,
					city: row.city,
					region: row.region,
					tax_percent: row.tax_percent
				});
			}
			return dataSet;
		}
	}
}
AdminUtilities.PopulateLocations = async function() {
	if (AdminUtilities.PopulateLocations.populated) {
		return;
	}
	AdminUtilities.PopulateLocations.populated = true;
	if (AdminUtilities.IsAuthorized(["sadmin","add_location"])) {
		$("#addlocation_btn").html(`<i class="fas fa-plus-circle" title="Add location" onclick="AdminUtilities.AddLocation();"></i>`);
	}
	let dataSet = AdminUtilities.createRowData(SubscriberDataUtilities.locationData,"locations");

	if (!$.fn.DataTable.isDataTable('#locations')) {
		$("#locations").DataTable({
			data: dataSet,
			responsive: true,
			scrollY: "calc(50vh - 125px)",
			scrollCollapse: true,
			paging: false,
			columns: [
				{title: "Office #", data: "office", render: {_:"display",sort:'sort'}},
				{title: "Name", data: "name"},
				{title: "City", data: "city"},
				{title: "State", data: "region"},
				{title: "Tax Rate", data: "tax_percent"}
			]
		});
	} else {
		$("#locations").DataTable().clear().rows.add(dataSet).draw();
	}
}

AdminUtilities.PopulateInfo = async function() {
	if (typeof tdf.server_version === "undefined") {
		tdf.server_version = tdf_version;
	}
	$("#infobox-serverversion .infobox-number").text(tdf.server_version);
	if (tdf_version === tdf.server_version) {
		$("#infobox-clientversion .infobox-number").text(tdf_version);
	} else {
		$("#infobox-clientversion .infobox-number").html(`<i class="fas fa-arrow-alt-circle-up" style="color:red;" title="Update Available"></i> ${tdf_version}`);
	}
	$("#infobox-activetickets .infobox-number").text("0");
	$("#infobox-closedtickets .infobox-number").text("0");
	$("#infobox-totaltickets .infobox-number").text("0");

	NodeJSUtilities.UQuery("adminDataRequest",{request: "getLast10Updates"}, null, function(data) {
		if ($("#updates").length === 0) {
			$("#admin-info").append(`<h4>Last 10 Updates</h4><table id="updates"></table>`);
		}
		let dataSet = [];
		let dateOptions = {
			weekday: "long", year: "numeric", month: "short",
			day: "numeric"
		};

		for (updates of data) {
			let update_date = new Date(updates.date).toLocaleDateString("en-us", dateOptions);
			update_date = `<span class="admin-sort">${updates.date}</span>${update_date}`;
			dataSet.push([updates.version, update_date, updates.description]);
		}
		if (!$.fn.DataTable.isDataTable('#updates')) {
			$("#updates").DataTable({
						data: dataSet,
						responsive: true,
						scrollY: "calc(50vh - 125px)",
						scrollCollapse: true,
						paging: false,
						order: [[1, "desc"]],
						columns: [
							{ title: "Version"},
							{ title: "Date"},
							{ title: "Details"}
						]
					});
		} else {
			$("#updates").DataTable().clear().rows.add(dataSet).draw();
		}
	});
}

AdminUtilities.PopulateStaff = async function() {
	NodeJSUtilities.UQuery("adminDataRequest",{request:"getStaff"}, null, function(data) {
		$("#admin-staff").html(`<h4>Staff List</h4><table id="stafflist"></table>`);
		let dataSet = [];
		let dateOptions = {
			weekday: "long", year: "numeric", month: "short",
			day: "numeric", hour: "2-digit", minute: "2-digit"
		};

		let usericons = {
			driver: `<i class="fas fa-user-clock" title="Driver"></i><span class="admin-sort">1</span>`,
			staff: `<i class="fas fa-user" title="Staff"></i><span class="admin-sort">2</span>`,
			admin: `<i class="fas fa-user-tie" title="Office Admin"></i><span class="admin-sort">3</span>`,
			sadmin: `<i class="fas fa-user-cog" title="Company Admin"></i><span class="admin-sort">4</span>`,
			master: `<i class="fas fa-user-shield" title="System Admin"></i><span class="admin-sort">5</span>`


		}
		for (staff of data) {
			let last_access = new Date(staff.last_access).toLocaleTimeString("en-us", dateOptions);
			dataSet.push({
				user_icon: usericons[staff.usertype],
				userid_display: staff.with_prefix ? staff.userid.substring(staff.userid.indexOf("_")+1):staff.userid,
				location_number: staff.location_number,
				user_name: `<span class="clickable link" onclick="AdminUtilities.Action('display_user',{userid: '${staff.userid}'});">${staff.firstname} ${staff.lastname}</span>`,
				last_access_display: `<span class="admin-sort">${staff.last_access}</span>${last_access}`
			});
		}
		$("#stafflist").DataTable({
			data: dataSet,
			responsive: true,
			scrollY: "calc(50vh - 125px)",
			scrollCollapse: true,
			paging: false,
			columns: [
				{ title: "", data: "user_icon"},
				{ title: "UserID", data: "userid_display"},
				{ title: "Office", data: "location_number"},
				{ title: "Name", data: "user_name"},
				{ title: "Last Seen", data: "last_access_display"}
			]
		});
	});
}

AdminUtilities.PopulateUsersList = async function () {
	NodeJSUtilities.UQuery("adminDataRequest",{request: "getUsers"}, null, function (data) {
		$("#admin-users").html(`<h4>User List</h4><table id="userlist"></table>`);
		let dataSet = [];
		let dateOptions = {
			weekday: "long",
			year: "numeric",
			month: "short",
			day: "numeric",
			hour: "2-digit",
			minute: "2-digit"
		};

		for (user of data) {
			let last_access = new Date(user.last_access).toLocaleTimeString("en-us", dateOptions);
			dataSet.push({
				location_number:user.location_number,
				userid_display: user.with_prefix ? user.userid.substring(user.userid.indexOf("_") + 1) : user.userid,
				user_name: `<span class="clickable link" onclick="AdminUtilities.Action('display_user',{userid: '${user.userid}'});">${user.firstname} ${user.lastname}</span>`,
				email: user.email,
				zipcode: user.zip,
				last_access_display: `<span class="admin-sort">${user.last_access}</span>${last_access}`
			});
		}
		$("#userlist").DataTable({
			data: dataSet,
			responsive: true,
			scrollY: "calc(50vh - 125px)",
			scrollCollapse: true,
			paging: false,
			order: [[4, "desc"]],
			columns: [
				{ title: "Office", data: "location_number" },
				{ title: "UserID", data: "userid_display" },
				{ title: "Name", data: "user_name" },
				{ title: "EMail", data: "email" },
				{ title: "Zipcode", data: "zipcode" },
				{ title: "Last Seen", data: "last_access_display" }
			]
		});
	});
}

AdminUtilities.PopulateDesignsList = async function () {
	NodeJSUtilities.UQuery("adminDataRequest",{request: "getDesignsList"}, null, function (data) {
		$("#admin-designs").html(`<h4>Designs List</h4><table id="designslist"></table>`);
		let dataSet = [];
		let dateOptions = {
			weekday: "long",
			year: "numeric",
			month: "short",
			day: "numeric",
			hour: "2-digit",
			minute: "2-digit"
		};

		for (design of data) {
			let create_date = new Date(design.create_date).toLocaleDateString("en-us", dateOptions);
			let design_id = design.design_id.indexOf(SubscriberDataUtilities.design_prefix + "_") === -1 ? design.design_id:design.design_id.substring(design.design_id.indexOf("_")+1);
			let design_link = `<span class="clickable link" onclick="AdminUtilities.Action('load_design',{design_id: '${design.design_id}', series_code: '${design.series_code}', in_file_bucket: ${design.in_file_bucket}});">`;
			let userid = design.userid.indexOf(SubscriberDataUtilities.design_prefix + "_") === -1 ? design.userid:design.userid.substring(design.userid.indexOf("_")+1);
			let product = design.data ? (design.data.data ? ( design.data.data.building_name ? `${design.data.data.building_width}x${design.data.data.building_length} ${design.data.data.building_name}`:"") : "") : "";
			let value = design.data ? (design.data.data ? ( design.data.data.building_price_subtotal ? design.data.data.building_price_subtotal:"") : "") : "";
			value = value === "0.00" ? "":value;
			dataSet.push([design.location_number,`${design_link}${design_id}</span>`,product,value,userid,design.shed_name,`<span class="admin-sort">${design.create_date}</span>${create_date}`]);
		}
		$("#designslist").DataTable({
			data: dataSet,
			responsive: true,
			scrollY: "calc(50vh - 125px)",
			scrollCollapse: true,
			paging: false,
			order: [[6, "desc"]],
			columns: [
				{ title: "Office"},
				{ title: "Design ID" },
				{ title: "Product" },
				{ title: "Value"},
				{ title: "User ID"},
				{ title: "Save Description" },
				{ title: "Created On" }
			]
		});
	});
};

AdminUtilities.PopulateOrdersList = async function () {
	NodeJSUtilities.UQuery("adminDataRequest",{request: "getOrdersList"}, null, function (data) {
		$("#admin-orders").html(`<h4>Orders List</h4><table id="orderslist"></table>`);
		let dataSet = [];
		let dateOptions = {
			weekday: "long",
			year: "numeric",
			month: "short",
			day: "numeric",
			hour: "2-digit",
			minute: "2-digit"
		};
		for (order of data) {
			let name = order.data.first_name + " " + order.data.last_name;
			let contact_time = new Date(order.contact_time).toLocaleDateString("en-us", dateOptions);
			if (order.user_id === null) {
				order.user_id = "";
			}
			let user_id = order.user_id.indexOf(SubscriberDataUtilities.design_prefix + "_") === -1 ? order.user_id:order.user_id.substring(order.user_id.indexOf("_")+1);
			let value = order.data.subTotal ? order.data.subTotal : "";
			let shortDescription = order.data.shortDescription ? order.data.shortDescription : "See saved design";
			let product = `<span class="clickable link" onclick="AdminUtilities.Action('display_order',{id: ${order.id}});">${shortDescription}</span>`;
			dataSet.push([order.location_number,product,value,user_id,name,`<span class="admin-sort">${order.contact_time}</span>${contact_time}`,order.data.delivery_zipcode]);
		}
		$("#orderslist").DataTable({
			data: dataSet,
			responsive: true,
			scrollY: "calc(50vh - 125px)",
			scrollCollapse: true,
			paging: false,
			order: [[5, "desc"]],
			columns: [
				{ title: "Office"},
				{ title: "Product"},
				{ title: "Value"},
				{ title: "User ID" },
				{ title: "Name"},
				{ title: "Order Date" },
				{ title: "Zipcode"}
			]
		});
	});
};

AdminUtilities.PopulateRequestsList = async function () {
	NodeJSUtilities.UQuery("adminDataRequest",{request: "getContactRequestsList"}, null, function (data) {
		$("#admin-requests").html(`<h4>Request List</h4><table id="requestslist"></table>`);
		let dataSet = [];
		let dateOptions = {
			weekday: "long",
			year: "numeric",
			month: "short",
			day: "numeric",
			hour: "2-digit",
			minute: "2-digit"
		};
		for (request of data) {
			let location_number = request.location_number;
			let link = `<span class="clickable link" onclick="AdminUtilities.Action('display_request',{id: ${request.id}})">`;
			let name = `${link}${request.data.first_name} ${request.data.last_name}</span>`;
			let contact_time = new Date(request.contact_time).toLocaleDateString("en-us", dateOptions);
			if (request.user_id === null) {
				request.user_id = "";
			}
			let user_id = request.user_id.indexOf(SubscriberDataUtilities.design_prefix + "_") === -1 ? request.user_id:request.user_id.substring(request.user_id.indexOf("_")+1);
			let text = `${link}${request.data.request.length > 40 ? request.data.request.substr(0,40) + "...":request.data.request}</span>`;
			dataSet.push([location_number,name,`<span class="admin-sort">${request.contact_time}</span>${contact_time}`,request.data.zipcode,text]);
		}
		$("#requestslist").DataTable({
			data: dataSet,
			responsive: true,
			scrollY: "calc(50vh - 125px)",
			scrollCollapse: true,
			paging: false,
			order: [[2, "desc"]],
			columns: [
				{ title: "Office"},
				{ title: "Name"},
				{ title: "Request Date" },
				{ title: "Zipcode", "max-wdith": "40em"},
				{ title: "Request"}
			]
		});
	});
};

AdminUtilities.Resize = async function() {
	await AuxUtilities.sleep(200);
	window.dispatchEvent(new Event('resize'));
}

AdminUtilities.ElementList = async function(params) {
	let button_title = params.button_title ? params.button_title:"Element";
	let elem_type = params.elem_type;
	let btn_dir = params.btn_dir;
	let sub_dir = params.sub_dir ? params.sub_dir:false;
	params.sub_dir = false;
	let suffix = params.suffix ? params.suffix:"";
	let elem_id_map = params.elem_id_map ? params.elem_id_map:"elem_id";
	params.elem_id_map = elem_id_map;
	let display_name_map = params.display_name_map ? params.display_name_map:"";
	let price = params.price ? params.price:false;
	let edit = params.edit ? params.edit:false;
	let data = params.data;
	let series = [];
	let series_data = AdminUtilities.currentElementTableData;
	if (!params.update) {
		$(`#admin-${elem_type}${suffix}`).html(`<ul class="tabs" data-tabs id="${elem_type}_series_tabs"></ul><div id="${elem_type}_series_content" class="tabs-content" data-tabs-content="${elem_type}_series_tabs"></div>`);
	}
	for (elem of data) {
		if (!elem.category) {
		if (elem_id_map) {
			elem.elem_id = elem[elem_id_map];
		}
		if (display_name_map) {
			elem.display_name = elem[display_name_map];
		} else {
			elem.display_name = elem.display_name ? elem.display_name:elem.element_name;
		}
		if (!elem.price) {
			elem.price = 0;
		}
		if (!series.includes(elem.series_code)) {
			series.push(elem.series_code);
			if (!params.update) {
				$(`#${elem_type}_series_tabs`).append(`<li class="tabs-title" id="${elem_type}_tt_${elem.series_code}" onclick="AdminUtilities.Resize();"><a href="#${elem_type}_${elem.series_code}" data-tabs-target="${elem_type}_${elem.series_code}">${elem.series_code}</a></li>`);
			}
			series_data[elem.series_code] = [];
		}
		elem.button_file = elem.override_button_file || elem.button_file;
		if (sub_dir) {
			elem.button_file = elem.belongs_to_category ? elem.belongs_to_category.toLowerCase() + "/" + elem.button_file : elem.button_file;
		}
		series_data[elem.series_code].push({
			product_id: elem.elem_id,
			product_type: elem_type,
			series_code: elem.series_code,
			button:`<img class="objbuttonimg" src="${RESOURCE_HOST}resources/buttons/${btn_dir}${elem.button_file}">`,
			display_name: `${elem.display_name}`,
			active: elem.active,
			active_display: function () { return this.active ? `<i class="fas fa-toggle-on admin_item_active clickable" onclick="AdminUtilities.Action('deactivate_product',{category: '${this.product_type}', product_id: '${this.product_id}',series: '${this.series_code}'});"></i>`:`<i class="fas fa-toggle-off admin_item_inactive clickable" onclick="AdminUtilities.Action('activate_product',{category: '${this.product_type}', product_id: '${this.product_id}',series: '${this.series_code}'});"></i>`;},
			admin_only: elem.admin_only,
			admin_only_display: function() { return this.admin_only ? `<i class="fas fa-toggle-on admin_only_active clickable" onclick="AdminUtilities.Action('unset_admin_only_product',{category: '${this.product_type}', product_id: '${this.product_id}',series: '${this.series_code}'});"></i>`:`<i class="fas fa-toggle-off clickable" onclick="AdminUtilities.Action('set_admin_only_product',{category: '${this.product_type}', product_id: '${this.product_id}',series: '${this.series_code}'});"></i>`;},
			display_order: `${elem.display_order}`,
			price: elem.price,
			edit_display: function () {let edit_button = AdminUtilities.IsAuthorized(["sadmin","edit_element_options"]) && edit ? `<i class="fas fa-edit clickable" title="Edit Options" onclick="AdminUtilities.Action('edit_${this.product_type}',{elem_id: '${this.product_id}', series_code: '${this.series_code}'});"></i>`:"";return AdminUtilities.IsAuthorized(["sadmin","edit_prices"]) && price ? `<i class="fas fa-dollar-sign clickable" title="Edit Pricing" style="margin-right: 15px; color: green;" onclick="AdminUtilities.Action('edit_price',{objectType: '${this.product_type}',elem_id: '${this.product_id}',series_code:'${this.series_code}'});"></i>`+edit_button:edit_button;}
		});
	}
	}
	if (DEBUG) { console.log(series_data); }
	for (elems of Object.entries(series_data)) {
		if (params.update) {
			let table = $(`#tbl_${elem_type}_series_${elems[0]}`).DataTable();
			table.clear();
			table.rows.add(elems[1])
			table.draw();
		} else {
			$(`#${elem_type}_series_content`).append(`<div class="tabs-panel" id="${elem_type}_${elems[0]}"><table id="tbl_${elem_type}_series_${elems[0]}"></table></div>`);
			$(`#tbl_${elem_type}_series_${elems[0]}`).DataTable({
				data: elems[1],
				responsive: true,
				scrollY: "calc(70vh - 125px)",
				scrollCollapse: true,
				paging: false,
				order: [[2, "asc"]],
				columns: [
					{ title: button_title, data: "button"},
					{ title: "Display Name", data: "display_name"},
					{ title: "Active", data: "active_display"},
					{ title: "Admin Only", data: "admin_only_display"},
					{ title: "Display Order", data: "display_order"},
					{ title: "Price", visible: price, data: "price"},
					{ title: "", data:"edit_display"}
				]
			});
		}
	}
	$(`#admin-${elem_type}${suffix}`).foundation();
	$(`#${elem_type}_${series[0]}`).addClass("is-active");
	$(`#${elem_type}_tt_${series[0]}`).addClass("is-active");
	AdminUtilities.Resize();
	params.update = true;
	if3CloseLeftMenu();
}

AdminUtilities.PopulatePanel = async function(panel) {
	switch (panel) {
		case "admin-series": {
			NodeJSUtilities.UQuery("adminDataRequest", {request: "getSeries"}, null, function (data) {
				$("#admin-series").html(`<div id="admin_series_list"><table id="tbl_series_list"></table></div>`);
				let table_data = [];
				for (series of data) {
					table_data.push({
						series_code: series.series_code,
						display_name: series.display_name,
						active: series.active,
						active_display: function () { return this.active ? `<i class="fas fa-toggle-on admin_item_active clickable" onclick="AdminUtilities.Action('deactivate_product',{category: 'series', product_id: '${this.series_code}',series: '${this.series_code}'});"></i>`:`<i class="fas fa-toggle-off admin_item_inactive clickable" onclick="AdminUtilities.Action('activate_product',{category: 'series', product_id: '${this.series_code}',series: '${this.series_code}'});"></i>`;},
						admin_only: series.admin_only,
						admin_only_display: function () { return this.admin_only ? `<i class="fas fa-toggle-on admin_only_active clickable" onclick="AdminUtilities.Action('unset_admin_only_product',{category: 'series', product_id: '${this.series_code}',series: '${this.series_code}'});"></i>`:`<i class="fas fa-toggle-off clickable" onclick="AdminUtilities.Action('set_admin_only_product',{category: 'series', product_id: '${this.series_code}',series: '${this.series_code}'});"></i>`;},
						edit: `<i class="fas fa-edit clickable" onclick="AdminUtilities.Action('edit_series',{series_code: '${series.series_code}'});"></i>`
					});
				}
				AdminUtilities.currentElementList = {
					data: table_data
				};
				$(`#tbl_series_list`).DataTable({
					data: table_data,
					responsive: true,
					scrollY: "calc(70vh - 125px)",
					scrollCollapse: true,
					paging: false,
					order: [[2, "asc"]],
					columns: [
						{ title: "Series Code", data: "series_code"},
						{ title: "Display Name", data: "display_name"},
						{ title: "Active", data: "active_display"},
						{ title: "Admin Only", data: "admin_only_display"},
						{ title: "", data: "edit"}
					]
				});
				/*$("#admin-series").foundation();
				$(`#building_${series[0]}`).addClass("is-active");
				$(`#building_tt_${series[0]}`).addClass("is-active");
				AdminUtilities.Resize();*/
				if3CloseLeftMenu();
			});
			break;
		}
		case "admin-buildings": {
			NodeJSUtilities.UQuery("adminDataRequest", {request: "getBuildings"}, null, function (data) {
				AdminUtilities.currentElementList = {
					button_title: "Building",
					elem_type: "style",
					btn_dir: "buildings/",
					suffix: "s",
					elem_id_map: "building_id",
					sub_dir: false,
					price: false,
					edit: true,
					data: data
				};
				AdminUtilities.currentElementTableData = [];
				AdminUtilities.ElementList(AdminUtilities.currentElementList);
			});
			break;
		}
		case "admin-doors": {
			NodeJSUtilities.UQuery("adminDataRequest", {request: "getDoors"}, null, function (data) {
				AdminUtilities.currentElementList = {
					button_title: "Doors",
					elem_type: "door",
					btn_dir: "doors/",
					suffix: "s",
					sub_dir: true,
					price: true,
					data: data
				};
				AdminUtilities.currentElementTableData = [];
				AdminUtilities.ElementList(AdminUtilities.currentElementList);
			});
			break;
		}
		case "admin-windows": {
			NodeJSUtilities.UQuery("adminDataRequest", {request: "getWindows"}, null, function (data) {
				AdminUtilities.currentElementList = {
					button_title: "Windows",
					elem_type: "window",
					btn_dir: "windows/",
					suffix: "s",
					sub_dir: false,
					price: true,
					data: data
				};
				AdminUtilities.currentElementTableData = [];
				AdminUtilities.ElementList(AdminUtilities.currentElementList);
			});
			break;
		}
		case "admin-options": {
			NodeJSUtilities.UQuery("adminDataRequest", {request: "getOptions"}, null, function (data) {
				AdminUtilities.currentElementList = {
					button_title: "Options",
					elem_type: "option",
					btn_dir: "options/",
					suffix: "s",
					sub_dir: false,
					price: true,
					data: data
				};
				AdminUtilities.currentElementTableData = [];
				AdminUtilities.ElementList(AdminUtilities.currentElementList);
			});
			break;
		}
		case "admin-shelves": {
			NodeJSUtilities.UQuery("adminDataRequest", {request: "getShelves"}, null, function (data) {
				AdminUtilities.currentElementList = {
					button_title: "Shelves",
					elem_type: "shelve",
					btn_dir: "shelves/",
					suffix: "s",
					sub_dir: false,
					price: true,
					data: data
				};
				AdminUtilities.currentElementTableData = [];
				AdminUtilities.ElementList(AdminUtilities.currentElementList);
			});
			break;
		}
		case "admin-siding": {
			NodeJSUtilities.UQuery("adminDataRequest", {request: "getSiding"}, null, function (data) {
				AdminUtilities.currentElementList = {
					button_title: "Siding",
					elem_type: "siding",
					btn_dir: "siding/",
					elem_id_map: "category_id",
					display_name_map: "",
					suffix: "",
					sub_dir: false,
					price: false,
					data: data
				};
				AdminUtilities.currentElementTableData = [];
				AdminUtilities.ElementList(AdminUtilities.currentElementList);
			});
			break;
		}
		case "admin-roofing": {
			NodeJSUtilities.UQuery("adminDataRequest", {request: "getRoofing"}, null, function (data) {
				AdminUtilities.currentElementList = {
					button_title: "Roofing",
					elem_type: "roofing",
					btn_dir: "roofing/",
					elem_id_map: "category_id",
					display_name_map: "category_name",
					suffix: "",
					sub_dir: false,
					price: false,
					data: data
				};
				AdminUtilities.currentElementTableData = [];
				AdminUtilities.ElementList(AdminUtilities.currentElementList);
			});
			break;
		}
	}
}

AdminUtilities.DisplayPanel = async function(panel) {
	switch (panel) {
		case "dashboard": {
			$(".admin-panel").hide();
			$("#admin-dashboard").show();
			AdminUtilities.PopulateDash();
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "requests": {
			$(".admin-panel").hide();
			$("#admin-requests").show();
			AdminUtilities.PopulateRequestsList();
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "orders": {
			$(".admin-panel").hide();
			$("#admin-orders").show();
			AdminUtilities.PopulateOrdersList();
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "designs": {
			$(".admin-panel").hide();
			$("#admin-designs").show();
			AdminUtilities.PopulateDesignsList();
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "users": {
			$(".admin-panel").hide();
			$("#admin-users").show();
			AdminUtilities.PopulateUsersList();
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "staff": {
			$(".admin-panel").hide();
			$("#admin-staff").show();
			AdminUtilities.PopulateStaff();
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "locations": {
			$(".admin-panel").hide();
			$("#admin-locations").show();
			AdminUtilities.PopulateLocations();
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "info": {
			$(".admin-panel").hide();
			$("#admin-info").show();
			AdminUtilities.PopulateInfo();
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "settings": {
			$(".admin-panel").hide();
			$("#admin-settings").show();
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "series": {
			$(".admin-panel").hide();
			$("#admin-series").show();
			AdminUtilities.PopulatePanel("admin-series");
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "buildings": {
			$(".admin-panel").hide();
			$("#admin-styles").show();
			AdminUtilities.PopulatePanel("admin-buildings");
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "doors": {
			$(".admin-panel").hide();
			$("#admin-doors").show();
			AdminUtilities.PopulatePanel("admin-doors");
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "windows": {
			$(".admin-panel").hide();
			$("#admin-windows").show();
			AdminUtilities.PopulatePanel("admin-windows");
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "options": {
			$(".admin-panel").hide();
			$("#admin-options").show();
			AdminUtilities.PopulatePanel("admin-options");
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "shelves": {
			$(".admin-panel").hide();
			$("#admin-shelves").show();
			AdminUtilities.PopulatePanel("admin-shelves");
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "siding": {
			$(".admin-panel").hide();
			$("#admin-siding").show();
			AdminUtilities.PopulatePanel("admin-siding");
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "roofing": {
			$(".admin-panel").hide();
			$("#admin-roofing").show();
			AdminUtilities.PopulatePanel("admin-roofing");
			AdminUtilities.CurrentView = panel;
			break;
		}
		case "designsave": {
			$(".admin-panel").hide();
			$("#admin-designsave").show();
			AdminUtilities.CurrentView = panel;
			if3CloseLeftMenu();
			break;
		}
	}
};

AdminUtilities.AdminViewMenuLoaded = false;
AdminUtilities.AdminViewMenuTabsLoaded = false;
AdminUtilities.AdminViewLoaded = false;
AdminUtilities.CurrentView = "";
AdminUtilities.Flags = {};
AdminUtilities.sessions = {};

AdminUtilities.OnConnectUpdate = async function() {
	return;
};

AdminUtilities.OnServerLog = async function(data) {
	return;
};

AdminUtilities.OnUpdate = async function(data) {
	return;
};