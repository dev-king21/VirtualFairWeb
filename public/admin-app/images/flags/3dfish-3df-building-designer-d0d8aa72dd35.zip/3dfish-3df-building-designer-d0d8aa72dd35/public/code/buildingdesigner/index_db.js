// Copyrighted 2014-2018 by 3D Fish, LLC
// All rights reserved.
// Un-authorized reproduction prohibited
// Violators will be prosecuted.
/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2 */
/*eslint-disable no-console, no-unused-vars, no-undef*/

/**
 * Container for IndexedDB Functions
 * @function IndexDB
 */
function IndexDB()
{}

IndexDB.DeleteIndexDB = function()
{
	let delreq = indexedDB.deleteDatabase("TDDesignerDatabase");
	delreq.onsuccess = function ()
	{
		console.log("Deleted database successfully");
	};
	delreq.onerror = function ()
	{
		console.log("Couldn't delete database");
	};
	delreq.onblocked = function ()
	{
		console.log("Couldn't delete database due to the operation being blocked");
	};
}

/**
 * Attempts to initialize the browser indexedDB and then calls the callback function
 * @function IndexDB.InitializeIndexDB
 * @param {Callback} dbInitializedFunction Callback function
 */
IndexDB.InitializeIndexDB = function (dbInitializedFunction)
{
	let indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;

	let IDBTransaction = window.IDBTransaction || window.webkitIDBTransaction || window.msIDBTransaction;
	let IDBKeyRange = window.IDBKeyRange || window.webkitIDBKeyRange || window.msIDBKeyRange;

	if (!indexedDB)
	{
		//alert("IndexedDB not supported by your browser.");
		dbInitializedFunction();
	}

	if (featureData && featureData.interface && featureData.interface.persistent_design_off)
	{
		let delreq = indexedDB.deleteDatabase("TDDesignerDatabase");
		delreq.onsuccess = function ()
		{
			console.log("Deleted database successfully");
		};
		delreq.onerror = function ()
		{
			console.log("Couldn't delete database");
		};
		delreq.onblocked = function ()
		{
			console.log("Couldn't delete database due to the operation being blocked");
		};
		dbInitializedFunction();
		return;
	}
	let request = indexedDB.open("TDDesignerDatabase", 25);

	if (request.readyState == "done" && request.result != undefined && request.result != null)
	{
		IndexDB.indexDB = request.result;

		IndexDB.GetPersistentDesign(dbInitializedFunction);
	}

	request.onerror = function (event)
	{
		console.log("error: ", event);

		IndexDB.GetPersistentDesign(dbInitializedFunction);
	};

	request.onsuccess = function (event)
	{
		IndexDB.indexDB = event.target.result;

		IndexDB.GetPersistentDesign(dbInitializedFunction);
	};

	request.onupgradeneeded = function (event)
	{
		IndexDB.indexDB = event.target.result;

		try
		{
			IndexDB.indexDB.deleteObjectStore("building_designer");
		}
		catch (ex)
		{
			//
		}

		try
		{
			IndexDB.indexDB.deleteObjectStore("buildingdesigner");
		}
		catch (ex)
		{
			//
		}

		try
		{
			IndexDB.indexDB.deleteObjectStore("designs");
		}
		catch (ex)
		{
			//
		}

		try
		{
			IndexDB.indexDB.deleteObjectStore("cached_data");
		}
		catch (ex)
		{
			//
		}


		let objectStore = IndexDB.indexDB.createObjectStore("cached_data", {
			keyPath: "id"
		});

		objectStore.createIndex("local_code_base_version", "local_code_base_version");
		objectStore.createIndex("current_stored_building_design", "current_stored_building_design");

		let tx = event.target.transaction;

		let item = {
			id: "current_designer",
			local_code_base_version: "",
			current_stored_building_design: ""
		};

		let result = objectStore.put(item);

		if (result.readyState == "done")
		{
			console.log("successfully initialized new browser storage db.");
		}

		tx.oncomplete = function (e)
		{
			console.log("successfully initialized new browser storage db.");
		};

		tx.onerror = function (e)
		{
			console.log("unsuccessfully initialized new browser storage db.");
		};

		tx.onabort = function (e)
		{
			console.log("unsuccessfully initialized new browser storage db.");
		};

	};
};

/**
 * This is called from IndexDB.GetCachedVersion -- which appears to be obsolete
 * @function IndexDB.SetCachedVersion
 */
IndexDB.SetCachedVersion = function ()
{
	if (IndexDB.indexDB != null)
	{
		let tx = IndexDB.indexDB.transaction(["cached_data"], "readwrite");
		let store = tx.objectStore("cached_data");

		store.openCursor().onsuccess = function (event)
		{
			let cursor = event.target.result;

			if (cursor)
			{
				if (cursor.value.id == "current_designer")
				{
					let updateData = cursor.value;

					updateData.local_code_base_version = BuildingDesigner.serverVersion;

					let request = cursor.update(updateData);

					request.onsuccess = function ()
					{
						console.log("design added to storage.");

						// was calling this loading function, but the below function is now obsolete (12/13/2018)
						// ScriptLoader.StartLoadingJSBuildingDesignerCode();
					};

					request.onerror = function (e)
					{
						console.log("Unable to add design.");
					};
				}
			}
		};
	}
};

/**
 * Saves passed design to browser storage
 * @function IndexDB.AddPersistentDesignToStorage
 * @param {*} buildingDesign either XMLDesign string or Javascript object
 */
IndexDB.AddPersistentDesignToStorage = function (buildingDesign)
{
	if (IndexDB.indexDB != null)
	{
		let tx = IndexDB.indexDB.transaction(["cached_data"], "readwrite");
		let store = tx.objectStore("cached_data");

		store.openCursor().onsuccess = function (event)
		{
			let cursor = event.target.result;

			if (cursor)
			{
				if (cursor.value.id == "current_designer")
				{
					let updateData = cursor.value;

					updateData.current_stored_building_design = buildingDesign;

					let request = cursor.update(updateData);

					request.onsuccess = function ()
					{
						console.log("design added to storage.");
					};

					request.onerror = function (e)
					{
						console.log("Unable to add design.");
					};
				}
			}
		};
	}
};

/**
 * As of 12/13/2018 This function appears to not be used anywhere. I think it is probably obsolete.
 * @function IndexDB.GetCachedVersion
 * @param {Callback} resultFunction Callback function, if successful, passes saved code version to callback otherwise passes null
 */
IndexDB.GetCachedVersion = function (resultFunction)
{
	try
	{
		let transaction;
		transaction = IndexDB.indexDB.transaction("cached_data");

		let objectStore = transaction.objectStore("cached_data");

		let request = objectStore.get("current_designer");

		//let request = objectStore.getAll();

		if (request.readyState == "done" && request.result != undefined && request.result != null)
		{
			console.log("Code version: " + request.result.local_code_base_version);

			resultFunction(request.result.local_code_base_version);
		}

		request.onerror = function (event)
		{
			console.log("Unable to retrieve version from database!");
		};

		request.onsuccess = function (event)
		{
			if (event.target.result)
			{
				console.log("Code version: " + event.target.result.local_code_base_version);

				resultFunction(event.target.result.local_code_base_version);
			}
			else
			{
				console.log("Unable to retrieve version from database!");

				IndexDB.SetCachedVersion();
			}
		};
	}
	catch (ex)
	{
		console.log("Unable to retrieve version from database!");
		resultFunction(null);
	}
};

/**
 * Attempt to retrieve design from browser indexedDB and then call callback function
 * @function IndexDB.GetPersistentDesign
 * @param {Callback} dbInitializedFunction Callback function
 */
IndexDB.GetPersistentDesign = function (dbInitializedFunction)
{
	try
	{
		if (IndexDB.indexDB != null)
		{
			let objectStore = IndexDB.indexDB.transaction("cached_data").objectStore("cached_data");
			let request = objectStore.get("current_designer");

			if (request.readyState == "done" && request.result != undefined && request.result != null)
			{
				console.log("design loaded from database!");

				if (typeof request.result.current_stored_building_design === "string")
				{
					IndexDB.persistentDesignXML = request.result.current_stored_building_design;
				}
				else
				{
					IndexDB.persistentDesignObject = request.result.current_stored_building_design;
				}

				dbInitializedFunction();
			}

			request.onerror = function (event)
			{
				console.log("Unable to retrieve design from database!");

				dbInitializedFunction();
			};

			request.onsuccess = function (event)
			{
				if (request.result)
				{
					console.log("design loaded from database!");

					if (typeof request.result.current_stored_building_design === "string")
					{
						IndexDB.persistentDesignXML = request.result.current_stored_building_design;
					}
					else
					{
						IndexDB.persistentDesignObject = request.result.current_stored_building_design;
					}
				}
				else
				{
					console.log("Unable to retrieve design from database!");
				}

				dbInitializedFunction();
			};
		}
		else
			dbInitializedFunction();
	}
	catch (ex)
	{
		dbInitializedFunction();
	}
};

IndexDB.persistentDesignXML = "";
IndexDB.persistentDesignObject = {};

IndexDB.indexDB = null;
