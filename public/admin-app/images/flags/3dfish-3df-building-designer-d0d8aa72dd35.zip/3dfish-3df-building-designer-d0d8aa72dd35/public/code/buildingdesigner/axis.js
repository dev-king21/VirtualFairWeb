/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Axis()
{
	this.xvec = new THREE.Vector3(1, 0, 0);
	this.yvec = new THREE.Vector3(0, 1, 0);
	this.zvec = new THREE.Vector3(0, 0, 1);

	this.initAxis = function (x1, y1, z1, x2, y2, z2, x3, y3, z3)
	{
		this.xvec = new THREE.Vector3(x1, y1, z1);
		this.yvec = new THREE.Vector3(x2, y2, z2);
		this.zvec = new THREE.Vector3(x3, y3, z3);
	};

	this.rotateAxis = function (x_axis, y_axis, z_axis, angle)
	{
		let axis2 = new Axis();

		if (x_axis)
		{
			axis2.xvec = MathUtilities.RotateVector(this.xvec, x_axis, y_axis, z_axis, angle);
			axis2.yvec = MathUtilities.RotateVector(this.yvec, x_axis, y_axis, z_axis, angle);
			axis2.zvec = MathUtilities.RotateVector(this.zvec, x_axis, y_axis, z_axis, angle);

			return axis2;
		}

		if (y_axis)
		{
			axis2.xvec = MathUtilities.RotateVector(this.xvec, x_axis, y_axis, z_axis, angle);
			axis2.yvec = MathUtilities.RotateVector(this.yvec, x_axis, y_axis, z_axis, angle);
			axis2.zvec = MathUtilities.RotateVector(this.zvec, x_axis, y_axis, z_axis, angle);

			return axis2;
		}

		if (z_axis)
		{
			axis2.xvec = MathUtilities.RotateVector(this.xvec, x_axis, y_axis, z_axis, angle);
			axis2.yvec = MathUtilities.RotateVector(this.yvec, x_axis, y_axis, z_axis, angle);
			axis2.zvec = MathUtilities.RotateVector(this.zvec, x_axis, y_axis, z_axis, angle);

			return axis2;
		}
	};

	this.DetermineAxisRotation = function ()
	{
		let axis2 = new Axis();

		axis2.xvec.x = this.xvec.x;
		axis2.xvec.y = this.xvec.y;
		axis2.xvec.z = this.xvec.z;

		axis2.yvec.x = this.yvec.x;
		axis2.yvec.y = this.yvec.y;
		axis2.yvec.z = this.yvec.z;

		axis2.zvec.x = this.zvec.x;
		axis2.zvec.y = this.zvec.y;
		axis2.zvec.z = this.zvec.z;

		let y_angle, x_angle, z_angle;
		let y_angle2, x_angle2, z_angle2;

		if ((this.zvec.y == 1) || (this.zvec.y == -1))
			y_angle = Math.atan2(this.xvec.z, this.xvec.x);
		else
			y_angle = Math.atan2(this.zvec.x, this.zvec.z);

		axis2 = axis2.rotateAxis(0, 1, 0, y_angle);

		x_angle = Math.atan2(axis2.zvec.y, axis2.zvec.z);

		axis2 = axis2.rotateAxis(1, 0, 0, -x_angle);

		z_angle = Math.atan2(axis2.yvec.x, axis2.yvec.y);

		axis2 = axis2.rotateAxis(0, 0, 1, z_angle);

		let vector = new THREE.Vector3();

		vector.x = x_angle;
		vector.y = -y_angle;
		vector.z = -z_angle;

		return vector;
	};
}
