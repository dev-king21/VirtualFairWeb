// admin-profile.js
/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1*/
/*eslint-disable no-console, no-unused-vars*/
/* global DEBUG, to, checkLoginStatus:false */

/* function returnToProfile(currentID){
	if(DEBUG) console.log("fn: returnToProfile");
	$(currentID).hide();
	$("#profile").show();
} */

function ReturntoProfile()
{
	if(DEBUG) console.log("fn: ReturntoProfile");
	$("#subprofile").hide();
	$("#profile").show();
}

function DisplaySPData(FieldName,spdata)
{
	/* if(FieldName === "expiration") {
		$("#sp_"+FieldName).text(spdata[FieldName].slice(0,10));
	} else {
		$("#sp_"+FieldName).text(spdata[FieldName]);
	} */
	switch (FieldName)
	{
	case "expiration":
		$("#sp_"+FieldName).text(spdata[FieldName].slice(0,10));
		break;
	case "url":
	case "trello_link":
		$("#sp_"+FieldName).attr("href",spdata[FieldName]);
		$("#sp_"+FieldName).text(spdata[FieldName]);
		break;
	default:
		$("#sp_"+FieldName).text(spdata[FieldName]);
	}
}

function addSidingType(subscriber_id) {
	if(DEBUG) console.log("fn:addSidingType");
	alert("still to be coded");
}

function editSidingType(subscriber_id,category_id,series_code){
	if(DEBUG) console.log("fn:editSidingType");
	alert("still to be coded");
}

async function deleteSidingType(subscriber_id,category_id,series_code){
	if(DEBUG) console.log("fn:deleteSidingType");
	let err, result;
	var r = confirm(`Are you sure you want to delete ${category_id} for ${series_code}?`);
	if (r == true) {
		[err, result] = await to($.ajax({
			url:"adminui?q=deletesubsidingtype",
			dataType:"json",
			type: "POST",
			data: {action: "deletesubsidingtype", subscriber_id: subscriber_id, siding_id: category_id, series_code: series_code}
		}));
		if(result.success) {
			$(`#${category_id}_${series_code}`).remove();
			$("#tbl_siding").DataTable().row().invalidate();
		}
	}
}

async function DeleteBuildingType(subscriber_id,building_id,building_type,series_code){
	let err, result;
	let r = confirm(`Are you sure you want to delete ${building_id} in series ${series_code}?`);
	if (r == true) {
		[err, result] = await to($.ajax({
			url:"adminui?q=deletesubbuildingid",
			dataType:"json",
			type: "POST",
			data: {action: "deletesubbuildingid", subscriber_id: subscriber_id, building_id: building_id, series_code: series_code}
		}));
		if(result.success) {
			$(`#${building_id}_${series_code}_row`).remove();
			$("#tbl_building_list").DataTable().row().invalidate();
		}
	}
}

async function RenameBuildingID(subscriber_id,building_id,building_type,series_code){
	let new_building_id = await prompt(`Enter new building id for ${building_id}:`);
	let err, result;
	if(new_building_id != null) {
		[err, result] = await to($.ajax({
			url:"adminui?q=renamesubbuildingid",
			dataType:"json",
			type: "POST",
			data: {action: "renamesubbuildingid", subscriber_id: subscriber_id, building_id: building_id, series_code: series_code, new_building_id: new_building_id}
		}));
		if(result.success) {
			let bdata = $(`#${building_id}_${series_code}_row`).data("bdata");
			bdata.building_id = new_building_id;
			$(`#${building_id}_${series_code}_row`).html(SetBuildingRowData(bdata));
			$(`#${building_id}_${series_code}_row`).attr("id",`#${new_building_id}_${series_code}_row`);
			$(`#${new_building_id}_${series_code}_row`).data("bdata",bdata);
			$("#tbl_building_list").DataTable().row().invalidate();
		}
		alert(result.status);
	}

}

function LoadSubscriberShelves(sub_id,table_id)
{
	$.post("adminui?q=shelves", {loaddata: "getsubshelves", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_shelves = JSON.parse(data);
		for (let i=0; i<sub_shelves.length; i++)
		{
			let sdata = sub_shelves[i];
			table_row = `
			<tr>
			<td>${sdata.elem_id}</td>
			<td>${sdata.series_code}</td>
			<td>${sdata.element_name}</td>
			<td>${sdata.object3D_name}</td>
			<td><i class='fa fa-pencil' aria-hidden='true' title='Edit Shelf'></i></td>
			<td><i class='fa fa-trash' aria-hidden='true' title='Remove Shelf'></i></td>
			</tr>
			`;
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		$("#"+table_id).DataTable();
	});
}

function LoadSubscriberOptions(sub_id,table_id)
{
	$.post("adminui?q=options", {loaddata: "getsuboptions", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_options = JSON.parse(data);
		for (let i=0; i<sub_options.length; i++)
		{
			let sdata = sub_options[i];
			table_row = `
			<tr>
			<td>${sdata.elem_id}</td>
			<td>${sdata.series_code}</td>
			<td>${sdata.belongs_to_category}</td>
			<td>${sdata.element_name}</td>
			<td>${sdata.object3D_name}</td>
			<td><i class='fa fa-pencil' aria-hidden='true' title='Edit Option'></i></td>
			<td><i class='fa fa-trash' aria-hidden='true' title='Remove Option'></i></td>
			</tr>
			`;
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		$("#"+table_id).DataTable();
	});
}

function removeWindow(sid,window_id,series_code)
{
	if(DEBUG) console.log("fn:removeWindow");
	if(confirm("Remove " +window_id+ "?")) {
		$.post({url:"adminui?q=removewindowfromsub", dataType:"json"}, {action: "removewindowfromsub", subscriber_id: sid, product_id: window_id, series_code: series_code}, function(serverReturn, status)
		{
			if(serverReturn.success === true) {
				$("#windowrow_"+window_id+series_code).remove();
			}
		});
	}
}

function removeRoofingCategory(sid,category_id,series_code)
{
	if(DEBUG) console.log("fn:removeRoofingCategory");
	if(confirm("Remove " +category_id+ "?")) {
		$.post({url:"adminui?q=deletesubroofingcategory", dataType:"json"}, {action: "deletesubroofingcategory", subscriber_id: sid, category_id: category_id, series_code: series_code}, function(serverReturn, status)
		{
			if(serverReturn.success === true) {
				$("#roofingcatrow_"+category_id+series_code).remove();
			}
		});
	}
}

function LoadSubscriberWindows(sub_id,table_id)
{
	$.post("adminui?q=windows", {loaddata: "getsubwindows", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_windows = JSON.parse(data);
		for (let i=0; i<sub_windows.length; i++)
		{
			let sdata = sub_windows[i];
			let buttonlink = "";
			if((sdata.belongs_to_category.length > 0) && (sdata.belongs_to_category !== "Windows")) {
				buttonlink = "resources/buttons/windows/" + sdata.belongs_to_category.toLowerCase() + "/" + sdata.button_file;
			} else {
				buttonlink = "resources/buttons/windows/" + sdata.button_file;
			}
			table_row = `
			<tr id="windowrow_${sdata.elem_id}${sdata.series_code}">
			<td><span rel="tooltip" data-toggle="tooltip" data-placement="right" title="<img src='${buttonlink}'>">${sdata.elem_id}</span></td>
			<td>${sdata.series_code}</td>
			<td>${sdata.belongs_to_category}</td>
			<td>${sdata.element_name}</td>
			<td>${sdata.object3D_name}</td>
			<td>&nbsp;<i class='fa fa-pencil' aria-hidden='true' title='Edit Window'></i>&nbsp;</td>
			<td>&nbsp;<a href="javascript:void(0);" onclick="removeWindow('${sub_id}','${sdata.elem_id}','${sdata.series_code}')"><i class='fa fa-trash' aria-hidden='true' title='Remove Window'></i></a>&nbsp;</td>
			</tr>
			`;
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		$("#"+table_id).DataTable();
	});
}

function editDoor(sid,door_id,series_code)
{
	if(DEBUG) console.log("fn:editDoor");
}

function copyDoor(sid,door_id,series_code){
	if(DEBUG) console.log("fn:copyDoor");
}

function removeDoor(sid,door_id,series_code)
{
	if(DEBUG) console.log("fn:removeDoor");
	if(confirm("Remove " +door_id+ "?")) {
		$.post({url:"adminui?q=removedoorfromsub", dataType:"json"}, {action: "removedoorfromsub", subscriber_id: sid, product_id: door_id, series_code: series_code}, function(serverReturn, status)
		{
			if(serverReturn.success === true) {
				$("#doorrow_"+door_id+series_code).remove();
			}
		});
	}
}

function LoadSubscriberDoors(sub_id,table_id)
{
	$.post("adminui?q=doors", {loaddata: "getsubdoors", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_doors = JSON.parse(data);
		for (let i=0; i<sub_doors.length; i++)
		{
			let sdata = sub_doors[i];
			let elem_id = sdata.elem_id;
			elem_id = elem_id.replace(/-/g,"_");
			let buttonlink = "";
			if((sdata.belongs_to_category.length > 0) && (sdata.belongs_to_category !== "Doors")) {
				buttonlink = "resources/buttons/doors/" + sdata.belongs_to_category.toLowerCase() + "/" + sdata.button_file;
			} else {
				buttonlink = "resources/buttons/doors/" + sdata.button_file;
			}
			/* Old id cell
			<td><div class="tooltip">${sdata.elem_id}<span><img src="${buttonlink}"></span></div></td>
			*/
			table_row = `
			<tr id="doorrow_${sdata.elem_id}${sdata.series_code}">
			<td><span rel="tooltip" data-toggle="tooltip" data-placement="right" title="<img src='${buttonlink}'>">${sdata.elem_id}</span></td>
			<td>${sdata.series_code}</td>
			<td>${sdata.belongs_to_category}</td>
			<td>${sdata.element_name}</td>
			<td>${sdata.object3D_name}</td>
			<td>&nbsp;<a href='javascript:void(0)' onclick='editDoor("${sub_id}","${sdata.elem_id}","${sdata.series_code}")'><i class='fa fa-pencil' aria-hidden='true' title='Edit Door'></i></a>&nbsp;</td>
			<td>&nbsp;<a href='javascript:void(0)' onclick='copyDoor("${sub_id}","${sdata.elem_id}","${sdata.series_code}")'><i class='fa fa-copy' aria-hidden='true' title='Copy Door'></i></a>&nbsp;</td>
			<td><a href='javascript:void(0)' onclick='removeDoor("${sub_id}","${sdata.elem_id}","${sdata.series_code}")'><i class='fa fa-trash' aria-hidden='true' title='Remove Door'></i></a></td>
			</tr>
			`;
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		$(function () {
			$("[data-toggle='tooltip']").tooltip({html:true});
		});
		$("#"+table_id).DataTable();
	});
}
function LoadSubscriberRoofingCategories(sub_id,table_id)
{
	$.post("adminui?q=roofingcat", {loaddata: "getsubroofingcat", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_data = JSON.parse(data);
		for (let i=0; i<sub_data.length; i++)
		{
			let sdata = sub_data[i];
			let sactive = "";
			if(sdata.active) {
				sactive = "<i class='fa fa-thumbs-up' aria-hidden='true' color='green' title='Roofing Active'></i>";
			} else {
				sactive = "<i class='fa fa-ban' aria-hidden='true' color='red' title='Roofing In-active'></i>";
			}
			table_row = `
			<tr id="roofingcatrow_${sdata.category_id}${sdata.series_code}">
			<td>${sdata.category_id}</td>
			<td>${sdata.series_code}</td>
			<td>${sdata.category_name}</td>
			<td>&nbsp;${sactive}&nbsp;</td>
			<td>&nbsp;<i class='fa fa-pencil' aria-hidden='true' title='Edit Roofing Category'></i>&nbsp;</td>
			<td>&nbsp;<a href="javascript:void(0);" onclick="removeRoofingCategory('${sub_id}','${sdata.category_id}','${sdata.series_code}');"><i class='fa fa-trash' aria-hidden='true' title='Remove Roofing Category'></i></a>&nbsp;</td>
			</tr>
			`;
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		$("#"+table_id).DataTable();
	});
}
function LoadSubscriberRoofing(sub_id,table_id)
{
	$.post("adminui?q=roofing", {loaddata: "getsubroofing", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_doors = JSON.parse(data);
		for (let i=0; i<sub_doors.length; i++)
		{
			let sdata = sub_doors[i];
			table_row = `
			<tr>
			<td>${sdata.roofing_id}</td>
			<td>${sdata.series_code}</td>
			<td>${sdata.category_id}</td>
			<td>${sdata.display_name}</td>
			<td><i class='fa fa-pencil' aria-hidden='true' title='Edit Roofing'></i></td>
			<td><i class='fa fa-trash' aria-hidden='true' title='Remove Roofing'></i></td>
			</tr>
			`;
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		$("#"+table_id).DataTable();
	});
}

function LoadSubscriberSiding(sub_id,table_id)
{
	$.post("adminui?q=siding", {loaddata: "getsubsiding", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_siding = JSON.parse(data);
		for (let i=0; i<sub_siding.length; i++)
		{
			/* $("#"+lastaccess[i].subscriber_id+"LU").text(lastaccess[i].date.substr(0,10)); */
			let sdata = sub_siding[i];
			let sactive = "";
			if(sdata.active) {
				sactive = "<i class='fa fa-thumbs-up' aria-hidden='true' color='green' title='Siding Active'></i>";
			} else {
				sactive = "<i class='fa fa-ban' aria-hidden='true' color='red' title='Siding In-active'></i>";
			}
			table_row = `
			<tr id="${sdata.category_id}_${sdata.series_code}"><td>&nbsp;${sdata.category_id}&nbsp;</td>
			<td>&nbsp;${sdata.series_code}&nbsp;</td>
			<td>&nbsp;${sdata.display_name}&nbsp;</td>
			<td>&nbsp;${sactive}&nbsp;</td>
			<td>&nbsp;<a href='EditSidingType' onclick="editSidingType('${sub_id}','${sdata.category_id}','${sdata.series_code}'); return false;"><i class='fa fa-pencil' aria-hidden='true' title='Edit Siding Type'></i></a>&nbsp;</form></td>
			<td>&nbsp;<a href="DeleteSidingType" onclick="deleteSidingType('${sub_id}','${sdata.category_id}','${sdata.series_code}'); return false;"><i class='fa fa-trash' aria-hidden='true' title='Remove Siding Type'></i></a>&nbsp;</td></tr>
			`;
			/* <script>
			function delete${sdata.category_id}() {
				var r = confirm("Are you sure you want to delete ${sdata.category_id}?")
				if (r == true) {
				// document.getElementById("delete${sdata.category_id}").submit();
				alert("Not deleted -- still to be coded");
				}
			}
			function edit${sdata.category_id}() {
				// document.getElementById("edit${sdata.category_id}").submit();
				alert("still to be coded");
			}
			</script>
			`; */
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		$("#"+table_id).DataTable();
	});
}

function LoadSubscriberDescriptions(sub_id,table_id)
{
	$.post("adminui?q=descriptions", {loaddata: "getsubdescriptions", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_descriptions = JSON.parse(data);
		for (let i=0; i<sub_descriptions.length; i++)
		{
			let sdata = sub_descriptions[i];
			table_row = `
			<tr>
			<td>${sdata.series_code}</td>
			<td>${sdata.object_id}</td>
			<td>${sdata.display_name}</td>
			<td><i class='fa fa-pencil' aria-hidden='true' title='Edit Roofing'></i></td>
			<td><i class='fa fa-trash' aria-hidden='true' title='Remove Roofing'></i></td>
			</tr>
			`;
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		$("#"+table_id).DataTable();
	});
}

function LoadSubscriberHinges(sub_id,table_id)
{
	$.post("adminui?q=hinges", {loaddata: "getsubhinges", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let sub_hinges = JSON.parse(data);
		for (let i=0; i<sub_hinges.length; i++)
		{
			let sdata = sub_hinges[i];
			table_row = `
			<tr>
			<td>${sdata.elem_id}</td>
			<td>${sdata.series_code}</td>
			<td>${sdata.belongs_to_category}</td>
			<td>${sdata.element_name}</td>
			<td><i class='fa fa-pencil' aria-hidden='true' title='Edit Roofing'></i></td>
			<td><i class='fa fa-trash' aria-hidden='true' title='Remove Roofing'></i></td>
			</tr>
			`;
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		$("#"+table_id).DataTable();
	});
}

function LoadSubscriberSeries(sub_id,table_id)
{
	$.post("adminui?q=series", {loaddata: "getsubseries", subscriber_id: sub_id}, function(data, status)
	{
		let buttonHTML = "";
		let seriesArray = "[";
		let table_row = "";
		let sub_series = JSON.parse(data);
		for (let i=0; i<sub_series.length; i++)
		{
			let sdata = sub_series[i];
			if(i>0) seriesArray += ", ";
			seriesArray += `"${sdata.series_code}"`;
			table_row = `
			<tr>
			<td>${sdata.series_code}</td>
			<td>${sdata.building_type}</td>
			<td>${sdata.display_name}</td>
			<td><i class='fa fa-pencil' aria-hidden='true' title='Edit Roofing'></i></td>
			<td><i class='fa fa-trash' aria-hidden='true' title='Remove Roofing'></i></td>
			</tr>
			`;
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		seriesArray += "]";
		buttonHTML = `<button onclick='manageSeriesObjects("${sub_id}",${seriesArray});'>Manage Series Objects</button><br>`;
		$("#seriesButtonHolder").html(buttonHTML);
		$("#"+table_id).DataTable();
	});
}

async function CopySubBuilding(subscriber_id,building_id,series_code) {
	let dialogbox = `
<div id="dialog-copybuilding" title="Copy Building">
	<form>
		<fieldset>
		<label for="newname"></label>
		<input type="text" name="newname" id="newname" class="text ui-widget-content ui-corner-all">

		<input type="submit" tabindex="-1" style="position:absolute; top:-1000px">
		</fieldset>
	</form>
</div>
`;
	let new_series_code, new_subscriber_id;
	let new_building_id = await prompt(`Enter to building id to copy ${building_id} to:`);
	if(new_building_id != null) {
		new_subscriber_id = await prompt(`Current subscriber id: ${subscriber_id}
Enter new subscriber id:`);
		if(new_subscriber_id == null || new_subscriber_id.length == 0) {
			new_subscriber_id = subscriber_id;
		}
	}
	if(new_building_id != null) {
		new_series_code = await prompt(`Current series code: ${series_code}
Enter new series code:`);
		if(new_series_code == null || new_series_code.length == 0) {
			new_series_code = series_code;
		}
	}
	let err, result;
	if(new_building_id != null) {
		[err, result] = await to($.ajax({
			url:"adminui?q=copysubbuilding",
			dataType:"json",
			type: "POST",
			data: {action: "copysubbuilding", subscriber_id: subscriber_id, building_id: building_id, series_code: series_code, new_subscriber_id: new_subscriber_id, new_series_code: new_series_code, new_building_id: new_building_id}
		}));
		if (err) {
			alert("Server Error copying building.");
			return;
		}
		if(result.success && subscriber_id === new_subscriber_id) {
			let bdata = $(`#${building_id}_${series_code}_row`).data("bdata");
			bdata.series_code = new_series_code;
			bdata.building_id = new_building_id;
			$("#tbl_building_list").DataTable().row.add($(`<tr id="${new_building_id}_${new_series_code}_row">${SetBuildingRowData(bdata)}</tr>`)[0]).draw();
			// $(`#${building_id}_row`).html(SetBuildingRowData(bdata));
			// $(`#${building_id}_row`).attr("id",`#${new_building_id}_row`);
			$(`#${new_building_id}_${new_series_code}_row`).data("bdata",bdata);
		}
		alert(result.status);
	}
}
function SetBuildingRowData(bdata) {
	let bactive = "";
	let badmin = "";
	if(bdata.active) {
		bactive = "<i class='fa fa-thumbs-up' aria-hidden='true' color='green' title='Building Active'></i>";
	} else {
		bactive = "<i class='fa fa-ban' aria-hidden='true' color='red' title='Building In-active'></i>";
	}
	if(bdata.admin_only) {
		badmin = "<i class='fa fa-lock' aria-hidden='true' color='red' title='Admin Only'></i>";
	} else {
		badmin = "<i class='fa fa-lock-open' aria-hidden='true' color='green' title='All Users'></i>";
	}
	return `
		<td>&nbsp;${bdata.building_id}&nbsp;<i class='fa fa-clone' aria-hidden='true' title='Copy Building' onclick='CopySubBuilding("${bdata.subscriber_id}","${bdata.building_id}","${bdata.series_code}")';></i></td>
		<td>&nbsp;${bdata.building_type}&nbsp;</td>
		<td><form method='post' id='${bdata.building_id}'>&nbsp;<a  title='Rename Building ID' href='javascript:void(0)' onclick='RenameBuildingID("${bdata.subscriber_id}","${bdata.building_id}","${bdata.building_type}","${bdata.series_code}");'><i class='fa fa-pencil' aria-hidden='true' title='Rename Building ID'></i></a>&nbsp;${bdata.building_id.split("_")[2]}&nbsp;</form></td>
		<td>&nbsp;${bdata.display_order}&nbsp;</td>
		<td>&nbsp;${bdata.display_name}&nbsp;</td>
		<td>&nbsp;${bdata.series_code}&nbsp;</td>
		<td>&nbsp;${bactive}&nbsp;</td>
		<td>&nbsp;${badmin}&nbsp;</td>
		<td><form method='post' id='edit${bdata.building_id}'>&nbsp;<a href='javascript:void(0)' onclick='SubscriberEditBuildingType("${bdata.subscriber_id}","${bdata.building_id}","${bdata.building_type}","${bdata.series_code}");'><i class='fa fa-pencil' aria-hidden='true' title='Edit Shed Type'></i></a></form></td>
		<td><form method='post' id='delete${bdata.building_id}'>&nbsp;<a href='javascript:void(0)' onclick='DeleteBuildingType("${bdata.subscriber_id}","${bdata.building_id}","${bdata.building_type}","${bdata.series_code}");'><i class='fa fa-trash' aria-hidden='true' title='Remove Shed Type'></i></a>&nbsp;</form></td>
	`;
}

function LoadSubcriberBuildings(sub_id,table_id)
{
	/* profile_html = `
	<br><table border='2' id="tbl_building_list"><tr><th>Building ID</th><th>Building Type</th><th>Name</th><th>Sort</th><th>Display Name</th><th>Series</th><th></th><th></th></tr>
	</table> */
	let table_row = "";
	$.post({url:"adminui?q=buildings", dataType:"json"}, {loaddata: "getsubbuildings", subscriber_id: sub_id}, function(sub_buildings, status)
	{
		// var sub_buildings = JSON.parse(data);
		for (var i=0; i<sub_buildings.length; i++)
		{
			let bdata = sub_buildings[i];

			table_row = `
			<tr id="${bdata.building_id}_${bdata.series_code}_row">
			${SetBuildingRowData(bdata)}</tr>
			`;

			$("#"+table_id+" > tbody:first").append(table_row);
			$(`#${bdata.building_id}_${bdata.series_code}_row`).data("bdata",bdata);
		}
		$("#"+table_id).DataTable();
		// LoadSubscriberDescriptions(sub_id);
	});
}

function LoadSubscriberUsers(sub_id,table_id)
{
	$.post("adminui?q=adminusers", {loaddata: "adminusers", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let rowsdata = JSON.parse(data);
		for (let i=0; i<rowsdata.length; i++)
		{
			let sdata = rowsdata[i];
			table_row = `
			<tr><td>${sdata.userid}</td><td>${sdata.firstname} ${sdata.lastname}</td><td>${sdata.location_number}</td><td>${sdata.usertype}</td><td></td><td></td></tr>
			`;
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		$("#"+table_id).DataTable();
	});
}

function LoadSubscriberLocations(sub_id,table_id)
{
	$.post("adminui?q=sublocations", {loaddata: "getsublocations", subscriber_id: sub_id}, function(data, status)
	{
		let table_row = "";
		let rowsdata = JSON.parse(data);
		for (let i=0; i<rowsdata.length; i++)
		{
			let sdata = rowsdata[i];
			table_row = `
			<tr><td>${sdata.location_number}</td><td>${sdata.name}</td><td>${sdata.city}</td>
			<td>&nbsp;<i class='fa fa-pencil' aria-hidden='true' title='Edit Location'></i>&nbsp;</td>
			<td>&nbsp;<i class='fa fa-trash' aria-hidden='true' title='Remove Location'></i>&nbsp;</td>
			</tr>
			`;
			$("#"+table_id+" > tbody:first").append(table_row);
		}
		$("#"+table_id).DataTable();
	});
}

function LoadSubscriberProfile(sub_id)
{
	$.post("adminui?q=profile", {loaddata: "getsubprofile", subscriber_id: sub_id}, function(data, status)
	{
		checkLoginStatus(data);
		var sub_profile = JSON.parse(data)[0];
		/*for (var i=0; i<lastaccess.length; i++)
		{
			$("#"+lastaccess[i].subscriber_id+"LU").text(lastaccess[i].date.substr(0,10));
		}
		SubLoadNumUsers(); */
		DisplaySPData("status",sub_profile);
		DisplaySPData("num_locations",sub_profile);
		DisplaySPData("expiration",sub_profile);
		DisplaySPData("name",sub_profile);
		DisplaySPData("address",sub_profile);
		DisplaySPData("city",sub_profile);
		DisplaySPData("region",sub_profile);
		DisplaySPData("postalcode",sub_profile);
		DisplaySPData("countrycode",sub_profile);
		DisplaySPData("phone",sub_profile);
		DisplaySPData("contact_name",sub_profile);
		DisplaySPData("contact_email",sub_profile);
		DisplaySPData("url",sub_profile);
		DisplaySPData("latitude",sub_profile);
		DisplaySPData("longitude",sub_profile);
		DisplaySPData("maxrange",sub_profile);
		DisplaySPData("display_prices",sub_profile);
		DisplaySPData("trello_link",sub_profile);
		DisplaySPData("active_features",sub_profile);
		DisplaySPData("interface_html",sub_profile);
		// LoadSubscriberUsers(sub_id);
	});
}

function EditBuildingType(sid, bid)
{
	$("#profile").hide();
	$("#subprofile").html("");
	$("#subprofile").show();
	let subprofile_html = `
	<div class='header'><i class='fas fa-arrow-alt-circle-left' onclick='ReturntoProfile()'>Return to ${sid} profile</i><h1>Editing Shedtype ${bid}</h1></div>
	`;
	$("#subprofile").append(subprofile_html);
}

function ReturntoMain()
{
	$("#profile").hide();
	$("#main").show();
}

function revertField(fieldID,fieldData)
{
	$("#"+fieldID).text(fieldData);
	$("#"+fieldID+" ~ .inactive").css("visibility", "hidden");
}

function updateField(sub_id, fieldID,fieldName,fieldData)
{
	$.post({url:"adminui?q=updatesubinfo", dataType:"json"}, {action: "updatesubinfo", subscriber_id: sub_id, fieldname: fieldName, value: fieldData}, function(serverReturn, status)
	{
		if(serverReturn.success === true) {
			$("#"+fieldID+" ~ .inactive").css("visibility", "hidden");
		}
	});
}

function SubscriberProfile(sid)
{
	if(DEBUG) console.log("fn: SubscriberProfile");
	$("#main").hide();
	$("#profile").html("");
	$("#profile").show();
	$("#profile").append("<div class='header'><i class='fas fa-arrow-alt-circle-left' onclick='ReturntoMain()'></i><h1>Subscriber Profile</h1></div>");
	// subscriber info
	let table_row = "";
	let profile_html = `
	<div class="content" id="profile_content"></div>
	`;

	$("#profile").append(profile_html);

	let snipet1 = `&nbsp;<i class="inactive red fas fa-times" onclick="revertField('sp_'+$(this).data('fieldid'),$(this).data('oldval'));"></i>&nbsp;<i class="inactive green fas fa-check" onclick="$(this).focus();updateField('${sid}','sp_'+$(this).data('fieldid'),$(this).data('fieldid'),$(this).data('newval'));"></i>&nbsp;`;
	profile_html = `
	<table border='2'>
	<tr><td>Subsriber ID:</td><td><a href='index.html?sc=${sid}' target='_blank'>${sid}</a></td></tr>
	<tr><td>Status:</td><td id="sp_status"></td></tr>
	<tr><td>Number of Locations:</td><td id="sp_num_locations"></td></tr>
	<tr><td>Expiration Date:</td><td><span id='sp_expiration' onclick="switchToInput('sp_expiration','date');">01/01/2000</span>${snipet1}</td></tr>
	<tr><td>Company Name:</td><td><span id="sp_name" onclick="switchToInput('sp_name','text');"></span>${snipet1}</td></tr>
	<tr><td>Address:</td><td><span id="sp_address" onclick="switchToInput('sp_address','text');"></span>${snipet1}</td></td></tr>
	<tr><td>City:</td><td><span id="sp_city" onclick="switchToInput('sp_city','text');"></span>${snipet1}</td></td></tr>
	<tr><td>State:</td><td><span id="sp_region" onclick="switchToInput('sp_region','text');"></span>${snipet1}</td></td></tr>
	<tr><td>Zip:</td><td><span id="sp_postalcode" onclick="switchToInput('sp_postalcode','text');"></span>${snipet1}</td></td></tr>
	<tr><td>Country:</td><td><span id="sp_countrycode" onclick="switchToInput('sp_countrycode','text');"></span>${snipet1}</td></td></tr>
	<tr><td>Phone Number:</td><td><span id="sp_phone" onclick="switchToInput('sp_phone','text');"></span>${snipet1}</td></td></tr>
	<tr><td>Contact Name:</td><td><span id="sp_contact_name" onclick="switchToInput('sp_contact_name','text');"></span>${snipet1}</td></td></tr>
	<tr><td>Contact E-Mail:</td><td><span id="sp_contact_email" onclick="switchToInput('sp_contact_email','text');"></span>${snipet1}</td></td></tr>
	<tr><td>Website:</td><td><a href='' target='_blank' id="sp_url" contenteditable="true"></a>${snipet1}</td></tr>
	<tr><td>Latitude:</td><td><span id="sp_latitude" onclick="switchToInput('sp_latitude','text');"></span>${snipet1}</td></td></tr>
	<tr><td>Longitude:</td><td ><span id="sp_longitude" onclick="switchToInput('sp_longitude','text');"></span>${snipet1}</td></td></tr>
	<tr><td>Maximum Range:</td><td><span id="sp_maxrange" onclick="switchToInput('sp_maxrange','text');"></span>${snipet1}</td></td></tr>
	<tr><td>Display Prices:</td><td><span id="sp_display_prices" onclick="switchToInput('sp_display_prices','text');"></span>${snipet1}</td></td></tr>
	<tr><td>Trello Link:</td><td><a href="" id="sp_trello_link"  contenteditable="true"></a>${snipet1}</td></td></tr>
	<tr><td>Active Features:</td><td><span id="sp_active_features" onclick="switchToInput('sp_active_features','text');"></span>${snipet1}</td></td></tr>
	<tr><td>Interface:</td><td><span id="sp_interface_html" onclick="switchToInput('sp_interface_html','text');"></span>${snipet1}</td></td></tr>
	</table>
`;
	$("#profile_content").append(profile_html);
	LoadSubscriberProfile(sid);

	// script for seamless input
	/*
	profile_html = `
	<script>
	var switchToInput = function () {
			var $input = $("<input>", {
				val: $(this).text(),
				type: "date"
			});
			$input.attr("ID", "sp_expiration");
			$(this).replaceWith($input);
			$input.on("blur", switchToSpan);
			$input.select();
		};
		var switchToSpan = function () {
			var $span = $("<span>", {
				text: $(this).val()
			});
			$span.attr("ID", "sp_expiration");
			$(this).replaceWith($span);
			$span.on("click", switchToInput);
		}
		$("#sp_expiration").on("click", switchToInput);
		</script>
`;
*/
	// Location List
	profile_html = `
	<br><table border='2' id="tbl_locations"><thead><tr><th>Location Number</th><th>Name</th><th>City</th><th></th><th></th></tr></thead>
	<tbody></tbody>
	</table>`;

	$("#profile_content").append(profile_html);
	LoadSubscriberLocations(sid,"tbl_locations");

	// User List
	profile_html = `
	<br><table border='2' id="tbl_users"><thead><tr><th>User ID</th><th>User Name</th><th>Location Number</th><th>Access Level</th><th></th><th></th></tr></thead><tbody>
	</tbody></table>
	`;

	$("#profile_content").append(profile_html);
	LoadSubscriberUsers(sid,"tbl_users");

	// Series List
	profile_html = `
	<br><table border='2' id="tbl_series_list"><thead><tr><th>Series ID</th><th>Building Type</th><th>Display Name</th><th></th><th></th></tr></thead><tbody></tbody>
	</table><br>
	<span id="seriesButtonHolder"></span> <button>Add Series</button>
	`;

	$("#profile_content").append(profile_html);

	LoadSubscriberSeries(sid,"tbl_series_list");

	// Building List (New)
	profile_html = `
	<br><table border='2' id="tbl_building_list"><thead><tr><th>Building ID</th><th>Building Type</th><th>Name</th><th>Sort</th><th>Display Name</th><th>Series</th><th></th><th></th><th></th><th></th></tr></thead>
	<tbody></tbody>
	</table><br>
	<form method='post'><input type='hidden' name='action' value='addshedtypeform'><input type='hidden' name='sc' value='${sid}'><input type='submit' name='submit' value='Add Shed Type'></form><br>
	`;

	$("#profile_content").append(profile_html);

	LoadSubcriberBuildings(sid,"tbl_building_list");

	// Hinges
	profile_html = `
	<table border='2' id="tbl_hinges"><thead><tr><th>Hinge ID</th><th>Series</th><th>Category</th><th>Display Name</th><th></th><th></th></tr></thead><tbody></tbody>
	</table><br>
	`;

	$("#profile_content").append(profile_html);
	LoadSubscriberHinges(sid,"tbl_hinges");

	// Descriptions
	profile_html = `
	<table border='2' id="tbl_descriptions"><thead><tr><th>Series</th><th>Object ID</th><th>Display Name</th><th></th><th></th></tr></theder>
	<tbody></tbody>
	</table><br>
	`;

	$("#profile_content").append(profile_html);
	LoadSubscriberDescriptions(sid,"tbl_descriptions");

	// siding list
	profile_html = `
	<table border='2' id="tbl_siding"><thead><tr><th>Siding ID</th><th>Series</th><th>Siding Name</th><th></th><th></th><th></th></tr></thead>
	<tbody></tbody>
	</table><br>
	<button onclick="addSidingType()">Add Siding Type</button>
	<br>
	`;

	$("#profile_content").append(profile_html);
	LoadSubscriberSiding(sid,"tbl_siding");

	// Roofing Category List
	profile_html = `
	<table border='2' id="tbl_roofing_categories"><thead><tr><th>Roofing ID</th><th>Series</th><th>Roofing Name</th><th></th><th></th><th></th></tr></thead>
	<tbody></tbody>
	</table><br>
	`;

	$("#profile_content").append(profile_html);
	LoadSubscriberRoofingCategories(sid,"tbl_roofing_categories");

	// Roofing List
	/*
	profile_html = `
	<table border='2' id="tbl_roofing"><thead><tr><th>Roofing ID</th><th>Series</th><th>Category</th><th>Roofing Name</th><th></th><th></th></tr></thead>
	<tbody></tbody>
	</table><br>
	`;

	$("#profile_content").append(profile_html);
	LoadSubscriberRoofing(sid,"tbl_roofing");
	*/

	// Door List
	profile_html = `
	<table border='2' id="tbl_doors"><thead><tr><th>Door ID</th><th>Series</th><th>Category</th><th>Description</th><th>3D Object</th><th></th><th></th><th></th></tr></thead>
	<tbody></tbody>
	</table><br>
	`;

	$("#profile_content").append(profile_html);
	LoadSubscriberDoors(sid,"tbl_doors");

	// Window List
	profile_html = `
	<table border='2' id="tbl_windows"><thead><tr><th>Window ID</th><th>Series</th><th>Category</th><th>Description</th><th>3D Object</th><th></th><th></th></tr></thead>
	<tbody></tbody>
	</table><br>
	`;

	$("#profile_content").append(profile_html);
	LoadSubscriberWindows(sid,"tbl_windows");

	// Option List
	profile_html = `
	<table border='2' id="tbl_options"><thead><tr><th>Option ID</th><th>Series</th><th>Category</th><th>Description</th><th>3D Object</th><th></th><th></th></tr></thead>
	<tbody></tbody>
	</table><br>
	`;

	$("#profile_content").append(profile_html);
	LoadSubscriberOptions(sid,"tbl_options");

	// Shelf List
	profile_html = `
	<table border='2' id="tbl_shelves"><thead><tr><th>Shelf ID</th><th>Series</th><th>Description</th><th>3D Object</th><th></th><th></th></tr></thead>
	<tbody></tbody>
	</table>
	`;

	$("#profile_content").append(profile_html);
	LoadSubscriberShelves(sid,"tbl_shelves");

	/* $(function () {
		$('[data-toggle="tooltip"]').tooltip({html:true});
	}); */
}
