/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

/**
 * @constructor Trim
 */
function Trim()
{
}

Trim.CreateTrimFromAngle = function(angle, convex)
{
	angle /= 2;

	let joinThickness = Trim.TRIM_THICKNESS/Math.sin(angle);

	let trimCrossSection = [];

	trimCrossSection.push({x: 0, y: -joinThickness});


	let PI2LessAngle = MathUtilities.PI2 - angle;

	let x1 = -Math.cos(PI2LessAngle) * Trim.CORNER_TRIM_WIDTH_SIDES;
	let y1 = Math.sin(PI2LessAngle) * Trim.CORNER_TRIM_WIDTH_SIDES - joinThickness;

	trimCrossSection.push({x: x1, y: y1});

	let axisZ = new THREE.Vector3(0.0, 0.0, 1.0);

	let widthVector = new THREE.Vector3(0.0, Trim.TRIM_THICKNESS, 0.0);

	widthVector = widthVector.applyAxisAngle(axisZ, -PI2LessAngle);


	trimCrossSection.push({x: x1 + widthVector.x, y: y1 + widthVector.y});

	trimCrossSection.push({x: 0, y: 0});

	trimCrossSection.push({x: -x1 - widthVector.x, y: y1 + widthVector.y});

	trimCrossSection.push({x: -x1, y: y1});


	/*////trimCrossSection.push({x: 10, y: -10});

    trimCrossSection.push({x: 10, y: 10});

    trimCrossSection.push({x: -10, y: 10});

    trimCrossSection.push({x: -10, y: -10});
    */

	if (!convex)
	{
		for (let i=0; i<trimCrossSection.length;i++)
		{
			trimCrossSection[i].y += joinThickness;
		}
	}


	let shape = new THREE.Shape(trimCrossSection);

	let deckingGeometry = new THREE.ExtrudeGeometry(shape, {
		depth:  buildingDesigner.building.height - buildingDesigner.building.floorHeight,
		bevelEnabled: false
	});

	deckingGeometry.matrixAutoUpdate = false;
	////deckingGeometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -buildingDesigner.building.height));

	deckingGeometry.applyMatrix4(new THREE.Matrix4().makeRotationX(-MathUtilities.PI2));

	return deckingGeometry;
}

Trim.TRIM_THICKNESS = INCHTOFEET * 3 / 4;
Trim.CORNER_TRIM_THICKNESS = INCHTOFEET * 1.01;
Trim.CORNER_TRIM_WIDTH_SIDES = BOARD_2x4_WIDTH;
Trim.CORNER_TRIM_WIDTH_ENDS = BOARD_2x4_WIDTH;
