/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Porch()
{
	this.ceiling = new PorchCeiling(this);
	this.railings = new PorchRailings(this);
	this.decking = new PorchDecking(this);
	this.trim = new PorchTrim(this);

	/**
	 * @method Porch.SetShapeAndWallSpecifications - Sets the outline for the porch area and also
	 * creates specification data for the porch walls
	 * @param width
	 * @param length
	 */
	this.SetShapeAndWallSpecifications = function(width, length)
	{
		this.shape = [];

		let tw2 = buildingDesigner.building.roofRafter.wallWidth / 2 + Wall.WALLTHICKNESS;

		this.porchWallSpecifications = [];

		if (length == 0)
		{
			let angle = Math.PI/4;

			this.shape[0] = new THREE.Vector3(0, 0, this.innerWallRadius);

			let circumferencePoint  = MathUtilities.RotateVector(this.shape[0], 0, 1, 0, angle);

			this.shape[3] = MathUtilities.RotateVector(circumferencePoint, 0, 1, 0, angle);

			let adjOpp = circumferencePoint.x - this.shape[3].x;

			hyp = adjOpp*adjOpp + adjOpp*adjOpp;

			hyp = Math.sqrt(hyp);

			this.shape[1] = new THREE.Vector3(circumferencePoint.x + adjOpp, 0, circumferencePoint.z + adjOpp);

			this.shape[2] = new THREE.Vector3(circumferencePoint.x - adjOpp, 0, circumferencePoint.z - adjOpp);

			this.shape[4] = new THREE.Vector3(-buildingDesigner.building.roofRafter.wallWidth, 0, 0);

			this.shape[5] = new THREE.Vector3(this.shape[4].x, 0, this.shape[0].z + this.width);

			this.shape[6] = new THREE.Vector3(this.shape[0].x, 0, this.shape[0].z + this.width);

			if (!this.rightSide)
			{
				for (let i=0;i<this.shape.length; i++)
					this.shape[i].z *= -1;
			}

			let rightPorchWallLength = this.shape[0].x-this.shape[1].x;


			this.porchWallSpecifications.push({width: rightPorchWallLength, coord: new THREE.Vector3(tw2 - rightPorchWallLength/2, 0, -width), eWall: WALL_RIGHT, angle: 0});

			this.porchWallSpecifications.push({width: hyp*2, coord: new THREE.Vector3(tw2 - rightPorchWallLength - adjOpp, 0, -width - adjOpp), eWall: WALL_RIGHT, angle: Math.PI/4});


			this.frontWallLength = buildingDesigner.building.length - width - buildingDesigner.building.porch.innerWallRadius - Wall.WALLTHICKNESS*2;
			this.backWallLength = buildingDesigner.building.length - width - Wall.WALLTHICKNESS*2;

			let frontPorchWallLength = Math.abs(this.shape[2].z-this.shape[3].z);


			this.porchWallSpecifications.push({width: frontPorchWallLength, coord: new THREE.Vector3(-buildingDesigner.building.length/2 + this.frontWallLength + frontPorchWallLength/2 + Wall.WALLTHICKNESS, 0, -width - Wall.WALLTHICKNESS), eWall: WALL_FRONT, angle: 0});

			let rightPorchWall2Length = this.shape[3].x-this.shape[4].x;

			this.porchWallSpecifications.push({width: rightPorchWall2Length, coord: new THREE.Vector3(-buildingDesigner.building.roofRafter.wallWidth / 2 + rightPorchWall2Length/2, 0, -width -buildingDesigner.building.porch.innerWallRadius), eWall: WALL_RIGHT, angle: 0});


			if (!this.rightSide)
			{
				this.porchWallSpecifications[0].eWall = this.porchWallSpecifications[1].eWall = this.porchWallSpecifications[3].eWall = WALL_LEFT;

				this.porchWallSpecifications[1].angle *= -1;

				this.porchWallSpecifications[2].coord.x = buildingDesigner.building.length/2 - this.frontWallLength - frontPorchWallLength/2 - Wall.WALLTHICKNESS;
			}
		}
		else
		{
			this.shape[0] = new THREE.Vector3(0, 0, width);
			this.shape[1] = new THREE.Vector3(-length, 0, width);
			this.shape[2] = new THREE.Vector3(-length, 0, 0);

			this.shape[3] = new THREE.Vector3(0, 0, 0);

			if (!this.fullLength)
			{
				if (length<0)
				{
					this.frontWallLength = buildingDesigner.building.length - Math.abs(width) - Wall.WALLTHICKNESS*2;
					this.backWallLength = buildingDesigner.building.length - Wall.WALLTHICKNESS*2;

					let wallLength = -length + Wall.WALLTHICKNESS;

					this.porchWallSpecifications.push({width: wallLength, coord: new THREE.Vector3(-tw2 + wallLength/2, 0, -Math.abs(width)), eWall: WALL_RIGHT, angle: 0});

					this.porchWallSpecifications.push({width: Math.abs(width), coord: new THREE.Vector3(buildingDesigner.building.length/2 - width/2 - Wall.WALLTHICKNESS, 0, length - Wall.WALLTHICKNESS), eWall: WALL_FRONT, angle: 0});


					if (!this.rightSide)
					{
						this.porchWallSpecifications[0].eWall = WALL_LEFT;

						this.porchWallSpecifications[1].coord.x = -buildingDesigner.building.length/2 - width/2 + Wall.WALLTHICKNESS;
					}
				}
				else
				{
					this.backWallLength = buildingDesigner.building.length - Math.abs(width) - Wall.WALLTHICKNESS*2;
					this.frontWallLength = buildingDesigner.building.length - Wall.WALLTHICKNESS*2;

					let wallLength = length + Wall.WALLTHICKNESS;

					this.porchWallSpecifications.push({width: wallLength, coord: new THREE.Vector3(tw2 - wallLength/2, 0, -Math.abs(width)), eWall: WALL_RIGHT, angle: 0});

					this.porchWallSpecifications.push({width: Math.abs(width), coord: new THREE.Vector3(buildingDesigner.building.length/2 - width/2 - Wall.WALLTHICKNESS, 0, -length - Wall.WALLTHICKNESS), eWall: WALL_BACK, angle: 0});

					if (!this.rightSide)
					{
						this.porchWallSpecifications[0].eWall = WALL_LEFT;

						this.porchWallSpecifications[1].coord.x = -buildingDesigner.building.length/2 - width/2 + Wall.WALLTHICKNESS;
					}
				}
			}
			else
			{
				this.frontWallLength = buildingDesigner.building.length - width - Wall.WALLTHICKNESS*2;
				this.backWallLength = buildingDesigner.building.length - width - Wall.WALLTHICKNESS*2;

				this.porchWallSpecifications.push({width: length, coord: new THREE.Vector3(tw2 - length/2, 0, -width), eWall: WALL_RIGHT, angle: 0});
			}
		}
	}

	this.Initialize = function(width, length)
	{
		this.width = width;
		this.length = length;

		this.rightSide =  true;

		if (this.width<0)
			this.rightSide =  false;

		this.innerWallRadius = 0;

		this.fullLength = false;

		if ((this.width != 0 && this.length == 0))
		{
			this.innerWallRadius = buildingDesigner.building.roofRafter.wallWidth - Math.abs(this.width);

			if (!this.rightSide)
			{
				this.width *= -1;
			}

			this.fullLength = true;
		}
		else
		{
			if (MathUtilities.Equals(Math.abs(this.length), buildingDesigner.building.roofRafter.wallWidth, 0.5) || this.length > buildingDesigner.building.roofRafter.wallWidth)
			{
				this.length = buildingDesigner.building.roofRafter.wallWidth;
				this.fullLength = true;
			}
			else
				this.fullLength = false;
		}

		this.SetShapeAndWallSpecifications(this.width, this.length);

		this.regenerate = true;
	}

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;

		this.ceiling.SetRegenerate(regenerate);
		this.railings.SetRegenerate(regenerate);
		this.decking.SetRegenerate(regenerate);
		this.trim.SetRegenerate(regenerate);
	};

	this.Generate = function (buildingMeshes)
	{
		this.ceiling.Generate(buildingMeshes);
		this.railings.Generate(buildingMeshes);
		this.decking.Generate(buildingMeshes);
		this.trim.Generate(buildingMeshes);
	};
}
