/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function MeshUtilities()
{

}

MeshUtilities.TranslateMeshes = function (meshes, x, y, z)
{
	for (i = 0; i < meshes.length; i++)
	{
		meshes[i].matrixAutoUpdate = false;
		meshes[i].applyMatrix4(new THREE.Matrix4().makeTranslation(x, y, z));
	}
};

MeshUtilities.GetGeometryCenter = function (geometry)
{
	if (!geometry.boundingBox)
		computeBoundingBox();

	let centerX = (geometry.boundingBox.min.x + geometry.boundingBox.max.x) / 2;
	let centerY = (geometry.boundingBox.min.y + geometry.boundingBox.max.y) / 2;
	let centerZ = (geometry.boundingBox.min.z + geometry.boundingBox.max.z) / 2;

	let geometryCenter = new THREE.Vector3(centerX * this.scale.x, centerY * this.scale.y, centerZ * this.scale.z);

	return geometryCenter;
};


MeshUtilities.CloneMeshSettings = function (originalMesh, clonedMesh)
{
	clonedMesh.type = originalMesh.type;

	clonedMesh.element = originalMesh.element;

	clonedMesh.component3DObject = originalMesh.component3DObject;

	clonedMesh.stallIndex = originalMesh.stallIndex;
	clonedMesh.eWall = originalMesh.eWall;

	if (originalMesh.children)
		for (let i = 0; i < originalMesh.children.length; i++)
		{
			MeshUtilities.CloneMeshSettings(originalMesh.children[i], clonedMesh.children[i]);
		}
};

MeshUtilities.CloneMesh = function (originalMesh)
{
	clonedMesh = originalMesh.clone();

	MeshUtilities.CloneMeshSettings(originalMesh, clonedMesh);

	/*////clonedMesh.type = originalMesh.type;

	clonedMesh.element = originalMesh.element;

	clonedMesh.stallIndex = originalMesh.stallIndex;
	clonedMesh.eWall = originalMesh.eWall;
	*/

	return clonedMesh;
};

MeshUtilities.CloneMeshes = function (originalMeshes, cloneMeshes)
{
	for (i = 0; i < originalMeshes.length; i++)
	{
		cloneMeshes[i] = MeshUtilities.CloneMesh(originalMeshes[i]);
	}
};

MeshUtilities.ReverseGeometryFaces = function (geometry)
{
	let tempIndex;

	for (i = 0; i < geometry.faces.length; i++)
	{
		tempIndex = geometry.faces[i].a;

		geometry.faces[i].a = geometry.faces[i].c;

		geometry.faces[i].c = tempIndex;
	}

	geometry.computeVertexNormals();
	//geometry.computeFaceNormals();

	if (geometry.__directGeometry)
		delete geometry.__directGeometry;
};

MeshUtilities.CreateMeshFromCrossSectionPoints = function (xyCrossSectionPointsFront, xyCrossSectionPointsBack, matter, extrudeSettings, x, y, z, rotTex90, frontSideClosed, backSideClosed)
{
	if (rotTex90 == undefined || rotTex90 == null)
	{
		rotTex90 = false;
	}

	xyCrossSectionPointsFront = AuxUtilities.Convert2DimensionalArrayToXYValuedArray(xyCrossSectionPointsFront);

	xyCrossSectionPointsBack = AuxUtilities.Convert2DimensionalArrayToXYValuedArray(xyCrossSectionPointsBack);

	let totalGeom = new THREE.Geometry();

	totalGeom = GeometryUtilities.ExtrudeGeometry(xyCrossSectionPointsFront, xyCrossSectionPointsBack, extrudeSettings.depth, rotTex90, frontSideClosed, backSideClosed);

	totalGeom.matrixAutoUpdate = false;
	totalGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(x, y, z));

	let mesh = new THREE.Mesh(totalGeom, matter);

	mesh.type = ELEM_ROOFING;

	return mesh;
};

MeshUtilities.IntersectMesh = function (mesh, intersectMesh)
{
	if (mesh.children)
		for (let i = 0; i < mesh.children.length; i++)
		{
			mesh.children[i] = MeshUtilities.IntersectMesh(mesh.children[i], intersectMesh);
			mesh.children[i].parent = mesh;
		}

	if (mesh.geometry.type != "BufferGeometry")
	{
		let material = mesh.material;
		let csgMesh = new ThreeBSP(mesh);

		let csgIntersectMesh = new ThreeBSP(intersectMesh);
		let intersect_bsp = csgMesh.intersect(csgIntersectMesh);

		mesh = intersect_bsp.toMesh(material);
	}

	return mesh;
};

MeshUtilities.SubtractMesh = function (mesh, subtractMesh)
{
	for (let i = 0; i < mesh.children.length; i++)
	{
		mesh.children[i] = MeshUtilities.SubtractMesh(mesh.children[i], subtractMesh);
		mesh.children[i].parent = mesh;
	}

	if (mesh.geometry.type != "BufferGeometry" && mesh.geometry.faces.length>0)
	{
		let material = mesh.material;
		let element = mesh.element;
		let type = mesh.type;
		let meshesEWall = mesh.eWall;
		let castShadow = mesh.castShadow;
		let receiveShadow = mesh.receiveShadow;
		let matrix = mesh.matrix;

		let csgMesh = new ThreeBSP(mesh);

		let csgSubractMesh = new ThreeBSP(subtractMesh);

		let subtract_bsp = csgMesh.subtract(csgSubractMesh);


		let result = subtract_bsp.toMesh(new THREE.MeshLambertMaterial());



		for (let i = 0; i < result.geometry.faces.length; i++)
		{
			if (result.geometry.faces[i].materialIndex > 0)
				result.type = 11;
		}

		result.material = material;
		result.element = element;
		result.type = type;
		result.eWall = meshesEWall;
		result.castShadow = castShadow;
		result.receiveShadow = receiveShadow;

		result.matrix = matrix;
		result.matrixWorldNeedsUpdate = true;

		result.geometry.computeFaceNormals();

		return result;
	}
	else
		return mesh;
};

MeshUtilities.CSGMeshWithMeshes = function (meshes, subtractMesh, eWall, elementType, CsgFunction)
{
	let meshType;

	for (i = 0; i < meshes.length; i++)
	{
		if (!RUN_IN_OPTIMISED)
		{
			if ((meshes[i].element && meshes[i].element.type == ELEM_WALL && meshes[i].element.eWall == eWall) || meshes[i].type == ELEM_WALL_RAFTER)
			{
				meshType = meshes[i].type;

				meshes[i] = CsgFunction(meshes[i], subtractMesh);

				meshes[i].type = meshType;
			}
		}
		else
		{
			if (elementType != null && elementType != undefined)
			{
				if ((eWall == -1 || meshes[i].eWall == eWall) && meshes[i].type == elementType)
				{
					meshType = meshes[i].type;
					meshes[i] = CsgFunction(meshes[i], subtractMesh);
					meshes[i].type = meshType;
				}
			}
			else
			if ((meshes[i].element && meshes[i].element.type == ELEM_WALL && meshes[i].element.eWall == eWall) || (meshes[i].eWall != undefined && meshes[i].eWall != null && meshes[i].eWall == eWall))
			{
				meshType = meshes[i].type;
				meshes[i] = CsgFunction(meshes[i], subtractMesh);
				meshes[i].type = meshType;
			}
			else
			if (meshes[i].eWall != undefined && meshes[i].eWall != null && meshes[i].eWall == eWall)
			{
				meshType = meshes[i].type;
				meshes[i].visible = false;
				meshes[i].type = meshType;
			}
		}

		meshes[i].updateMatrixWorld();
	}

	return meshes;
};

MeshUtilities.SubtractMeshFromMeshes = function (meshes, subtractMesh, eWall, elementType)
{
	for (let i = 0; i < meshes.length; i++)
	{
		if (meshes[i])
		{
			if (!RUN_IN_OPTIMISED)
			{
				if ((meshes[i].element && meshes[i].element.type == ELEM_WALL && meshes[i].element.eWall == eWall) || meshes[i].type == ELEM_WALL_RAFTER)
				{
					meshes[i] = MeshUtilities.SubtractMesh(meshes[i], subtractMesh);
				}
			}
			else
			{
				if (elementType != null && elementType != undefined)
				{
					if ((eWall == -1 || meshes[i].eWall == eWall) && meshes[i].type == elementType)
						meshes[i] = MeshUtilities.SubtractMesh(meshes[i], subtractMesh);
				}
				else
				if ((meshes[i].element && meshes[i].element.type == ELEM_WALL && meshes[i].element.eWall == eWall) || (meshes[i].eWall != undefined && meshes[i].eWall != null && meshes[i].eWall == eWall))
				{
					meshes[i] = MeshUtilities.SubtractMesh(meshes[i], subtractMesh);
				}
				else
				if (meshes[i].eWall != undefined && meshes[i].eWall != null && meshes[i].eWall == eWall)
				{
					meshes[i].visible = false;
				}
			}

			meshes[i].updateMatrixWorld();
		}
	}

	return meshes;
};

MeshUtilities.MergeMeshIntoGeometry = function (totalGeometry, mesh, materials, type)
{
	for (let i = 0; i < mesh.children.length; i++)
	{
		if (mesh.children[i].type == type || type == undefined)
			MeshUtilities.MergeMeshIntoGeometry(totalGeometry, mesh.children[i], materials);

		mesh.children[i] = null;
	}

	if (mesh.geometry.type != "BufferGeometry" && mesh.visible)
	{

		////if (mesh.material.type == "MultiMaterial")
		if (mesh.material.length > 0)
		{
			GeometryUtilities.IncFaceIndex(mesh.geometry, materials.length);

			////for (let j = 0; j < mesh.material.materials.length; j++)
			for (let j = 0; j < mesh.material.length; j++)
			{
				mesh.material[j].element = mesh.element;
				materials.push(mesh.material[j]);
			}
		}
		else
		{
			GeometryUtilities.SetFaceIndex(mesh.geometry, materials.length);

			let elementParentObject = MeshUtilities.GetElementParentObject(mesh);

			if (elementParentObject)
				mesh.material.element = elementParentObject.element;
			else
				mesh.material.element = null;

			materials.push(mesh.material);
		}

		totalGeometry.merge(mesh.geometry, mesh.matrixWorld);
	}
};

MeshUtilities.MergeMeshGeometry = function (mesh, type)
{
	mesh.updateMatrixWorld();

	if (mesh.children.length == 0)
		return mesh;
	else
	{
		let newMesh = new THREE.Mesh();

		let materials = [];

		let totalGeometry = new THREE.Geometry();

		MeshUtilities.MergeMeshIntoGeometry(totalGeometry, mesh, materials, type);

		////newMesh = new THREE.Mesh(totalGeometry, new THREE.MeshFaceMaterial(materials));

		newMesh = new THREE.Mesh(totalGeometry, materials);

		return newMesh;
	}
};

MeshUtilities.SetElement = function (mesh, element)
{
	if (mesh.material.length)
	{
		for (let j = 0; j < mesh.material.length; j++)
		{
			mesh.material[j].element = element;
		}
	}

	mesh.material.element = element;

	mesh.element = element;
};

MeshUtilities.MergeMeshes = function (meshes, type)
{
	let mesh = new THREE.Mesh();

	mesh.children = meshes;

	return MeshUtilities.MergeMeshGeometry(mesh, type);
};

MeshUtilities.GetElementParentObject = function (object)
{
	let current = object;

	while (current && (current.element == null || current.element == undefined))
		current = current.parent;

	return current;
};

MeshUtilities.SetMeshType = function (mesh, type)
{
	for (let i = 0; i < mesh.children.length; i++)
	{
		MeshUtilities.SetMeshType(mesh.children[i], type);
	}

	mesh.type = type;
};


MeshUtilities.SetMeshCastReceiveShadow = function (mesh, castShadow, receiveShadow)
{
	for (let i = 0; i < mesh.children.length; i++)
	{
		MeshUtilities.SetMeshCastReceiveShadow(mesh.children[i], castShadow, receiveShadow);
	}

	mesh.castShadow = castShadow;
	mesh.receiveShadow = receiveShadow;
};

MeshUtilities.SetMaterialOpacity = function (mesh, opacity)
{
	if (mesh.children)
	{
		for (let i = 0; i < mesh.children.length; i++)
		{
			if (mesh.children[i])
				MeshUtilities.SetMaterialOpacity(mesh.children[i], opacity);
		}
	}
	else
	{
		//
	}

	Material.SetMaterialOpacity(mesh.material, opacity);
};

MeshUtilities.RevertMaterialOpacity = function (mesh)
{
	for (let i = 0; i < mesh.children.length; i++)
	{
		MeshUtilities.RevertMaterialOpacity(mesh.children[i]);
	}

	Material.RevertMaterialOpacity(mesh.material);
};

MeshUtilities.RemoveAndDestroyMesh = function (mesh)
{
	for (let i = 0; i < mesh.children.length; i++)
	{
		if (mesh.children[i])
		{
			MeshUtilities.RemoveAndDestroyMesh(mesh.children[i]);

			mesh.children[i] = null;
		}
	}

	mesh.children = [];

	threeScene.remove(mesh);
	threeRenderer.shadowMap.needsUpdate = true;
	mesh = null;
};

MeshUtilities.RemoveAndDestroyMeshes = function (meshes)
{
	for (i = 0; i < meshes.length; i++)
	{
		threeScene.remove(meshes[i]);
		threeRenderer.shadowMap.needsUpdate = true;
		meshes[i] = null;
	}

	meshes = [];
};
