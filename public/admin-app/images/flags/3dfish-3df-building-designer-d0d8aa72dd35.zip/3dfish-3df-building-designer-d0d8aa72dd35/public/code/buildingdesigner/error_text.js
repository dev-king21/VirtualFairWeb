function ErrorText()
{
}

ErrorText.WALL_HAS_ELEMENTS = "Walls with elements on them cannot have their style changed";
