/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-undef */

function Floor()
{
	////this.width = width;
	this.length = buildingDesigner.building.length - Wall.WALLTHICKNESS * 2;

	if (!Floor.OPTIONS)
	{
		Floor.OPTIONS = {};
	}
	this.floorTextureFileName = Floor.OPTIONS.texture || "";
	this.floorTexture = null;
	this.floorColor = Floor.OPTIONS.color || 0xC29369;

	this.joistTextureFileName = Floor.OPTIONS.joist_texture || "Southern_yellowpine_horizontal";
	this.joistTexture = null;
	this.joistColor = Floor.OPTIONS.joist_color || 0xFFFFFF;

	this.regenerate = true;

	this.SetFloorColor = function (color)
	{
		this.floorColor = color;
	};

	this.SetFloorTextureFileName = function (fileName)
	{
		this.floorTextureFileName = fileName;
	};

	this.SetSelected = function (selected)
	{
		this.selected = selected;
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.GetTextures = function ()
	{
		if (this.floorTextureFileName != "")
		{
			this.floorTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.floorTextureFileName, buildingDesigner.building.roofRafter.wallWidth, this.length);
		}
		else
			this.floorTexture = null;


		if (this.joistTextureFileName != "")
		{
			this.joistTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.joistTextureFileName, -1, -1);
		}
		else
			this.joistTexture = null;
	};

	/* looking for runners? They are in base.js */

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			this.GetTextures();

			////if (TexturesDataUtilities.TextureLoaded(this.floorTexture))
			{
				//let joistlength = buildingDesigner.building.roofRafter.wallWidth - (Floor.JOIST_THICKNESS * 2);
				let numjoists = Math.floor(this.length / Floor.JOIST_SPACING);

				let bandMatter = new THREE.MeshStandardMaterial({
					color: this.joistColor,
					map: this.joistTexture,
					roughness: 1.0,
					metalness: METALNESS
				});

				let bandBoard = new THREE.BoxGeometry(Floor.JOIST_THICKNESS, Floor.JOIST_HEIGHT, this.length);

				let frontBand = new THREE.Mesh(bandBoard, bandMatter);
				frontBand.matrixAutoUpdate = false;
				frontBand.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.roofRafter.wallWidth / 2 + Floor.JOIST_THICKNESS / 2, Floor.JOIST_HEIGHT / 2, 0));

				buildingMeshes.push(frontBand);


				let backBand = new THREE.Mesh(bandBoard, bandMatter);
				backBand.matrixAutoUpdate = false;
				backBand.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.roofRafter.wallWidth / 2 - Floor.JOIST_THICKNESS / 2, Floor.JOIST_HEIGHT / 2, 0));

				buildingMeshes.push(backBand);

				let joistBoardGeometry = new THREE.BoxGeometry(buildingDesigner.building.roofRafter.wallWidth - Floor.JOIST_THICKNESS * 2, Floor.JOIST_HEIGHT, Floor.JOIST_THICKNESS);

				let joist;

				let minZ = -this.length / 2 + Floor.JOIST_THICKNESS / 2;

				if (this.length - Floor.JOIST_SPACING * numjoists > Floor.JOIST_SPACING / 2)
					numjoists++;

				for (let i = 0; i < numjoists; i++)
					joist = new THREE.Mesh(joistBoardGeometry, bandMatter);
				joist.matrixAutoUpdate = false;
				joist.applyMatrix4(new THREE.Matrix4().makeTranslation(0.0, Floor.JOIST_HEIGHT / 2, minZ + (i * Floor.JOIST_SPACING)));

				buildingMeshes.push(joist);

				joist = new THREE.Mesh(joistBoardGeometry, bandMatter);
				joist.matrixAutoUpdate = false;
				joist.applyMatrix4(new THREE.Matrix4().makeTranslation(0.0, Floor.JOIST_HEIGHT / 2, this.length / 2 - Floor.JOIST_THICKNESS / 2));

				buildingMeshes.push(joist);

				let floorMater = new THREE.MeshStandardMaterial({
					color: this.floorColor,
					map: this.floorTexture,
					roughness: 1.0,
					metalness: METALNESS
				});

				let floorGeom = new THREE.BoxGeometry(buildingDesigner.building.roofRafter.wallWidth, Floor.FLOOR_PANEL_THICKNESS, this.length);

				floorGeom.matrixAutoUpdate = false;
				floorGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(0.0, Floor.JOIST_HEIGHT + Floor.FLOOR_PANEL_THICKNESS / 2, 0.0));

				let mesh = new THREE.Mesh(floorGeom, floorMater);
				mesh.type = ELEM_FLOORING;

				mesh.castShadow = true;
				mesh.receiveShadow = true;

				buildingMeshes.push(mesh);

				this.regenerate = false;
			}
		}
	};
}

Floor.Configure = function (data)
{
	if (data)
	{
		Floor.JOIST_THICKNESS = data.joist_thickness;
		Floor.JOIST_HEIGHT = data.joist_height;
		Floor.JOIST_SPACING = data.joist_spacing;
		Floor.FLOOR_PANEL_THICKNESS = data.panel_thickness;
		Floor.OPTIONS = data.options;

		Floor.FLOOR_THICKNESS = Floor.JOIST_HEIGHT + Floor.FLOOR_PANEL_THICKNESS;
	}
};


Floor.JOIST_THICKNESS = BOARD_2x4_THICKNESS;
Floor.JOIST_HEIGHT = BOARD_2x4_WIDTH;
Floor.JOIST_SPACING = 1.33;
Floor.FLOOR_PANEL_THICKNESS = 0.062; // 0.062 = 0.75 inches
Floor.FLOOR_THICKNESS = Floor.JOIST_HEIGHT + Floor.FLOOR_PANEL_THICKNESS;
Floor.OPTIONS = {};
