/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Anchors(buttonData)
{
	////Element.call(this, "Anchors", "Anchors", "", Anchors.radius*2, Base.JOISTSIZE, "", "", Anchors.radius*2, price);

	Element.call(this, buttonData);

	buttonData.type = ELEM_ANCHORS;

	this.anchorColor = 0xFFFFFF;
	this.anchorMaterial = 0xFFFFFF;

	this.draggable = false;

	this.regenerate = true;

	this.mesh = null;

	this.SetPos(0, 0, 0);

	this.GetMatrix = function()
	{
		return this.mesh.matrix;
	};

	this.AddAnchor = function(x, y, z)
	{
		let geometry = new THREE.CylinderGeometry(Anchors.radius, Anchors.radius, buttonData.height, 4, 1);

		geometry.matrixAutoUpdate = false;
		geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(x, y, z));

		this.anchorMater = new THREE.MeshStandardMaterial( { color: this.anchorColor, map: null, roughness: 1.0, metalness: METALNESS } );

		let anchorMesh = new THREE.Mesh(geometry, this.anchorMater);

		this.mesh.add(anchorMesh);
	};

	this.Generate = function(buildingMeshes)
	{
		if (this.regenerate)
		{
			this.Destroy();

			this.mesh = new THREE.Mesh();

			let x1 = -buildingDesigner.building.width/2;
			let x2 = buildingDesigner.building.width/2;
			let length2 = buildingDesigner.building.length/2;

			if (this.selected)
			{
				this.anchorColor = 0x0000FF;
				////this.GenerateSelectedBoxes(this.mesh, new THREE.Matrix4().makeTranslation(0, -buttonData.height, length2), this.component3DObjects.scale);
			}
			else
				this.anchorColor = 0xFFFFFF;

			this.AddAnchor( x1, -buttonData.height/2, length2 - Anchors.radius * 2);
			this.AddAnchor( x2, -buttonData.height/2, length2 - Anchors.radius * 2);
			this.AddAnchor( x2, -buttonData.height/2, -length2 + Anchors.radius * 2);
			this.AddAnchor( x1, -buttonData.height/2, -length2 + Anchors.radius * 2);

			////this.mesh = MeshUtilities.MergeMeshGeometry(this.mesh);

			this.mesh.type = ELEM_ANCHORS;

			MeshUtilities.SetElement(this.mesh, this);

			this.UpdateMatrix();

			this.regenerate = false;
		}

		return this.mesh;
	};

	this.UpdateMatrix = function()
	{
		if (this.mesh)
		{
			let matrix = new THREE.Matrix4();

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z));

			this.mesh.matrix = new THREE.Matrix4();
			this.mesh.matrixAutoUpdate = false;
			this.mesh.applyMatrix4(matrix);
		}
	};
}

Anchors.AddAnchors = function(buttonData)
{
	let anchors = new Anchors(buttonData);

	Elements.AddElement(anchors);

	buildingDesigner.building.SetRegenerateElementMeshes(true);

	return anchors;
};

Anchors.radius = 0.1;
