/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function ShedBuildingDesigner(background, groundTextureName)
{
	BuildingDesigner.call(this, background, groundTextureName);

	BuildingDesigner.buildingType = BUILDING_SHED;

	this.CreateBuilding = async function(buildingID, sizeData, rafter)
	{
		if (this.building)
			this.building.Destroy();

		this.buildingButtonData = GuiDataUtilities.GetButtonData(buildingDesigner.buildingID);
		let buildEngine = BuildingDesigner.GetBuildEngineCode(buildingID);

		if (buildEngine != null)
		{
			switch (buildEngine.toLowerCase())
			{
			case ("barn"):
				this.building = new ShedBuilding(buildingID, rafter, sizeData);

				ElementsMenu.SetDormersTabVisibility(false);
				break;

			case ("bentbow"):
			case ("aframe"):
			case ("gable"):
				this.building = new ShedBuilding(buildingID, rafter, sizeData);

				ElementsMenu.SetDormersTabVisibility(false);
				break;

			case ("manor"):
				this.building = new ManorShedBuilding(buildingID, rafter, sizeData);

				ElementsMenu.SetDormersTabVisibility(true, sizeData.width_display);
				break;
			}
		}

		await this.building.Initialize();

		////ElementsMenu.ElementsListPricingUpdate();
	};

	this.MouseOver = function(mousepos)
	{};

	this.OnLeftMouseDownOrTouchDelayed = async function()
	{
		let elementAndPos;
		if (!GUIInput.touchStart)
		{
			/*////if (buildingDesigner.building)
				buildingDesigner.building.ClearSelections();
				*/

			if (Elements.draggableElement)
			{
				GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.IDLE;

				GUIInput.EndDraggingElement();
			}
			else
			if (GUIInput.currentGuiMode == GUIInput.GUI_MODE.DESIGN_EDITOR)
			{
				switch (GUIInput.currentDesignEditorMode)
				{
				case GUIInput.DESIGN_EDIT_MODE.ADD_ELEMENT:

					break;

				case GUIInput.DESIGN_EDIT_MODE.IDLE:
				case GUIInput.DESIGN_EDIT_MODE.SET_PARTITION:
					let vecDelta = new THREE.Vector2().subVectors(GUIInput.vecCurrentMousePos, GUIInput.vecLastMousePos);

					let regenerate = false;
					////buildingDesigner.building.ClearSelections();
					let selectedObject = Elements.GetSelectedElement();

					if (vecDelta.length() < 4 && buildingDesigner.building)
					{
						elementAndPos = buildingDesigner.building.GetSelectedElement({
							x: GUIInput.vecCurrentMousePos.x,
							y: GUIInput.vecCurrentMousePos.y
						});

						if (elementAndPos != null && elementAndPos.element != null)
						{
							selectedObject = elementAndPos;

							//don't set regenerate = true here since a dragging element function will be called that will regenerate
						}
						else
						{
							if (selectedObject)
							{
								regenerate = true;
								selectedObject.SetSelected(false);
							}

							selectedObject = null;
						}

						let buildingSelectedDistance = buildingDesigner.building.IsBuildingSelected({
							x: GUIInput.vecCurrentMousePos.x,
							y: GUIInput.vecCurrentMousePos.y
						});

						if ((!selectedObject && buildingSelectedDistance >= 0) || (buildingSelectedDistance >= 0 && MathUtilities.Round(buildingSelectedDistance, 0) < MathUtilities.Round(selectedObject.distance, 0)))
						{
							if (!buildingDesigner.building.selected)
							{
								buildingDesigner.building.SetSelected(true);
								selectedObject = buildingDesigner.building;
							}
							else
								buildingDesigner.building.SetSelected(false);

							regenerate = true;
						}
						else
						if (selectedObject)
						{
							selectedObject.element.SetSelected(true);

							if (selectedObject.element.draggable)
							{
								let mtxWorldToElem = new THREE.Matrix4().getInverse(elementAndPos.element.GetMatrix());
								elementAndPos.vectorPos.matrixAutoUpdate = false;
								elementAndPos.vectorPos.applyMatrix4(mtxWorldToElem);

								elementAndPos.vectorPos.multiply(elementAndPos.element.component3DObjects.scale);

								elementAndPos.element.SetMousePosOnElementVector(elementAndPos.vectorPos);

								Elements.StartDraggingElement(elementAndPos.element);

								GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT;

								regenerate = true;
							}
						}

						if (regenerate && buildingDesigner.building)
						{
							buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
							buildingDesigner.Draw();
						}
					}

					ElementsMenu.ElementsListPricingUpdate();

					break;
				}
			}
			else
			{
				elementAndPos = buildingDesigner.building.GetSelectedElement({
					x: GUIInput.vecCurrentMousePos.x,
					y: GUIInput.vecCurrentMousePos.y
				});
			}

			if (elementAndPos == null || elementAndPos.element == null)
			{
				GUIInput.OnRotateMouseOrTouch({
					clientX: GUIInput.vecCurrentMousePos.x,
					clientY: GUIInput.vecCurrentMousePos.y
				});
			}


			GUIInput.touchStart = true;
		}
	};

	this.DeleteSelectedElement = function()
	{
		Elements.DeleteSelectedElement();

		Elements.ClearNulls();

		buildingDesigner.building.SetRegenerateElementMeshes(true);

		this.building.SetBuildingModified();
	};

	/**
	 * @function ShedBuildingDesigner.LaunchCreateBuildingCode
	 * @async
	 * @param {string} buildingID
	 * @param {number} sizeIndex
	 * @param {string|Object} savedDesign
	 */
	this.LaunchCreateBuildingCode = async function(buildingID, sizeIndex, savedDesign)
	{
		if (savedDesign)
			BuildingDesigner.buildingLoadedFromDesign = true;
		else
			BuildingDesigner.buildingLoadedFromDesign = false;

		Elements.loadedObjectData = [];
		if (BuildingDesigner.buildingChangedbyUser && buildingDesigner.building)
		{
			BuildingDesigner.previousWidth = buildingDesigner.building.sizeData.width_display;
			BuildingDesigner.previousLength = buildingDesigner.building.sizeData.length_display;
			BuildingDesigner.previousSiding = buildingDesigner.building.walls.sidingColorData.siding_id;
			BuildingDesigner.previousSidingCategory = buildingDesigner.building.walls.sidingCategoryData.category_id;
			BuildingDesigner.previousTrim = buildingDesigner.building.roof.cornerTrimColorID;
			BuildingDesigner.previousRoofing = buildingDesigner.building.roof.data.roofing_id;
			BuildingDesigner.previousRoofingCategory = buildingDesigner.building.roof.categoryID;
		}
		else
		{
			BuildingDesigner.buildingChangedbyUser = false;
		}

		buildingDesigner.buildingID = buildingID;

		if (BuildingDesigner.buildingChangedbyUser)
		{
			buildingDesigner.selectedBuildingSizeIndex = buildingDesigner.GetBuildingIndexForWidthLengthHeightDisplay(BuildingDesigner.previousWidth,BuildingDesigner.previousLength,buildingDesigner.buildingSizes[0].height_display);
		}
		else
		{
			buildingDesigner.selectedBuildingSizeIndex = sizeIndex;
		}
		if (BuildingDesigner.buildingLoadedFromDesign)
		{
			if (savedDesign.localName)
			{
				buildingDesigner.xmlDesignDoc = savedDesign;
			}
			else
			{
				buildingDesigner.savedDesignObject = savedDesign;
			}
		}

		await ShedBuildingDesigner.CreateBuildingThread();

		ElementsMenu.DestroyContextMenu();
	};

	this.OnClickChangeBuildingSize = async function(event)
	{
		// buildingDesigner.selectedBuildingSizeIndex = event.currentTarget.iSizeIndex;
		let newSelectedBuildingSizeIndex = event.currentTarget.iSizeIndex;
		if (buildingDesigner.selectedBuildingSizeIndex === newSelectedBuildingSizeIndex)
		{
			return; //same size selected
		}

		buildingDesigner.building.designID = "";
		GuiDataUtilities.displayDesignID("");

		let err, rafterData;
		//Rafters.rafterData = await GuiDataUtilities.LoadRafterData(buildingDesigner.buildingID, MathUtilities.Round(buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].width, 0));
		[err,rafterData] = await to(GuiDataUtilities.LoadRafterDataE(buildingDesigner.buildingID, MathUtilities.Round(buildingDesigner.buildingSizes[newSelectedBuildingSizeIndex].width, 0)));

		if (err)
		{
			alert("Unable to contact server.");
			return;
		}

		buildingDesigner.selectedBuildingSizeIndex = newSelectedBuildingSizeIndex;
		Rafters.rafterData = rafterData;

		let rafter = null;

		if (Rafters.rafterData.length > 0)
		{
			rafter = new Rafter(Rafters.rafterData[0]);
			rafter.Process();
		}

		await buildingDesigner.building.SetRafterAndSizeData(rafter, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex]);

		if (event.currentTarget)
		{
			ElementsMenu.SetBuildingSizeChecked(event.currentTarget.iSizeIndex);
		}
		else if (event.target)
		{
			ElementsMenu.SetBuildingSizeChecked(event.target.iSizeIndex);
		}

		buildingDesigner.InitializeCameraAndRender();
	};

	this.IsValidBuilding = function(buildingID)
	{
		if (buildingID == undefined || buildingID == null || buildingID == "")
			return false;

		let buildEngine = BuildingDesigner.GetBuildEngineCode(buildingID);

		if (buildEngine != null)
		{
			switch (buildEngine.toLowerCase())
			{
			case ("barn"):
			case ("bentbow"):
			case ("aframe"):
			case ("gable"):
			case ("manor"):
				return true;
				// break; (unreachable code)
			}
		}

		return false;
	};
}

ShedBuildingDesigner.prototype = Object.create(BuildingDesigner.prototype);
ShedBuildingDesigner.prototype.constructor = ShedBuildingDesigner;

ShedBuildingDesigner.CreateBuildingThread = async function()
{
	clearTimeout(this.createBuildingThreadHandle);

	if (buildingDesigner.selectedBuildingSizeIndex == -1)
		buildingDesigner.selectedBuildingSizeIndex = 0;

	if (buildingDesigner.xmlDesignDoc != undefined && buildingDesigner.xmlDesignDoc != null)
	{
		Rafters.rafterData = BuildingDesigner.LoadRafterDataFromXML(buildingDesigner.xmlDesignDoc);

		Rafters.rafterData[0].designLoaded = true;
	}
	else if (buildingDesigner.savedDesignObject && buildingDesigner.savedDesignObject.TDFDESIGN)
	{
		Rafters.rafterData = BuildingDesigner.LoadRafterDataFromObject(buildingDesigner.savedDesignObject.TDFDESIGN);Rafters.rafterData[0].designLoaded = true;
	}
	else
	{
		Rafters.rafterData = await GuiDataUtilities.LoadRafterData(buildingDesigner.buildingID, MathUtilities.Round(buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].width, 0));
		if (Rafters.rafterData.length === 0)
		{
			alert("Error retrieving building data from server. Please contact support. Error Code: RD01");
		}
		Rafters.rafterData[0].designLoaded = false;
	}

	let rafter = null;

	if (Rafters.rafterData.length > 0)
	{
		rafter = new Rafter(Rafters.rafterData[0]);
		rafter.Process();
	}

	await buildingDesigner.CreateBuilding(buildingDesigner.buildingID, buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex], rafter);

	if (buildingDesigner.xmlDesignDoc != undefined && buildingDesigner.xmlDesignDoc != null)
	{
		await buildingDesigner.building.LoadTDFDesignerFileVersion10(buildingDesigner.xmlDesignDoc);
	}
	else if (buildingDesigner.savedDesignObject && buildingDesigner.savedDesignObject.TDFDESIGN)
	{
		await buildingDesigner.building.LoadTDFDesignerObject(buildingDesigner.savedDesignObject);
	}

	ElementsMenu.UpdateAvailableSizes(buildingDesigner.buildingSizes, buildingDesigner.selectedBuildingSizeIndex);

	ElementsMenu.SetBuildingSizeChecked(buildingDesigner.selectedBuildingSizeIndex);

	buildingDesigner.InitializeCameraAndRender();

	buildingDesigner.xmlDesignDoc = null;
	buildingDesigner.savedDesignObject = null;

};

ShedBuildingDesigner.LoadDataForGUIRequiredForStartingTheBuildingProcess = async function()
{
	let buttonParams = {
		subscriber_id: SubscriberDataUtilities.subscriber,
		series_code: SubscriberDataUtilities.series_code,
		building_type: BUILDING_STRING[BuildingDesigner.buildingType]
	};
	[GuiDataUtilities.buildingsButtonData, GuiDataUtilities.sidingCategoryButtonData, GuiDataUtilities.sidingColorButtonData, GuiDataUtilities.roofingButtonData, GuiDataUtilities.trimColorButtonData, GuiDataUtilities.windowsButtonData, GuiDataUtilities.rampsData, GuiDataUtilities.dormersButtonData, TexturesDataUtilities.dataLoaded] = await Promise.all([
		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Buildings", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("SidingCategories", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("SidingColors", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Roofing", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("TrimColors", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Windows", buttonParams),

		GuiDataUtilities.GetRamps(),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Dormers", buttonParams),

		TexturesDataUtilities.GetTextureDataFromServer()
	]);
};

ShedBuildingDesigner.LoadDataForGUI = async function()
{
	let buttonParams = {
		subscriber_id: SubscriberDataUtilities.subscriber,
		series_code: SubscriberDataUtilities.series_code,
		building_type: BUILDING_STRING[BuildingDesigner.buildingType]
	};
	[GuiDataUtilities.doorsButtonData, GuiDataUtilities.hingesButtonData, GuiDataUtilities.optionsButtonData, GuiDataUtilities.shelvesButtonData] = await Promise.all([

		GuiDataUtilities.currentGuiDataUtilities.LoadElementAndCategoryButtons("Doors"),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Hinges", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Options", buttonParams),

		GuiDataUtilities.currentGuiDataUtilities.LoadButtons("Shelves", buttonParams)
	]);
};

/**
 * Initialize the building designer object, set the camera and render
 * @function ShedBuildingDesigner.Initialize
 * @async
 */
ShedBuildingDesigner.Initialize = async function()
{
	if (DEBUG)
	{
		console.log(THREE.REVISION);
	}

	if (BuildingDesigner.cachedVersion != BuildingDesigner.serverVersion)
	{
		location.reload(true);
		return;
	}

	if (SubscriberDataUtilities.subscriber.length == 0)
	{
		SubscriberDataUtilities.subscriber = AuxUtilities.GetURLParameter("sc");
	}
	DEBUG = await BuildingDesigner.IsDebugVersion();
	if (DEBUG)
	{
		console.log("SBDI - 1");
	}
	await AuxUtilities.sleep(5);
	BuildingDesigner.buildingType = BUILDING_SHED;

	if (DEBUG)
	{
		console.log("SBDI - 2");
	}
	await AuxUtilities.sleep(5);
	await GuiDataUtilities.currentGuiDataUtilities.ProcessParametersCreateAdditionalHTMLAndConfigurePage("Shed Designer");
	if (DEBUG)
	{
		console.log("SBDI - 3");
	}
	await AuxUtilities.sleep(5);

	/*////if (location.origin.indexOf("localhost"))
	{
        let saveAsDefaultConfiguration = document.getElementById("saveAsDefaultConfiguration");

	    let editObjects = document.getElementById("editObjects");


	    saveAsDefaultConfiguration.style.display = "block";
	    editObjects.style.display = "inline";
    }*/

	let background = await GuiDataUtilities.GetBackground();
	if (DEBUG)
	{
		console.log("SBDI - 4");
	}
	await AuxUtilities.sleep(5);
	if (background && background.length > 0)
	{
		background = background[0];
	}
	else
	{
		background = new Object();

		background.texture = "sheddesigner_background";

		background.color = "rgb(255, 255, 255, 255)";
	}

	buildingDesigner = new ShedBuildingDesigner(background, tdf.groundTextureName);
	if (DEBUG)
	{
		console.log("SBDI - 5");
	}
	await AuxUtilities.sleep(5);
	BuildingDesigner.OnWindowResize();
	buildingDesigner.InitializeCameraAndRender();
	if (DEBUG)
	{
		console.log("SBDI - 6");
	}
	await AuxUtilities.sleep(5);

	if (DEBUG)
	{
		console.log("SBDI - 7");
	}
	await AuxUtilities.sleep(5);

	if (!await UserDataUtilities.IsSessionZipCodeSet())
	{
		window.location.href = "#zipCodeFormDiv";
		if3CloseLeftMenu();
	}

	if (SubscriberDataUtilities.subscriber)
	{
		let loader = new THREE.FontLoader();

		loader.load(Ruler.RULER_TEXT_FONT, function(font)
		{
			Ruler.rulerFont = font;
		});

		await buildingDesigner.GetFloorConstructionDetails(SubscriberDataUtilities.subscriber);
		if (DEBUG)
		{
			console.log("SBDI - 8");
		}
		await AuxUtilities.sleep(5);
		await ColorsDataUtilities.GetColorsDataFromServer();
		if (DEBUG)
		{
			console.log("SBDI - 9");
		}
		await AuxUtilities.sleep(5);
		await ShedBuildingDesigner.LoadDataForGUIRequiredForStartingTheBuildingProcess();
		if (DEBUG)
		{
			console.log("SBDI - 10");
		}
		await AuxUtilities.sleep(5);
		TexturesDataUtilities.AddToData(GuiDataUtilities.sidingColorButtonData);
		TexturesDataUtilities.AddToData(GuiDataUtilities.roofingButtonData);
		await BuildingDesigner.CreateOrLoadBuilding();
		buildingDesigner.InitializeCameraAndRender();
		ElementsMenu.SetAvailableSiding();
		ElementsMenu.SetAvailableTrim();
		ElementsMenu.SetAvailableRoofing();
		ElementsMenu.SetAvailableElements();
		buildingDesigner.building.horizLengthRuler.GetTexturesAsync();
		buildingDesigner.building.horizWidthRuler.GetTexturesAsync();
		buildingDesigner.building.vertHeightRuler.GetTexturesAsync();
		if (DEBUG)
		{
			console.log("SBDI - 11");
		}
		await AuxUtilities.sleep(5);
		BuildingDesigner.OnWindowResize();
		if (DEBUG)
		{
			console.log("SBDI - 12");
		}

		await AuxUtilities.sleep(5);

		if (DEBUG)
		{
			console.log("SBDI - 14");
		}
		await AuxUtilities.sleep(5);
		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		if (DEBUG)
		{
			console.log("SBDI - 15");
		}
		await AuxUtilities.sleep(5);
		buildingDesigner.Draw();
		if (DEBUG)
		{
			console.log("SBDI - 16");
		}
		await AuxUtilities.sleep(5);
		await ShedBuildingDesigner.LoadDataForGUI();

		if (DEBUG)
		{
			console.log("SBDI - 17");
		}
		await AuxUtilities.sleep(5);
		/* this is being called from ShedBuilding.Initialize inside of ShedBuildingDesigner.CreateBuilding */
		/* if (!BuildingDesigner.buildingLoadedFromDesign) {
			await buildingDesigner.building.InitializeSidingRoofingTrimAndDefaultElements();
		} */
		if (DEBUG)
		{
			console.log("SBDI - 18");
		}
		await AuxUtilities.sleep(5);
		await SubscriberDataUtilities.LoadData();
		if (DEBUG)
		{
			console.log("SBDI - 19");
		}
		await AuxUtilities.sleep(5);
		await ColorsDataUtilities.GetDoorColorsDataFromServer();
		if (DEBUG)
		{
			console.log("SBDI - 20");
		}
		await AuxUtilities.sleep(5);
		//add siding textures data
		// TexturesDataUtilities.AddToData(GuiDataUtilities.sidingColorButtonData);
		if (DEBUG)
		{
			console.log("SBDI - 22");
		}
		await AuxUtilities.sleep(5);
		//add roofing textures data
		// TexturesDataUtilities.AddToData(GuiDataUtilities.roofingButtonData);
		if (DEBUG)
		{
			console.log("SBDI - 22");
		}
		await AuxUtilities.sleep(5);
		ObjectDataUtilities.LoadData();
		if (DEBUG)
		{
			console.log("SBDI - 23");
		}
		await AuxUtilities.sleep(5);
		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		if (DEBUG)
		{
			console.log("SBDI - 24");
		}
		await AuxUtilities.sleep(5);
		buildingDesigner.building.SetBuildingModified();
		if (DEBUG)
		{
			console.log("SBDI - 25");
		}
		await AuxUtilities.sleep(5);

		ElementsMenu.SetAvailableSiding();
		ElementsMenu.SetAvailableRoofing();
		ElementsMenu.SetAvailableElements();
	}
	else
	{
		// alert("No Subscriber Detected");
		window.location.href = "https://sheddesigner2.3dfish.net/";
	}
};

BuildingDesigner.Initialize = ShedBuildingDesigner.Initialize;
