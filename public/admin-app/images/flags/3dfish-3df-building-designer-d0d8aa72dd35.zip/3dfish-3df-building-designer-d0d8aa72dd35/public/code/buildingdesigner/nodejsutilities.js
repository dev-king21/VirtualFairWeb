/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef, no-useless-escape */

/**
 * Helper method to parse the title tag from the html response.
 * @function getTitle
 * @param {string} text -- html text string to extract title from
 * @returns {string} title -- the text value contained in the title if any
 */
function getTitle(text)
{
	return text.match("<title>(.*)?</title>")[1];
}

function NodeJSUtilities()
{

}

NodeJSUtilities.nodeJSUrls = [];

NodeJSUtilities.Initialize = function (command, parameters)
{
	let protocol;

	if (AuxUtilities.IsHTTPS())
		protocol = "https://";
	else
		protocol = "http://";

	let url = document.location.href;

	if (AuxUtilities.IsRemote())
	{
		let urlString = url.toString().replace(/^(.*\/\/[^\/?#]*).*$/, "$1") + "/";

		if (urlString.indexOf("10.0.0.4") > -1 && urlString.indexOf("10.0.0.4:3000") == -1)
			urlString = urlString.replace("10.0.0.4", "10.0.0.4:3000");

		NodeJSUtilities.nodeJSUrls.push(urlString);
	}
	else
		NodeJSUtilities.nodeJSUrls.push(protocol + "localhost:3000/");
};

NodeJSUtilities.Query = async function (command, parameters, method)
{
	let dataString = "";
	if (method== null)
	{
		method="POST";
	}

	for (let i = 0; i < this.nodeJSUrls.length; i++)
	{
		dataString = await FileIO.GetFileData(this.nodeJSUrls[i] + command, parameters, method);

		if (dataString != "")
			break;
	}

	return dataString;
};

NodeJSUtilities.QueryE = async function (command, parameters, method)
{
	let dataString = "";
	let err;
	if (method== null)
	{
		method="POST";
	}

	for (let i = 0; i < this.nodeJSUrls.length; i++)
	{
		[err,dataString] = await to(FileIO.GetFileDataE(this.nodeJSUrls[i] + command, parameters, method));

		if (err)
		{
			throw (err);
		}
	}

	return dataString;
};

NodeJSUtilities.QueryS = async function (command, parameters, timeout = 30000)
{
	let dataString = "";
	let err;

	[err, dataString] = await to(promiseTimeout(timeout, FileIO.GetFileDataS(command, parameters)));

	if (err)
	{
		throw (err);
	}
	if (dataString.error)
	{
		throw (dataString.err);
	}

	return dataString;
};

// Unified Query, works with sockets or http post
NodeJSUtilities.UQuery = async function (command, parameters, timeout = 30000, callBack)
{
	if (timeout === null)
	{
		timeout = 30000;
	}
	let err, result;
	if (window.socket) {
		if (!socket.connected) {
			let interval = 15;
			let countdown = interval;
			while (!socket.connected) {
				$("#retryseconds").text(countdown)
				if (countdown === 0) {
					countdown = interval;
				}
				$("#noconnection").show();
				await AuxUtilities.sleep(1000);
				countdown--;
			}
			$("#noconnection").hide();
		}
		[err, result] = await to(NodeJSUtilities.QueryS(command, parameters, timeout));
		if (err)
		{
			if (callBack)
			{
				console.error(`Socket for ${command} returned error ${err}`);
				return;
			}
			throw err;
		}
		if (callBack)
		{
			callBack(result);
			return;
		}
		else
		{
			return result;
		}
	}
	[err,result] = await to(NodeJSUtilities.QueryE(command, parameters, "POST"));
	if (err)
	{
		if (callBack)
		{
			console.error(`HTTP request for ${command} returned error ${JSON.stringify(err)}`);
			return;
		}
		throw err;
	}
	if (callBack)
	{
		callBack(result);
		return;
	}
	else
	{
		return result;
	}
}

NodeJSUtilities.PQuery = async function (command, parameters, method)
{
	let dataString = "";

	for (let i = 0; i < this.nodeJSUrls.length; i++)
	{
		dataString = await FileIO.PGetFileData(this.nodeJSUrls[i] + command, parameters, method);

		if (dataString != "")
			break;
	}

	return dataString;
};


NodeJSUtilities.SaveDesignToWeb = function (subscriber_id, series_code, userID, location_number, design_id, designNameForWeb, building_type, data_format, designStr)
{
	let command = "saveDesignToWeb";

	let formData = new FormData();

	formData.append("subscriber_id", subscriber_id);
	formData.append("series_code", series_code);
	formData.append("userID", userID);
	formData.append("location_number", location_number);
	formData.append("tdf_version", tdf_version);
	formData.append("design_id", design_id);
	formData.append("designNameForWeb", designNameForWeb);
	formData.append("product_id",buildingDesigner.building.sizeData.product_id);
	formData.append("linked_product_id", buildingDesigner.building.sizeData.linked_product_id);
	formData.append("building_price_subtotal", building.subTotal);
	formData.append("shortDescription",building.baseDescription);
	formData.append("building_name", buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].building_display_name);
	formData.append("building_width", buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].width_display);
	formData.append("building_length", buildingDesigner.buildingSizes[buildingDesigner.selectedBuildingSizeIndex].length_display);
	formData.append("building_type", building_type);
	formData.append("data_format", data_format);

	let blob = new Blob([designStr], {
		type: "text/xml"
	});

	formData.append("designData", blob);

	for (let i = 0; i < this.nodeJSUrls.length; i++)
	{
		dataString = FileIO.SendFormData(this.nodeJSUrls[i] + command, formData);

		if (dataString != "")
			break;
	}

	return dataString;
};


NodeJSUtilities.Initialize();
