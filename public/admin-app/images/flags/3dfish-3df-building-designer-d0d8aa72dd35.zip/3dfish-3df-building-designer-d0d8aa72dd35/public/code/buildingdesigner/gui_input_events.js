/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2 */
/*eslint-disable no-console, no-unused-vars, no-undef*/
function GUIInput()
{}

GUIInput.vecCurrentMousePos = new THREE.Vector2(); // Current cursor position
GUIInput.vecLastMousePos = new THREE.Vector2(); // Previous cursor position

GUIInput.mouseDownOrTouchDelayed = null;

GUIInput.touchStart = false;
GUIInput.lastTap = 0;

GUIInput.ROTATE_SPEED = 0.2;

GUIInput.windowHalfX = window.innerWidth / 2;

GUIInput.targetRotation = 0;
GUIInput.targetRotationOnMouseDown = 0;

GUIInput.mouseX = 0;
GUIInput.mouseXOnMouseDown = 0;

GUIInput.mouseLeftButton = false;
GUIInput.mouseRightButton = false;

GUIInput.OnTouchyPinch = function (e, $target, data)
{
	//buildingDesigner.camera.ZoomScale(data.scale);
};

GUIInput.OnMouseDown = function (event)
{
	switch (event.button)
	{
	case 0: // LMB
		GUIInput.mouseLeftButton = true;
		GUIInput.OnLeftMouseDownOrTouch(event);
		break;
	case 1: // MMB
		GUIInput.OnMiddleMouseDown();
		break;
	case 2: // RMB
		GUIInput.touchStart = true;
		GUIInput.mouseRightButton = true;

		GUIInput.OnRotateMouseOrTouch(event);
		break;
	}

	if (ElementsMenu)
		ElementsMenu.HideRightClickMenu();
	////ElementsMenu.DestroyContextMenu();
};

GUIInput.OnMiddleMouseDown = function ()
{};

GUIInput.OnMouseMove = function (event)
{
	GUIInput.OnMouseOrTouchMove(event);
};

GUIInput.OnMouseWheel = function (event)
{
	if (event.preventDefault)
		event.preventDefault();

	if (event.currentTarget.id == "building_designer_canvas")
	{
		window.scrollTo(0, 0);
		let delta = 0;

		if (event.wheelDelta !== undefined)
		{ // WebKit / Opera / Explorer 9
			delta = -event.wheelDelta / 1000;
		}
		else if (event.detail !== undefined)
		{ // Firefox
			delta = event.detail / 10;
		}

		buildingDesigner.camera.Zoom(delta);
	}
};

GUIInput.OnMouseUpCanvas = function (event)
{
	switch (event.button)
	{
	case 0: // LMB
		GUIInput.mouseLeftButton = false;

		setTimeout(GUIInput.OnLeftMouseUpOrTouchEnd, (GUIInput.currentDesignEditorMode == GUIInput.DESIGN_EDIT_MODE.ROTATE) ? 0 : CLICKORTOUCHDELAY);
		break;
	case 1: // MMB
		break;
	case 2: // RMB
		GUIInput.mouseRightButton = false;
		GUIInput.OnRightMouseUp(event);
		break;
	}

	ElementsMenu.DestroyContextMenu();
};

GUIInput.OnMouseUpPage = function (event)
{
	if (ElementsMenu)
		ElementsMenu.DestroyContextMenu();
};

GUIInput.OnTouchStart = function (event)
{
	//event.preventDefault();
	GUIInput.OnLeftMouseDownOrTouch(event);
};

GUIInput.onTouchMove = function (event)
{
	//event.preventDefault();

	GUIInput.OnMouseOrTouchMove(event);
};

GUIInput.onTouchEnd = function (event)
{
	//event.preventDefault();
	setTimeout(GUIInput.OnLeftMouseUpOrTouchEnd, (GUIInput.currentDesignEditorMode == GUIInput.DESIGN_EDIT_MODE.ROTATE) ? 0 : CLICKORTOUCHDELAY);

	let currentTime = new Date().getTime();
	let tapLength = currentTime - GUIInput.lastTap;

	if (tapLength < 300 && tapLength > 0)
	{
		clearTimeout(GUIInput.mouseDownOrTouchDelayed);
	}

	GUIInput.lastTap = currentTime;
};


GUIInput.OnDblClick = function (event)
{};

GUIInput.OnContextMenu = function (event)
{
	return false;
};

GUIInput.GetMouseOrTouchCoords = function (event)
{
	if (event.touches && event.touches.length > 0)
	{
		mousePosX = event.touches[0].pageX - event.touches[0].target.offsetLeft - event.touches[0].target.offsetParent.offsetLeft;
		mousePosY = event.touches[0].pageY - event.touches[0].target.offsetTop - event.touches[0].target.offsetParent.offsetTop;
	}
	else
	if (event.offsetX || event.offsetY)
	{
		mousePosX = event.offsetX;
		mousePosY = event.offsetY;
	}
	else
	if (event.pageX || event.pageY)
	{
		mousePosX = event.pageX - event.target.offsetLeft - event.target.offsetParent.offsetLeft;
		mousePosY = event.pageY - event.target.offsetTop - event.target.offsetParent.offsetTop;
	}
	else
	{
		mousePosX = event.clientX - event.target.offsetLeft;
		mousePosY = event.clientY - event.target.offsetTop;
	}

	GUIInput.vecCurrentMousePos.set(mousePosX, mousePosY);

	return GUIInput.vecCurrentMousePos;
};

GUIInput.ProcessDesignEditorMouseOrTouchMove = function (mousePos)
{
	switch (GUIInput.currentDesignEditorMode)
	{
	case GUIInput.DESIGN_EDIT_MODE.SET_WALL:
	case GUIInput.DESIGN_EDIT_MODE.IDLE:
		if (buildingDesigner && buildingDesigner.MouseOver)
		{
			buildingDesigner.MouseOver(mousePos);
		}
		break;

	case GUIInput.DESIGN_EDIT_MODE.ADD_ELEMENT:
	case GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT:
		let wallAndPosOnWall = buildingDesigner.building.GetWallMouseOver({
			x: mousePos.x,
			y: mousePos.y
		});

		if (wallAndPosOnWall != null && wallAndPosOnWall.wall.style == Wall.CLOSED)
		{
			/*////let mtxWorldToElem = new THREE.Matrix4().getInverse(wallAndPosOnWall.wall.matrix);
							wallAndPosOnWall.vectorPos.matrixAutoUpdate = false;
							wallAndPosOnWall.vectorPos.applyMatrix4(mtxWorldToElem);

							let centerOffset = Elements.draggableElement.mousePosOnElement.clone();

							if (wallAndPosOnWall.wall.eWall == WALL_RIGHT || wallAndPosOnWall.wall.eWall == WALL_FRONT)
							{
								centerOffset.x -= Elements.draggableElement.component3DObjects.geometryCenter.x;
								wallAndPosOnWall.vectorPos.x -= centerOffset.x;
							}
							else
							{
								centerOffset.x -= Elements.draggableElement.component3DObjects.geometryCenter.x;
								wallAndPosOnWall.vectorPos.x += centerOffset.x;
							}

							centerOffset.y -= Elements.draggableElement.component3DObjects.geometryCenter.y;
							wallAndPosOnWall.vectorPos.y -= centerOffset.y;

							if (wallAndPosOnWall.wall.eWall == WALL_LEFT || wallAndPosOnWall.wall.eWall == WALL_BACK)
								wallAndPosOnWall.vectorPos.z = -Wall.WALLTHICKNESS;
							else
								wallAndPosOnWall.vectorPos.z = Wall.WALLTHICKNESS;
								*/

			wallAndPosOnWall.vectorPos = Elements.draggableElement.CalculateElementPosOnWall(wallAndPosOnWall);

			buildingDesigner.building.DraggingElement(wallAndPosOnWall.wall, wallAndPosOnWall.wallFacetIndex, wallAndPosOnWall.vectorPos);

			buildingDesigner.Draw();
		}
		break;

	case GUIInput.DESIGN_EDIT_MODE.SET_PARTITION:
	{
		if (Partition.SelectedPartitionButtonData)
		{
			let partition = buildingDesigner.building.GetSelectedPartitionAtMouseCoord({
				x: mousePos.x,
				y: mousePos.y
			});

			if (partition != null && partition.element.style == Partition.NO_PARTITION)
			{
				partition.element.SetPartitionData(Partition.SelectedPartitionButtonData);

				buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

				buildingDesigner.Draw();

				ElementsMenu.ElementsListPricingUpdate();
			}
		}
		break;
	}
	}
};


GUIInput.ProcessObjectEditorMouseOrTouchMove = function (mousePos)
{
	if (Elements.editableComponent && GUIInput.mouseLeftButton)
	{
		switch (GUIInput.currentObjectEditorMode)
		{
		case GUIInput.OBJECT_EDIT_MODE.ROTATE_ELEMENT:
			////Elements.RotateElement(GUIInput.vecCurrentMousePos);

			Elements.RotateComponent(GUIInput.vecCurrentMousePos, Elements.editableComponent);

			buildingDesigner.building.SetRegenerateElementMeshes(true);
			buildingDesigner.Draw();

			break;

		case GUIInput.OBJECT_EDIT_MODE.TRANSLATE_ELEMENT:
			Elements.TranslateComponent(GUIInput.vecCurrentMousePos, Elements.editableComponent);

			buildingDesigner.building.SetRegenerateElementMeshes(true);
			buildingDesigner.Draw();
			break;


		case GUIInput.OBJECT_EDIT_MODE.SCALE_ELEMENT:
			Elements.ScaleComponent(GUIInput.vecCurrentMousePos, Elements.editableComponent);

			buildingDesigner.building.SetRegenerateElementMeshes(true);
			buildingDesigner.Draw();
			break;
		}
	}
};

GUIInput.OnMouseOrTouchMove = function (event)
{
	GUIInput.vecCurrentMousePos = GUIInput.GetMouseOrTouchCoords(event);

	if (GUIInput.currentDesignEditorMode == GUIInput.DESIGN_EDIT_MODE.ROTATE)
	{
		////GUIInput.OnMouseMoveRotate(GUIInput.vecCurrentMousePos.x, GUIInput.vecCurrentMousePos.y);
		////const updated = cameraControls.update( delta );
	}
	else
	if (GUIInput.currentGuiMode == GUIInput.GUI_MODE.DESIGN_EDITOR)
	{
		GUIInput.ProcessDesignEditorMouseOrTouchMove(GUIInput.vecCurrentMousePos);
	}
	else
	{
		GUIInput.ProcessObjectEditorMouseOrTouchMove(GUIInput.vecCurrentMousePos);
	}

	GUIInput.vecLastMousePos.set(GUIInput.vecCurrentMousePos.x, GUIInput.vecCurrentMousePos.y);
};



//vr mobile orientation controls
GUIInput.setOrientationControls = function (e)
{
	if (!e.alpha)
	{
		return;
	}

	let fDeltaX = e.alpha;
	let fDeltaY;

	if (e.gamma > 0)
		fDeltaY = 90 - e.gamma;
	else
	if (e.gamma < 0)
		fDeltaY = -(90 + e.gamma);

	fDeltaY *= -1;

	if (buildingDesigner.camera.pan)
	{
		buildingDesigner.camera.AdjustHeight(fDeltaY / 10);
	}
	else
	{
		buildingDesigner.camera.SetHorizAngle(THREE.Math.degToRad(fDeltaX));
		buildingDesigner.camera.SetVertAngle(THREE.Math.degToRad(fDeltaY));
	}

	if (buildingDesigner.building && buildingDesigner.building.selected)
		buildingDesigner.building.SetRulerWalls(buildingDesigner.camera.g_fCameraHorizAngleExterior);

	buildingDesigner.InitializeCameraAndRender();
};


GUIInput.OnMouseMoveRotate = function (x, y)
{
	let vecNewMousePos = new THREE.Vector2(x, y);
	let vecDelta = new THREE.Vector2().subVectors(vecNewMousePos, GUIInput.vecLastMousePos);
	let fDeltaX = ((buildingDesigner.camera.modeCamera == Camera.CAM_MODE_EXTERIOR) ? -1 : 1) * vecDelta.x * GUIInput.ROTATE_SPEED;
	let fDeltaY = vecDelta.y * GUIInput.ROTATE_SPEED;


	if (buildingDesigner.camera.pan)
	{
		buildingDesigner.camera.AdjustHeight(fDeltaY / 10);
	}
	else
	{
		buildingDesigner.camera.AdjustHorizAngle(THREE.Math.degToRad(fDeltaX));
		buildingDesigner.camera.AdjustVertAngle(THREE.Math.degToRad(fDeltaY));
	}

	if (buildingDesigner.building && buildingDesigner.building.selected)
		buildingDesigner.building.SetRulerWalls();

	////buildingDesigner.InitializeCameraAndRender();
};

GUIInput.OnLeftMouseDownOrTouchDelayed = function ()
{
	buildingDesigner.OnLeftMouseDownOrTouchDelayed(GUIInput.vecCurrentMousePos);
};

GUIInput.OnLeftMouseDownOrTouch = function (event)
{
	GUIInput.vecCurrentMousePos = GUIInput.GetMouseOrTouchCoords(event);
	GUIInput.vecLastMousePos.set(GUIInput.vecCurrentMousePos.x, GUIInput.vecCurrentMousePos.y);

	GUIInput.mouseDownOrTouchDelayed = setTimeout(GUIInput.OnLeftMouseDownOrTouchDelayed, CLICKORTOUCHDELAY);

	if (AuxUtilities.IsMobileOrTablet())
	{
		let myElement = document.getElementById("viewbox");
		let hammertime = new Hammer(myElement);
		hammertime.get("press").set({
			time: 1000,
			pointers: 1,
			threshold: 10
		});

		hammertime.on("press", function (ev)
		{
			let selectedElement = Elements.GetSelectedElement();
			if (selectedElement)
				ElementsMenu.ShowRightClickMenu(selectedElement, event.layerX, event.layerY);
		});
	}
};

GUIInput.OnRotateMouseOrTouch = function (event)
{
	GUIInput.vecLastMousePos.set(event.clientX, event.clientY);

	GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.ROTATE;
};

GUIInput.OnLeftMouseUpOrTouchEnd = function ()
{
	GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.IDLE;

	if (Elements.draggableElement)
	{
		GUIInput.EndDraggingElement();
	}

	GUIInput.touchStart = false;
};

GUIInput.OnRightMouseUp = function (event)
{
	GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.IDLE;

	GUIInput.touchStart = false;

	let selectedElement = Elements.GetSelectedElement();

	if (!selectedElement && buildingDesigner.building)
		selectedElement = buildingDesigner.building.GetSelectedPartition();

	if (selectedElement)
		ElementsMenu.ShowRightClickMenu(selectedElement, event.layerX, event.layerY);

	return false;
};

GUIInput.EndDraggingElement = function ()
{
	Elements.draggableElement.EndDragging();
	Elements.draggableElement = null;

	buildingDesigner.building.SetBuildingModified();
};

GUIInput.OnKeyDown = function (event)
{
	////if (document.activeElement.tagName=="BODY")
	if (document.activeElement.tagName.indexOf("INPUT")==-1)
	{
		let eState;
		switch (event.key)
		{
		case ("Del"):
		case ("Delete"):
		/* Delete element */
			buildingDesigner.DeleteSelectedElement();
			break;

		case ("-"):
		/* Zoom Out */
			buildingDesigner.camera.Zoom(-0.1);
			break;

		case ("="):
		case ("+"):
		/* Zoom In */
			buildingDesigner.camera.Zoom(0.1);
			break;
		case ("Shift"):
			if (DEBUG)
			{
				buildingDesigner.camera.pan = true;
			}
			break;
		case ("ArrowUp"):
			eState = ControlsMenu.SPIN_STATE_UP;
			//contextSpin.drawImage(ControlsMenu.imageSpinControl[ControlsMenu.SPIN_STATE_UP], 0, 0);
			break;
		case ("ArrowDown"):
			eState = ControlsMenu.SPIN_STATE_DOWN;
			//contextSpin.drawImage(ControlsMenu.imageSpinControl[ControlsMenu.SPIN_STATE_DOWN], 0, 0);
			break;
		case ("ArrowLeft"):
			eState = ControlsMenu.SPIN_STATE_LEFT;
			//contextSpin.drawImage(ControlsMenu.imageSpinControl[ControlsMenu.SPIN_STATE_LEFT], 0, 0);
			break;
		case ("ArrowRight"):
			eState = ControlsMenu.SPIN_STATE_RIGHT;
			// contextSpin.drawImage(ControlsMenu.imageSpinControl[ControlsMenu.SPIN_STATE_RIGHT], 0, 0);
			break;
		}
		if (eState && !ControlsMenu.keyState)
		{
			if (contextSpin)
			{
				contextSpin.drawImage(ControlsMenu.imageSpinControl[eState], 0, 0);
			}
			if (DEBUG)
			{
				console.log("Key Down","Key State:",ControlsMenu.keyState);
			}
			ControlsMenu.KillRotateTimer();
			ControlsMenu.rotateTimer = window.setInterval(ControlsMenu.OnRotateTimer, ControlsMenu.ROTATE_TIMER_INTERVAL);
			ControlsMenu.stateSpin = eState;
			ControlsMenu.keyState = ControlsMenu.KEY_STATE_DOWN;
		}
	}
};

GUIInput.OnKeyUp = function (event)
{
	switch (event.key)
	{
	case ("Shift"):
		if (DEBUG)
		{
			buildingDesigner.camera.pan = false;
		}
		break;
	case ("ArrowUp"):
	case ("ArrowDown"):
	case ("ArrowLeft"):
	case ("ArrowRight"):
		if (DEBUG)
		{
			console.log("Key Up");
		}
		if (contextSpin)
		{
			contextSpin.drawImage(ControlsMenu.imageSpinControl[ControlsMenu.SPIN_STATE_IDLE], 0, 0);
		}
		ControlsMenu.KillRotateTimer();
		ControlsMenu.keyState = ControlsMenu.KEY_STATE_UP;
		break;
	}
};

GUIInput.togglefstext = function ()
{
	if (screenfull.isFullscreen) $("#fullscreen").text("Exit Full Screen");
	else $("#fullscreen").text("Full Screen");
};

GUIInput.SetEditModeRadioButton = function (id, text, checked)
{
	let elem = document.getElementById(id);

	elem.value = text;
	elem.checked = checked;

	elem = document.getElementById(id + "Label");

	if (elem)
		elem.innerHTML = text;
};

GUIInput.SetEditModeButtonVisibility = function (id, visibility)
{
	let elem = document.getElementById(id);
	elem.style.visibility = visibility;

	elem = document.getElementById(id + "Label");
	elem.style.visibility = visibility;
};

GUIInput.UpdateEditModeRadioButtons = function ()
{
	GUIInput.currentEditModeAxis = GUIInput.OBJECT_EDIT_AXIS_MODE.X;

	switch (GUIInput.currentGuiMode)
	{
	case (GUIInput.GUI_MODE.DESIGN_EDITOR):
		GUIInput.SetEditModeRadioButton("designerMode", "BuildingDesigner", true);
		GUIInput.SetEditModeRadioButton("editMode1", "Rotate", false);
		GUIInput.SetEditModeRadioButton("editMode2", "Translate", false);
		GUIInput.SetEditModeRadioButton("editMode3", "Scale", false);

		GUIInput.SetEditModeButtonVisibility("editMode3", "visible");

		GUIInput.SetEditModeButtonVisibility("editModeBackButton", "hidden");
		break;

	case (GUIInput.GUI_MODE.OBJECT_EDITOR):
		switch (GUIInput.currentObjectEditorMode)
		{
		case (GUIInput.OBJECT_EDIT_MODE.ROTATE_ELEMENT):
			GUIInput.SetEditModeRadioButton("designerMode", "BuildingDesigner", false);
			GUIInput.SetEditModeRadioButton("editMode1", "X Axis", true);
			GUIInput.SetEditModeRadioButton("editMode2", "Y Axis", false);
			GUIInput.SetEditModeRadioButton("editMode3", "Z Axis", false);

			GUIInput.SetEditModeButtonVisibility("editMode3", "visible");

			GUIInput.SetEditModeButtonVisibility("editModeBackButton", "visible");
			break;


		case (GUIInput.OBJECT_EDIT_MODE.TRANSLATE_ELEMENT):
			GUIInput.currentEditModeAxis = GUIInput.OBJECT_EDIT_AXIS_MODE.XY;

			GUIInput.SetEditModeRadioButton("designerMode", "BuildingDesigner", false);
			GUIInput.SetEditModeRadioButton("editMode1", "X-Y Axis", true);
			GUIInput.SetEditModeRadioButton("editMode2", "Z Axis", false);
			////GUIInput.SetEditModeRadioButton("editMode3", "Z Axis", false);

			GUIInput.SetEditModeButtonVisibility("editMode3", "hidden");

			GUIInput.SetEditModeButtonVisibility("editModeBackButton", "visible");
			break;

		case (GUIInput.OBJECT_EDIT_MODE.SCALE_ELEMENT):
			GUIInput.SetEditModeRadioButton("designerMode", "BuildingDesigner", false);
			break;
		}
		break;
	}
};

GUIInput.SetDesignerEditMode = function ()
{
	buildingDesigner.building.ClearSelections();

	GUIInput.currentGuiMode = GUIInput.GUI_MODE.DESIGN_EDITOR;

	GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.IDLE;

	GUIInput.currentObjectEditorMode = GUIInput.OBJECT_EDIT_MODE.IDLE;

	GUIInput.UpdateEditModeRadioButtons();

	buildingDesigner.building.SetRegenerateElementMeshes(true);
	buildingDesigner.Draw();
};

GUIInput.ProcessEditModeInput = function (editModeInput)
{
	if (editModeInput.checked)
	{
		GUIInput.currentGuiMode = GUIInput.GUI_MODE.OBJECT_EDITOR;

		switch (editModeInput.value)
		{
		case ("BuildingDesigner"):
			GUIInput.SetDesignerEditMode();
			break;

		case ("Rotate"):
			GUIInput.currentObjectEditorMode = GUIInput.OBJECT_EDIT_MODE.ROTATE_ELEMENT;

			GUIInput.UpdateEditModeRadioButtons();
			break;

		case ("Translate"):
			GUIInput.currentObjectEditorMode = GUIInput.OBJECT_EDIT_MODE.TRANSLATE_ELEMENT;

			GUIInput.UpdateEditModeRadioButtons();
			break;

		case ("Scale"):
			GUIInput.currentObjectEditorMode = GUIInput.OBJECT_EDIT_MODE.SCALE_ELEMENT;

			GUIInput.UpdateEditModeRadioButtons();
			break;

		case ("X Axis"):
			GUIInput.currentEditModeAxis = GUIInput.OBJECT_EDIT_AXIS_MODE.X;
			break;

		case ("X-Y Axis"):
			GUIInput.currentEditModeAxis = GUIInput.OBJECT_EDIT_AXIS_MODE.XY;
			break;

		case ("Y Axis"):
			GUIInput.currentEditModeAxis = GUIInput.OBJECT_EDIT_AXIS_MODE.Y;
			break;

		case ("Z Axis"):
			GUIInput.currentEditModeAxis = GUIInput.OBJECT_EDIT_AXIS_MODE.Z;
			break;

		case ("Back"):
			GUIInput.SetDesignerEditMode();
			break;
		}
	}
};

GUIInput.Update3DObjects = function ()
{
	if (confirm("Are you sure you want to update the object's configuration on the webserver?"))
	{
		buildingDesigner.building.Update3DObjects();
	}
};

GUIInput.Reload3DObjectConfig = function()
{
	if (confirm("Reload current object from the server?"))
	{
		//
	}
};

GUIInput.GUI_MODE = {};

GUIInput.GUI_MODE.DESIGN_EDITOR = 0;
GUIInput.GUI_MODE.OBJECT_EDITOR = 1;


GUIInput.DESIGN_EDIT_MODE = {};

GUIInput.DESIGN_EDIT_MODE.IDLE = 0;
GUIInput.DESIGN_EDIT_MODE.ROTATE = 1;
GUIInput.DESIGN_EDIT_MODE.ADD_ELEMENT = 2;
GUIInput.DESIGN_EDIT_MODE.DRAG_ELEMENT = 3;
GUIInput.DESIGN_EDIT_MODE.SET_PARTITION = 4;
GUIInput.DESIGN_EDIT_MODE.SET_WALL = 5;
GUIInput.DESIGN_EDIT_MODE.SET_SIDING = 6;

GUIInput.OBJECT_EDIT_MODE = {};

GUIInput.OBJECT_EDIT_MODE.IDLE = 0;
GUIInput.OBJECT_EDIT_MODE.ROTATE_ELEMENT = 1;
GUIInput.OBJECT_EDIT_MODE.TRANSLATE_ELEMENT = 2;
GUIInput.OBJECT_EDIT_MODE.SCALE_ELEMENT = 3;

GUIInput.OBJECT_EDIT_AXIS_MODE = {};

GUIInput.OBJECT_EDIT_AXIS_MODE.X = 0;
GUIInput.OBJECT_EDIT_AXIS_MODE.Y = 1;
GUIInput.OBJECT_EDIT_AXIS_MODE.Z = 2;
GUIInput.OBJECT_EDIT_AXIS_MODE.XY = 3;

GUIInput.currentGuiMode = GUIInput.GUI_MODE.DESIGN_EDITOR;

GUIInput.currentDesignEditorMode = GUIInput.DESIGN_EDIT_MODE.IDLE;

GUIInput.currentObjectEditorMode = GUIInput.OBJECT_EDIT_MODE.IDLE;

GUIInput.currentEditModeAxis = GUIInput.OBJECT_EDIT_AXIS_MODE.X;
