/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1*/
/*eslint-disable no-console, no-unused-vars*/
/* globals THREE, threeScene, threeRenderer, TexturesDataUtilities, GRASS_RADIUS, GRASS_RADIUS, BACKGROUND_HEIGHT, BACKGROUND_CURVE_SEGMENTS, material */
function BackGround(background)
{
	this.mesh = null;
	this.regenerate = true;

	this.background = background;

	this.SetRegenerate = function(regenerate)
	{
		this.regenerate = regenerate;
	};

	this.Draw = function()
	{
		if (this.regenerate)
		{
			let texture = null;
			let material;

			if (this.background.texture)
			{
				texture = TexturesDataUtilities.SelectTexture( this.background.texture, THREE.RepeatWrapping, THREE.RepeatWrapping );
			}

			this.Destroy();

			let geometry = new THREE.CylinderGeometry( GRASS_RADIUS, GRASS_RADIUS, BACKGROUND_HEIGHT, BACKGROUND_CURVE_SEGMENTS, 1, true );

			geometry.scale( - 1, 1, 1 );

			texture = TexturesDataUtilities.TextureLoaded(texture);

			if (texture)
			{
				material = new THREE.MeshBasicMaterial({map: TexturesDataUtilities.TextureLoaded(texture), color: 0xffffff});
			}
			else
			{
				material = new THREE.MeshBasicMaterial({color: this.background.color});
			}

			////material = new THREE.MeshBasicMaterial({color: 0xFFFFFF});

			this.mesh = new THREE.Mesh(geometry, material);

			this.mesh.position.y = BACKGROUND_HEIGHT/2-1;
			this.mesh.rotation.y = MathUtilities.PI / BACKGROUND_CURVE_SEGMENTS;

			threeScene.add(this.mesh);
			threeRenderer.shadowMap.needsUpdate = true;

			this.regenerate = false;
		}
	};

	this.Destroy = function()
	{
		if (this.mesh != null)
		{
			threeScene.remove( this.mesh );
			threeRenderer.shadowMap.needsUpdate = true;
			this.mesh = null;
		}
	};
}
