// admin-editbuildingtype.js
/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1*/
/*eslint-disable no-console, no-unused-vars*/


function fieldmodified(elm) {
	$(elm).css('background','powderblue');
}

function removeBuildingSize(sub_id,product_id,series_code)
{
	// alert("To be coded");
	if(confirm("Delete " +product_id+ "?")) {
		$.post({url:"adminui?q=deletesubbuildingsize", dataType:"json"}, {action: "deletesubbuildingsize", subscriber_id: sub_id, product_id: product_id, series_code: series_code}, function(serverReturn, status)
		{
			if(serverReturn.success === true) {
				$("#sizerow_"+serverReturn.product_id).remove();
			}
		});
	}
}

async function updateBaseOptionsPrice(sub_id,product_id,category_id,series_code)
{
	let std_options_price = await prompt("Standard Options Price:", $(`#price${product_id}`).data('base_std_options_price'));
	let base_siding = $(`#price${product_id}`).data("base_siding_category_id");
	if (std_options_price == null || std_options_price == "") {
		return;
	} else {
		std_options_price = Number(std_options_price);
		$(`#price${product_id}`).data('base_std_options_price',std_options_price);
		updateBuildingPrice(sub_id,product_id,category_id,series_code);
		$(`#price${product_id}`).prop('title','Std Options: '+std_options_price+'\nBase Siding: '+base_siding);
	}
}

async function updateOptionsPrice(sub_id,product_id,category_id,series_code)
{
	let std_options_price = await prompt("Standard Options Price:", $(`#price${product_id}${category_id}`).data('std_options_price'));
	if (std_options_price == null || std_options_price == "") {
		return;
	} else {
		std_options_price = Number(std_options_price);
		$(`#price${product_id}${category_id}`).data('std_options_price',std_options_price);
		updateBuildingPrice(sub_id,product_id,category_id,series_code);
		$(`#price${product_id}${category_id}`).prop('title','Std Options: '+std_options_price);
	}
}

function updateBuildingPrice(sub_id,product_id,category_id,series_code)
{
	let price;
	let std_options_price, base_std_options_price;
	if(category_id.length > 0){
		price = Number($(`#price${product_id}${category_id}`).val()) - Number($(`#price${product_id}`).data('base_price')) - Number($(`#price${product_id}${category_id}`).data('std_options_price'));
		std_options_price = $(`#price${product_id}${category_id}`).data('std_options_price');
		$(`#price${product_id}${category_id}`).css("background-color","wheat");
		$.post({url:"adminui?q=updateprice", dataType:"json"}, {action: "updateprice", subscriber_id: sub_id, product_id: product_id, category_id: category_id, series_code: series_code, price: price, std_options_price: std_options_price}, function(serverReturn, status)
		{
			if(serverReturn.success)
			{
				$(`#price${product_id}${category_id}`).css("background-color","palegreen");
				$(`#price${product_id}${category_id}`).data("markup_price",price);
			}
			else
				$(`#price${product_id}${category_id}`).css("background-color","lightpink");
		});
	} else {
		price = Number($(`#price${product_id}`).val()) - Number($(`#price${product_id}`).data('base_std_options_price'));
		base_std_options_price = Number($(`#price${product_id}`).data('base_std_options_price'));
		$(`#price${product_id}`).css("background-color","wheat");
		$.post({url:"adminui?q=updateprice", dataType:"json"}, {action: "updateprice", subscriber_id: sub_id, product_id: product_id, category_id: category_id, series_code: series_code, price: price, base_std_options_price: base_std_options_price}, function(serverReturn, status)
		{
			if(serverReturn.success)
			{
				$(`#price${product_id}`).css("background-color","palegreen");
				$(`#price${product_id}`).data('base_price',price);
				let siding_list = $("#BuildingSizes").data("siding_list");
				siding_list = siding_list.split(" ");
				for (let i=0; i<siding_list.length; i++)
				{
					$(`#price${product_id}${siding_list[i]}`).val(Number(price) + Number($(`#price${product_id}${siding_list[i]}`).data('markup_price')) + Number($(`#price${product_id}${siding_list[i]}`).data('std_options_price')));
				}
			}
			else
				$(`#price${product_id}`).css("background-color","lightpink");
		});
	}
}

function SidingTypesInUse(sidingTypes)
{
	let returnData;
	for (let i=0; i<sidingTypes.length; i++)
	{
		returnData += ` ${sidingTypes[i].category_id} `;
	}
	return returnData;
}

function SidingColumns(sub_id,product_id,building_type,sidingTypes,rowtype,series_code)
{
	let returndata, base_siding_category_id;
	let siding_list = "";
	if(building_type != "CARPORT") {
		if(rowtype === "header") {
			for (let i=0; i<sidingTypes.length; i++)
			{
				if(i>0) siding_list += " ";
				siding_list += sidingTypes[i].category_id;
				returndata += `<th>${sidingTypes[i].category_id}</th>`;
			}
			$("#BuildingSizes").data("siding_list",siding_list);
		} else {
			for (let i=0; i<sidingTypes.length; i++)
			{
			/* This won't work here because the row hasn't been created yet ---
			base_siding_category_id = $(`#price${product_id}`).data('base_siding_category_id');
			if(base_siding_category_id.length == 0)
				$(`#price${product_id}`).data('base_siding_category_id',sidingTypes[i].category_id); */
				returndata += `<td><input type="number" name="price" id="price${product_id}${sidingTypes[i].category_id}" size="8" min="0" max="999999" title="" data-std_options_price="0" data-markup_price="0" oninput="fieldmodified(this);">&nbsp;<a href="javascript:void(0)" onclick="updateOptionsPrice('${sub_id}','${product_id}','${sidingTypes[i].category_id}','${series_code}');"><i class="fa fa-wrench" aria-hidden="true" title="Update Options Price"></i></a>&nbsp;<a href="javascript:void(0)" onclick="updateBuildingPrice('${sub_id}','${product_id}','${sidingTypes[i].category_id}','${series_code}');"><i class="fa fa-save" aria-hidden="true" title="Update Siding Price"></i></a></td>`;
			}
		}
		return returndata;
	} else
	{
		return " ";
	}
}

function building_type_header(building_type){
	if(building_type == "CARPORT")
		return "<th>&nbsp;height&nbsp</th>";
	else
		return "";
}

function building_type_data(building_type,building_size){
	if(building_type == "CARPORT")
		return `<td>&nbsp;${building_size.height}&nbsp</td>`;
	else
		return "";
}

function addbuildingsize(sub_id,building_id,series_code) {
	let width = $("#width_display").val();
	let length = $("#length_display").val();
	$.post({url:"/adminui?addbuildingsize", dataType:"json"},{action:"addbuildingsize", subscriber_id: sub_id,building_id:building_id,series_code:series_code,width:width,length:length},function(serverReturn, status){
		if(!serverReturn.success) {
			alert(serverReturn.reason);
		} else {
			$("#BuildingSizes").append(`<tr><td>${width}</td><td>${length}</td></tr>`);
		}
	});
}

function SubscriberEditBuildingType(sub_id,building_id,building_type,series_code)
{
	$("#profile").hide();
	$("#subprofile").html("");
	$("#subprofile").show();
	$.post({url:"dataRequest", dataType:"json"}, {request: "getSidingCategories", subscriber_id: sub_id, series_code: series_code}, function(sidingTypes, status)
	{
		$("#subprofile").append(`
	<div class='header'>
		<i class='fas fa-arrow-alt-circle-left' onclick='ReturntoProfile()'></i>
		<h1>Editing Building ${building_id} - Series ${series_code}</h1>
	</div>
	<p>Note: If changing base price, save base prices before editing siding prices.</p>
	<table border='2' id="BuildingWidthSettings">
		<tr><th>Sub-Type</th><th>&nbsp;Width&nbsp;</th><th>&nbsp;Height&nbsp;</th><th></th></tr>
	</table>
	<br>
	<table border='2' id="BuildingSizes" class="price" data-siding_list=""></table>
	<br>Width: <input type='number' name='width_display' id='width_display' required size='4'>&nbsp;&nbsp;Length: <input type='number' name='length_display' id='length_display' required size='4'>&nbsp;<button type='button' name='addsize' onclick="addbuildingsize('${sub_id}','${building_id}','${series_code}');">Add Shed Size</button>
`);
		$("#BuildingSizes").append(`
<tr><th>&nbsp;Width&nbsp;</th><th>&nbsp;Length&nbsp;</th>${building_type_header(building_type)}<th>&nbsp;Base Price&nbsp;</th>${SidingColumns(sub_id,building_id,building_type,sidingTypes,"header")}<th></th></tr>
`);

		$.post({url:"dataRequest", dataType:"json"}, {request: "getBuildingSizes", subscriber_id: sub_id, buildingID: building_id, series_code: series_code}, function(buildingSizes, status)
		{
			for (let i=0; i<buildingSizes.length; i++)
			{
				$("#BuildingSizes").append(`
			<tr id="sizerow_${buildingSizes[i].product_id}">
				<td>${buildingSizes[i].width_display}</td>
				<td>${buildingSizes[i].length_display}</td>
				${building_type_data(building_type,buildingSizes[i])}
				<td><input type="number" name="price" id="price${buildingSizes[i].product_id}" data-base_price="${buildingSizes[i].price}" data-base_std_options_price="${buildingSizes[i].base_std_options_price}" data-base_siding_category_id="${buildingSizes[i].base_siding_category_id}" title="Std Options: ${buildingSizes[i].base_std_options_price}&#10;Base Siding: ${buildingSizes[i].base_siding_category_id}" size="8" min="0" max="999999" value="${Number(buildingSizes[i].price) + Number(buildingSizes[i].base_std_options_price)}" oninput="fieldmodified(this);">&nbsp;<a href="javascript:void(0)" onclick="updateBaseOptionsPrice('${sub_id}','${buildingSizes[i].product_id}','','${series_code}');"><i class="fa fa-wrench" aria-hidden="true" title="Update Options Price"></i></a>&nbsp;<a href="javascript:void(0)" onclick="updateBuildingPrice('${sub_id}','${buildingSizes[i].product_id}','','${series_code}');"><i class="fa fa-save" aria-hidden="true" title="Update Siding Price"></i></a>&nbsp;</td>
				${SidingColumns(sub_id,buildingSizes[i].product_id,building_type,sidingTypes,"body",series_code)}
				<td>&nbsp;&nbsp;&nbsp;<a href="javascript:void(0)" onclick="removeBuildingSize('${sub_id}','${buildingSizes[i].product_id}','${series_code}');"><i class="fa fa-trash" aria-hidden="true" title="Remove Shed Size"></i></td>`);
			}
			$.post({url:"adminui?q=getsidingprices", dataType:"json"}, {loaddata: "getsidingprices", subscriber_id: sub_id, building_id: building_id, series_code: series_code}, function(sidingPrices, status)
			{
				let sidingList = SidingTypesInUse(sidingTypes);
				for (let i=0; i<sidingPrices.length; i++)
				{
					if(sidingList.indexOf(sidingPrices[i].siding_category_id)>0)
					{
						$(`#price${sidingPrices[i].building_product_id}${sidingPrices[i].siding_category_id}`).val(Number(sidingPrices[i].price) + Number($(`#price${sidingPrices[i].building_product_id}`).data("base_price")) + Number(sidingPrices[i].std_options_price));
						$(`#price${sidingPrices[i].building_product_id}${sidingPrices[i].siding_category_id}`).prop('title',`Std Options: ${sidingPrices[i].std_options_price}`);
						$(`#price${sidingPrices[i].building_product_id}${sidingPrices[i].siding_category_id}`).data('markup_price',`${sidingPrices[i].price}`);
						$(`#price${sidingPrices[i].building_product_id}${sidingPrices[i].siding_category_id}`).data('std_options_price',`${sidingPrices[i].std_options_price}`);
					}
				}
			});
		});
	});
}

