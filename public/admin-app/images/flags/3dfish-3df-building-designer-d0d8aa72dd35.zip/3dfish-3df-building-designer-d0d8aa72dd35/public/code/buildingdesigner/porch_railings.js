/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function PorchRailings(parent)
{
	this.parent = parent;

	let options = {};
	if (buildingDesigner.buildingButtonData.options && buildingDesigner.buildingButtonData.options.porch)
	{
		options = buildingDesigner.buildingButtonData.options.porch;
	}

	PorchRailings.ENTRY_WIDTH = options.entry_width || 3;
	PorchRailings.POST_WIDTH = options.post_width || 0.291;
	PorchRailings.RAILING_WIDTH = options.railing_width || 0.1;
	PorchRailings.RAILING_VERTICAL_GAP = options.railing_vertical_gap || 0.3;
	PorchRailings.RAILING_HEIGHT = options.railing_height || 3;
	PorchRailings.PICKET_WIDTH = options.picket_width || 0.1;
	PorchRailings.PICKET_DEPTH = options.picket_depth || 0.1;
	PorchRailings.PICKET_GAP = options.picket_gap || 0.3;
	PorchRailings.FRONT_RAIL = typeof options.front_rail === "undefined" ? true:options.front_rail;
	PorchRailings.RIGHT_RAIL = typeof options.right_rail === "undefined" ? true:options.right_rail;
	PorchRailings.LEFT_RAIL = typeof options.left_rail === "undefined" ? true:options.left_rail;
	PorchRailings.FRONT_ENTRY = typeof options.front_entry === "undefined" ? false:options.front_entry;
	PorchRailings.RIGHT_ENTRY = typeof options.right_entry === "undefined" ? true:options.right_entry;
	PorchRailings.LEFT_ENTRY = typeof options.left_entry === "undefined" ? false:options.left_entry;
	PorchRailings.ENTRY_CENTERED = typeof options.entry_centered === "undefined" ? false:options.entry_centered;

	this.railingTextureFileName = options.railingTextureFileName || "Southern_yellowpine_horizontal";
	this.railingTexture = null;
	this.railingColor = options.railingColor || 0xFFFFFF;

	this.postTextureFileName = options.postTextureFileName || "Southern_yellowpine_vertical";
	this.postTexture = null;
	this.postColor = options.postColor || 0xFFFFFF;

	this.regenerate = true;

	this.SetDeckColor = function (color)
	{
		this.deckColor = color;
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	/**
	 * @method PorchRailings.CreatePost
	 * @param postHeight height of the post
	 * @param x, y, z for placement of the post
	 * @returns {THREE.Mesh} 3D mesh object for the post
	 */
	this.CreatePost = function (postHeight, x = 0, y = 0, z = 0)
	{
		let postMatter = new THREE.MeshStandardMaterial({
			color: this.postColor,
			map: this.postTexture,
			roughness: 1.0,
			metalness: METALNESS
		});

		let postGeometry = new THREE.BoxGeometry(PorchRailings.POST_WIDTH, postHeight, PorchRailings.POST_WIDTH);

		let post = new THREE.Mesh(postGeometry, postMatter);

		post.matrixAutoUpdate = false;
		post.applyMatrix4(new THREE.Matrix4().makeTranslation(x, postHeight / 2 + y, z));

		return post;
	};

	this.GetTextures = function ()
	{
		if (this.railingTextureFileName != "")
		{
			this.railingTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.railingTextureFileName, -1, -1);
		}
		else
			this.railingTexture = null;

		if (this.postTextureFileName != "")
		{
			this.postTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.railingTextureFileName, -1, -1);
		}
		else
			this.postTexture = null;
	};

	/**
	* @method PorchRailings.CreateRailing
	* @param length
	* @param createLeftPost when a post on the left of the railing is required
	* @param addRailing optional, set to false to only set posts and no railing
	* @param startXOffset set to starting location if other than 0
	* @returns {THREE.Mesh} 3D mesh object for the railing
	*/
	this.CreateRailing = function (length, createLeftPost, addRailing = true, startXOffset = 0)
	{
		let mesh = new THREE.Mesh();

		let boardLength = length - PorchRailings.POST_WIDTH * 2;

		let numPickets = Math.floor(boardLength / (PorchRailings.PICKET_GAP + PorchRailings.PICKET_WIDTH));

		let railingMatter = new THREE.MeshStandardMaterial({
			color: this.railingColor,
			map: this.railingTexture,
			roughness: 1.0,
			metalness: METALNESS
		});

		let postMatter = new THREE.MeshStandardMaterial({
			color: this.postColor,
			map: this.postTexture,
			roughness: 1.0,
			metalness: METALNESS
		});

		let postHeight = buildingDesigner.building.height - buildingDesigner.building.floorHeight - BOARD_2x4_THICKNESS;

		if (createLeftPost)
		{
			mesh.add(this.CreatePost(postHeight,startXOffset));
		}

		let board1Geometry = new THREE.BoxGeometry(boardLength, BOARD_2x4_THICKNESS, BOARD_2x4_WIDTH);
		let board1 = new THREE.Mesh(board1Geometry, railingMatter);

		board1.matrixAutoUpdate = false;
		if (addRailing)
		{
			board1.applyMatrix4(new THREE.Matrix4().makeTranslation(PorchRailings.POST_WIDTH / 2 + boardLength / 2 + startXOffset, BOARD_2x4_THICKNESS / 2 + PorchRailings.RAILING_VERTICAL_GAP, 0));

			mesh.add(board1);


			let adjPicketGap = boardLength / numPickets;

			let xOffset = PorchRailings.POST_WIDTH / 2 + adjPicketGap;

			let picketGeometry = new THREE.BoxGeometry(PorchRailings.PICKET_WIDTH, PorchRailings.RAILING_HEIGHT, PorchRailings.PICKET_DEPTH);

			for (let i = 0; i < numPickets - 1; i++)
			{
				railing = new THREE.Mesh(picketGeometry, railingMatter);
				railing.matrixAutoUpdate = false;
				railing.applyMatrix4(new THREE.Matrix4().makeTranslation(xOffset + startXOffset, BOARD_2x4_THICKNESS / 2 + PorchRailings.RAILING_VERTICAL_GAP + PorchRailings.RAILING_HEIGHT / 2, 0));

				mesh.add(railing);

				xOffset += adjPicketGap;
			}

			let board2Geometry = new THREE.BoxGeometry(boardLength, BOARD_2x4_THICKNESS, BOARD_2x4_WIDTH);

			let board2 = new THREE.Mesh(board2Geometry, railingMatter);

			board2.matrixAutoUpdate = false;
			board2.applyMatrix4(new THREE.Matrix4().makeTranslation(PorchRailings.POST_WIDTH / 2 + boardLength / 2 + startXOffset, BOARD_2x4_THICKNESS / 2 + PorchRailings.RAILING_VERTICAL_GAP + PorchRailings.RAILING_HEIGHT, 0));

			mesh.add(board2);
		}


		mesh.add(this.CreatePost(postHeight, PorchRailings.POST_WIDTH + boardLength + startXOffset, 0, 0));

		return mesh;
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			this.GetTextures();

			this.mesh = new THREE.Mesh();

			let createLeftRailing, createRightRailing, frontRailingLength;
			let sideRailingLength, rightRailing, leftRailing;

			if (this.parent.rightSide)
			{
				createLeftRailing = (buildingDesigner.building.porch.fullLength || buildingDesigner.building.porch.length < 0);
				createRightRailing = (buildingDesigner.building.porch.fullLength || buildingDesigner.building.porch.length > 0);

				frontRailingLength = Math.abs(buildingDesigner.building.porch.length == 0 ? buildingDesigner.building.porch.width : buildingDesigner.building.porch.length);
				if (PorchRailings.FRONT_ENTRY)
				{
					if (PorchRailings.ENTRY_CENTERED)
					{
						let frontRailingLength1 = (frontRailingLength - PorchRailings.ENTRY_WIDTH) / 2;
						let frontRailing1 = this.CreateRailing(frontRailingLength1, true, PorchRailings.FRONT_RAIL);
						this.mesh.add(frontRailing1);
						let frontRailing2 = this.CreateRailing(frontRailingLength1, true, PorchRailings.FRONT_RAIL,frontRailingLength1+PorchRailings.ENTRY_WIDTH);
						this.mesh.add(frontRailing2);
					}
					else
					{
						let frontRailingLength1 = frontRailingLength - PorchRailings.ENTRY_WIDTH;
						let frontRailing1 = this.CreateRailing(frontRailingLength1, true, PorchRailings.FRONT_RAIL);
						this.mesh.add(frontRailing1);
					}
				}
				else
				{
					let frontRailing = this.CreateRailing(frontRailingLength, true, PorchRailings.FRONT_RAIL);
					this.mesh.add(frontRailing);
				}

				sideRailingLength = Math.abs(buildingDesigner.building.porch.width) - Wall.WALLTHICKNESS;

				if (createRightRailing)
				{
					let rightRailingLength = sideRailingLength - (buildingDesigner.building.porch.length == 0 ? 0 : PorchRailings.RIGHT_ENTRY ? PorchRailings.ENTRY_WIDTH:0);

					if (rightRailingLength>0)
					{
						let endPost = (PorchRailings.FRONT_ENTRY === true) && (PorchRailings.ENTRY_CENTERED === false);
						rightRailing = this.CreateRailing(rightRailingLength,endPost);

						rightRailing.matrixAutoUpdate = false;
						rightRailing.applyMatrix4(new THREE.Matrix4().makeRotationY(MathUtilities.PI / 2));

						rightRailing.applyMatrix4(new THREE.Matrix4().makeTranslation(frontRailingLength - PorchRailings.POST_WIDTH, 0, 0));

						this.mesh.add(rightRailing);
					}
				}

				if (createLeftRailing)
				{
					if (buildingDesigner.building.porch.length == 0)
						leftSideRailingLength = buildingDesigner.building.porch.innerWallRadius - Wall.WALLTHICKNESS;
					else
						leftSideRailingLength = sideRailingLength;

					leftSideRailingLength -= (!createRightRailing ? PorchRailings.LEFT_ENTRY ? PorchRailings.ENTRY_WIDTH:0 : 0);

					if (leftSideRailingLength > 0)
					{
						leftRailing = this.CreateRailing(leftSideRailingLength, buildingDesigner.building.porch.length == 0);

						leftRailing.matrixAutoUpdate = false;
						leftRailing.applyMatrix4(new THREE.Matrix4().makeRotationY(MathUtilities.PI / 2));

						if (buildingDesigner.building.porch.length == 0)
						{
							leftRailing.applyMatrix4(new THREE.Matrix4().makeTranslation(-(buildingDesigner.building.roofRafter.wallWidth - frontRailingLength), 0, -this.parent.width));

							let postHeight = buildingDesigner.building.height - buildingDesigner.building.floorHeight - BOARD_2x4_THICKNESS;

							this.mesh.add(this.CreatePost(postHeight, -(buildingDesigner.building.roofRafter.wallWidth - frontRailingLength), 0, 0));
						}

						this.mesh.add(leftRailing);
					}
				}

				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(new THREE.Matrix4().makeTranslation(PorchRailings.POST_WIDTH / 2, 0, -PorchRailings.POST_WIDTH / 2));

				let xPos;

				if ((buildingDesigner.building.porch.fullLength || buildingDesigner.building.porch.length < 0) && buildingDesigner.building.porch.length != 0)
					xPos = -buildingDesigner.building.roofRafter.wallWidth / 2;
				else
				{
					xPos = buildingDesigner.building.roofRafter.wallWidth / 2 - frontRailingLength;
				}

				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(new THREE.Matrix4().makeTranslation(xPos, buildingDesigner.building.floorHeight, buildingDesigner.building.length / 2 - Wall.WALLTHICKNESS));
			}
			else
			{
				createLeftRailing = (buildingDesigner.building.porch.fullLength || buildingDesigner.building.porch.length > 0);
				createRightRailing = (buildingDesigner.building.porch.fullLength || buildingDesigner.building.porch.length < 0);

				frontRailingLength = Math.abs(buildingDesigner.building.porch.length == 0 ? buildingDesigner.building.porch.width : buildingDesigner.building.porch.length);

				sideRailingLength = Math.abs(buildingDesigner.building.porch.width) - Wall.WALLTHICKNESS;

				let frontRailing = this.CreateRailing(frontRailingLength, true);

				this.mesh.add(frontRailing);

				if (createLeftRailing)
				{
					let leftRailingLength = sideRailingLength - (buildingDesigner.building.porch.length == 0 ? 0 : PorchRailings.LEFT_ENTRY ? PorchRailings.ENTRY_WIDTH:0);

					if (leftRailingLength>0)
					{
						leftRailing = this.CreateRailing(leftRailingLength);

						leftRailing.matrixAutoUpdate = false;
						leftRailing.applyMatrix4(new THREE.Matrix4().makeRotationY(-MathUtilities.PI / 2));

						leftRailing.applyMatrix4(new THREE.Matrix4().makeTranslation(frontRailingLength - PorchRailings.POST_WIDTH, 0, 0));

						this.mesh.add(leftRailing);
					}
				}

				if (createRightRailing)
				{
					if (buildingDesigner.building.porch.length == 0)
						rightSideRailingLength = buildingDesigner.building.porch.innerWallRadius - Wall.WALLTHICKNESS;
					else
						rightSideRailingLength = sideRailingLength;

					rightSideRailingLength -= (!createLeftRailing ? PorchRailings.ENTRY_WIDTH : 0);

					if (rightSideRailingLength > 0)
					{
						rightRailing = this.CreateRailing(rightSideRailingLength, buildingDesigner.building.porch.length == 0);

						rightRailing.matrixAutoUpdate = false;
						rightRailing.applyMatrix4(new THREE.Matrix4().makeRotationY(-MathUtilities.PI / 2));

						if (buildingDesigner.building.porch.length == 0)
						{
							rightRailing.applyMatrix4(new THREE.Matrix4().makeTranslation(-(buildingDesigner.building.roofRafter.wallWidth - frontRailingLength), 0, this.parent.width));

							let postHeight = buildingDesigner.building.height - buildingDesigner.building.floorHeight - BOARD_2x4_THICKNESS;

							this.mesh.add(this.CreatePost(postHeight, -(buildingDesigner.building.roofRafter.wallWidth - frontRailingLength), 0, 0));
						}

						this.mesh.add(rightRailing);
					}
				}

				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(new THREE.Matrix4().makeTranslation(PorchRailings.POST_WIDTH / 2, 0, PorchRailings.POST_WIDTH / 2));

				let xPos;

				if ((buildingDesigner.building.porch.fullLength || buildingDesigner.building.porch.length < 0) && buildingDesigner.building.porch.length != 0)
					xPos = -buildingDesigner.building.roofRafter.wallWidth / 2;
				else
				{
					xPos = buildingDesigner.building.roofRafter.wallWidth / 2 - frontRailingLength;
				}

				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(new THREE.Matrix4().makeTranslation(xPos, buildingDesigner.building.floorHeight, -buildingDesigner.building.length / 2 + Wall.WALLTHICKNESS));
			}

			MeshUtilities.SetMeshType(this.mesh, ELEM_RAILING);
			MeshUtilities.SetMeshCastReceiveShadow(this.mesh, true, true);

			buildingMeshes.push(this.mesh);

			this.regenerate = false;
		}
	};
}


PorchRailings.ENTRY_WIDTH = 3;
PorchRailings.POST_WIDTH = 0.291;
PorchRailings.RAILING_WIDTH = 0.1;
PorchRailings.RAILING_VERTICAL_GAP = 0.3;
PorchRailings.RAILING_HEIGHT = 3;
PorchRailings.PICKET_WIDTH = 0.1;
PorchRailings.PICKET_DEPTH = 0.1;
PorchRailings.PICKET_GAP = 0.3;

