/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function HipRoof(buttonData)
{
	////Element.call(this, "Hip Roof", "HipRoof", "", -1, -1, "", "", "", price);

	Element.call(this, buttonData);

	this.buttonData.type = ELEM_HIP_ROOF;

	this.draggable = false;

	this.regenerate = false;

	this.Generate = function (buildingMeshes)
	{};

	this.UpdateMatrix = function ()
	{};

	this.Destroy = function ()
	{
		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
	};

}

HipRoof.AddHipRoof = function (buttonData)
{
	let hipRoof = new HipRoof(buttonData);

	Elements.AddElement(hipRoof);

	buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

	return hipRoof;
};
