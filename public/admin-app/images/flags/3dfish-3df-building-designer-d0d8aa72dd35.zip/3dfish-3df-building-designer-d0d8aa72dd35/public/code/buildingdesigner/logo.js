/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Logo(logoFileName)
{
	this.length = 0;

	this.wall = null;

	this.matrix = null;

	this.pos = new THREE.Vector3(0, 0, 0);

	this.mesh = null;

	this.logoTextureFileName = DIR_IMAGES + logoFileName;

	this.visible = true;

	this.logoCanvas = document.createElement("canvas");
	this.logoContext = this.logoCanvas.getContext("2d");

	this.logoTexture = new THREE.Texture(this.logoCanvas);

	this.logoImage = new Image();
	this.logoImage.src = this.logoTextureFileName;

	this.logoImage.onload = function()
	{
		this.loaded = true;
	};

	this.regenerate = true;

	this.SetVisibility = function(visible)
	{
		this.visible = visible;

		if (this.mesh)
		{
			this.mesh.material.visible = visible;
		}
	};

	this.SetLogoFileName = function (name)
	{
		this.logoTextureFileName = name;
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	// .Generate is called once for the logo
	this.Generate = function ()
	{
		if (this.regenerate && this.visible && this.logoImage.loaded)
		{
			this.logoContext.drawImage(this.logoImage, 0, 0, 300, 150);

			this.logoTexture.needsUpdate = true;

			let logoMaterial = new THREE.MeshBasicMaterial({map: this.logoTexture});
			logoMaterial.transparent = true;

			this.mesh = new THREE.Mesh(new THREE.PlaneGeometry(6 * this.logoTexture.image.width/this.logoTexture.image.height, 6), logoMaterial);

			threeScene.add(this.mesh);

			this.regenerate = false;
		}

		this.UpdateMatrix();
	};

	this.UpdateMatrix = function ()
	{
		if (this.mesh)
		{
			this.SetWall(buildingDesigner.building.walls.GetWall(WALL_FRONT));

			if (this.visible && this.wall && this.wall.matrix)
			{
				let wallMatrix = this.wall.matrix;

				max = undefined;

				for (let i=0; i<this.wall.wallFacets.length; i++)
				{
					pos = new THREE.Vector3().setFromMatrixPosition(this.wall.wallFacets[i].matrix);

					if (this.wall.eWall == WALL_FRONT || this.wall.eWall == WALL_BACK)
					{
						value = Math.abs(pos.x);
					}
					else
					{
						value = Math.abs(pos.z);
					}


					if (value>max || !max)
					{
						max = value;

						wallMatrix = this.wall.wallFacets[i].matrix;
					}
				}

				let matrix = new THREE.Matrix4();

				matrix = new THREE.Matrix4().multiplyMatrices(wallMatrix, matrix);

				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, Ruler.RULER_THICKNESS, Logo.DistanceToWall));

				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationX(-Math.PI/2));

				this.mesh.matrix = new THREE.Matrix4();
				this.mesh.matrixAutoUpdate = false;
				this.mesh.applyMatrix4(matrix);
			}
		}
	};

	this.SetWall = function (wall)
	{
		if (!this.wall || this.wall != wall)
		{
			this.wall = wall;
		}

		if (this.wall)
		{
			return true;
		}
		else
		{
			return false;
		}
	};

	this.SetPos = function (x, y, z)
	{
		this.pos.x = x;
		this.pos.y = y;
		this.pos.z = z;
	};

	this.SetPos = function (vector)
	{
		this.pos.x = vector.x;
		this.pos.y = vector.y;
		this.pos.z = vector.z;
	};

	this.SetLength = function (length)
	{
		this.length = length;
	};

	this.Destroy = function ()
	{
		if (this.mesh != null)
		{
			threeScene.remove(this.mesh);
			this.mesh = null;
		}
	};
}


Logo.DistanceToWall = 15;
