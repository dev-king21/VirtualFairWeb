/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8 */
/*eslint-disable no-console, no-unused-vars, no-undef */

function Door(buttonData, configuration)
{
	this.doorWidth = buttonData.width;

	if (buttonData.double_door_from_single_door)
		buttonData.width = buttonData.width / 2;

	Element.call(this, buttonData);

	this.buttonData.type = ELEM_DOOR;

	this.configurationMode = configuration;

	this.leftHinges = [];
	this.rightHinges = [];

	this.ramp = null;
	this.rampID = "";

	this.mesh = null;

	this.AddObjects();

	if (buttonData.double_door_from_single_door)
		buttonData.width = this.doorWidth;

	let doorHandles = this.component3DObjects.GetObjectsWithStringInName("handle");

	for (let i = 0; i < doorHandles.length; i++)
	{
		if (doorHandles[i].objectData.configurationMode != this.configurationMode && this.configurationMode != undefined && !isNaN(this.configurationMode))
			doorHandles[i].SetVisibility(false);
	}

	/**
	 * @method Door.GetDesignXMLString
	 * @returns {string} XML door design string
	 */
	this.GetDesignXMLString = function ()
	{
		let strElemType = ELEM_STRING[this.type];

		let strXml = "<ELEMENT ";

		strXml += " buttonData=\"" + AuxUtilities.JSONStringifyAndEncode(this.buttonData) + "\"";

		if (this.wall)
			strXml += " wall=\"" + WALL_STRING[this.wall.eWall] + "\"";

		strXml += " configurationMode=\"" + this.configurationMode + "\"";

		strXml += " x=\"" + this.pos.x + "\"";
		strXml += " y=\"" + this.pos.y + "\"";
		strXml += " z=\"" + this.pos.z + "\"";

		strXml += " colorID=\"" + this.colorID +
			"\" color_from_barn=\"" + this.colorFromBarn +
			"\" trimColor=\"" + this.trimColor +
			"\"";

		if (this.leftHinges && this.leftHinges.length > 0)
			strXml += " hingeButtonData=\"" + AuxUtilities.JSONStringifyAndEncode(this.leftHinges[0].buttonData) + "\"";
		else
			strXml += " hingeButtonData=\"null\"";

		strXml += " rampID=\"" + this.rampID + "\"";

		strXml += " defaultElementData=\"" + AuxUtilities.JSONStringifyAndEncode(this.defaultElementData) + "\"";

		strXml += "></ELEMENT>";

		return strXml;
	};

	/**
	 * @method Door.GetDesignObject
	 * @returns {Object} door object
	 */
	this.GetDesignObject = function ()
	{
		let door = {
			buttonData: this.buttonData,
			configurationMode: this.configurationMode,
			x: this.pos.x,
			y: this.pos.y,
			z: this.pos.z,
			colorID: this.colorID,
			colorFromBarn: this.colorFromBarn,
			trimColor: this.trimColor,
			rampID: this.rampID,
			defaultElementData: this.defaultElementData
		};
		if (this.leftHinges && this.leftHinges.length > 0)
		{
			door.hingeButtonData = this.leftHinges[0].buttonData;
		}
		else
		{
			door.hingeButtonData = null;
		}
		if (this.wall)
		{
			door.wall = this.wall.eWall;
			door.facetIndex = this.facetIndex;
		}
		return door;
	};

	this.GetObjectsData = function ()
	{
		let objectsDataArray = this.component3DObjects.GetObjectsData();

		if (this.leftHinges && this.leftHinges.length > 0)
		{
			objectsDataArray = AuxUtilities.MergeArrays(objectsDataArray, this.leftHinges[0].component3DObjects.GetObjectsData());
		}

		return objectsDataArray;
	};

	/**
	 * @method Door.GetObjectsDataObject
	 * @returns {Object}
	 */
	this.GetObjectsDataObject = function ()
	{
		let objectsDataArray = this.component3DObjects.GetObjectsDataObject();

		if (this.leftHinges && this.leftHinges.length > 0)
		{
			objectsDataArray = AuxUtilities.MergeArrays(objectsDataArray, this.leftHinges[0].component3DObjects.GetObjectsDataObject());
		}

		return objectsDataArray;
	};

	this.UpdateModifiedHingePlacement = async function ()
	{
		let params = {
			elem_id: this.buttonData.elem_id,
			left_hinge_coords: JSON.stringify(this.buttonData.left_hinge_coords),
			right_hinge_coords: JSON.stringify(this.buttonData.right_hinge_coords)
		}

			let [err,resultStr] = await to(NodeJSUtilities.UQuery("masterAction",{request: "updateDoorHingePlacement", ...params}));

		if (resultStr == "Success!")
		{
			return true;
		}

		return false;
	};

	this.UpdateModifiedElements3DObjects = function ()
	{
		this.component3DObjects.UpdateModified3DObjects();

		let hingeCoordsNeedUpdate = false;
		if (this.leftHinges)
		{
			for (let i = 0; i < this.leftHinges.length; i++)
			{
				if (this.leftHinges[i].component3DObjects.objectList[0].modified)
				{
					this.leftHinges[i].component3DObjects.objectList[0].DetermineRotationAndRoundValues();

					this.buttonData.left_hinge_coords[i][0] = this.leftHinges[i].component3DObjects.objectList[0].pos.x;
					this.buttonData.left_hinge_coords[i][1] = this.leftHinges[i].component3DObjects.objectList[0].pos.y;
					this.buttonData.left_hinge_coords[i][2] = this.leftHinges[i].component3DObjects.objectList[0].pos.z;

					hingeCoordsNeedUpdate = true;
				}
			}
		}

		if (this.rightHinges)
		{
			for (let i = 0; i < this.rightHinges.length; i++)
			{
				if (this.rightHinges[i].component3DObjects.objectList[0].modified)
				{
					this.rightHinges[i].component3DObjects.objectList[0].DetermineRotationAndRoundValues();

					this.buttonData.right_hinge_coords[i][0] = this.rightHinges[i].component3DObjects.objectList[0].pos.x;
					this.buttonData.right_hinge_coords[i][1] = this.rightHinges[i].component3DObjects.objectList[0].pos.y;
					this.buttonData.right_hinge_coords[i][2] = this.rightHinges[i].component3DObjects.objectList[0].pos.z;

					hingeCoordsNeedUpdate = true;
				}
			}

		}


		if (hingeCoordsNeedUpdate)
		{
			if (this.UpdateModifiedHingePlacement())
			{
				for (let i = 0; i < this.leftHinges.length; i++)
					this.leftHinges[i].component3DObjects.objectList[0].modified = false;

				for (let i = 0; i < this.rightHinges.length; i++)
					this.rightHinges[i].component3DObjects.objectList[0].modified = false;
			}
		}

	};

	this.SetPos = function (x, y, z)
	{
		this.pos.x = x;
		this.pos.y = (buildingDesigner.building.base ? buildingDesigner.building.floorHeight : 0) + this.buttonData.height / 2;
		this.pos.z = z;

		this.UpdateMatrix();
	};

	/**
	* This adds the hinges to the door
	* @method Door.CreateHinges
	* @param {object} hingeButtonData
	*/
	this.CreateHinges = function (hingeButtonData)
	{
		this.hingeButtonData = hingeButtonData;

		if (buttonData.available_hinges.indexOf(this.hingeButtonData.elem_ID) > -1)
		{
			if (!this.component3DObjects.boundingBox)
			{
				this.component3DObjects.CalculateGeometryScale(this.buttonData.double_door_from_single_door ? this.buttonData.width / 2 : this.buttonData.width, this.buttonData.height, this.buttonData.height);
				this.component3DObjects.CalculateGeometryCenter();
			}

			let newHinge;

			this.leftHinges = [];

			let hingesXOffset = 0;

			if (this.buttonData.double_door_from_single_door)
			{
				hingesXOffset = this.doorWidth / 4;
				hingesXOffset *= 1 / this.component3DObjects.scale.x;
			}

			for (let i = 0; i < this.buttonData.left_hinge_coords.length; i++)
			{
				newHinge = new Hinge(this.hingeButtonData, this);

				//newHinge.SetPos(this.component3DObjects.boundingBox.min.x - hingesXOffset, this.buttonData.left_hinge_coords[i][1], this.buttonData.left_hinge_coords[i][2]);
				newHinge.SetPos(this.buttonData.left_hinge_coords[i][0], this.buttonData.left_hinge_coords[i][1], this.buttonData.left_hinge_coords[i][2]);

				this.leftHinges.push(newHinge);
			}

			this.rightHinges = [];

			for (let i = 0; i < this.buttonData.right_hinge_coords.length; i++)
			{
				newHinge = new Hinge(this.hingeButtonData, this);

				//newHinge.SetPos(this.component3DObjects.boundingBox.max.x + hingesXOffset, this.buttonData.right_hinge_coords[i][1], this.buttonData.right_hinge_coords[i][2]);
				newHinge.SetPos(this.buttonData.right_hinge_coords[i][0], this.buttonData.right_hinge_coords[i][1], this.buttonData.right_hinge_coords[i][2]);

				newHinge.SetZRotation(Math.PI);

				this.rightHinges.push(newHinge);
			}
		}
		else
		{
			if (DEBUG)
			{
				alert("The hinge is not available for this door");
			}
		}
	};


	this.SetConfiguration = function (configurationMode)
	{
		this.configurationMode = configurationMode;

		let doorHandles = this.component3DObjects.GetObjectsWithStringInName("handle");

		for (let i = 0; i < doorHandles.length; i++)
		{
			if (doorHandles[i].objectData.configurationMode != this.configurationMode && this.configurationMode != undefined && !isNaN(this.configurationMode))
				doorHandles[i].SetVisibility(false);
			else
				doorHandles[i].SetVisibility(true);
		}
	};

	this.GetElementPointsOnWall = function ()
	{
		let points = [
			new THREE.Vector2(this.pos.x - this.doorWidth / 2, this.pos.y - this.buttonData.height / 2),
			new THREE.Vector2(this.pos.x - this.doorWidth / 2, this.pos.y + this.buttonData.height / 2),
			new THREE.Vector2(this.pos.x + this.doorWidth / 2, this.pos.y + this.buttonData.height / 2),
			new THREE.Vector2(this.pos.x + this.doorWidth / 2, this.pos.y - this.buttonData.height / 2)
		];

		return points;
	};

	this.GenerateInteriorFraming = function ()
	{
		let framingThickness;
		let framingWidth;

		////if (BuildingDesigner.buildingType == BUILDING_CARPORT)
		if (buildingDesigner.building.metalFraming)
		{
			framingThickness = buildingDesigner.building.roofRafter.data.thickness;
			framingWidth = buildingDesigner.building.roofRafter.data.width;
		}
		else
		{
			framingThickness = buildingDesigner.building.roofRafter.data.thickness;
			framingWidth = buildingDesigner.building.roofRafter.data.width;
		}

		this.GetInteriorFramingTexture();

		////if (TexturesDataUtilities.TextureLoaded(this.framingTexture))
		{
			let rafterCoords = this.GetClosestWallRafterCoords();

			let rafterCoordsCenter;
			let plankLength;

			let rafterXOffset;

			plankLength = rafterCoords.rightCoord - rafterCoords.leftCoord;

			rafterCoordsCenter = (rafterCoords.leftCoord + rafterCoords.rightCoord) / 2;

			rafterXOffset = rafterCoordsCenter - this.pos.x;

			if (this.wall.eWall == WALL_LEFT || this.wall.eWall == WALL_BACK)
				rafterXOffset *= -1;

			if (this.cutoutGeometry)
			{
				this.cutoutGeometry.computeBoundingBox();

				let height = (this.cutOutCenter.y + this.cutOutHeight / 2) - (buildingDesigner.building.base ? Floor.FLOOR_PANEL_THICKNESS : 0);

				let left = (this.cutOutCenter.x - this.cutOutWidth / 2) + (this.component3DObjects.geometryCenter.x - this.cutOutCenter.x);

				let right = (this.cutOutCenter.x + this.cutOutWidth / 2) + (this.cutOutCenter.x - this.component3DObjects.geometryCenter.x);

				let horizontalPlank = GeometryUtilities.CreateOrientatedBox(plankLength, framingThickness, framingWidth, this.framingColor, this.framingTexture, null, new THREE.Vector3(1 / this.component3DObjects.scale.x, 1 / this.component3DObjects.scale.y, 1 / this.component3DObjects.scale.y), new THREE.Vector3(this.component3DObjects.geometryCenter.x - plankLength / 2 + rafterXOffset, height, -(framingWidth + Wall.WALLTHICKNESS)));

				let verticalPlank1 = GeometryUtilities.CreateOrientatedBox(framingThickness, height, framingWidth, this.framingColor, this.framingTexture, null, new THREE.Vector3(1 / this.component3DObjects.scale.x, 1 / this.component3DObjects.scale.y, 1 / this.component3DObjects.scale.y), new THREE.Vector3(left-framingThickness, 0, -(framingWidth + Wall.WALLTHICKNESS)));
				let verticalPlank2 = GeometryUtilities.CreateOrientatedBox(framingThickness, height, framingWidth, this.framingColor, this.framingTexture, null, new THREE.Vector3(1 / this.component3DObjects.scale.x, 1 / this.component3DObjects.scale.y, 1 / this.component3DObjects.scale.y), new THREE.Vector3(right, 0, -(framingWidth + Wall.WALLTHICKNESS)));

				////if (BuildingDesigner.buildingType == BUILDING_CARPORT)
				if (buildingDesigner.building.metalFraming)
				{
					let mater = new THREE.MeshPhongMaterial({
						color: MetalRafters.METAL_RAFTERS_COLOR,
						specular: 0xFFFFFF,
						shininess: 100,
						map: this.framingTexture
					});

					horizontalPlank.material = mater;

					verticalPlank1.material = mater;
					verticalPlank2.material = mater;
				}

				horizontalPlank.type = ELEM_FRAMING;
				verticalPlank1.type = ELEM_FRAMING;
				verticalPlank2.type = ELEM_FRAMING;

				this.component3DObjects.mesh.add(horizontalPlank);
				this.component3DObjects.mesh.add(verticalPlank1);
				this.component3DObjects.mesh.add(verticalPlank2);
			}
		}

		return null;
	};

	this.AddHinges = function (hingeMeshBase, hingeCoords, zRotation, xOffset, buildingMeshes)
	{
		let hingeMesh;

		if (xOffset == undefined || xOffset == null)
			xOffset = 0;

		for (let i = 0; i < hingeCoords.length; i++)
		{
			hingeMesh = this.currentHinge.Generate(buildingMeshes);

			let matrix = new THREE.Matrix4();
			hingeMesh.matrix = matrix.clone();

			matrix = new THREE.Matrix4().makeTranslation(hingeCoords[i][0] + xOffset, hingeCoords[i][1], hingeCoords[i][2]);

			matrix.scale(new THREE.Vector3(hingeMesh.element.component3DObjects.scale.x, hingeMesh.element.component3DObjects.scale.y, hingeMesh.element.component3DObjects.scale.z));
			matrix.scale(new THREE.Vector3(1 / this.component3DObjects.scale.x, 1 / this.component3DObjects.scale.y, 1 / this.component3DObjects.scale.z));

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationZ(zRotation));

			hingeMesh.matrixAutoUpdate = false;
			hingeMesh.applyMatrix4(matrix);

			this.component3DObjects.mesh.add(hingeMesh);
		}
	};

	this.GenerateHinges = function (hinges, hingeCoords, zRotation, xOffset, buildingMeshes)
	{
		let hingeMesh;

		if (xOffset == undefined || xOffset == null)
			xOffset = 0;

		for (let i = 0; i < hinges.length; i++)
		{
			if (hinges[i].component3DObjects.objectList && hinges[i].component3DObjects.objectList.length > 0)
			{

				hinges[i].wall = this.wall;

				////if (hinges[i].component3DObjects.boundingBox == null)
				{
					hinges[i].component3DObjects.objectList[0].scale.x = 1;
					hinges[i].component3DObjects.objectList[0].scale.y = 1;
					hinges[i].component3DObjects.objectList[0].scale.z = 1;

					let origX = hinges[i].component3DObjects.objectList[0].pos.x;
					let origY = hinges[i].component3DObjects.objectList[0].pos.y;
					let origZ = hinges[i].component3DObjects.objectList[0].pos.z;

					hinges[i].component3DObjects.objectList[0].pos.x = 0;
					hinges[i].component3DObjects.objectList[0].pos.y = 0;
					hinges[i].component3DObjects.objectList[0].pos.z = 0;

					hinges[i].component3DObjects.CalculateGeometryScale(hinges[i].buttonData.width, hinges[i].buttonData.height, hinges[i].buttonData.height);
					hinges[i].component3DObjects.CalculateGeometryCenter();

					hinges[i].component3DObjects.objectList[0].pos.x = origX;
					hinges[i].component3DObjects.objectList[0].pos.y = origY;
					hinges[i].component3DObjects.objectList[0].pos.z = origZ;
				}

				hinges[i].component3DObjects.objectList[0].scale.x = hinges[i].component3DObjects.scale.x * 1 / this.component3DObjects.scale.x;
				hinges[i].component3DObjects.objectList[0].scale.y = hinges[i].component3DObjects.scale.y * 1 / this.component3DObjects.scale.y;
				hinges[i].component3DObjects.objectList[0].scale.z = hinges[i].component3DObjects.scale.z * 1 / this.component3DObjects.scale.z;

				hingeMesh = hinges[i].Generate(buildingMeshes);

				if (hingeMesh)
				{
					let matrix = new THREE.Matrix4();
					hingeMesh.matrix = matrix.clone();

					hingeMesh.matrixAutoUpdate = false;
					hingeMesh.applyMatrix4(matrix);

					this.component3DObjects.mesh.add(hingeMesh);
				}
			}
		}
	};

	this.Generate = function (buildingMeshes, subtractGeometryFromWall = false)
	{
		if (this.regenerate && this.wall && this.wall.matrix)
		{
			{
				if (this.component3DObjects.boundingBox == null)
				{
					this.component3DObjects.CalculateGeometryScale(this.buttonData.double_door_from_single_door ? this.buttonData.width / 2 : this.buttonData.width, this.buttonData.height, this.buttonData.height);
					this.component3DObjects.CalculateGeometryCenter();
				}

				if (!this.colorFromBarn && this.colorID && this.colorID != "undefined" && ColorsDataUtilities.colorsData.length > 0)
					this.component3DObjects.SetGuiDefinedColor(ColorsDataUtilities.FindColor(this.colorID).color);

				this.mesh = new THREE.Mesh();

				if (this.buttonData.double_door_from_single_door)
				{
					this.component3DObjects.Generate(buildingMeshes, this.component3DObjects.scale, true);

					if (this.configurationMode == Door.LEFT_OPENING)
						this.component3DObjects.SetCameraAndConfigurationModeVisibility(buildingDesigner.camera.modeCamera, OBJECT_CONFIGURATION2);
					else
						this.component3DObjects.SetCameraAndConfigurationModeVisibility(buildingDesigner.camera.modeCamera, OBJECT_CONFIGURATION1);

					let matrix = new THREE.Matrix4();

					matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(-this.buttonData.width / 4 / this.component3DObjects.scale.x, 0, 0));

					let mesh1 = MeshUtilities.CloneMesh(this.component3DObjects.mesh);

					mesh1.matrixAutoUpdate = false;
					mesh1.applyMatrix4(matrix);

					this.mesh.add(mesh1);

					this.component3DObjects.Generate(buildingMeshes, this.component3DObjects.scale, true);

					if (this.configurationMode == Door.RIGHT_OPENING)
						this.component3DObjects.SetCameraAndConfigurationModeVisibility(buildingDesigner.camera.modeCamera, OBJECT_CONFIGURATION3);
					else
						this.component3DObjects.SetCameraAndConfigurationModeVisibility(buildingDesigner.camera.modeCamera, OBJECT_CONFIGURATION1);

					let mesh2 = MeshUtilities.CloneMesh(this.component3DObjects.mesh);

					matrix = new THREE.Matrix4();

					matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.buttonData.width / 4 / this.component3DObjects.scale.x, 0, 0));

					mesh2.matrixAutoUpdate = false;
					mesh2.applyMatrix4(matrix);

					this.mesh.add(mesh2);

					this.component3DObjects.mesh = this.mesh;
				}
				else
				{
					this.component3DObjects.Generate(buildingMeshes, this.component3DObjects.scale, false);
					this.component3DObjects.SetCameraAndConfigurationModeVisibility(buildingDesigner.camera.modeCamera, this.configurationMode);
				}

				if (!this.hingeButtonData && this.component3DObjects.boundingBox)
				{
					if (this.buttonData.available_hinges && this.buttonData.available_hinges.length > 0)
					{
						let hingeButtonData = GuiDataUtilities.GetHingeButtonData(this.buttonData.available_hinges[0]);

						if (hingeButtonData)
							this.CreateHinges(hingeButtonData);
					}
				}

				if (this.hingeButtonData)
				{
					let hingeMeshBase = null;

					let hinges;
					let hingeCoords;

					if (this.buttonData.double_door_from_single_door)
					{
						let xOffset = 0;

						hinges = this.leftHinges;
						hingeCoords = this.buttonData.left_hinge_coords;
						xOffset = -this.doorWidth / 4;
						xOffset *= 1 / this.component3DObjects.scale.x;

						this.GenerateHinges(hinges, hingeCoords, 0, xOffset, buildingMeshes);

						hinges = this.rightHinges;
						hingeCoords = this.buttonData.right_hinge_coords;
						xOffset = this.doorWidth / 4;
						xOffset *= 1 / this.component3DObjects.scale.x;

						this.GenerateHinges(hinges, hingeCoords, MathUtilities.PI, xOffset, buildingMeshes);
					}
					else if (buttonData.double_door)
					{
						hinges = this.leftHinges;
						hingeCoords = this.buttonData.left_hinge_coords;

						this.GenerateHinges(hinges, hingeCoords, 0, 0, buildingMeshes);

						hinges = this.rightHinges;
						hingeCoords = this.buttonData.right_hinge_coords;

						this.GenerateHinges(hinges, hingeCoords, MathUtilities.PI, 0, buildingMeshes);
					}
					else
					{
						if (this.configurationMode == Door.LEFT_OPENING)
						{
							hinges = this.leftHinges;
							hingeCoords = this.buttonData.left_hinge_coords;

							this.GenerateHinges(hinges, hingeCoords, 0, 0, buildingMeshes);
						}
						else
						if (this.configurationMode == Door.RIGHT_OPENING)
						{
							hinges = this.rightHinges;
							hingeCoords = this.buttonData.right_hinge_coords;

							this.GenerateHinges(hinges, hingeCoords, MathUtilities.PI, 0, buildingMeshes);
						}
					}
				}

				if (this.selected)
				{
					this.GenerateSelectedBoxes(this.component3DObjects.mesh, this.component3DObjects.mesh.matrix, new THREE.Vector3(this.buttonData.double_door_from_single_door ? 2 : 1, 1, 1));
				}

				this.component3DObjects.mesh.type = ELEM_DOOR;

				MeshUtilities.SetElement(this.component3DObjects.mesh, this);

				this.component3DObjects.mesh.castShadow = true;

				this.component3DObjects.mesh.receiveShadow = true;

				this.component3DObjects.mesh.visible = true;
			}

			this.UpdateMatrix();

			if (!this.dragging && subtractGeometryFromWall)
			{
				this.SubtractCutoutGeometryFromBuildingMeshes(buildingMeshes, 1 / this.component3DObjects.scale.z);

				if (buildingDesigner.camera.modeCamera == Camera.CAM_MODE_INTERIOR)
					this.GenerateInteriorFraming();
			}

			this.UpdateMatrix();

			this.regenerate = false;
		}

		return this.component3DObjects.mesh;
	};

	this.UpdateMatrix = function ()
	{
		if (this.component3DObjects.mesh && this.wall.matrix)
		{
			let matrix;

			if (this.facetIndex != undefined && this.facetIndex != null && this.wall.wallFacets != undefined && this.wall.wallFacets[this.facetIndex])
			{
				matrix = this.wall.wallFacets[this.facetIndex].matrix.clone();
			}
			else
			{
				matrix = this.wall.matrix.clone();
			}

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z));

			if (this.wall.eWall == WALL_LEFT || this.wall.eWall == WALL_BACK)
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationY(-MathUtilities.PI));

			if (this.dragging)
			{
				if (buildingDesigner.camera.modeCamera == Camera.CAM_MODE_EXTERIOR)
					matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, 0, DRAGGING_Z_SHIFT));
				else
					matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(0, 0, -DRAGGING_Z_SHIFT));
			}

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(-this.component3DObjects.geometryCenter.x, -this.component3DObjects.geometryCenter.y, 0));

			matrix.scale(new THREE.Vector3(this.component3DObjects.scale.x, this.component3DObjects.scale.y, this.component3DObjects.scale.y));

			this.component3DObjects.mesh.matrix = new THREE.Matrix4();
			this.component3DObjects.mesh.matrixAutoUpdate = false;
			this.component3DObjects.mesh.applyMatrix4(matrix);

			if (this.selected)
			{
				threeRenderer.shadowMap.needsUpdate = true;
				this.horizRuler.SetRegenerate(true);
				this.vertRuler.SetRegenerate(true);

				let elementWidth = this.buttonData.width; //for generating the rulers
				this.buttonData.width = this.doorWidth;

				////this.GenerateRulers();

				this.buttonData.width = elementWidth;

				if (this.dragging)
				{
					Elements.ProcessCollisions(this);
				}
			}
		}
	};

	this.Destroy = function ()
	{
		if (this.ramp)
		{
			Elements.DeleteElement(this.ramp);
		}

		this.horizRuler.Destroy();
		this.vertRuler.Destroy();
	};
}

Door.AddDoor = function (doorButtonData, configuration)
{
	if (!doorButtonData)
		doorButtonData = ElementsMenu.currentButtonClicked;

	if (doorButtonData && doorButtonData.object3D_name)
	{
		let element = null;

		if (doorButtonData.object3D_name.indexOf("Run-In") > -1)
		{
			element = new RunIn(doorButtonData);
		}
		else
		{
			element = new Door(doorButtonData, configuration);

			element.SetConfiguration(configuration);
		}

		Elements.AddElement(element);

		return element;
	}
};

Door.LEFT_OPENING = OBJECT_CONFIGURATION2;
Door.RIGHT_OPENING = OBJECT_CONFIGURATION3;

// The correct place to call parent object is in child class constructor
// as we call it in above Student function code
Door.prototype = Object.create(Element.prototype);
// Set the "constructor" property to refer to Student
Door.prototype.constructor = Door;
