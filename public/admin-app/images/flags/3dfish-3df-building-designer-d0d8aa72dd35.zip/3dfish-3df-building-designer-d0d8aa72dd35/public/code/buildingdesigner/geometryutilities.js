/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function GeometryUtilities()
{}

GeometryUtilities.stlLoader = new THREE.STLLoader();
GeometryUtilities.objLoader = new THREE.OBJLoader();

GeometryUtilities.fileData = [];
GeometryUtilities.geometry = [];

GeometryUtilities.geometryFilenamesToBeLoaded = [];

GeometryUtilities.currentFilenameBeingLoadedIndex = -1;

GeometryUtilities.objectsLoaded = false;


GeometryUtilities.CreateGeometryFromBoundingBox = function (boundingBox, depth)
{
	let boxWidth = boundingBox.max.x - boundingBox.min.x;
	let boxHeight = boundingBox.max.y - boundingBox.min.y;
	let boxDepth = boundingBox.max.z - boundingBox.min.z;

	let centerX = (boundingBox.min.x + boundingBox.max.x) / 2;
	let centerY = (boundingBox.min.y + boundingBox.max.y) / 2;
	let centerZ = (boundingBox.min.z + boundingBox.max.z) / 2;

	if (depth == undefined)
		depth = boxDepth * 4;

	let boxGeom = new THREE.BoxGeometry(boxWidth, boxHeight, depth);

	boxGeom.matrixAutoUpdate = false;
	boxGeom.applyMatrix4(new THREE.Matrix4().makeTranslation(centerX, centerY, centerZ));

	return boxGeom;
};

GeometryUtilities.ResizeBoundingBox = function (boundingBox, xInc, yInc, zInc)
{
	if (xInc)
	{
		boundingBox.min.x -= xInc / 2;
		boundingBox.max.x += xInc / 2;
	}

	if (yInc)
	{
		boundingBox.min.y -= yInc / 2;
		boundingBox.max.y += yInc / 2;
	}

	if (zInc)
	{
		boundingBox.min.z -= zInc / 2;
		boundingBox.max.z += zInc / 2;
	}

	return boundingBox;
};


GeometryUtilities.GetApexCoordIndex = function (framingPoints)
{
	let apexFound = false;

	for (let i = 0; i < framingPoints.length; i++)
	{
		if (!apexFound && framingPoints[i + 1][1] <= framingPoints[i][1])
			return i;
	}

	return -1;
};

GeometryUtilities.TranslatePoints = function (points, x, y)
{
	for (let i = 0; i < points.length; i++)
	{
		points[i][0] += x;
		points[i][1] += y;
	}

	return points;
};

GeometryUtilities.GenerateCurve = function (width, height)
{
	let points = [];

	let x;
	let r = height * height;

	let ySegments = 30;

	let varYInc = height / ySegments;

	let y = 0;

	let ellipseRatio = width / height;

	for (let i = 0; i <= ySegments; i++)
	{
		if (y > height)
			x = 0;
		else
		{
			x = Math.sqrt(r - y * y);

			x *= ellipseRatio;
		}

		points.push([x, y]);

		y += varYInc;
	}

	return points;
};

GeometryUtilities.GenerateCurveCrossSection = function (points, width)
{
	let crossSectionPoints = [];

	for (let i = 0; i < points.length; i++)
	{
		crossSectionPoints.push(points[i]);
	}

	for (let i = points.length - 1; i >= 0; i--)
	{
		crossSectionPoints.push([points[i][0] + width, points[i][1]]);
	}

	return crossSectionPoints;
};

GeometryUtilities.ExtrudeGeometry = function (frontCrossSection, backCrossSection, thickness, rotTex90, frontSideClosed, backSideClosed)
{
	let geometry = new THREE.Geometry();

	let vertice;

	for (let i = 0; i < frontCrossSection.length; i++)
	{
		vertice = new THREE.Vector3(frontCrossSection[i].x, frontCrossSection[i].y, thickness);
		geometry.vertices.push(vertice);
	}

	let holes = [];

	if (frontSideClosed || frontSideClosed == undefined || frontSideClosed == null)
	{
		let triangles = THREE.ShapeUtils.triangulateShape(geometry.vertices, holes);

		for (let i = 0; i < triangles.length; i++)
		{
			geometry.faces.push(new THREE.Face3(triangles[i][0], triangles[i][1], triangles[i][2]));

			geometry.faceVertexUvs[0].push([
				new THREE.Vector2(0, 0),
				new THREE.Vector2(0, 0),
				new THREE.Vector2(0, 0)
			]);
		}
	}

	let extrudeOffset = frontCrossSection.length;

	let extrudeFarSurfaceVertices = [];

	let i;

	for (i = 0; i < backCrossSection.length; i++)
	{
		vertice = new THREE.Vector3(backCrossSection[i].x, backCrossSection[i].y, 0);
		extrudeFarSurfaceVertices.push(vertice);

		geometry.vertices.push(vertice);
	}


	if (backSideClosed || backSideClosed == undefined || backSideClosed == null)
	{
		triangles = THREE.ShapeUtils.triangulateShape(extrudeFarSurfaceVertices, holes);

		for (let i = 0; i < triangles.length; i++)
		{
			geometry.faces.push(new THREE.Face3(extrudeOffset + triangles[i][2], extrudeOffset + triangles[i][1], extrudeOffset + triangles[i][0]));

			geometry.faceVertexUvs[0].push([
				new THREE.Vector2(0, 0),
				new THREE.Vector2(0, 0),
				new THREE.Vector2(0, 0)
			]);
		}
	}

	let totalLength = 0;

	let vertice1, vertice2;

	for (i = 0; i < frontCrossSection.length - 1; i++)
	{
		vertice1 = new THREE.Vector2(frontCrossSection[i].x, frontCrossSection[i].y);
		vertice2 = new THREE.Vector2(frontCrossSection[i + 1].x, frontCrossSection[i + 1].y);

		totalLength += vertice2.sub(vertice1).length();
	}

	vertice1 = new THREE.Vector2(frontCrossSection[i].x, frontCrossSection[i].y);
	vertice2 = new THREE.Vector2(frontCrossSection[0].x, frontCrossSection[0].y);

	totalLength += vertice2.sub(vertice1).length();

	let length = 0;

	let maxTexCoordX = totalLength;
	let maxTexCoordY = thickness;

	let texCoord1, texCoord2;

	for (i = 0; i < frontCrossSection.length - 1; i++)
	{
		geometry.faces.push(new THREE.Face3(i, i + 1, extrudeOffset + i + 1, null, null, frontCrossSection[i].s));


		vertice1 = new THREE.Vector2(frontCrossSection[i].x, frontCrossSection[i].y);
		vertice2 = new THREE.Vector2(frontCrossSection[i + 1].x, frontCrossSection[i + 1].y);

		texCoord1 = length;

		length += vertice2.sub(vertice1).length();

		texCoord2 = length;

		geometry.faces.push(new THREE.Face3(extrudeOffset + i + 1, extrudeOffset + i, i, null, null, frontCrossSection[i].s));

		if (frontCrossSection[i].u == undefined)
		{
			if (!rotTex90)
			{
				geometry.faceVertexUvs[0].push([
					new THREE.Vector2(texCoord1, 0),
					new THREE.Vector2(texCoord2, 0),
					new THREE.Vector2(texCoord2, maxTexCoordY)
				]);

				geometry.faceVertexUvs[0].push([
					new THREE.Vector2(texCoord2, maxTexCoordY),
					new THREE.Vector2(texCoord1, maxTexCoordY),
					new THREE.Vector2(texCoord1, 0)
				]);
			}
			else
			{
				geometry.faceVertexUvs[0].push([
					new THREE.Vector2(maxTexCoordY, texCoord1),
					new THREE.Vector2(maxTexCoordY, texCoord2),
					new THREE.Vector2(0, texCoord2)
				]);

				geometry.faceVertexUvs[0].push([
					new THREE.Vector2(0, texCoord2),
					new THREE.Vector2(0, texCoord1),
					new THREE.Vector2(maxTexCoordY, texCoord1)
				]);
			}
		}
		else
		{
			if (!rotTex90)
			{
				geometry.faceVertexUvs[0].push([
					new THREE.Vector2(frontCrossSection[i].u, frontCrossSection[i].v),
					new THREE.Vector2(frontCrossSection[i + 1].u, frontCrossSection[i + 1].v),
					new THREE.Vector2(frontCrossSection[i + 1].u2, frontCrossSection[i + 1].v2)
				]);

				geometry.faceVertexUvs[0].push([
					new THREE.Vector2(frontCrossSection[i + 1].u2, frontCrossSection[i + 1].v2),
					new THREE.Vector2(frontCrossSection[i].u2, frontCrossSection[i].v2),
					new THREE.Vector2(frontCrossSection[i].u, frontCrossSection[i].v)
				]);
			}
			else
			{
				geometry.faceVertexUvs[0].push([
					new THREE.Vector2(frontCrossSection[i].v2, frontCrossSection[i].u),
					new THREE.Vector2(frontCrossSection[i].v2, frontCrossSection[i + 1].u),
					new THREE.Vector2(frontCrossSection[i].v, frontCrossSection[i + 1].u)
				]);

				geometry.faceVertexUvs[0].push([
					new THREE.Vector2(frontCrossSection[i].v, frontCrossSection[i + 1].u2),
					new THREE.Vector2(frontCrossSection[i].v, frontCrossSection[i].u2),
					new THREE.Vector2(frontCrossSection[i].v2, frontCrossSection[i].u)
				]);
			}
		}
	}

	geometry.faces.push(new THREE.Face3(i, 0, extrudeOffset));

	geometry.faces.push(new THREE.Face3(extrudeOffset, extrudeOffset + i, i));

	if (frontCrossSection[i].u == undefined)
	{
		if (!rotTex90)
		{
			geometry.faceVertexUvs[0].push([
				new THREE.Vector2(texCoord2, 0),
				new THREE.Vector2(maxTexCoordX, 0),
				new THREE.Vector2(maxTexCoordX, maxTexCoordY)
			]);

			geometry.faceVertexUvs[0].push([
				new THREE.Vector2(maxTexCoordX, maxTexCoordY),
				new THREE.Vector2(texCoord2, maxTexCoordY),
				new THREE.Vector2(texCoord2, 0)
			]);
		}
		else
		{
			geometry.faceVertexUvs[0].push([
				new THREE.Vector2(maxTexCoordY, texCoord2),
				new THREE.Vector2(maxTexCoordY, maxTexCoordX),
				new THREE.Vector2(0, maxTexCoordX)
			]);

			geometry.faceVertexUvs[0].push([
				new THREE.Vector2(0, maxTexCoordX),
				new THREE.Vector2(0, texCoord2),
				new THREE.Vector2(maxTexCoordY, texCoord2)
			]);
		}
	}
	else
	{
		geometry.faceVertexUvs[0].push([
			new THREE.Vector2(frontCrossSection[i].u, frontCrossSection[i].v),
			new THREE.Vector2(frontCrossSection[0].u, frontCrossSection[0].v),
			new THREE.Vector2(frontCrossSection[0].u2, frontCrossSection[0].v2)
		]);

		geometry.faceVertexUvs[0].push([
			new THREE.Vector2(frontCrossSection[0].u2, frontCrossSection[0].v2),
			new THREE.Vector2(frontCrossSection[i].u2, frontCrossSection[i].v2),
			new THREE.Vector2(frontCrossSection[i].u, frontCrossSection[i].v, 0)
		]);
	}

	geometry.computeFaceNormals();

	return geometry;
};

GeometryUtilities.GetSurfaceLength = function (surface)
{
	let line;

	let totalLength = 0;

	for (let i = 0; i < surface.length - 1; i++)
	{
		line = new THREE.Vector2(surface[i + 1][0] - surface[i][0], surface[i + 1][1] - surface[i][1]);

		totalLength += line.length();
	}

	return totalLength;
};


GeometryUtilities.GenerateExtendedSurface = function (array, start, end, thickness)
{
	let surfacePoints = [];

	let line = new THREE.Vector2(array[start + 1][0] - array[start][0], array[start + 1][1] - array[start][1]);

	line.divideScalar(line.length());
	line.multiplyScalar(thickness);

	let point = new THREE.Vector2(array[start][0], array[start][1]).sub(line);

	surfacePoints.push([point.x, point.y]);

	for (let i = start + 1; i <= end - 1; i++)
		surfacePoints.push(array[i]);

	line = new THREE.Vector2(array[end][0] - array[end - 1][0], array[end][1] - array[end - 1][1]);

	line.divideScalar(line.length());
	line.multiplyScalar(thickness);

	point = new THREE.Vector2(array[end][0], array[end][1]).add(line);

	surfacePoints.push([point.x, point.y]);

	return surfacePoints;
};

GeometryUtilities.ReplaceApexWithAdjCoords = function (framingPoints, shift)
{
	let newPoints = [];

	let apexFound = false;

	for (let i = 0; i < framingPoints.length; i++)
	{
		newPoints.push(framingPoints[i]);

		if (!apexFound && framingPoints[i + 2][1] <= framingPoints[i + 1][1])
		{
			apexFound = true;

			let line = new THREE.Vector2(framingPoints[i + 1][0] - framingPoints[i][0], framingPoints[i + 1][1] - framingPoints[i][1]);

			line.divideScalar(line.length());
			line.multiplyScalar(shift);

			let newPoint = new THREE.Vector2(framingPoints[i + 1][0], framingPoints[i + 1][1]).sub(line);

			newPoints.push([newPoint.x, newPoint.y]);

			line = new THREE.Vector2(framingPoints[i + 2][0] - framingPoints[i + 1][0], framingPoints[i + 2][1] - framingPoints[i + 1][1]);

			line.divideScalar(line.length());
			line.multiplyScalar(shift);

			newPoint = new THREE.Vector2(framingPoints[i + 1][0], framingPoints[i + 1][1]).add(line);

			newPoints.push([newPoint.x, newPoint.y]);

			i++;
		}
	}

	return newPoints;
};


GeometryUtilities.IncreaseResolution = function (array, start, end, size)
{
	let surfacePoints = [];

	let line;

	let newPointsCount;
	let newPoint;

	let newSize;
	for (let i = start; i < end; i++)
	{
		surfacePoints.push(array[i]);

		line = new THREE.Vector2(array[i + 1][0] - array[i][0], array[i + 1][1] - array[i][1]);

		newPointsCount = line.length() / size;

		newPointsCount = Math.floor(newPointsCount);

		newSize = line.length() / newPointsCount;

		line.divideScalar(line.length());
		line.multiplyScalar(newSize);

		for (let j = 0; j < newPointsCount - 1; j++)
		{
			newPoint = new THREE.Vector2(surfacePoints[surfacePoints.length - 1][0], surfacePoints[surfacePoints.length - 1][1]).add(line);

			surfacePoints.push([newPoint.x, newPoint.y]);
		}
	}

	surfacePoints.push(array[end]);

	return surfacePoints;
};

GeometryUtilities.GetSurfacePoint = function (array, index, start, end, thickness, sideAngle, distAlongLine)
{
	let line1;
	let line2;

	let perp1;
	let perp2;

	let point;
	let startPoint;
	let endPoint;

	if (distAlongLine == undefined || distAlongLine == null)
		distAlongLine = 0;

	if (index == start || distAlongLine > 0)
	{
		switch (sideAngle)
		{
		case (Roof.ANGLED_TRIM):
			line1 = new THREE.Vector2(array[index + 1][0] - array[index][0], array[index + 1][1] - array[index][1]);

			perp1 = MathUtilities.GetPerpendicular(line1);

			perp1.divideScalar(perp1.length());
			perp1.multiplyScalar(thickness);

			if (distAlongLine > 0)
			{
				line1.divideScalar(line1.length());
				line1.multiplyScalar(distAlongLine);

				point = perp1.add(line1.add(new THREE.Vector2(array[index][0], array[index][1])));
			}
			else
				point = perp1.add(new THREE.Vector2(array[index][0], array[index][1]));
			break;

		case (Roof.VERTICAL_TRIM):
			startPoint = new THREE.Vector2(array[index][0], array[index][1]);
			point = startPoint.add(new THREE.Vector2(0, thickness));
			break;

		case (Roof.HORIZONTAL_TRIM):
			startPoint = new THREE.Vector2(array[index][0], array[index][1]);
			point = startPoint.add(new THREE.Vector2(-thickness, 0));
			break;
		}
	}
	else
	if (index >= start && index < end)
	{
		line1 = new THREE.Vector2(array[index][0] - array[index - 1][0], array[index][1] - array[index - 1][1]);
		line1Inverse = new THREE.Vector2(array[index - 1][0] - array[index][0], array[index - 1][1] - array[index][1]);
		line2 = new THREE.Vector2(array[index + 1][0] - array[index][0], array[index + 1][1] - array[index][1]);

		perp1 = MathUtilities.GetPerpendicular(line1);

		perp2 = MathUtilities.GetPerpendicular(line2);

		perp1.add(perp2);

		perp1.divideScalar(perp1.length());

		let acosValue = line1Inverse.dot(line2) / (line1Inverse.length() * line2.length());

		let lineAngle = Math.acos(MathUtilities.Round(acosValue, 2));

		let widthPointSurfacePointAngle = (MathUtilities.PI * 2 - lineAngle) / 2 - MathUtilities.PI2;

		let pointHeight = thickness / Math.cos(widthPointSurfacePointAngle);

		perp1.multiplyScalar(pointHeight);

		point = perp1.add(new THREE.Vector2(array[index][0], array[index][1]));
	}
	else
	if (index == end)
	{
		switch (sideAngle)
		{
		case (Roof.ANGLED_TRIM):
			line1 = new THREE.Vector2(array[index][0] - array[index - 1][0], array[index][1] - array[index - 1][1]);

			perp1 = MathUtilities.GetPerpendicular(line1);

			perp1.divideScalar(perp1.length());
			perp1.multiplyScalar(thickness);

			point = perp1.add(new THREE.Vector2(array[index][0], array[index][1]));
			break;

		case (Roof.VERTICAL_TRIM):
			endPoint = new THREE.Vector2(array[index][0], array[index][1]);
			point = endPoint.add(new THREE.Vector2(0, thickness));
			break;

		case (Roof.HORIZONTAL_TRIM):
			endPoint = new THREE.Vector2(array[index][0], array[index][1]);
			point = endPoint.add(new THREE.Vector2(thickness, 0));
			break;
		}
	}

	return [point.x, point.y];
};

GeometryUtilities.GetSurfacePoints = function (array, start, end, thickness, sideAngle, enclosed)
{
	let surfacePoints = [];

	for (let i = start; i <= end; i++)
		surfacePoints.push(this.GetSurfacePoint(array, i, start, end, thickness, sideAngle));


	if (enclosed == undefined || enclosed)
	{
		for (let i = end; i >= start; i--)
			surfacePoints.push([array[i][0], array[i][1]]);
	}

	return surfacePoints;
};

GeometryUtilities.GetSurfacePointsUsingProfile = function (array, start, end, height, sideAngle, tiled, profilePoints, useSurfaceAsBase, thickness)
{
	if (thickness == undefined || thickness == null)
		thickness = Roof.TILE_THICKNESS;

	let surfacePoints = [];
	let surfacePoint;

	let apexFound = false;

	let ptThickness;

	if (useSurfaceAsBase == undefined || useSurfaceAsBase == null)
		useSurfaceAsBase = false;

	let profilePtIndex = start;

	let totalProcessedLength = 0;

	let prevTotalProcessedLength = totalProcessedLength;

	let distAlongLine;

	for (let i = start; i <= end; i++)
	{
		if (tiled)
		{
			let minThickness = height / 10;

			if (!apexFound && array[i + 1][1] <= array[i][1])
			{
				apexFound = true;

				surfacePoints.push(this.GetSurfacePoint(array, i, start, end, minThickness, sideAngle));
			}
			else
			{
				if (!apexFound)
					surfacePoints.push(this.GetSurfacePoint(array, i, start, end, minThickness, sideAngle));

				surfacePoints.push(this.GetSurfacePoint(array, i, start, end, height, sideAngle));

				if (apexFound)
					surfacePoints.push(this.GetSurfacePoint(array, i, start, end, minThickness, sideAngle));
			}
		}
		else
		{
			if (profilePoints)
			{
				while (profilePtIndex < profilePoints.length && MathUtilities.Round(profilePoints[profilePtIndex][0], 6) < totalProcessedLength)
				{
					distAlongLine = profilePoints[profilePtIndex][0] - prevTotalProcessedLength;

					if (distAlongLine > 0)
					{
						surfacePoint = this.GetSurfacePoint(array, i - 1, start, end, height + profilePoints[profilePtIndex][1], sideAngle, distAlongLine);

						profilePoint = profilePoints[profilePtIndex];

						surfacePoints.push([surfacePoint[0], surfacePoint[1], profilePoint[2], profilePoint[3], profilePoint[4], profilePoint[5], 0]);
					}

					profilePtIndex++;
				}

				if (profilePtIndex < profilePoints.length)
				{
					ptThickness = height + profilePoints[profilePtIndex][1];

					profilePoint = profilePoints[profilePtIndex];

					profilePtIndex++;

				}
				else
				{
					ptThickness = height;

					profilePoint = [0, 0, 0, 0];
				}
			}
			else
			{
				ptThickness = height;
				profilePoint = [0, 0, 0, 0];
			}

			surfacePoint = this.GetSurfacePoint(array, i, start, end, ptThickness, sideAngle);
			surfacePoints.push([surfacePoint[0], surfacePoint[1], profilePoint[2], profilePoint[3], profilePoint[4], profilePoint[5], 0]);

			if (i < array.length - 1)
			{
				prevTotalProcessedLength = totalProcessedLength;
				totalProcessedLength += MathUtilities.Round(new THREE.Vector2(array[i + 1][0] - array[i][0], array[i + 1][1] - array[i][1]).length(), 6);
			}
		}
	}

	if (useSurfaceAsBase)
	{
		for (let i = end; i >= start; i--)
			surfacePoints.push([array[i][0], array[i][1], 0, 0, 0, 0, 1]);
	}
	else
	{
		let length = surfacePoints.length;

		let newPoint, prevPoint;

		for (let i = length - 1; i >= 0; i--)
		{
			newPoint = new THREE.Vector2(surfacePoints[i][0], surfacePoints[i][1] - thickness);

			prevPoint = new THREE.Vector2(surfacePoints[surfacePoints.length - 1][0], surfacePoints[surfacePoints.length - 1][1]);

			surfacePoints.push([newPoint.x, newPoint.y, surfacePoints[i][2], surfacePoints[i][3], surfacePoints[i][4], surfacePoints[i][5], 1]);
		}
	}

	return surfacePoints;
};

GeometryUtilities.CreateBoxGeometry = function (width, height, thickness)
{
	let points = [];

	points.push({
		x: 0,
		y: 0
	});
	points.push({
		x: width,
		y: 0
	});
	points.push({
		x: width,
		y: height
	});
	points.push({
		x: 0,
		y: height
	});


	let shape = new THREE.Shape(points);
	let geom = new THREE.ExtrudeGeometry(shape, {
		depth: thickness,
		bevelEnabled: false
	});

	return geom;
};

GeometryUtilities.CreateBoxMesh = function (length, width, thickness, materialColor, texture)
{
	let geom = GeometryUtilities.CreateBoxGeometry(length, width, thickness);

	let mesh = GeometryUtilities.CreateMeshFromGeometry(geom, materialColor, texture);

	return mesh;
};


GeometryUtilities.CreateOrientatedBox = function (length, width, thickness, color, texture, assignUVsFunction, scale, translationVector, xAngle, yAngle, zAngle)
{
	let mesh = GeometryUtilities.CreateBoxMesh(length, width, thickness, color, texture);

	if (assignUVsFunction)
	{
		assignUVsFunction(mesh.geometry);
	}

	let matrix = new THREE.Matrix4();

	if (scale)
	{
		matrix.scale(scale);
	}

	if (translationVector)
	{
		matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(translationVector.x, translationVector.y, translationVector.z));
	}

	if (xAngle)
	{
		matrix.makeRotationX(xAngle);
	}

	if (yAngle)
	{
		matrix.makeRotationY(yAngle);
	}

	if (zAngle)
	{
		matrix.makeRotationZ(zAngle);
	}

	mesh.geometry.matrixAutoUpdate = false;
	mesh.geometry.applyMatrix4(matrix);

	return mesh;
};

GeometryUtilities.CreateGeomYSymmetricBox = function (fWidth, fHeight, fDepth, textureCoordsFunction)
{
	let shapeRect = new THREE.Shape([{
		x: -fWidth / 2.0,
		y: 0.0
	},
	{
		x: fWidth / 2.0,
		y: 0.0
	},
	{
		x: fWidth / 2.0,
		y: fHeight
	},
	{
		x: -fWidth / 2.0,
		y: fHeight
	},
	{
		x: -fWidth / 2.0,
		y: 0.0
	}
	]);

	let geomBox = new THREE.ExtrudeGeometry(shapeRect, {
		depth: fDepth,
		bevelEnabled: false
	});

	geomBox.matrixAutoUpdate = false;
	geomBox.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -fDepth / 2));

	if (textureCoordsFunction)
		textureCoordsFunction(geomBox);

	return geomBox;
};

GeometryUtilities.CreateMeshFromGeometry = function (geometry, materialColor, texture)
{
	let mater;

	mater = new THREE.MeshStandardMaterial({
		color: materialColor,
		map: TexturesDataUtilities.TextureLoaded(texture),
		roughness: 1,
		metalness: METALNESS
	});

	let mesh = new THREE.Mesh(geometry, mater);

	return mesh;
};

GeometryUtilities.CreatePhongMeshFromGeometry = function (geometry, materialColor, texture)
{
	let mater = new THREE.MeshPhongMaterial({
		color: materialColor,
		specular: 0xFFFFFF,
		shininess: 100,
		map: TexturesDataUtilities.TextureLoaded(texture)
	});

	let mesh = new THREE.Mesh(geometry, mater);

	return mesh;
};

GeometryUtilities.AddFilenameToBeLoaded = function (filename)
{
	GeometryUtilities.geometryFilenamesToBeLoaded.push(filename);
};

GeometryUtilities.OnProgress = function ()
{};

GeometryUtilities.LoadError = function ()
{
	GeometryUtilities.LoadNextGeomtry();
};

GeometryUtilities.ReducePrecision = function (geometry)
{
	for (let i = 0; i < geometry.vertices.length; i++)
	{
		geometry.vertices[i].x = MathUtilities.Round(geometry.vertices[i].x, 2);
		geometry.vertices[i].y = MathUtilities.Round(geometry.vertices[i].y, 2);
		geometry.vertices[i].z = MathUtilities.Round(geometry.vertices[i].z, 2);
	}

	return geometry;
};

GeometryUtilities.LoadNextGeomtry = function()
{
	if (GeometryUtilities.currentFilenameBeingLoadedIndex < (GeometryUtilities.geometryFilenamesToBeLoaded.length - 1))
	{
		GeometryUtilities.currentFilenameBeingLoadedIndex++;
		let newGeometryFileToBeLoaded = GeometryUtilities.geometryFilenamesToBeLoaded[GeometryUtilities.currentFilenameBeingLoadedIndex];

		GeometryUtilities.LoadGeomtry(newGeometryFileToBeLoaded);

		return true;
	}
	else
	{
		/////////GeometryUtilities.objectsLoaded = true;

		return false;
	}
}

GeometryUtilities.ObjectLoaded = function (fileData)
{
	let regenerateBuildingForNewGeometry = false;

	ProgressBar.SetValue(20 + (GeometryUtilities.currentFilenameBeingLoadedIndex + 1) / GeometryUtilities.geometryFilenamesToBeLoaded.length * 80);

	if (GeometryUtilities.geometryFilenamesToBeLoaded[GeometryUtilities.currentFilenameBeingLoadedIndex].indexOf(".stl") > -1)
	{
		geometry = GeometryUtilities.stlLoader.parse(fileData);
	}
	else
	if (GeometryUtilities.geometryFilenamesToBeLoaded[GeometryUtilities.currentFilenameBeingLoadedIndex].indexOf(".obj") > -1)
	{
		geometry = GeometryUtilities.objLoader.parse(fileData);
	}

	if (geometry.type == "Group")
	{
		geometry = geometry.children[0].geometry;
	}

	if (geometry.type == "BufferGeometry")
	{
		let bufferedGeometry;
		bufferedGeometry = new THREE.Geometry().fromBufferGeometry(geometry);
		geometry.dispose();
		geometry = bufferedGeometry;
	}

	let geometry2 = GeometryUtilities.ReducePrecision(geometry);

	if (GeometryUtilities.geometry[GeometryUtilities.geometryFilenamesToBeLoaded[GeometryUtilities.currentFilenameBeingLoadedIndex]] == "required")
	{
		regenerateBuildingForNewGeometry = true;
	}


	GeometryUtilities.geometry[GeometryUtilities.geometryFilenamesToBeLoaded[GeometryUtilities.currentFilenameBeingLoadedIndex]] = geometry;


	if (GeometryUtilities.geometryFilenamesToBeLoaded[GeometryUtilities.currentFilenameBeingLoadedIndex].indexOf(".obj") > -1)
		GeometryUtilities.fileData[GeometryUtilities.geometryFilenamesToBeLoaded[GeometryUtilities.currentFilenameBeingLoadedIndex]] = fileData;
	else
	{
		let mater = new THREE.MeshStandardMaterial({
			color: 0XFFFFFF,
			map: null,
			metalness: METALNESS
		});
		let mesh = new THREE.Mesh(geometry2, mater);

		let exporter = new THREE.OBJExporter();
		let result = exporter.parse(mesh);

		GeometryUtilities.fileData[GeometryUtilities.geometryFilenamesToBeLoaded[GeometryUtilities.currentFilenameBeingLoadedIndex]] = result;
	}

	if (!GeometryUtilities.LoadNextGeomtry())
		GeometryUtilities.objectsLoaded = true;

	if (regenerateBuildingForNewGeometry)
	{
		buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);
		buildingDesigner.Draw();

		buildingDesigner.building.SetBuildingModified();
	}
};

GeometryUtilities.LoadGeomtry = function (filename)
{
	let loader = new THREE.FileLoader(GeometryUtilities.stlLoader.manager);

	if (filename.indexOf(".stl") > -1)
	{
		loader.setResponseType("arraybuffer");
	}

	loader.load(filename, function (fileData)
	{
		GeometryUtilities.ObjectLoaded(fileData);
	}, GeometryUtilities.OnProgress, GeometryUtilities.LoadError);
};

GeometryUtilities.StartLoadingGeomtry = function ()
{
	GeometryUtilities.currentFilenameBeingLoadedIndex = 0;

	let filename = GeometryUtilities.geometryFilenamesToBeLoaded[GeometryUtilities.currentFilenameBeingLoadedIndex];

	GeometryUtilities.LoadGeomtry(filename);
};

GeometryUtilities.GeometryAlreadyLoaded = function (filename)
{
	if (RESOURCE_HOST && (filename.indexOf(RESOURCE_HOST) === -1))
	{
		filename = RESOURCE_HOST + filename;
	}
	if (GeometryUtilities.geometry[filename] != undefined)
	{
		return true;
	}

	return false;
};

GeometryUtilities.GetObjectFileData = function (filename)
{
	if (RESOURCE_HOST && (filename.indexOf(RESOURCE_HOST) === -1))
	{
		filename = RESOURCE_HOST + filename;
	}
	if (GeometryUtilities.fileData[filename] != undefined && GeometryUtilities.fileData[filename] != "required")
	{
		return GeometryUtilities.fileData[filename];
	}

	return null;
};

GeometryUtilities.GetGeometry = function (filename)
{
	if (RESOURCE_HOST && (filename.indexOf(RESOURCE_HOST) === -1))
	{
		filename = RESOURCE_HOST + filename;
	}
	if (GeometryUtilities.geometry[filename] != undefined && GeometryUtilities.geometry[filename] != "required")
	{
		return GeometryUtilities.geometry[filename];
	}

	return null;
};

GeometryUtilities.SetFaceIndex = function (geometry, index)
{
	for (let i = 0; i < geometry.faces.length; i++)
		geometry.faces[i].materialIndex = index;
};

GeometryUtilities.IncFaceIndex = function (geometry, inc)
{
	for (let i = 0; i < geometry.faces.length; i++)
		geometry.faces[i].materialIndex += inc;
};

GeometryUtilities.SetFaceElement = function (geometry, element)
{
	for (let i = 0; i < geometry.faces.length; i++)
		geometry.faces[i].element = element;
};

GeometryUtilities.SetWallFaceIndexes = function (meshes)
{
	let orientation = 0;

	for (let i = 0; i < meshes.length; i++)
	{
		if (meshes[i])
		{
			if (meshes[i].element != undefined && meshes[i].element && meshes[i].element.eWall != undefined)
			{
				if (meshes[i].material.length > 1)
				{
					for (let j = 0; j < meshes[i].geometry.faces.length; j++)
					{
						let eWall = meshes[i].element.eWall;

						switch (eWall)
						{
						case (WALL_FRONT):
							if (meshes[i].geometry.faces[j].normal.x < 0)
								meshes[i].geometry.faces[j].materialIndex = orientation;
							else
								meshes[i].geometry.faces[j].materialIndex = orientation ? 0 : 1;
							break;

						case (WALL_BACK):
							if (meshes[i].geometry.faces[j].normal.x < 0)
								meshes[i].geometry.faces[j].materialIndex = orientation ? 0 : 1;
							else
								meshes[i].geometry.faces[j].materialIndex = orientation;
							break;

						case (WALL_RIGHT):
							if (meshes[i].geometry.faces[j].normal.z < 0)
								meshes[i].geometry.faces[j].materialIndex = orientation ? 0 : 1;
							else
								meshes[i].geometry.faces[j].materialIndex = orientation;
							break;

						case (WALL_LEFT):
							if (meshes[i].geometry.faces[j].normal.z < 0)
								meshes[i].geometry.faces[j].materialIndex = orientation;
							else
								meshes[i].geometry.faces[j].materialIndex = orientation ? 0 : 1;
							break;
						}
					}
				}
			}
		}
	}
};

GeometryUtilities.RotateTexture90degrees = function (geometry)
{
	let temp;

	for (let i = 0; i < geometry.faceVertexUvs[0].length; i++)
	{
		for (let j = 0; j < 3; j++)
		{
			geometry.faceVertexUvs[0][i][j] = new THREE.Vector2(geometry.faceVertexUvs[0][i][j].y, geometry.faceVertexUvs[0][i][j].x);
		}
	}

	geometry.uvsNeedUpdate = true;
};

GeometryUtilities.ShiftTextureCoords = function (geometry, x, y)
{
	let temp;

	for (let i = 0; i < geometry.faceVertexUvs[0].length; i++)
	{
		for (let j = 0; j < 3; j++)
		{
			geometry.faceVertexUvs[0][i][j].x += x;
			geometry.faceVertexUvs[0][i][j].y += y;
		}
	}

	geometry.uvsNeedUpdate = true;
};

GeometryUtilities.ScaleTextureCoords = function (geometry, scaleX, scaleY)
{
	let temp;

	for (let i = 0; i < geometry.faceVertexUvs[0].length; i++)
	{
		for (let j = 0; j < 3; j++)
		{
			geometry.faceVertexUvs[0][i][j].x *= scaleX;
			geometry.faceVertexUvs[0][i][j].y *= scaleY;
		}
	}

	geometry.uvsNeedUpdate = true;
};

GeometryUtilities.GetMinUVs = function (geometry)
{
	let minU = -1;
	let minV = -1;

	for (let i = 0; i < geometry.faceVertexUvs[0].length; i++)
	{
		for (let j = 0; j < 3; j++)
		{
			if (geometry.faceVertexUvs[0][i][j].x < minU || minU == -1)
				minU = geometry.faceVertexUvs[0][i][j].x;

			if (geometry.faceVertexUvs[0][i][j].y < minV || minV == -1)
				minV = geometry.faceVertexUvs[0][i][j].y;
		}
	}

	return {
		u: minU,
		v: minV
	};
};


GeometryUtilities.GetMaxUVs = function (geometry)
{
	let maxU = -1;
	let maxV = -1;

	for (let i = 0; i < geometry.faceVertexUvs[0].length; i++)
	{
		for (let j = 0; j < 3; j++)
		{
			if (geometry.faceVertexUvs[0][i][j].x > maxU)
				maxU = geometry.faceVertexUvs[0][i][j].x;

			if (geometry.faceVertexUvs[0][i][j].y > maxV)
				maxV = geometry.faceVertexUvs[0][i][j].y;
		}
	}

	return {
		u: maxU,
		v: maxV
	};
};

GeometryUtilities.NormalSignForVectors = function (point1, point2, point3)
{
	let point1ToPoint2 = new THREE.Vector2();
	let point1ToPoint3 = new THREE.Vector2();

	point1ToPoint2.subVectors(point2, point1);

	if (point1ToPoint2.length() == 0) //i and i-1 the same points
		return null;

	point1ToPoint3.subVectors(point3, point2);

	if (point1ToPoint2.y == 0 && point1ToPoint3.y == 0) //point on the lower horizontal boundary so continue
		return null;

	let vecCross = new THREE.Vector3();

	vecCross.crossVectors(new THREE.Vector3(point1ToPoint2.x, point1ToPoint2.y, 0.0),
		new THREE.Vector3(point1ToPoint3.x, point1ToPoint3.y, 0.0)
	);

	iCurrSign = (vecCross.z < 0.0) ? -1 : 1;

	return iCurrSign;
};

GeometryUtilities.IsPointInside = function (point, points)
{
	let iSign = 0,
		iCurrSign = 0;
	let i;

	// i is used below -- this should be changed
	for (i = 0; i < points.length - 1; i++)
	{
		if (!(MathUtilities.Equals(points[i].x, points[i + 1].x, 0.15)&&MathUtilities.Equals(points[i].y, points[i + 1].y, 0.15)))
		{
			iCurrSign = GeometryUtilities.NormalSignForVectors(points[i], points[i + 1], point);

			if (iCurrSign != null)
			{
				if (iSign === 0)
					iSign = iCurrSign;
				else if (iCurrSign !== iSign)
					return false;
			}
		}
	}

	iCurrSign = GeometryUtilities.NormalSignForVectors(points[i], points[0], point);

	if (iCurrSign != null)
	{
		if (iSign === 0)
			iSign = iCurrSign;
		else if (iCurrSign !== iSign)
			return false;
	}

	return true;
};

GeometryUtilities.LinesIntersectPoint = function (point1, point2, point3, point4)
{
	let x1 = point1.x;
	let y1 = point1.y;

	let x2 = point2.x;
	let y2 = point2.y;

	let x3 = point3.x;
	let y3 = point3.y;

	let x4 = point4.x;
	let y4 = point4.y;

	let fDenom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
	if (Math.abs(fDenom) < 1e-6)
		return false;

	let fCoef1 = x1 * y2 - y1 * x2;
	let fCoef2 = x3 * y4 - y3 * x4;
	let vecInt = new THREE.Vector2((fCoef1 * (x3 - x4) - (x1 - x2) * fCoef2) / fDenom, (fCoef1 * (y3 - y4) - (y1 - y2) * fCoef2) / fDenom);

	return vecInt;
};

GeometryUtilities.LinesIntersect = function (point1, point2, point3, point4)
{
	let vecInt = GeometryUtilities.LinesIntersectPoint(point1, point2, point3, point4);

	return GeometryUtilities.IsPointOnLineSegment(vecInt, point1, point2) && GeometryUtilities.IsPointOnLineSegment(vecInt, point3, point4);
};

GeometryUtilities.IsPointOnLineSegment = function (point1, point2, point3)
{
	let xp = point1.x;
	let yp = point1.y;

	let x1 = point2.x;
	let y1 = point2.y;

	let x2 = point3.x;
	let y2 = point3.y;

	if (Math.abs(x1 - x2) > Math.abs(y1 - y2)) //Closer to horizontal
		return (x1 < x2) ? (xp >= x1 && xp < x2) : (xp > x2 && xp <= x1);
	else //Closer to vertical
		return (y1 < y2) ? (yp >= y1 && yp < y2) : (yp > y2 && yp <= y1);
};

GeometryUtilities.IsIntersectedByLine = function (point1, point2, points)
{
	let i;
	// i is used below -- probably should be changed
	for (i = 0; i < points.length - 1; i++)
	{
		if (GeometryUtilities.LinesIntersect(point1, point2, points[i], points[i + 1]))
		{
			return true;
		}
	}

	if (GeometryUtilities.LinesIntersect(point1, point2, points[i], points[0]))
	{
		return true;
	}

	return false;
};

GeometryUtilities.IsCollision = function (points1, points2)
{

	for (let j = 0; j < points1.length; j++)
	{
		for (let i = 0; i < points2.length; i++)
		{
			if (points1[j].x == points2[i].x && points1[j].y == points2[i].y)
			{
				return true;
			}
		}
	}

	{
		let i;
		// i used below for loop -- this is probably a better way
		for (i = 0; i < points1.length - 1; i++)
			if (GeometryUtilities.IsIntersectedByLine(points1[i], points1[i + 1], points2))
			{
				return true;
			}

		if (GeometryUtilities.IsIntersectedByLine(points1[i], points1[0], points2))
		{
			return true;
		}
	}

	for (let i = 0; i < points1.length; i++)
	{
		if (GeometryUtilities.IsPointInside(points1[i], points2))
		{
			return true;
		}
	}

	for (let i = 0; i < points2.length; i++)
	{
		if (GeometryUtilities.IsPointInside(points2[i], points1))
		{
			return true;
		}
	}

	return false;
};

/**
 * Compare the x value of the supplied vertice with the specified value and return the minimum
 * @function GeometryUtilities.XMinComparator
 * @param {THREE.Vector3} vertice
 * @param {number} value
 * @returns {number}
 */
GeometryUtilities.XMinComparator = function (vertice, value)
{
	if (value == undefined || vertice.x < value)
		return vertice.x;
	else
		return value;
}

/**
 * Compare the y value of the supplied vertice with the specified value and return the minimum
 * @function
 * @param {THREE.Vector3} vertice
 * @param {number} value
 * @returns {number}
 */
GeometryUtilities.YMinComparator = function (vertice, value)
{
	if (value == undefined || vertice.y < value)
		return vertice.y;
	else
		return value;
}

/**
 * Compare the z value of the supplied vertice with the specified value and return the minimum
 * @function
 * @param {THREE.Vector3} vertice
 * @param {number} value
 * @returns {number}
 */
GeometryUtilities.ZMinComparator = function (vertice, value)
{
	if (value == undefined || vertice.z < value)
		return vertice.z;
	else
		return value;
}

/**
 * Get the geometries coordinate with the minimum value for the specified axis and region
 * @function
 * @param {THREE.Geometry} geometry
 * @param {THREE.Box3} region
 * @param {string} axis
 * @returns {number}
 */
GeometryUtilities.GetMinCoordForRegion = function (geometry, region, axis)
{
	let min = undefined, prevMin;

	let minCoord = undefined;

	let comparator = GeometryUtilities.XMinComparator;

	if (axis.toLowerCase() == "x")
		comparator = GeometryUtilities.XMinComparator;

	if (axis.toLowerCase() == "y")
		comparator = GeometryUtilities.YMinComparator;

	if (axis.toLowerCase() == "z")
		comparator = GeometryUtilities.ZMinComparator;

	for (let i = 0; i < geometry.vertices.length; i++)
	{
		if (geometry.vertices[i].x >= region.min.x && geometry.vertices[i].x <= region.max.x && geometry.vertices[i].y >= region.min.y && geometry.vertices[i].y <= region.max.y && geometry.vertices[i].z >= region.min.z && geometry.vertices[i].z <= region.max.z)
		{
			min = comparator(geometry.vertices[i], min);

			if (min != prevMin)
				minCoord = geometry.vertices[i].clone();

			prevMin = min;
		}
	}

	return minCoord;
};



/**
 * Compare the x value of the supplied vertice with the specified value and return the maximum
 * @function GeometryUtilities.XMinComparator
 * @param {THREE.Vector3} vertice
 * @param {number} value
 * @returns {number}
 */
GeometryUtilities.XMaxComparator = function (vertice, value)
{
	if (value == undefined || vertice.x > value)
		return vertice.x;
	else
		return value;
}

/**
 * Compare the y value of the supplied vertice with the specified value and return the maximum
 * @function
 * @param {THREE.Vector3} vertice
 * @param {number} value
 * @returns {number}
 */
GeometryUtilities.YMaxComparator = function (vertice, value)
{
	if (value == undefined || vertice.y > value)
		return vertice.y;
	else
		return value;
}

/**
 * Compare the z value of the supplied vertice with the specified value and return the maximum
 * @function
 * @param {THREE.Vector3} vertice
 * @param {number} value
 * @returns {number}
 */
GeometryUtilities.ZMaxComparator = function (vertice, value)
{
	if (value == undefined || vertice.z > value)
		return vertice.z;
	else
		return value;
}

/**
 * Get the geometries coordinate with the maximum value for the specified axis and region
 * @function
 * @param {THREE.Geometry} geometry
 * @param {THREE.Box3} region
 * @param {string} axis
 * @returns {number}
 */
GeometryUtilities.GetMaxCoordForRegion = function (geometry, region, axis)
{
	let max = undefined, prevMax;

	let maxCoord = undefined;

	let comparator = GeometryUtilities.XMaxComparator;

	if (axis.toLowerCase() == "x")
		comparator = GeometryUtilities.XMaxComparator;

	if (axis.toLowerCase() == "y")
		comparator = GeometryUtilities.YMaxComparator;

	if (axis.toLowerCase() == "z")
		comparator = GeometryUtilities.ZMaxComparator;

	for (let i = 0; i < geometry.vertices.length; i++)
	{
		if (geometry.vertices[i].x >= region.min.x && geometry.vertices[i].x <= region.max.x && geometry.vertices[i].y >= region.min.y && geometry.vertices[i].y <= region.max.y && geometry.vertices[i].z >= region.min.z && geometry.vertices[i].z <= region.max.z)
		{
			max = comparator(geometry.vertices[i], max);

			if (max != prevMax)
				maxCoord = geometry.vertices[i].clone();

			prevMax = max;
		}
	}

	return maxCoord;
};
