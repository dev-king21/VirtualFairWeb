/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Rafters(thickness, wallRafterWidth)
{
	this.rafterColor = 0xFFFFFF;

	buildingDesigner.building.sizeData.actual_combo_building_length = buildingDesigner.building.length;

	this.thickness = thickness;

	this.wallRafterWidth = wallRafterWidth;

	this.floorColor = 0xC29369;

	this.frontBackRafterCoords = [];
	this.leftRightRafterCoords = [];

	this.mesh = null;
	this.regenerate = true;

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.CreateStrutCoords = function (strutRatioCoords, frontRoofAngle, apexCoordsIndices, leftBeamCoord, rightBeamCoord)
	{
		let wallRafterWidth2 = this.wallRafterWidth / 2;

		let lengthFromCenterBase = strutRatioCoords[0] * buildingDesigner.building.roofRafter.frontRoofWidth;

		let lengthFromApex = strutRatioCoords[1] * buildingDesigner.building.roofRafter.frontRoofLength;

		let apexCoord = new THREE.Vector2(buildingDesigner.building.roofRafter.data.rafter_spec[apexCoordsIndices[1]][0], buildingDesigner.building.roofRafter.data.rafter_spec[apexCoordsIndices[1]][1]);

		let apexToApexNextLength1Vector = leftBeamCoord.clone().sub(apexCoord);
		apexToApexNextLength1Vector = apexToApexNextLength1Vector.divideScalar(apexToApexNextLength1Vector.length());

		let roofTrussCoord = apexToApexNextLength1Vector.clone().multiplyScalar(lengthFromApex);
		roofTrussCoord = roofTrussCoord.add(apexCoord);

		let baseTrussCoord = new THREE.Vector2(apexCoord.x - lengthFromCenterBase, Math.min(leftBeamCoord.y, rightBeamCoord.y));

		let baseToRoofVector = roofTrussCoord.clone().sub(baseTrussCoord);

		let baseToRoofGradient = baseToRoofVector.y / baseToRoofVector.x;

		let strutAngle = Math.abs(Math.atan(baseToRoofGradient));
		let strutAngleDegrees = strutAngle / MathUtilities.RADIAN;

		let strutBaseWidth = 0;

		if (strutRatioCoords[0] == strutRatioCoords[1])
			strutBaseWidth = wallRafterWidth2;
		else
		{
			strutBaseWidth = wallRafterWidth2 / Math.cos(Math.PI - (Math.PI / 2 + strutAngle));
		}


		let strutRoofWidth = 0;
		let strutRoofWidth2 = 0;

		if (baseToRoofGradient > 0)
		{
			strutRoofWidth = wallRafterWidth2 / Math.cos((Math.PI / 2 - strutAngle) + frontRoofAngle);

			if (strutRatioCoords[1] == 0)
				strutRoofWidth2 = wallRafterWidth2 / Math.cos(Math.PI - (strutAngle + frontRoofAngle + Math.PI / 2));
		}
		else
		{
			strutRoofWidth = wallRafterWidth2 / Math.cos(Math.PI - (strutAngle + frontRoofAngle + Math.PI / 2));
		}


		let roofTrussCenterToLeftVector = apexToApexNextLength1Vector.clone().multiplyScalar(strutRoofWidth);

		let roofTrussCenterToRightVector;

		if (strutRatioCoords[1] != 0)
		{
			roofTrussCenterToRightVector = roofTrussCenterToLeftVector.clone();

			roofTrussCenterToRightVector.x *= -1;
			roofTrussCenterToRightVector.y *= -1;
		}
		else
		{
			roofTrussCenterToRightVector = apexToApexNextLength1Vector.clone().multiplyScalar(strutRoofWidth2);

			roofTrussCenterToRightVector.x *= -1;
		}

		let roofTrussLeftCoord = roofTrussCenterToLeftVector.add(roofTrussCoord);

		let roofTrussRightCoord = roofTrussCenterToRightVector.add(roofTrussCoord);

		let strutCoords = [];

		strutCoords.push(new THREE.Vector2(baseTrussCoord.x - strutBaseWidth, baseTrussCoord.y));
		strutCoords.push(roofTrussLeftCoord);

		if (strutRatioCoords[1] == 0)
			strutCoords.push(apexCoord);

		strutCoords.push(roofTrussRightCoord);
		strutCoords.push(new THREE.Vector2(baseTrussCoord.x + strutBaseWidth, baseTrussCoord.y));

		return strutCoords;
	};

	this.GenerateBaseAndStrutCoords = function ()
	{
		let baseCoords = [];
		let strutCoords = [];

		let apexCoordsIndices = buildingDesigner.building.roofRafter.GetApexCoordIndices();
		let frontRoofAngle = Math.atan(buildingDesigner.building.roofRafter.frontTanAngleRatio);

		let baseHeight = buildingDesigner.building.roofRafter.data.truss_base_height_from_wall_height;

		let frontAttachIndex = buildingDesigner.building.roofRafter.GetCoordIndice(buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0], buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1]);

		if (frontAttachIndex)
		{
			let frontAttachCoord1 = new THREE.Vector2(buildingDesigner.building.roofRafter.data.rafter_spec[frontAttachIndex][0], buildingDesigner.building.roofRafter.data.rafter_spec[frontAttachIndex][1]);
			let frontAttachCoord2 = new THREE.Vector2(buildingDesigner.building.roofRafter.data.rafter_spec[frontAttachIndex - 1][0], buildingDesigner.building.roofRafter.data.rafter_spec[frontAttachIndex - 1][1]);

			let leftBeamCoord1;

			if (frontAttachCoord2.y == frontAttachCoord1.y)
			{
				leftBeamCoord1 = frontAttachCoord2;
			}
			else
				leftBeamCoord1 = frontAttachCoord1;
		}
		else
		{
			leftBeamCoord1 = new THREE.Vector2(buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0], buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][1]);
		}


		leftBeamCoord1.y += baseHeight;
		leftBeamCoord1.x += (baseHeight / buildingDesigner.building.roofRafter.frontTanAngleRatio);

		let leftBeamCoord2 = leftBeamCoord1.clone();

		leftBeamCoord2.y += this.wallRafterWidth;
		leftBeamCoord2.x += (this.wallRafterWidth / buildingDesigner.building.roofRafter.frontTanAngleRatio);


		let rearAttachIndex = buildingDesigner.building.roofRafter.GetCoordIndice(buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[1][0], buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[1][1]);

		if (rearAttachIndex)
		{
			let rearAttachCoord1 = new THREE.Vector2(buildingDesigner.building.roofRafter.data.rafter_spec[rearAttachIndex][0], buildingDesigner.building.roofRafter.data.rafter_spec[rearAttachIndex][1]);
			let rearAttachCoord2 = new THREE.Vector2(buildingDesigner.building.roofRafter.data.rafter_spec[rearAttachIndex + 1][0], buildingDesigner.building.roofRafter.data.rafter_spec[rearAttachIndex + 1][1]);

			let rightBeamCoord1;

			if (rearAttachCoord2.y == rearAttachCoord1.y)
			{
				rightBeamCoord1 = rearAttachCoord2;
			}
			else
				rightBeamCoord1 = rearAttachCoord1;
		}
		else
		{
			rightBeamCoord1 = new THREE.Vector2(buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[1][0], buildingDesigner.building.roofRafter.data.rear_wall_attach_coord[1][1]);
		}


		rightBeamCoord1.y += baseHeight;
		rightBeamCoord1.x -= (baseHeight / buildingDesigner.building.roofRafter.rearTanAngleRatio);

		let rightBeamCoord2 = rightBeamCoord1.clone();

		rightBeamCoord2.y += this.wallRafterWidth;
		rightBeamCoord2.x -= (this.wallRafterWidth / buildingDesigner.building.roofRafter.rearTanAngleRatio);


		baseCoords.push(leftBeamCoord1);
		baseCoords.push(leftBeamCoord2);
		baseCoords.push(rightBeamCoord2);
		baseCoords.push(rightBeamCoord1);

		for (let i = 0; i < buildingDesigner.building.roofRafter.data.truss_strut_ratio_coords.length; i++)
		{
			strutCoords.push(this.CreateStrutCoords(buildingDesigner.building.roofRafter.data.truss_strut_ratio_coords[i], frontRoofAngle, apexCoordsIndices, leftBeamCoord2, rightBeamCoord2));
		}

		return {
			baseCoords: baseCoords,
			strutCoords: strutCoords
		};
	};


	this.GenerateStrut = function (coords, material, extrudeSettings, x, y, z, buildingMeshes1, buildingMeshes2, mirror)
	{
		rafter_sh = new THREE.Shape();

		let buildingMeshes;

		if (!mirror)
		{
			rafter_sh.moveTo(coords[0].x, coords[0].y);

			for (let j = 1; j < coords.length; j++)
			{
				rafter_sh.lineTo(coords[j].x, coords[j].y);
			}

			if (coords[0].x <= coords[1].x)
				buildingMeshes = buildingMeshes1;
			else
				buildingMeshes = buildingMeshes2;
		}
		else
		{
			rafter_sh.moveTo(-coords[0].x + buildingDesigner.building.roofRafter.width, coords[0].y);

			for (let j = 1; j < coords.length; j++)
			{
				rafter_sh.lineTo(-coords[j].x + buildingDesigner.building.roofRafter.width, coords[j].y);
			}

			if (-coords[0].x <= -coords[1].x)
				buildingMeshes = buildingMeshes1;
			else
				buildingMeshes = buildingMeshes2;
		}

		let geom = new THREE.ExtrudeGeometry(rafter_sh, extrudeSettings);

		TexturesDataUtilities.AssignUVsToGeometryXY(geom);

		mesh = new THREE.Mesh(geom, material);
		mesh.geometry.matrixAutoUpdate = false;
		mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(x, y, z));

		buildingMeshes.push(mesh);
	};

	this.GenerateStruts = function (coords, extrudeSettings, x, y, z, material, buildingMeshes1, buildingMeshes2, mirror)
	{
		for (let i = 0; i < coords.length; i++)
		{
			let mesh = this.GenerateStrut(coords[i], material, extrudeSettings, x, y, z, buildingMeshes1, buildingMeshes2, mirror);
		}
	};

	this.GenerateRafterBase = function (coords, extrudeSettings, x, y, z, material, buildingMeshes)
	{
		rafter_sh = new THREE.Shape();

		rafter_sh.moveTo(coords[0].x, coords[0].y);

		for (let j = 1; j < coords.length; j++)
		{
			rafter_sh.lineTo(coords[j].x, coords[j].y);
		}

		let geom = new THREE.ExtrudeGeometry(rafter_sh, extrudeSettings);

		TexturesDataUtilities.AssignUVsToGeometryXY(geom);

		mesh = new THREE.Mesh(geom, material);
		mesh.geometry.matrixAutoUpdate = false;
		mesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(x, y, z));

		buildingMeshes.push(mesh);
	};
}

Rafters.rafterData = [];
