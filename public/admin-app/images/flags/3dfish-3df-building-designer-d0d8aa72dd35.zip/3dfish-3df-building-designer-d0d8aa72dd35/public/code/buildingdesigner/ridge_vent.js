/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

////function RidgeVent(roofRafter, length, thickness, price)
function RidgeVent(buttonData)
{
	////Element.call(this, "Ridge Vent", "RidgeVent", "", RidgeVent.RIDGE_VENT_WIDTH, Roof.ROOF_THICKNESS, "" + RidgeVent.RIDGE_VENT_WIDTH, "" + Roof.ROOF_THICKNESS, Roof.ROOF_THICKNESS, price);

	Element.call(this, buttonData);

	buttonData.type = ELEM_RIDGEVENT;

	/*////
    this.roofRafter = roofRafter;
    buildingDesigner.building.roofRafter.wallWidth = this.roofRafter.wallWidth;
    */

	this.length = buttonData.width;
	this.thickness = Roof.ROOF_THICKNESS;

	this.tileTextureName = "";
	this.tileTexture = null;
	this.tileMater = null;
	this.tileColor = 0xFFFFFF;

	this.mesh = null;

	this.draggable = false;

	this.regenerate = true;

	this.GetTextures = function ()
	{
		this.tileTexture = TexturesDataUtilities.GetRealWorldSizedTexture(buildingDesigner.building.roof.tileTextureName, 1, 1);

		this.tileMater = new THREE.MeshStandardMaterial({
			color: this.tileColor,
			map: TexturesDataUtilities.TextureLoaded(this.tileTexture),
			roughness: 1.0,
			metalness: METALNESS
		});
	};

	this.SetTileTextureName = function (textureName)
	{
		this.tileTextureName = textureName;
	};

	this.SetTileTextureName("gafbr_f1.38x1.38");

	this.GetMatrix = function ()
	{
		return this.mesh.matrix;
	};

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.GenerateRidgeVentBottomSurface = function (array, apexIndex, width)
	{
		let surfacePoints = [];

		let line = new THREE.Vector2(array[apexIndex - 1][0] - array[apexIndex][0], array[apexIndex - 1][1] - array[apexIndex][1]);

		line.divideScalar(line.length());
		line.multiplyScalar(width / 2);

		let point = new THREE.Vector2(array[apexIndex][0], array[apexIndex][1]).add(line);

		surfacePoints.push([point.x, point.y]);

		surfacePoints.push(array[[apexIndex][0]]);

		line = new THREE.Vector2(array[apexIndex + 1][0] - array[apexIndex][0], array[apexIndex + 1][1] - array[apexIndex][1]);

		line.divideScalar(line.length());
		line.multiplyScalar(width / 2);

		point = new THREE.Vector2(array[apexIndex][0], array[apexIndex][1]).add(line);

		surfacePoints.push([point.x, point.y]);

		return surfacePoints;
	};


	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate)
		{
			this.Destroy();

			this.GetTextures();

			////if (TexturesDataUtilities.TextureLoaded(this.tileTexture) )
			{
				let apexCoordsIndices = buildingDesigner.building.roofRafter.GetApexCoordIndices();

				let ridgeVentBottomSurface = this.GenerateRidgeVentBottomSurface(buildingDesigner.building.roofRafter.data.rafter_spec, apexCoordsIndices[0], RidgeVent.RIDGE_VENT_WIDTH);

				let ridgeVentPoints = GeometryUtilities.GetSurfacePoints(ridgeVentBottomSurface, 0, ridgeVentBottomSurface.length - 1, Roof.ROOF_THICKNESS, Roof.ANGLED_TRIM);

				let extrudeSettings = {
					depth: this.length,
					steps: 1,
					material: 1,
					extrudeMaterial: 0,
					bevelEnabled: false,
				};

				let offsetX = buildingDesigner.building.roofRafter.data.rafter_spec[apexCoordsIndices[0]][0];
				let offsetY = buildingDesigner.building.roofRafter.data.rafter_spec[apexCoordsIndices[0]][1];

				this.mesh = MeshUtilities.CreateMeshFromCrossSectionPoints(ridgeVentPoints, ridgeVentPoints, this.tileMater, extrudeSettings, -offsetX, -offsetY, -this.length / 2);

				//this.mesh = MeshUtilities.CreateMeshFromCrossSectionPoints(ridgeVentPoints, this.tileMater, extrudeSettings, 0, 0, 0);

				//buildingMeshes.push(this.mesh);

				this.mesh.geometry.computeBoundingBox();

				this.mesh.type = ELEM_RIDGEVENT;

				MeshUtilities.SetElement(this.mesh, this);

				let max = this.mesh.geometry.boundingBox.max;
				let min = this.mesh.geometry.boundingBox.min;

				this.width = max.x - min.x;
				this.height = max.y - min.y;

				if (this.selected)
				{
					////this.GenerateSelectedBoxes(this.mesh, new THREE.Matrix4().makeTranslation(-this.width/2, 0, this.length/2), this.component3DObjects.scale);
					this.GenerateSelectedBoxes(this.mesh, new THREE.Matrix4().makeTranslation(0, 0, 0));
				}

				this.UpdateMatrix();

				this.regenerate = false;
			}
		}

		return this.mesh;
	};

	this.UpdateMatrix = function ()
	{
		if (this.mesh)
		{
			let matrix = new THREE.Matrix4();

			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z));

			this.mesh.matrix = new THREE.Matrix4();
			this.mesh.matrixAutoUpdate = false;
			this.mesh.applyMatrix4(matrix);
		}
	};

	this.SetRoofingData = function (data)
	{
		this.data = data;

		this.SetTileTextureName(data.textureName);
		this.SetPrice(data.price);

		////this.SetSidingDisplayName(data.display_name);
	};

}

RidgeVent.AddRidgeVent = function (buttonData)
{
	////let ridgeVent = new RidgeVent(buildingDesigner.building.roofRafter, buttonData.width, Roof.ROOF_THICKNESS, buttonData.price);

	let ridgeVent = new RidgeVent(buttonData);

	let frontRafteroffsetx = 0;
	let rafterOffsetY = 0;

	if (buildingDesigner.building.roofRafter.data.front_wall_attach_coord != "")
	{
		frontRafteroffsetx = buildingDesigner.building.roofRafter.data.front_wall_attach_coord[1][0];
	}

	ridgeVent.SetPos(-buildingDesigner.building.width / 2 - frontRafteroffsetx + buildingDesigner.building.roofRafter.frontRoofWidth, buildingDesigner.building.height + buildingDesigner.building.roofRafter.roofHeight + Roof.ROOF_THICKNESS, 0);

	Elements.AddElement(ridgeVent);

	buildingDesigner.building.SetRegenerateElementMeshes(true);

	return ridgeVent;
};

RidgeVent.RIDGE_VENT_WIDTH = 0.6;
