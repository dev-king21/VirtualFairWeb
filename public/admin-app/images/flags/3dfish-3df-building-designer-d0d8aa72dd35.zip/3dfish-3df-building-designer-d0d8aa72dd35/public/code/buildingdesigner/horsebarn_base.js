/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function HorseBarnBase()
{
	this.width = buildingDesigner.building.width;
	this.length = buildingDesigner.building.length - Wall.WALLTHICKNESS * 2;

	this.baseTextureFileName = "Southern_yellowpine_horizontal";

	this.hooks = [];

	this.hooks.push(new HorseBarnHook(-((this.width / 2)- HorseBarnHook.HOOK_CORNEROFFSET), -HorseBarnBase.BASEWIDTH / 2, (this.length / 2) + HorseBarnHook.HOOK_STRAIGHTLENGTH, Math.PI/2));

	this.hooks.push(new HorseBarnHook(-((this.width / 2)- HorseBarnHook.HOOK_CORNEROFFSET), -HorseBarnBase.BASEWIDTH / 2, -this.length / 2 - HorseBarnHook.HOOK_STRAIGHTLENGTH, -(Math.PI/2)));

	this.hooks.push(new HorseBarnHook((this.width / 2)- HorseBarnHook.HOOK_CORNEROFFSET, -HorseBarnBase.BASEWIDTH / 2, -this.length / 2 - HorseBarnHook.HOOK_STRAIGHTLENGTH, -(Math.PI/2)));

	this.hooks.push(new HorseBarnHook((this.width / 2) - HorseBarnHook.HOOK_CORNEROFFSET, -HorseBarnBase.BASEWIDTH / 2, (this.length / 2) + HorseBarnHook.HOOK_STRAIGHTLENGTH, Math.PI/2));

	this.regenerate = true;

	this.SetRegenerate = function (regenerate)
	{
		this.regenerate = regenerate;
	};

	this.GetTextures = function ()
	{
		if (this.baseTextureFileName != "")
		{
			this.baseTexture = TexturesDataUtilities.GetRealWorldSizedTexture(this.baseTextureFileName, this.length / 5, HorseBarnBase.BASEWIDTH / 2);
		}
	};

	this.Generate = function (buildingMeshes)
	{
		this.mesh = new THREE.Mesh();


		for (let i = 0; i < this.hooks.length; i++)
		{
			this.mesh.add(this.hooks[i].Generate());
		}


		this.GetTextures();

		let baseMater = Material.CreateMaterial(HorseBarnBase.BASE_COLOR, TexturesDataUtilities.TextureLoaded(this.baseTexture));

		let geomBase = new THREE.BoxGeometry(HorseBarnBase.BASEWIDTH, HorseBarnBase.BASEWIDTH, this.length);

		geomBase.matrixAutoUpdate = false;
		geomBase.applyMatrix4(new THREE.Matrix4().makeTranslation(-buildingDesigner.building.width / 2 + HorseBarnBase.BASEWIDTH / 2, -HorseBarnBase.BASEWIDTH / 2, 0));

		let meshBase = new THREE.Mesh(geomBase, baseMater);

		this.mesh.add(meshBase);


		geomBase = new THREE.BoxGeometry(HorseBarnBase.BASEWIDTH, HorseBarnBase.BASEWIDTH, this.length);

		geomBase.matrixAutoUpdate = false;
		geomBase.applyMatrix4(new THREE.Matrix4().makeTranslation(buildingDesigner.building.width / 2 - HorseBarnBase.BASEWIDTH / 2, -HorseBarnBase.BASEWIDTH / 2, 0));

		meshBase = new THREE.Mesh(geomBase, baseMater);

		this.mesh.add(meshBase);


		geomBase = new THREE.BoxGeometry(this.width, HorseBarnBase.BASEWIDTH, HorseBarnBase.BASEWIDTH);

		geomBase.matrixAutoUpdate = false;
		geomBase.applyMatrix4(new THREE.Matrix4().makeTranslation(0, -HorseBarnBase.BASEWIDTH / 2, -this.length / 2 + HorseBarnBase.BASEWIDTH / 2 - Wall.WALLTHICKNESS));

		meshBase = new THREE.Mesh(geomBase, baseMater);

		this.mesh.add(meshBase);



		geomBase = new THREE.BoxGeometry(this.width, HorseBarnBase.BASEWIDTH, HorseBarnBase.BASEWIDTH);

		geomBase.matrixAutoUpdate = false;
		geomBase.applyMatrix4(new THREE.Matrix4().makeTranslation(0, -HorseBarnBase.BASEWIDTH / 2, this.length / 2 - HorseBarnBase.BASEWIDTH / 2 + Wall.WALLTHICKNESS));

		meshBase = new THREE.Mesh(geomBase, baseMater);

		this.mesh.add(meshBase);

		this.mesh = MeshUtilities.MergeMeshGeometry(this.mesh);


		MeshUtilities.SetMeshCastReceiveShadow(this.mesh, true, true);

		buildingMeshes.push(this.mesh);
	};
}

HorseBarnBase.BASEWIDTH = 0.5; // 6 inches

HorseBarnBase.BASE_COLOR = 0xAAAAAA;

HorseBarnBase.HOOK_COLOR = 0x63543D;
