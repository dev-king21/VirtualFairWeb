/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Component3DObjects(parentObject)
{
	this.parentObject = parentObject;

	this.objectList = [];

	this.regenerate = true;

	this.mesh = null;

	this.scale = new THREE.Vector3(1, 1, 1);
	this.geometryCenter = new THREE.Vector3(0, 0, 0);

	this.AddObject = function (geometryFilename, objectData)
	{
		this.objectList.push(new Component3DObject(this, geometryFilename, objectData));
	};

	this.ClearSelections = function ()
	{
		for (let i = 0; i < this.objectList.length; i++)
			this.objectList[i].selected = false;
	};

	/**
	 * @method Component3DObjects.GetObjectsData
	 * @returns {Object} Object with Data encoded for XML storage
	 */
	this.GetObjectsData = function ()
	{
		let elementObjectDataArray = [];

		for (let i = 0; i < this.objectList.length; i++)
		{
			let filename = this.objectList[i].objectData.fileDataFilename;
			if (RESOURCE_HOST && (filename.indexOf(RESOURCE_HOST) === -1))
			{
				filename = RESOURCE_HOST + filename;
			}
			this.objectList[i].objectData.fileData = GeometryUtilities.fileData[filename];

			elementObjectDataArray.push(AuxUtilities.JSONStringifyAndEncode(this.objectList[i].objectData));
		}

		return elementObjectDataArray;
	};

	/**
	 * @method Component3DObjects.GetObjectsDataObject
	 * @returns {Object} Object for Object storage
	 */
	this.GetObjectsDataObject = function()
	{
		let elementObjectDataArray = [];

		for (let i = 0; i < this.objectList.length; i++)
		{
			let filename = this.objectList[i].objectData.fileDataFilename;
			if (RESOURCE_HOST && (filename.indexOf(RESOURCE_HOST) === -1))
			{
				filename = RESOURCE_HOST + filename;
			}
			this.objectList[i].objectData.fileData = GeometryUtilities.fileData[filename];

			elementObjectDataArray.push(this.objectList[i].objectData);
		}

		return elementObjectDataArray;
	};

	this.UpdateModified3DObjects = function ()
	{
		for (let i = 0; i < this.objectList.length; i++)
		{
			this.objectList[i].UpdateModified3DObject();
		}
	};


	this.SetGuiDefinedColor = function (color)
	{
		for (let i = 0; i < this.objectList.length; i++)
		{
			this.objectList[i].SetGuiDefinedColor(color);
		}
	};

	this.CalculateGeometryScale = function (width, height, length)
	{
		if (width == undefined || height == undefined || length == undefined || width == -1 || height == -1 || length == -1)
		{
			this.scale = new THREE.Vector3(1.0, 1.0, 1.0);
		}
		else
		{
			this.ComputeBoundingBoxForAllObjects(false, false, true);

			if (!this.boundingBox)
				this.ComputeBoundingBoxForAllObjects(false, false, false);

			if (this.boundingBox)
			{
				let size = new THREE.Vector3();

				size = this.boundingBox.getSize(size);


				this.scale = new THREE.Vector3(width / size.x, height / size.y, length / size.y);
			}
			else
				buildingDesigner.building.needsRefresh = true;
		}

		if (this.scale.y == 0)
		{
			this.scale.y = this.scale.x;
			this.scale.z = this.scale.x;
		}

	};

	this.CalculateGeometryCenter = function ()
	{
		this.ComputeBoundingBoxForAllObjects(false, false, true);

		if (this.boundingBox)
		{
			let centerX = (this.boundingBox.min.x + this.boundingBox.max.x) / 2;
			let centerY = (this.boundingBox.min.y + this.boundingBox.max.y) / 2;
			let centerZ = (this.boundingBox.min.z + this.boundingBox.max.z) / 2;

			this.geometryCenter = new THREE.Vector3(centerX * this.scale.x, centerY * this.scale.y, centerZ * this.scale.z);
		}
	};

	this.ApplyTranslationToGeometry = function (x, y, z, useOriginalScale)
	{
		for (let i = 0; i < this.objectList.length; i++)
		{
			if (GeometryUtilities.geometry[this.objectList[i].geometryFilename])
			{
				let matrix = new THREE.Matrix4();

				if (useOriginalScale)
				{
					matrix.makeTranslation(x * 1/this.objectList[i].scale.x, y * 1/this.objectList[i].scale.y, z * 1/this.objectList[i].scale.z);
				}
				else
				{
					matrix.makeTranslation(x, y, z);
				}

				GeometryUtilities.geometry[this.objectList[i].geometryFilename].matrixAutoUpdate = false;
				GeometryUtilities.geometry[this.objectList[i].geometryFilename].applyMatrix4(matrix);
			}
		}
	};

	this.ApplyMatrixToGeometry = function (matrix)
	{
		for (let i = 0; i < this.objectList.length; i++)
		{
			GeometryUtilities.geometry[this.objectList[i].geometryFilename].matrixAutoUpdate = false;
			GeometryUtilities.geometry[this.objectList[i].geometryFilename].applyMatrix4(matrix);
		}
	};

	this.UseObject = function (objectData, useInteriorVisibility, useForWallCutout, usedInDimensions, useOnlyTrimObjects)
	{
		let useObject = false;

		if (useOnlyTrimObjects)
			if (!objectData.trimColorFromBarnEnabled)
				return false;
			else
				return true;

		if (useForWallCutout)
			if (!objectData.affectsWallCutout)
				return false;

		if (useInteriorVisibility)
			if (!objectData.interiorVisibility)
				return false;

		if (usedInDimensions)
			if (!objectData.usedInDimensions)
				return false;

		return true;
	};

	this.InteriorVisibility = function ()
	{
		for (let i = 0; i < this.objectList.length; i++)
			if (this.objectList[i].objectData.interiorVisibility)
				return true;

		return false;
	};

	this.ComputeBoundingBoxForAllObjects = function (useInteriorVisibility, useForWallCutout, usedInDimensions, useOnlyTrimObjects)
	{
		let tempGeometry;
		let matrix;

		let newBoundingBox = null;

		if (usedInDimensions == null || usedInDimensions == undefined)
			usedInDimensions = true;

		if (useOnlyTrimObjects == null || useOnlyTrimObjects == undefined)
			useOnlyTrimObjects = false;

		let vector;

		for (let i = 0; i < this.objectList.length; i++)
		{
			if (!this.UseObject(this.objectList[i].objectData, useInteriorVisibility, useForWallCutout, usedInDimensions, useOnlyTrimObjects))
				continue;

			if (!GeometryUtilities.GetGeometry(this.objectList[i].geometryFilename))
				continue;

			tempGeometry = GeometryUtilities.geometry[this.objectList[i].geometryFilename].clone();

			vector = this.objectList[i].axis.DetermineAxisRotation();

			matrix = new THREE.Matrix4().makeTranslation(this.objectList[i].pos.x, this.objectList[i].pos.y, this.objectList[i].pos.z);
			matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(vector.x, vector.y, vector.z), "ZXY"));

			matrix = matrix.scale(this.objectList[i].scale);

			tempGeometry.matrixAutoUpdate = false;
			tempGeometry.applyMatrix4(matrix);

			tempGeometry.computeBoundingBox();

			if (newBoundingBox == null)
				newBoundingBox = tempGeometry.boundingBox;
			else
			{
				tempGeometry.boundingBox.min.x < newBoundingBox.min.x ? newBoundingBox.min.x = tempGeometry.boundingBox.min.x : null;
				tempGeometry.boundingBox.min.y < newBoundingBox.min.y ? newBoundingBox.min.y = tempGeometry.boundingBox.min.y : null;
				tempGeometry.boundingBox.min.z < newBoundingBox.min.z ? newBoundingBox.min.z = tempGeometry.boundingBox.min.z : null;

				tempGeometry.boundingBox.max.x > newBoundingBox.max.x ? newBoundingBox.max.x = tempGeometry.boundingBox.max.x : null;
				tempGeometry.boundingBox.max.y > newBoundingBox.max.y ? newBoundingBox.max.y = tempGeometry.boundingBox.max.y : null;
				tempGeometry.boundingBox.max.z > newBoundingBox.max.z ? newBoundingBox.max.z = tempGeometry.boundingBox.max.z : null;
			}

			tempGeometry.dispose();
			tempGeometry = null;
		}

		if (newBoundingBox)
			this.boundingBox = newBoundingBox;

		return newBoundingBox;
	};

	/**
 *
 *
 * @param {number} useInteriorVisibility set to true to use objects with interiorVisibility set
 * @param {number} useForWallCutout set to true to use objects with affectsWallCutout set
 * @param {number} usedInDimensions set to true to use objects with usedInDimensions set
 * @param {number} useOnlyTrimObjects set to true to use objects with trimColorFromBarnEnabled set
 * @returns merged geometry or null if no objects match parameters
 */
	this.GetMergedGeometry = function (useInteriorVisibility, useForWallCutout, usedInDimensions, useOnlyTrimObjects)
	{
		//if (!this.mergedGeometry)
		{
			let tempGeometry;
			let matrix;

			let csgWall = null;

			let vector;

			for (let i = 0; i < this.objectList.length; i++)
			{
				if (!this.UseObject(this.objectList[i].objectData, useInteriorVisibility, useForWallCutout, usedInDimensions, useOnlyTrimObjects))
					continue;

				if (!GeometryUtilities.geometry[this.objectList[i].geometryFilename])
					continue;

				if (GeometryUtilities.geometry[this.objectList[i].geometryFilename] == "required")
					continue;

				tempGeometry = GeometryUtilities.geometry[this.objectList[i].geometryFilename].clone();

				vector = this.objectList[i].axis.DetermineAxisRotation();

				matrix = new THREE.Matrix4().makeTranslation(this.objectList[i].pos.x, this.objectList[i].pos.y, this.objectList[i].pos.z);
				matrix = new THREE.Matrix4().multiplyMatrices(matrix, new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(vector.x, vector.y, vector.z), "ZXY"));

				matrix = matrix.scale(this.objectList[i].scale);

				tempGeometry.matrixAutoUpdate = false;
				tempGeometry.applyMatrix4(matrix);

				tempGeometry.computeBoundingBox();

				if (csgWall == null)
				{
					csgWall = new ThreeBSP(tempGeometry);
				}
				else
				{
					let geometry = new ThreeBSP(tempGeometry);
					csgWall = csgWall.union(geometry);
				}
			}

			if (csgWall)
				this.mergedGeometry = csgWall.toMesh(new THREE.MeshNormalMaterial());
		}

		if (this.mergedGeometry)
			return this.mergedGeometry.geometry;
		else
			return null;
	};

	/**
	 *
	 *
	 * @param {number} useInteriorVisibility
	 * @param {number} cutoutMode valid modes: 0 - rectangle cutout, 1 - no wall cutout, 2 curved cutout
	 * @param {*} depth
	 * @param {*} useOnlyTrimObjects
	 * @returns geometry or null
	 */
	this.ComputeCutoutGeometry = function (useInteriorVisibility, cutoutMode, depth, useOnlyTrimObjects)
	{
		if (useOnlyTrimObjects == null || useOnlyTrimObjects == undefined)
			useOnlyTrimObjects = false;

		if (cutoutMode == 1)
		{
			this.boundingBox = this.ComputeBoundingBoxForAllObjects(useInteriorVisibility, true, true, useOnlyTrimObjects);

			if (!this.boundingBox)
				return null;

			let geometry = GeometryUtilities.CreateGeometryFromBoundingBox(this.boundingBox, depth);

			if (useOnlyTrimObjects)
			{
				let originalDepth = this.boundingBox.max.z - this.boundingBox.min.z;

				let zOffset = originalDepth / 2 - depth / 2;


				let matrix = new THREE.Matrix4().makeTranslation(0, 0, -zOffset);

				geometry.matrixAutoUpdate = false;
				geometry.applyMatrix4(matrix);
			}

			return geometry;
		}
		else
		if (cutoutMode == 2)
		{
			let geometry = this.GetMergedGeometry(false, true, false, false);

			if (geometry)
			{
				geometry.computeBoundingBox();

				let boxDepth = geometry.boundingBox.max.z - geometry.boundingBox.min.z;

				let depthScale = 1;

				if (depth != undefined)
					depthScale = depth / boxDepth;

				let matrix = new THREE.Matrix4();
				matrix.scale(new THREE.Vector3(1, 1, depthScale));

				geometry.matrixAutoUpdate = false;
				geometry.applyMatrix4(matrix);


				return geometry;
			}
			else
			{
				if (DEBUG)
				{
					console.warn("Object with wall cutout mode set but no cutout objects defined.");
				}
				return null;
			}
		}
	};

	this.SetCameraAndConfigurationModeVisibility = function (modeCamera, configurationMode)
	{
		for (let i = 0; i < this.objectList.length; i++)
		{
			this.objectList[i].SetCameraAndConfigurationModeVisibility(modeCamera, configurationMode);
		}
	};

	this.Generate = function (buildingMeshes, scale, merge)
	{
		//if (this.regenerate)
		{

			this.mesh = new THREE.Mesh();

			let componentMesh;
			for (let i = 0; i < this.objectList.length; i++)
			{
				componentMesh = this.objectList[i].Generate(buildingMeshes, scale);

				if (componentMesh)
					this.mesh.add(componentMesh);
			}

			/*////if (merge || merge == undefined || merge == null)
				this.mesh = MeshUtilities.MergeMeshGeometry(this.mesh);
				*/

			this.mesh.castShadow = true;
			this.mesh.receiveShadow = true;

			return this.mesh;
		}
	};

	this.GetObjectWithStringInName = function (string)
	{
		for (let i = 0; i < this.objectList.length; i++)
		{
			if (this.objectList[i].objectData.objectFile.toLowerCase().indexOf(string) > -1)
				return this.objectList[i];
		}

		return null;
	};

	this.GetObjectsWithStringInName = function (string)
	{
		let objects = [];
		for (let i = 0; i < this.objectList.length; i++)
		{
			if (this.objectList[i].objectData.objectFile.toLowerCase().indexOf(string) > -1)
				objects.push(this.objectList[i]);
		}

		return objects;
	};

	this.GetAffectsWallCutoutObjects = function ()
	{
		let wallCutoutObjects = [];

		for (let i = 0; i < this.objectList.length; i++)
		{
			if (this.objectList[i].objectData.affectsWallCutout)
				wallCutoutObjects.push(this.objectList[i]);
		}

		return wallCutoutObjects;
	};
}
