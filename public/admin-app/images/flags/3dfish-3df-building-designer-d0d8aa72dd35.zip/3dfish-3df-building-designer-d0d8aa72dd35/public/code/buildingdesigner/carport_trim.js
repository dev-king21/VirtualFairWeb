/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */
function Trim()
{
}

Trim.TRIM_THICKNESS = INCHTOFEET * 3/4;
Trim.CORNER_TRIM_THICKNESS = 0.0078125;
Trim.CORNER_TRIM_WIDTH_SIDES = 0.28125;
Trim.CORNER_TRIM_WIDTH_ENDS = 0.125;
