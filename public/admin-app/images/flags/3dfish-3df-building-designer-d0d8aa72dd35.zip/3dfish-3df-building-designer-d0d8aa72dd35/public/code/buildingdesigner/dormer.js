// Copyrighted 2014-2017 by 3D Fish, LLC
// All rights reserved.
// Un-authorized reproduction prohibited
// Violators will be prosecuted.
/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

function Dormer(shedParent, buttonData)
{
	if (!buttonData)
	{
		// TODO: send notice to server
		console.warn("Dormer data missing");
		return;
	}
	Element.call(this, buttonData);

	this.dormerColor = 0xFFFFFF;
	this.dormerTileColor = 0xFFFFFF;
	this.dormerRoofColor = 0xFFFFFF;
	this.dormerWallColor = 0xFFFFFF;

	if (this.buttonData)
	{
		this.dormer_type = this.buttonData.type;
		this.buttonData.type = ELEM_DORMER;
	}

	this.width = this.buttonData.width;
	this.height = this.buttonData.height;

	this.roofWidth = shedParent.width;

	this.dormerMesh = null;

	this.pos = new THREE.Vector3(0, 0, 0);

	this.AddObjects();

	this.tiles = this.component3DObjects.GetObjectWithStringInName("?roof");

	if (this.tiles)
	{
		this.tiles.SetTextureName(buildingDesigner.building.roof.tileTextureName);
	}

	this.roof = this.component3DObjects.GetObjectWithStringInName("?ceiling");

	if (this.roof)
	{
		this.roof.SetTextureName(buildingDesigner.building.roof.roofTextureName);
	}

	this.wall = this.component3DObjects.GetObjectWithStringInName("?outerwall");

	if (this.wall)
		this.wall.eWall = WALL_FRONT;

	this.trim = this.component3DObjects.GetObjectWithStringInName("?trim");

	if (this.trim)
		this.trim.SetColor(buildingDesigner.building.roof.trimColor);

	this.container = this.component3DObjects.GetObjectWithStringInName("?cutout");

	let wallCutoutObjects = this.component3DObjects.GetAffectsWallCutoutObjects();

	for (let i = 0; i < wallCutoutObjects.length; i++)
	{
		wallCutoutObjects[i].SetVisibility(false);
	}

	this.cutoutMode = 2;

	this.attachedElement = null;
	this.attachedElements = null;

	this.draggable = false;

	this.bIsSelected = false;

	this.regenerate = true;

	this.SetPos = function (x, y, z)
	{
		this.pos.x = x;
		this.pos.y = y;
		this.pos.z = z;
	};

	this.SetSidingCategoryData = function (data)
	{
		this.sidingCategoryData = data;
	};

	this.SetSidingColorData = function (data)
	{
		if (this.wall)
		{
			this.SetWallTextureName(data.textureName);

			let colorData = ColorsDataUtilities.FindColor(data.color_id);

			this.wall.SetColor(colorData.color);

			this.SetInnerWallTextureName(data.textureNameInterior);
		}
	};

	this.SetWallTextureName = function (textureName)
	{
		this.wall.SetTextureName(textureName);
	};

	this.SetInnerWallTextureName = function (textureName)
	{
		if (this.innerwall)
			this.innerwall.SetTextureName(textureName);
	};


	this.SetRoofingData = function (data)
	{
		this.SetTileTextureName(data.textureFile);
	};

	this.SetTileTextureName = function (textureName)
	{
		this.tiles.SetTextureName(textureName);
	};

	this.SetTileColor = function (color)
	{
		this.tiles.SetColor(color);
	};


	this.SetTrimColor = function (color)
	{
		this.trim.SetColor(color);
	};

	/**
	 * @method Dormer.GetDesignXMLString
	 * @returns {string} XML Design string for dormer
	 */
	this.GetDesignXMLString = function ()
	{
		let strElemType = ELEM_STRING[this.type];

		let strXml = "<ELEMENT ";

		strXml += " buttonData=\"" + AuxUtilities.JSONStringifyAndEncode(this.buttonData) + "\"";

		strXml += " defaultElementData=\"" + AuxUtilities.JSONStringifyAndEncode(this.defaultElementData) + "\"";

		strXml += "></ELEMENT>";

		return strXml;
	};

	/**
	 * @method Dormer.getDesignObject
	 * @returns {Object} dormer object
	 */
	this.getDesignObject = function ()
	{
		let dormer = {
			buttonData: this.buttonData,
			defaultElementData: this.defaultElementData
		};
		return dormer;
	};

	this.LoadFromXML = function (nodeComp)
	{
		this.buttonData.type = ELEM_STRING.indexOf(nodeComp.getAttribute("type"));

		this.dormer_type = ELEM_STRING.indexOf(nodeComp.getAttribute("dormer_type"));

		this.strCompName = nodeComp.getAttribute("component_name");

		this.width = Number(nodeComp.getAttribute("width"));
		this.height = Number(nodeComp.getAttribute("height"));
		this.fPrice = Number(nodeComp.getAttribute("price"));
		this.object3D_ID = nodeComp.getAttribute("object3D_ID");
		this.attachedElementName = nodeComp.getAttribute("attachedElementName");
		this.attachedXPos = Number(nodeComp.getAttribute("attachedXPos"));
		this.attachedYPos = Number(nodeComp.getAttribute("attachedYPos"));

		let dormerYPos = shedGraphics.dimHeight.fValue;

		if (this.dormer_type == ELEM_DORMER_SHED)
			dormerYPos += shedGraphics.frontBackWallHeightIncreaseForRafter_L;

		this.SetPos(-shedGraphics.dimWidth.fValue / 2, dormerYPos, 0);

		if (this.attachedElementName != "")
		{
			this.AddAttachedElement(this.attachedElementName, this.attachedXPos, this.attachedYPos);
		}
	};

	this.CreateExtrudedSection = function (texture, color, shape, thickness, width, height, yRot, assignUVsToGeometry)
	{
		let matter = CreateMaterial(color, texture);

		let geom = new THREE.ExtrudeGeometry(shape, {
			depth: thickness,
			bevelEnabled: false
		});

		if (assignUVsToGeometry)
			assignUVsToGeometry(geom);

		GeometryUtilities.ScaleTextureCoords(geom, width, height);

		let matrix = new THREE.Matrix4().makeTranslation(0, 0, -thickness / 2);
		geom.matrixAutoUpdate = false;
		geom.applyMatrix4(matrix);

		let mesh = new THREE.Mesh(geom, matter);

		geom.matrixAutoUpdate = false;
		geom.applyMatrix4(new THREE.Matrix4().makeRotationY(yRot));

		return mesh;
	};

	this.GenerateFromFiles = function ()
	{
		//if (this.regenerate)
		{
			this.Destroy();

			this.containerMesh = null;

			let objectsToBeLoadedIndices = Get3DObjectsIndices(this.object3D_ID);

			let geometry, geometryMaterial, mesh, texture;

			let geometryColor = 0xFFFFFF;

			let object3D_file;

			for (objectToBeLoadedIndex = 0; objectToBeLoadedIndex < objectsToBeLoadedIndices.length; objectToBeLoadedIndex++)
			{
				object3D_file = objects3DList[objectsToBeLoadedIndices[objectToBeLoadedIndex]].object3D_file;

				loadingObjectFileName = DIR_3DPARTS + "/" + objects3DList[objectsToBeLoadedIndices[objectToBeLoadedIndex]].objectType + "/" + object3D_file;

				geometry = geometryCache[loadingObjectFileName].clone();

				geometryColor = 0xFFFFFF;

				if (object3D_file.indexOf("tile") > 0)
				{
					texture = texturesList.SelectTexture(DIR_ROOFING + "/" + shedGraphics.imgRoofing.filename, THREE.RepeatWrapping, THREE.RepeatWrapping);

					GeometryUtilities.ScaleTextureCoords(geometry, 1 / shedGraphics.imgRoofing.size_x, 1 / shedGraphics.imgRoofing.size_y);
				}
				else
				if (object3D_file.indexOf("roof") > 0)
				{
					texture = texturesList.SelectTexture(DIR_ROOFING + "/" + shedGraphics.imgRoofingInt.filename, THREE.RepeatWrapping, THREE.RepeatWrapping);
					GeometryUtilities.ScaleTextureCoords(geometry, 1 / shedGraphics.imgRoofingInt.size_x, 1 / shedGraphics.imgRoofingInt.size_y);
				}
				else
				if (object3D_file.indexOf("wall") > 0)
				{
					texture = texturesList.SelectTexture(DIR_SIDING + "/" + shedGraphics.imgSiding.filename, THREE.RepeatWrapping, THREE.RepeatWrapping);

					GeometryUtilities.ScaleTextureCoords(geometry, 1 / shedGraphics.imgSiding.size_x, 1 / shedGraphics.imgSiding.size_y);

					let minWallUV = shedGraphics.meshWalls[WALL_LEFT][CAM_MODE_EXTERIOR][WALL_LAYER_BASIC].minUV;
					let maxWallUV = shedGraphics.meshWalls[WALL_LEFT][CAM_MODE_EXTERIOR][WALL_LAYER_BASIC].maxUV;

					minDormerWallUV = GeometryUtilities.GetMinUVs(geometry);

					let uStart = ((this.pos.z - this.width / 2) - shedGraphics.meshWalls[WALL_LEFT][CAM_MODE_EXTERIOR][WALL_LAYER_BASIC].vecWallExts[0].x) / shedGraphics.dimLength.fValue * (maxWallUV.u - minWallUV.u) + minWallUV.u;

					let uShift = uStart - minDormerWallUV.u;

					GeometryUtilities.ShiftTextureCoords(geometry, uShift, maxWallUV.v - minDormerWallUV.v);
				}
				else
				if (object3D_file.indexOf("trim") > 0)
				{
					geometryColor = shedGraphics.colTrim.color;
					texture = null;
				}
				else
					texture = null;

				geometryMaterial = CreateMaterial(geometryColor, texture);

				if (object3D_file.indexOf("wall") > 0)
				{
					geometry.matrixAutoUpdate = false;
					geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, this.pos.y, 0));

					if (this.attachedElement && this.attachedElement.cutoutMode)
					{
						let csgWall = new ThreeBSP(geometry);

						let boundingBoxGeometry = null;

						let infoWall = shedGraphics.GetWallInfo(this.attachedElement.eWall);

						this.attachedElement.ResetWallCutoutGeometry();

						boundingBoxGeometry = this.attachedElement.GetWallCutoutGeometry(infoWall.vecWallExts);

						boundingBoxMesh = new THREE.Mesh(boundingBoxGeometry, geometryMaterial);

						if (boundingBoxGeometry != null)
						{
							let cube_mesh = new THREE.Mesh(boundingBoxGeometry);

							if (modeCamera === CAM_MODE_INTERIOR)
							{
								cube_mesh.matrixAutoUpdate = false;
								cube_mesh.applyMatrix4(new THREE.Matrix4().makeRotationY(PI));
							}

							let cube = new ThreeBSP(cube_mesh);

							let subtract_bsp = csgWall.subtract(cube);

							let result = subtract_bsp.toMesh(new THREE.MeshNormalMaterial());
							geometry = result.geometry;
						}
					}

					geometry.matrixAutoUpdate = false;
					geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(-PI2));
					geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(this.pos.x, 0, this.pos.z));
				}
				else
				{
					geometry.matrixAutoUpdate = false;
					geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(-PI2));
					geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z));
				}


				mesh = new THREE.Mesh(geometry, geometryMaterial);

				if (objects3DList[objectsToBeLoadedIndices[objectToBeLoadedIndex]].affectsWallCutout)
				{
					this.containerMesh = mesh;
				}
				else
				{
					if (object3D_file.indexOf("?roof") > 0)
					{
						mesh.castShadow = true;
					}
					else
					if (object3D_file.indexOf("?ceiling") > 0)
					{
						mesh.castShadow = true;
					}
					else
					if (object3D_file.indexOf("?outerwall") > 0)
					{
						mesh.receiveShadow = true;
					}
					else
					if (object3D_file.indexOf("?trim") > 0)
					{
						mesh.castShadow = true;
					}

					this.meshElement.push(mesh);
				}
			}

			this.RegenerateSelection();

			this.regenerate = false;
		}
	};


	this.RegenerateSelection = function ()
	{
		this.DestroySelection();

		if (this.bIsSelected && !this.bIsSuppresed)
		{
			let dt = this.shedParent.roof_extra_len2;


			let fSelBoxSize = SEL_BOX_SIZE * g_fCanvasHeight;
			let box_size2 = fSelBoxSize;

			let box_offs_x = this.shedParent.dimWidth.fValue / 2 + this.roofOverHang + box_size2;

			let box_offs_y = this.shedParent.roofHeight1 + box_size2;

			let shedWidth2 = this.shedParent.dimLength.fValue / 2;

			let dormerWidth2 = this.width / 2;

			let vecOffs = [{
				x: -box_offs_x,
				y: box_offs_y,
				z: shedWidth2 - dormerWidth2 - box_size2
			},
			{
				x: 0,
				y: box_offs_y,
				z: shedWidth2 - dormerWidth2 - box_size2
			},
			{
				x: -box_offs_x,
				y: box_offs_y,
				z: shedWidth2 + dormerWidth2 + box_size2
			},
			{
				x: 0,
				y: box_offs_y,
				z: shedWidth2 + dormerWidth2 + box_size2
			},
			{
				x: -box_offs_x,
				y: 0,
				z: shedWidth2 - dormerWidth2 - box_size2
			},
			{
				x: -box_offs_x,
				y: 0,
				z: shedWidth2 + dormerWidth2 + box_size2
			}
			];
			let materSelBox = CreateMaterial(SEL_BOX_COLOR, null);

			let pnt_cent = new THREE.Vector2(-(this.shedParent.dimWidth.fValue + this.shedParent.visor_size_L) / 2 + this.shedParent.roofApexCoordinate.x, this.shedParent.dimHeight.fValue);

			let tt = this.shedParent.tile_thick;
			let pt = this.shedParent.roof_thick;

			pnt_cent.y += pt + tt;

			for (let i = 0; i < vecOffs.length; i++)
			{
				let geomSelBox = new THREE.BoxGeometry(fSelBoxSize, fSelBoxSize, fSelBoxSize);

				let mtxSelBoxToComp = new THREE.Matrix4().makeTranslation(pnt_cent.x + vecOffs[i].x, pnt_cent.y + vecOffs[i].y, vecOffs[i].z - shedWidth2);
				geomSelBox.matrixAutoUpdate = false;
				geomSelBox.applyMatrix4(mtxSelBoxToComp);

				let meshSelBox = new THREE.Mesh(geomSelBox, materSelBox);
				this.meshSelBoxes.push(meshSelBox);
				threeScene.add(meshSelBox);
				threeRenderer.shadowMap.needsUpdate = true;
			}
		}
	};

	this.Generate = function(buildingMeshes)
	{
		if (this.regenerate)
		{
			if (!this.tiles)
			{
				this.tiles = this.component3DObjects.GetObjectWithStringInName("?roof");
			}

			if (this.tiles)
			{
				buildingDesigner.building.dormer.SetTileTextureName(buildingDesigner.building.roof.tileTextureName);
				buildingDesigner.building.dormer.SetTileColor(buildingDesigner.building.roof.tileColor);
			}

			if (!this.roof)
			{
				this.roof = this.component3DObjects.GetObjectWithStringInName("?ceiling");
			}

			if (this.roof)
			{
				this.roof.SetTextureName(buildingDesigner.building.roof.roofTextureName);
			}

			if (!this.wall)
			{
				this.wall = this.component3DObjects.GetObjectWithStringInName("?outerwall");
			}

			if (this.wall)
			{
				this.wall.eWall = WALL_FRONT;
			}


			if (!this.trim)
			{
				this.trim = this.component3DObjects.GetObjectWithStringInName("?trim");
			}

			if (this.trim)
			{
				this.trim.SetColor(buildingDesigner.building.roof.trimColor);
			}

			if (!this.container)
			{
				this.container = this.component3DObjects.GetObjectWithStringInName("?cutout");
			}


			let frontWall = buildingDesigner.building.walls.GetWall(WALL_FRONT);

			if (buildingDesigner.building.dormer.wall) //// && !buildingDesigner.building.dormer.sidingColorDataSet)
			{
				if (!buildingDesigner.building.walls.sidingColorData)
					buildingDesigner.building.dormer.SetSidingColorData(GuiDataUtilities.sidingColorButtonData[30]);
				else
				{
					buildingDesigner.building.dormer.SetSidingCategoryData(frontWall.sidingCategoryData);
					buildingDesigner.building.dormer.SetSidingColorData(frontWall.sidingColorData);
				}
			}


			if (this.wall && frontWall.mesh)
			{
				if (GeometryUtilities.GetGeometry(this.wall.geometryFilename))
				{
					this.innerwall = this.component3DObjects.GetObjectWithStringInName("?innerwall");

					if (this.innerwall)
					{
						if (this.innerwall.objectData.object3D_ID.indexOf("Shed") > -1)
						{
							this.innerwall.visible = false;
						}
						else
						{
							GeometryUtilities.geometry[this.innerwall.geometryFilename] = GeometryUtilities.geometry[this.wall.geometryFilename].clone();

							GeometryUtilities.geometry[this.innerwall.geometryFilename].scale(1, 1, 0.1);

							this.innerwall.eWall = WALL_FRONT;
						}
					}

					this.wall.texture = frontWall.wallTexture;
					this.innerwall.texture = frontWall.innerWallTexture;

					this.scale = new THREE.Vector3(1.0, 1.0, 1.0);

					if (this.component3DObjects.boundingBox == null)
					{
						this.component3DObjects.CalculateGeometryScale(this.buttonData.width, this.buttonData.height, this.buttonData.height);
						this.component3DObjects.CalculateGeometryCenter();
					}

					if (!this.wall.mesh)
					{
						buildingDesigner.building.elementRequiresAdditionalRegenerate = true;
					}

					this.component3DObjects.Generate(buildingMeshes, this.component3DObjects.scale, true);

					let minX, minY, minZ;
					let maxX, maxY, maxZ;

					let frontRightCoordBottom, frontLeftCoordTop, backRightCoordBottom, backLeftCoordTop;

					let frontRightCoordTop, backRightCoordTop;

					if (this.tiles && this.tiles.mesh)
					{
						let size = new THREE.Vector3();

						this.tiles.mesh.geometry.boundingBox.getSize(size);

						let region;

						region = this.tiles.mesh.geometry.boundingBox.clone();

						region.min.x = region.max.x - size.x/10;

						region.max.z = this.tiles.mesh.geometry.boundingBox.min.z + size.z/10;

						backRightCoordBottom = GeometryUtilities.GetMinCoordForRegion(this.tiles.mesh.geometry, region, "y");

						if (backRightCoordBottom)
						{
							backRightCoordTop = GeometryUtilities.GetMaxCoordForRegion(this.tiles.mesh.geometry, region, "y");

							region = this.tiles.mesh.geometry.boundingBox.clone();

							region.min.x = region.max.x - size.x/10;

							region.min.z = region.max.z - size.z/10;

							frontRightCoordBottom = GeometryUtilities.GetMinCoordForRegion(this.tiles.mesh.geometry, region, "y");

							frontRightCoordTop = GeometryUtilities.GetMaxCoordForRegion(this.tiles.mesh.geometry, region, "y");


							region = this.tiles.mesh.geometry.boundingBox.clone();

							region.min.x = this.tiles.mesh.geometry.boundingBox.min.x;

							region.max.x = this.tiles.mesh.geometry.boundingBox.min.x + size.x/10;


							frontLeftCoordTop = GeometryUtilities.GetMaxCoordForRegion(this.tiles.mesh.geometry, region, "y");


							let y = backRightCoordTop.y-frontRightCoordTop.y;

							let z = frontRightCoordTop.z - backRightCoordTop.z;

							let shedDormerRoofAngle = Math.atan(y/z);

							shedDormerRoofAngle += this.tiles.objectData.rot_x * MathUtilities.RADIAN;


							let width = frontRightCoordTop.x - frontLeftCoordTop.x;

							let length = Math.sqrt(y*y + z*z);

							width*=this.tiles.scale.x;

							length*=this.tiles.scale.z;

							length+=Roof.ROOF_THICKNESS*2;

							let boxMesh = GeometryUtilities.CreateBoxMesh(width, 0.1, length, 0xffffff, null);

							boxMesh.matrixAutoUpdate = false;
							boxMesh.applyMatrix4(new THREE.Matrix4().makeTranslation(0, 0, -length));

							let tileProfileSection = buildingDesigner.building.roof.GenerateTileProfileSectionMesh(length*2, width);

							tileProfileSection.geometry.matrixAutoUpdate = false;
							tileProfileSection.geometry.applyMatrix4(new THREE.Matrix4().makeRotationY(MathUtilities.PI2));

							tileProfileSection.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(width, 0, 0));


							boxMesh = MeshUtilities.IntersectMesh(tileProfileSection, boxMesh);

							boxMesh.geometry.matrixAutoUpdate = false;
							boxMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-width/2, 0, 0));

							boxMesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(shedDormerRoofAngle));

							boxMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(0, frontRightCoordBottom.y*this.tiles.scale.y, frontRightCoordBottom.z*this.tiles.scale.z));

							this.component3DObjects.mesh.add(boxMesh);
						}
						else
						{
							region = this.tiles.mesh.geometry.boundingBox.clone();

							region.min.x = region.max.x - size.x/10;

							region.min.z = region.max.z - size.z/10;

							let frontRightCoord = GeometryUtilities.GetMaxCoordForRegion(this.tiles.mesh.geometry, region, "x");


							region.min.x = this.tiles.mesh.geometry.boundingBox.min.x;

							region.max.x = this.tiles.mesh.geometry.boundingBox.min.x + size.x/10;

							let frontLeftCoord = GeometryUtilities.GetMinCoordForRegion(this.tiles.mesh.geometry, region, "x");


							region.max.x = this.tiles.mesh.geometry.boundingBox.max.x;

							let frontApexCoord = GeometryUtilities.GetMaxCoordForRegion(this.tiles.mesh.geometry, region, "y");


							region.min.z = this.tiles.mesh.geometry.boundingBox.min.z;

							region.max.z = this.tiles.mesh.geometry.boundingBox.min.z + size.z/10;

							let backApexCoord = GeometryUtilities.GetMaxCoordForRegion(this.tiles.mesh.geometry, region, "y");


							let y = frontApexCoord.y - frontRightCoord.y;

							let x = frontRightCoord.x - frontApexCoord.x;

							let rightDormerRoofAngle = Math.atan(y/x);


							y = frontApexCoord.y - frontLeftCoord.y;

							x = frontApexCoord.x - frontLeftCoord.x;

							let leftDormerRoofAngle = Math.atan(y/x);


							region = this.roof.mesh.geometry.boundingBox.clone();

							region.min.x = region.max.x - size.x/10;

							region.min.z = region.max.z - size.z/10;

							let frontRightCoordRoof = GeometryUtilities.GetMaxCoordForRegion(this.roof.mesh.geometry, region, "x");


							region.min.x = this.roof.mesh.geometry.boundingBox.min.x;

							region.max.x = region.min.x + size.x/10;

							let frontLeftCoordRoof = GeometryUtilities.GetMinCoordForRegion(this.roof.mesh.geometry, region, "x");


							region.max.x = this.tiles.mesh.geometry.boundingBox.max.x;

							let frontApexCoordRoof = GeometryUtilities.GetMaxCoordForRegion(this.roof.mesh.geometry, region, "y");


							region.min.z = this.tiles.mesh.geometry.boundingBox.min.z;

							region.max.z = this.tiles.mesh.geometry.boundingBox.min.z + size.z/10;

							let backApexCoordRoof = GeometryUtilities.GetMaxCoordForRegion(this.roof.mesh.geometry, region, "y");


							let frontApexToBackApexLength = frontApexCoord.distanceTo(backApexCoord);

							let frontRightToFrontApexLength = frontRightCoord.distanceTo(frontApexCoord);

							let frontRightToBackApexLength = frontRightCoord.distanceTo(backApexCoord);

							let frontLeftToFrontApexLength = frontLeftCoord.distanceTo(frontApexCoord);

							let frontLeftToBackApexLength = frontLeftCoord.distanceTo(backApexCoord);


							let frontRightToApexesAngle = Math.acos((frontRightToFrontApexLength*frontRightToFrontApexLength + frontRightToBackApexLength*frontRightToBackApexLength - frontApexToBackApexLength*frontApexToBackApexLength) / (2 * frontRightToFrontApexLength * frontRightToBackApexLength));

							let frontLeftToApexesAngle = Math.acos((frontLeftToFrontApexLength*frontLeftToFrontApexLength + frontLeftToBackApexLength*frontLeftToBackApexLength - frontApexToBackApexLength*frontApexToBackApexLength) / (2 * frontLeftToFrontApexLength * frontLeftToBackApexLength));


							let frontApexToBackApexLengthRoof = frontApexCoordRoof.distanceTo(backApexCoordRoof);

							let frontRightToFrontApexLengthRoof = frontRightCoordRoof.distanceTo(frontApexCoordRoof);

							let frontRightToBackApexLengthRoof = frontRightCoordRoof.distanceTo(backApexCoordRoof);

							let frontLeftToFrontApexLengthRoof = frontLeftCoordRoof.distanceTo(frontApexCoordRoof);

							let frontLeftToBackApexLengthRoof = frontLeftCoordRoof.distanceTo(backApexCoordRoof);


							frontRightToFrontApexLengthRoof+=Roof.ROOF_THICKNESS*1.14;

							frontLeftToFrontApexLengthRoof+=Roof.ROOF_THICKNESS*1.14;


							let tileProfileSection = buildingDesigner.building.roof.GenerateTileProfileSectionMesh(frontLeftToFrontApexLength + frontRightToFrontApexLength, frontApexToBackApexLength);


							let dormerRoofPts = [{
								x: 0,
								y: 0
							},
							{
								x: 0,
								y: frontApexToBackApexLength
							},
							{
								x: frontRightToFrontApexLengthRoof,
								y: 0
							}
							];


							let dormerRoofShape = new THREE.Shape(dormerRoofPts);

							let dormerRoofGeom = new THREE.ExtrudeGeometry(dormerRoofShape, {
								depth: 1,
								bevelEnabled: false
							});


							let dormerRoofMesh = GeometryUtilities.CreateMeshFromGeometry(dormerRoofGeom, 0xffffff, null);

							dormerRoofMesh.geometry.matrixAutoUpdate = false;
							dormerRoofMesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(-MathUtilities.PI2));

							dormerRoofMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation((frontLeftToFrontApexLengthRoof + frontRightToFrontApexLengthRoof)/2, 0, 0));


							dormerRoofMesh = MeshUtilities.IntersectMesh(tileProfileSection, dormerRoofMesh);

							dormerRoofMesh.geometry.computeBoundingBox();

							let dormerRoofMeshHeightCoord = GeometryUtilities.GetMaxCoordForRegion(dormerRoofMesh.geometry, dormerRoofMesh.geometry.boundingBox, "y");

							dormerRoofMesh.geometry.matrixAutoUpdate = false;
							dormerRoofMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(-(frontLeftToFrontApexLengthRoof + frontRightToFrontApexLengthRoof)/2 - frontRightToFrontApexLengthRoof, 0, 0));

							dormerRoofMesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationZ(-rightDormerRoofAngle));

							dormerRoofMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(frontRightCoordRoof.x, frontRightCoordRoof.y, frontRightCoordRoof.z));

							this.component3DObjects.mesh.add(dormerRoofMesh);


							dormerRoofPts = [{
								x: 0,
								y: 0
							},
							{
								x: 0,
								y: frontApexToBackApexLength
							},
							{
								x: -frontLeftToFrontApexLengthRoof,
								y: 0
							}
							];

							dormerRoofShape = new THREE.Shape(dormerRoofPts);

							dormerRoofGeom = new THREE.ExtrudeGeometry(dormerRoofShape, {
								depth: 1,
								bevelEnabled: false
							});

							dormerRoofMesh = GeometryUtilities.CreateMeshFromGeometry(dormerRoofGeom, 0xffffff, null);

							dormerRoofMesh.geometry.matrixAutoUpdate = false;
							dormerRoofMesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationX(-MathUtilities.PI2));


							dormerRoofMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(frontLeftToFrontApexLengthRoof, 0, 0));


							dormerRoofMesh = MeshUtilities.IntersectMesh(tileProfileSection, dormerRoofMesh);

							dormerRoofMesh.geometry.computeBoundingBox();

							dormerRoofMeshHeightCoord = GeometryUtilities.GetMaxCoordForRegion(dormerRoofMesh.geometry, dormerRoofMesh.geometry.boundingBox, "y");

							dormerRoofMesh.geometry.matrixAutoUpdate = false;
							dormerRoofMesh.geometry.applyMatrix4(new THREE.Matrix4().makeRotationZ(leftDormerRoofAngle));


							dormerRoofMesh.geometry.applyMatrix4(new THREE.Matrix4().makeTranslation(frontLeftCoordRoof.x, frontLeftCoordRoof.y, frontLeftCoordRoof.z));

							this.component3DObjects.mesh.add(dormerRoofMesh);

						}

						this.tiles.mesh.visible = false;
						this.tiles.mesh.material.visible = false;
					}

					if (this.buttonData.elem_ID.toLowerCase().indexOf("shed") == -1)
					{
						this.wall.mesh.visible = false;
						this.wall.mesh.material.visible = false;
					}

					if (this.wall.mesh && this.wall.texture)
					{
						/*////if (this.attachedElement)
						{
							////this.component3DObjects.mesh.children = this.attachedElement.SubtractCutoutGeometryFromMeshes(this.component3DObjects.mesh.children, 1 / this.attachedElement.component3DObjects.scale.z, new THREE.Vector3(this.attachedXPos - this.attachedElement.component3DObjects.geometryCenter.x, this.attachedYPos - this.attachedElement.component3DObjects.geometryCenter.y, Wall.WALLTHICKNESS - this.attachedElement.component3DObjects.geometryCenter.z), this.attachedElement.component3DObjects.scale);

							let meshes = [];
							meshes.push(this.component3DObjects.mesh);

							meshes[0].eWall = WALL_FRONT;

							this.component3DObjects.mesh.children = this.attachedElement.SubtractCutoutGeometryFromMeshes(meshes, 1 / this.attachedElement.component3DObjects.scale.z, new THREE.Vector3(this.attachedXPos - this.attachedElement.component3DObjects.geometryCenter.x, this.attachedYPos - this.attachedElement.component3DObjects.geometryCenter.y, Wall.WALLTHICKNESS - this.attachedElement.component3DObjects.geometryCenter.z), this.attachedElement.component3DObjects.scale);
						}*/

						if (this.selected)
							this.GenerateSelectedBoxes(this.component3DObjects.mesh, this.component3DObjects.mesh.matrix);

						////this.component3DObjects.mesh = MeshUtilities.MergeMeshGeometry(this.component3DObjects.mesh);

						this.component3DObjects.mesh.matrixAutoUpdate = false;
						this.component3DObjects.mesh.applyMatrix4(new THREE.Matrix4().makeRotationY(-MathUtilities.PI2));
						this.component3DObjects.mesh.applyMatrix4(new THREE.Matrix4().makeTranslation(this.pos.x, this.pos.y, this.pos.z));

						this.cutoutGeometry = this.component3DObjects.ComputeCutoutGeometry(false /*////buildingDesigner.camera.modeCamera == Camera.CAM_MODE_INTERIOR*/ , this.cutoutMode);

						if (this.cutoutGeometry)
						{
							let matrix = new THREE.Matrix4();

							this.cutoutGeometry.matrixAutoUpdate = false;
							this.cutoutGeometry.applyMatrix4(this.component3DObjects.mesh.matrix);

							let subtractMaterial = new THREE.MeshStandardMaterial({
								color: 0xffffff,
								map: null,
								roughness: 1.0,
								metalness: METALNESS
							});

							let subtractMesh = new THREE.Mesh(this.cutoutGeometry, subtractMaterial);

							MeshUtilities.SubtractMeshFromMeshes(buildingMeshes, subtractMesh, -1, ELEM_ROOFING);
							MeshUtilities.SubtractMeshFromMeshes(buildingMeshes, subtractMesh, -1, ELEM_ROOF_RAFTER);
						}

						this.component3DObjects.mesh.type = ELEM_DORMER;
						this.component3DObjects.mesh.element = this;

						this.component3DObjects.mesh.castShadow = true;
						this.component3DObjects.mesh.receiveShadow = true;
					}
				}
			}
		}

		return this.component3DObjects.mesh;
	};

	this.AddAttachedElement = function (buttonData, attachedXPos, attachedYPos)
	{
		switch (ELEM_STRING[buttonData.type])
		{
		case "Window": {
			this.attachedElement = Window.AddWindow(buttonData);
			break;
		}
		case "Door": {
			this.attachedElement = Door.AddDoor(buttonData);
			break;
		}
		case "Option": {
			this.attachedElement = Option.AddOption(buttonData);
			break;
		}
		default: {
			console.warn(`Unsupported dormer attachment type -- ${ELEM_STRING[buttonData.type]}`);
			return null;
		}
		}

		this.attachedXPos = attachedXPos;
		this.attachedYPos = attachedYPos;
		this.attachedElement.dormer = this;
		this.attachedElement.isAttached = true;

		this.attachedElement.draggable = false;

		this.attachedElement.wall = buildingDesigner.building.walls.GetWall(WALL_FRONT);

		this.attachedElement.pos.x = this.attachedXPos;
		this.attachedElement.pos.y = this.attachedYPos;

		this.attachedElement.pos.z = Wall.WALLTHICKNESS;

		return this.attachedElement;
	};
}

Dormer.AddDormer = function (dormerButtonData)
{
	if (!dormerButtonData)
	{
		return;
	}
	Elements.DeleteElement(buildingDesigner.building.dormer);
	Elements.ClearNulls();

	buildingDesigner.building.dormer = new Dormer(buildingDesigner.building, dormerButtonData);

	buildingDesigner.building.dormer.SetPos(-buildingDesigner.building.roofRafter.wallWidth / 2 + dormerButtonData.x_offset, buildingDesigner.building.height + dormerButtonData.y_offset, dormerButtonData.z_offset);

	if (Array.isArray(nestedObj(dormerButtonData.options,"attached_elements")))
	{
		for (attachment of dormerButtonData.options.attached_elements)
		{
			let buttonData = GuiDataUtilities.GetButtonData(attachment.element);
			let elem = buildingDesigner.building.dormer.AddAttachedElement(buttonData, attachment.x_pos, attachment.y_pos);
		}
	}

	Elements.AddElement(buildingDesigner.building.dormer);

	buildingDesigner.building.SetRegenerateBuildingAndElementMeshes(true);

	Elements.draggableElement = null;

	return buildingDesigner.building.dormer;
};


Dormer.prototype = Object.create(Element.prototype);
// Set the "constructor" property to refer to Student
Dormer.prototype.constructor = Dormer;
