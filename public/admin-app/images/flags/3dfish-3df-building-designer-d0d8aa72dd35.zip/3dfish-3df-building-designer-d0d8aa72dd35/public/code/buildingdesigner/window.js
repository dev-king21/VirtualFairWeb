/*eslint-env jquery, browser, es6*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-parserOptions ecmaVersion:8*/
/*eslint-disable no-console, no-unused-vars, no-undef */

////function Window(name, elem_ID, object3D_ID, width, height, width_display, height_display, price)
function Window(buttonData)
{
	////Element.call(this, name, elem_ID, object3D_ID, width, height, width_display, height_display, 1, price);

	Element.call(this, buttonData);

	buttonData.type = ELEM_WINDOW;

	this.AddObjects();

	let default_color = nestedObj(buttonData,"options.default_trim_color_id") || nestedObj(buildingDesigner.building,"options.defaults.window_trim_color_id");
	if (default_color)
	{
		let trimColor = ColorsDataUtilities.FindColor(default_color);
		if (trimColor)
		{
			this.trimColor = trimColor.color;
			this.trimColor_name = trimColor.color_name;
			this.trimColor_id = trimColor.color_id;
		}
	}

	this.SetPos = function (x, y, z)
	{
		this.pos.x = x;

		let heightSet = false;

		if (!this.IsTransomWindow())
		{
			let windowPlacementHeight;
			let windowVAlignment = "top";
			if (buildingDesigner.building.options && buildingDesigner.building.options.window && buildingDesigner.building.options.window.placement_height)
			{
				windowPlacementHeight = buildingDesigner.building.options.window.placement_height;
			}
			if (buildingDesigner.building.sizeData.window_height > 0)
			{
				windowPlacementHeight = buildingDesigner.building.sizeData.window_height;
			}
			if (buildingDesigner.building.sizeData.size_options && buildingDesigner.building.sizeData.size_options.window && buildingDesigner.building.sizeData.size_options.window.vert_align)
			{
				windowVAlignment = buildingDesigner.building.sizeData.size_options.window.vert_align;
			}
			else if (buildingDesigner.building.options && buildingDesigner.building.options.window && buildingDesigner.building.options.window.vert_align)
			{
				windowVAlignment = buildingDesigner.building.options.window.vert_align;
			}
			if (windowPlacementHeight > 0) // i.e. placement height is specified.
			{
				switch (windowVAlignment)
				{
				case "bottom": {
					this.pos.y = windowPlacementHeight + buttonData.height / 2;
					break;
				}
				case "center": {
					this.pos.y = windowPlacementHeight;
					break;
				}
				default: {
					// set vertical position to height from ground to center of window -- ie, subtract half of the window height from the position setting.
					this.pos.y = windowPlacementHeight - buttonData.height / 2;
				}
				}
				heightSet = true;
			}
			else
			{
				let windowsOnSameWall = buildingDesigner.building.GetWindowsOnWall(this.wall.eWall);

				for (let i = 0; i < windowsOnSameWall.length; i++)
				{
					if (this != windowsOnSameWall[i] && !windowsOnSameWall[i].IsTransomWindow() && !windowsOnSameWall[i].dormer)
					{
						this.pos.y = windowsOnSameWall[i].pos.y;
						heightSet = true;

						break;
					}
				}
			}
		}

		if (!heightSet)
			this.pos.y = y;

		this.pos.z = z;

		this.UpdateMatrix();
	};

	this.IsTransomWindow = function ()
	{
		if (this.buttonData.height / this.buttonData.width < 0.5)
			return true;
		else
			return false;
	};

	this.GenerateInteriorFraming = function ()
	{
		let framingThickness;
		let framingWidth;

		////if (BuildingDesigner.buildingType == BUILDING_CARPORT)
		if (buildingDesigner.building.metalFraming)
		{
			framingThickness = buildingDesigner.building.roofRafter.data.thickness;
			framingWidth = buildingDesigner.building.roofRafter.data.width;
			////framingWidth = buildingDesigner.building.roofRafter.data.thickness;
		}
		else
		{
			framingThickness = buildingDesigner.building.roofRafter.data.thickness;
			framingWidth = buildingDesigner.building.roofRafter.data.width;
			////framingWidth = BOARD_2x4_WIDTH;
		}

		this.GetInteriorFramingTexture();

		////if (TexturesDataUtilities.TextureLoaded(this.framingTexture))
		{
			let rafterCoords = this.GetClosestWallRafterCoords();

			let rafterCoordsCenter;
			let plankLength;

			let rafterXOffset;

			//if (rafterCoords.leftCoord != -1 || rafterCoords.rightCoord != -1)
			{
				plankLength = rafterCoords.rightCoord - rafterCoords.leftCoord;

				rafterCoordsCenter = (rafterCoords.leftCoord + rafterCoords.rightCoord) / 2;

				rafterXOffset = rafterCoordsCenter - this.pos.x;
			}


			if (this.wall.eWall == WALL_LEFT || this.wall.eWall == WALL_BACK)
				rafterXOffset *= -1;

			let boxWidth = this.width;

			if (this.boundingBox)
			{
				boxWidth = this.boundingBox.max.x - this.boundingBox.min.x;

				boxWidth *= this.component3DObjects.scale.x;
			}

			let top = (this.cutOutCenter.y + this.cutOutHeight / 2);

			let bottom = (this.cutOutCenter.y - this.cutOutHeight / 2) - buildingDesigner.building.roofRafter.data.thickness;

			let left = (this.cutOutCenter.x - this.cutOutWidth / 2) + (this.component3DObjects.geometryCenter.x - this.cutOutCenter.x) - buildingDesigner.building.roofRafter.data.thickness;

			let right = (this.cutOutCenter.x + this.cutOutWidth / 2) + (this.cutOutCenter.x - this.component3DObjects.geometryCenter.x);

			let length = top - bottom;

			let horizontalPlank1 = GeometryUtilities.CreateOrientatedBox(plankLength, framingThickness, framingWidth, this.framingColor, this.framingTexture, null, new THREE.Vector3(1 / this.component3DObjects.scale.x, 1 / this.component3DObjects.scale.y, 1 / this.component3DObjects.scale.y), new THREE.Vector3(this.component3DObjects.geometryCenter.x - plankLength / 2 + rafterXOffset, top, -framingWidth - Wall.WALLTHICKNESS));
			let horizontalPlank2 = GeometryUtilities.CreateOrientatedBox(plankLength, framingThickness, framingWidth, this.framingColor, this.framingTexture, null, new THREE.Vector3(1 / this.component3DObjects.scale.x, 1 / this.component3DObjects.scale.y, 1 / this.component3DObjects.scale.y), new THREE.Vector3(-plankLength / 2 + rafterXOffset + this.component3DObjects.geometryCenter.x, bottom, -framingWidth - Wall.WALLTHICKNESS));

			let verticalPlank1 = GeometryUtilities.CreateOrientatedBox(framingThickness, length, framingWidth, this.framingColor, this.framingTexture, null, new THREE.Vector3(1 / this.component3DObjects.scale.x, 1 / this.component3DObjects.scale.y, 1 / this.component3DObjects.scale.y), new THREE.Vector3(left, -length / 2 + this.component3DObjects.geometryCenter.y, -framingWidth - Wall.WALLTHICKNESS));
			let verticalPlank2 = GeometryUtilities.CreateOrientatedBox(framingThickness, length, framingWidth, this.framingColor, this.framingTexture, null, new THREE.Vector3(1 / this.component3DObjects.scale.x, 1 / this.component3DObjects.scale.y, 1 / this.component3DObjects.scale.y), new THREE.Vector3(right, -length / 2 + this.component3DObjects.geometryCenter.y, -framingWidth - Wall.WALLTHICKNESS));

			////if (BuildingDesigner.buildingType == BUILDING_CARPORT)
			if (buildingDesigner.building.metalFraming)
			{
				let mater = new THREE.MeshPhongMaterial({
					color: MetalRafters.METAL_RAFTERS_COLOR,
					specular: 0xFFFFFF,
					shininess: 100,
					map: this.framingTexture
				});

				horizontalPlank1.material = mater;
				horizontalPlank2.material = mater;

				verticalPlank1.material = mater;
				verticalPlank2.material = mater;
			}

			horizontalPlank1.type = ELEM_FRAMING;
			horizontalPlank2.type = ELEM_FRAMING;
			verticalPlank1.type = ELEM_FRAMING;
			verticalPlank2.type = ELEM_FRAMING;

			this.component3DObjects.mesh.add(horizontalPlank1);
			this.component3DObjects.mesh.add(horizontalPlank2);
			this.component3DObjects.mesh.add(verticalPlank1);
			this.component3DObjects.mesh.add(verticalPlank2);
		}

		return null;
	};

	this.Generate = function (buildingMeshes)
	{
		if (this.regenerate && this.wall && this.wall.matrix)
		{
			if (this.component3DObjects.boundingBox == null)
			{
				this.component3DObjects.CalculateGeometryScale(this.buttonData.width, this.buttonData.height, this.buttonData.height);
				this.component3DObjects.CalculateGeometryCenter();
			}

			if (this.component3DObjects.boundingBox)
			{
				let size = new THREE.Vector3();

				size = this.component3DObjects.boundingBox.getSize(size);

				this.length = size.z * this.component3DObjects.scale.z;

				this.component3DObjects.Generate(buildingMeshes, this.component3DObjects.scale, true);

				this.component3DObjects.SetCameraAndConfigurationModeVisibility(buildingDesigner.camera.modeCamera, this.configurationMode);

				if (this.selected)
					this.GenerateSelectedBoxes(this.component3DObjects.mesh, this.component3DObjects.mesh.matrix);

				this.component3DObjects.mesh.type = ELEM_WINDOW;

				MeshUtilities.SetElement(this.component3DObjects.mesh, this);

				this.component3DObjects.mesh.castShadow = true;
				this.component3DObjects.mesh.receiveShadow = true;

				this.component3DObjects.mesh.visible = true;
			}


			this.UpdateMatrix();

			if (!this.dragging)
			{
				this.SubtractCutoutGeometryFromBuildingMeshes(buildingMeshes, 1 / this.component3DObjects.scale.z);

				if (buildingDesigner.camera.modeCamera == Camera.CAM_MODE_INTERIOR)
					this.GenerateInteriorFraming();
			}

			this.regenerate = false;
		}

		return this.component3DObjects.mesh;
	};
}

Window.AddWindow = function (windowButtonData)
{
	let element = new Window(windowButtonData);

	//element.SetFixedHeight(windowButtonData.fixed_height);

	Elements.AddElement(element);

	return element;
};



// The correct place to call parent object is in child class constructor
// as we call it in above Student function code
Window.prototype = Object.create(Element.prototype);
// Set the "constructor" property to refer to Student
Window.prototype.constructor = Window;
