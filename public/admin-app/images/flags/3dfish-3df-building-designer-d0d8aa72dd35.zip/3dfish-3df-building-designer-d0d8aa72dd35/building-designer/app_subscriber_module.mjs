/*eslint-env node, es6*/
/*eslint-parserOptions ecmaVersion:2020*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape, no-undef*/

/*This module is for subscriber specific actions */

import Dbfunctions from "./dbfunctions.cjs";
import mysql from "mysql2/promise.js";
import { CleanSubscriberID, getSubscriberData } from "./app.mjs";
import to from "togo";
import deepFind from "deep-find";

export class SubscriberModule {
	constructor(params) {
		this.con = params.mysql_connection;
		this.tcon = params.mysql_transaction_connection;
		this.logger = params.logger;
		this.DEBUG = params.DEBUG;
		this.dbfunc = new Dbfunctions({mysql_connection:this.con, mysql_transaction_connection:this.tcon, logger:this.logger, DEBUG:this.DEBUG});
		//this.P_GetQueryData = this.dbfunc.P_GetQueryData;
		this.ParseMySqlRowDataObj = this.dbfunc.ParseMySqlRowDataObj.bind(this.dbfunc);
		this.P_ParseMySqlRowsDataObj = this.dbfunc.P_ParseMySqlRowsDataObj.bind(this.dbfunc);
		this.MySQLActionResult = this.dbfunc.MySQLActionResult.bind(this.dbfunc);
		this.ReturnSingleMySQLRow = this.dbfunc.ReturnSingleMySQLRow.bind(this.dbfunc);

	}

	async data(req) {
		let err;
		let result = {};
		switch (req.body.request) {
			case "verifysub": {
				[err, result] = await to(this.verifysub(req));
				break;
			}
			default: {
				err = {
					message: "Invalid request"
				};
			}
		}
		if (err) {
			throw err;
		}
		return result;
	}

	async verifysub(req) {
		let [err, result] = await to(getSubscriberData(req, req.body.subscriber_id));
		if (err) {
			return {success: false, err: err};
		}
		return result;
	}

	async CleanSubscriberID(subscriber_id, req) {
		let err, result;
		this.logger.debug("CleanSubscriberID");

		// req = req || request;
		if(typeof req==="undefined") req={};

		if (subscriber_id == undefined || subscriber_id == null)
			if(req.body.subscriber_id) {
				subscriber_id = req.body.subscriber_id;
			} else {
				if (req.session && req.session.subscriber_data && req.session.subscriber_data.subscriber_id) {
					subscriber_id = req.session.subscriber_data.subscriber_id;
				}
			}

		if(!subscriber_id) {
			this.logger.warn("fn:CleanSubscriberID - subscriber_id not set.");
			return null;
		}
		let subscriber = subscriber_id.replace(/([^a-z0-9\-]+)/gi,"");

		if (subscriber.substr(0,3) === "MT-")
		{
			// master_test = true;
			if(req.session !== "undefined") req.session.master_test = true;
			subscriber = subscriber.substr(3,subscriber.length - 3);
		}

		subscriber_id = subscriber.toUpperCase();
		if(typeof req.session !== "undefined") {
			if (!req.session.subscriber_data) {
				[err, result] = await to(getSubscriberData(req, subscriber_id));
			} else {
				if (req.session.subscriber_data.subscriber_id !== subscriber_id) {
					[err, result] = await to(resetSubscriberDataFromDb(req, subscriber_id));
				}
			}
		}

		return subscriber_id;
	}
}
