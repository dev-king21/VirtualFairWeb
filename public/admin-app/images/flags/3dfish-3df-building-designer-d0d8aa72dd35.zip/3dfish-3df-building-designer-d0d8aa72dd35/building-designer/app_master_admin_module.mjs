/*eslint-env node, es6*/
/*eslint-parserOptions ecmaVersion:2020*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape, no-undef*/

/* This module is for Master Admin only actions */

/* currently may have some other actions, these should be moved to subscriber_admin_module.js */

import Dbfunc from "./dbfunctions.cjs";
import mysql from "mysql2/promise.js";
import to from "togo";
import path from "path";
import CSV from "comma-separated-values";
import _ from "lodash";
import deepFind from "deep-find";

import { dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

export class MasterAdminModule {
	constructor(params) {
		this.app = params.app;
		this.con = params.mysql_connection; // mysql_connection;
		this.tcon = params.mysql_transaction_connection; //mysql_transaction_connection;
		this.logger = params.logger;
		this.DEBUG = params.DEBUG;
		this.dbfunc = new Dbfunc({mysql_connection:this.con, mysql_transaction_connection:this.tcon, logger:this.logger,DEBUG:this.DEBUG});
		this.P_GetQueryData = this.dbfunc.P_GetQueryData.bind(this.dbfunc);
		this.ParseMySqlRowDataObj = this.dbfunc.ParseMySqlRowDataObj.bind(this.dbfunc);
		this.P_ParseMySqlRowsDataObj = this.dbfunc.P_ParseMySqlRowsDataObj.bind(this.dbfunc);
		this.ParseMySqlRowData = this.dbfunc.ParseMySqlRowData.bind(this.dbfunc);
		this.P_ParseMySqlRowsData = this.dbfunc.P_ParseMySqlRowsData.bind(this.dbfunc);
		this.MySQLActionResult = this.dbfunc.MySQLActionResult.bind(this.dbfunc);
		this.ParseAdminDataRowData = this.ParseAdminDataRowData.bind(this);
		this.DeleteSubscriber = this.DeleteSubscriber.bind(this);

		this.app.post('/verifysub', async (req, res) => {
			if (this.DEBUG) console.log("/verifysub");
			if (typeof (req.body.subscriber_id) !== 'undefined') {
				let subscriber_id = mysql.escape(req.body.subscriber_id);
				let query = `SELECT * FROM subscribers WHERE subscriber_id = ${subscriber_id}`;
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData));
				if (err) {
					console.error(err);
				}
				if (this.DEBUG) console.log(result);
				if (result.length > 2) {
					res.send({
						status: "success",
						subscriber_status: JSON.parse(result)[0].status,
						success: true,
						name: JSON.parse(result)[0].name
					});
				} else {
					res.send({
						status: "failed",
						success: false
					});
				}
			} else {
				res.send({
					status: "failed",
					success: false
				});
			}
		});

		this.app.get('/s3browser.html', async (request, res) => {
			if (this.DEBUG) console.log("/s3browser.html");
			let rootdir;
			/*if (serverLocal == "true") { */
				rootdir = __dirname + "/..";
			/*} else {
				rootdir = __dirname + "/..";
			} */
			res.sendFile(path.join(rootdir + '/s3browser.html'));
		});

		this.app.get('/adminui', async (request, res) => {
			let rootdir;
			/* if (serverLocal == "true") { */
				rootdir = __dirname + "/..";
				/*
			} else {
				rootdir = __dirname + "/..";
			}*/
			if (typeof (request.session.userdata) !== 'undefined') {
				console.log(typeof (request.session.userdata));
				if (request.session.userdata.usertype == 'master') {
					// res.sendFile(path.join(rootdir + '/admin_files/admin-menu_header.html'));
					// res.sendFile(path.join(rootdir + '/admin_files/admin-menu_footer.html'));
					res.render('pages/admin-menu');
				} else {
					if (this.DEBUG) console.log("Get - Userdata Defined - Admin Login");
					res.sendFile(path.join(rootdir + '/admin_files/loginform.html'));
				}
			} else {
				if (this.DEBUG) console.log("Get - Userdata Not Defined - Admin Login");
				res.sendFile(path.join(rootdir + '/admin_files/loginform.html'));
			}
		});

		this.app.post('/adminui', async (req, res) => {
			let pset = false;
			let p, p2;
			let rootdir;
			let query;
			let rowdata, result, currentTableName, elem_id_field, err;
			/* if (serverLocal == "true") { */
			rootdir = __dirname + "/..";
			/*} else {
				rootdir = __dirname + "/..";
			} */
			if (typeof (req.session.userdata) !== 'undefined') {
				this.logger.debug(`Adminui: typeof userdata: ${typeof req.session.userdata}`);
				if (["staff","admin","sadmin","master"].includes(req.session.userdata.usertype)) {
					if (typeof (req.body.loaddata) !== 'undefined') {
						switch (req.body.loaddata) {
							case "admin-view_menu": {
								let ejsdata = {
									userdata: req.session.userdata
								};
								res.render("partials/admin-view_menu.ejs", {
									data: ejsdata
								});
								return;
							} // case admin-view_menu
							case "admin-view_menu_tab_panels": {
								let ejsdata = {
									userdata: req.session.userdata
								};
								res.render("partials/admin-view_menu_tab_panels.ejs", {
									data: ejsdata
								});
								return;
							} // case admin-view_menu_tab_panels
							case "admin-view_content": {
								let ejsdata = {
									userdata: req.session.userdata
								};
								res.render("partials/admin-view_content.ejs", {
									data: ejsdata
								});
								return;
							}
							case "getmfgcolors": {
								query = `SELECT * FROM colors WHERE mfg_id = '${req.body.mfg_id}' ORDER BY sort_string, color_name`;
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowDataObj, this.ParseMySQLRowsDataObj));
								if (err) {
									res.send({
										success: false,
										status: "Error",
										err: err
									});
									return;
								}
								res.send(result);
								break;
							} // case getmfgcolors
							case "getcolormfgs": {
								query = `SELECT * FROM clr_mfgs ORDER BY mfg_name`;
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowDataObj, this.P_ParseMySqlRowsDataObj));
								if (err) {
									res.send({
										success: false,
										status: "Error",
										err: err
									});
									return;
								}
								res.send(result);
								break;
							} //getcolormfgs
							case "subscribers": {
								query = "SELECT * FROM subscribers ORDER BY expiration";
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case subscribers
							case "getsublocations": {
								if (this.DEBUG) console.log('adminui:getsubprofile');
								query = "SELECT * from subscriber_locations WHERE subscriber_id = '" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsublocations
							case "adminusers": {
								query = "SELECT * FROM users WHERE subscriber_id = '" + req.body.subscriber_id + "' AND usertype IN ('admin', 'sadmin')";
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case adminusers
							case "sublastaccess": {
								if (!req.body.subscriber_id) {
									query = "SELECT subscriber_id FROM subscribers";
								} else {
									query = "SELECT subscriber_id FROM subscribers WHERE subscriber_id = ?";
									query = mysql.format(query, req.body.subscriber_id);
								}
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowDataObj, this.P_ParseMySqlRowsDataObj));
								if (err) {
									res.send({
										err: err
									});
									return;
								}
								if (result.length === 0) {
									res.send({
										err: "no results"
									});
									return;
								}
								//query = "SELECT a1.subscriber_id, a1.date FROM access_log a1 LEFT JOIN access_log a2 ON a1.subscriber_id = a2.subscriber_id AND a1.date < a2.date WHERE a2.subscriber_id IS NULL GROUP BY subscriber_id"; This was taking too long to execute on a large dataset
								let access_data = [];
								let result2;
								for (let i = 0; i < result.length; i++) {
									query = `SELECT subscriber_id, date FROM access_log WHERE subscriber_id = "${result[i].subscriber_id}" ORDER BY id DESC LIMIT 1`;
									[err, result2] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowDataObj, this.P_ParseMySqlRowsDataObj));
									if (err) {
										res.send({
											err: err
										});
										return;
									}
									if (result2.length > 0) {
										access_data.push(result2[0]);
									}
								}
								pset = false;
								res.send(access_data);
								//p = this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowData,this.P_ParseMySqlRowsData);
								return;
							} // case sublastaccess
							case "rafters": {
								query = "SELECT * FROM rafters";
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case rafters
							case "subnumusers": {
								query = "SELECT DISTINCT subscriber_id, COUNT(subscriber_id) as users FROM users GROUP BY subscriber_id";
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case subnumusers
							case "subnumsaveddesigns": {
								query = "SELECT DISTINCT subscriber_id, count(subscriber_id) as designs FROM usersheds GROUP BY subscriber_id";
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case subnumsaveddesigns
							case "getsubprofile": {
								if (this.DEBUG) console.log('adminui:getsubprofile');
								query = "SELECT * from subscribers WHERE subscriber_id = '" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubprofile
							case "getsubseries": {
								if (this.DEBUG) console.log('adminui:getsubseries');
								query = "SELECT * from subscriber_series WHERE subscriber_id = '" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubseries
							case "getsubramps": {
								if (this.DEBUG) console.log('adminui:getsubramps');
								query = "SELECT * FROM subscriber_ramps INNER JOIN ramps WHERE subscriber_ramps.ramp_id = ramps.ramp_id AND subscriber_ramps.subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubramps
							case "getsubpartitions": {
								if (this.DEBUG) console.log('adminui:getsubpartitions');
								query = "SELECT * FROM subscriber_partitions INNER JOIN partitions WHERE subscriber_partitions.partition_id = partitions.partition_id AND subscriber_partitions.subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubpartitions
							case "getsubwalls": {
								if (this.DEBUG) console.log('adminui:getsubwalls');
								query = "SELECT * FROM subscriber_walls INNER JOIN walls WHERE subscriber_walls.wall_id = walls.wall_id AND subscriber_walls.subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubwalls
							case "getsubdormers": {
								if (this.DEBUG) console.log('adminui:getsubdormers');
								query = "SELECT * FROM subscriber_dormers INNER JOIN dormers WHERE subscriber_dormers.elem_id = dormers.elem_id AND subscriber_dormers.subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubdormers
							case "getsubkickboards": {
								if (this.DEBUG) console.log('adminui:getsubkickboards');
								query = "SELECT * FROM subscriber_kickboards WHERE subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubkickboards
							case "getsubbuildings": {
								if (this.DEBUG) console.log('adminui:getsubbuildings');
								// the buildings table is no longer used in the main app
								// query = "SELECT * FROM subscriber_buildings INNER JOIN buildings WHERE subscriber_buildings.building_id = buildings.building_id AND subscriber_buildings.subscriber_id='" + req.body.subscriber_id + "' AND subscriber_buildings.building_type=buildings.building_type ORDER BY display_order ASC";
								query = `SELECT * FROM subscriber_buildings WHERE subscriber_id='${req.body.subscriber_id}' ORDER BY display_order ASC`;
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubbuildings
							case "getsubdescriptions": {
								if (this.DEBUG) console.log('adminui:getsubbuildings');
								query = "SELECT * FROM subscriber_descriptions WHERE subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubdescriptions
							case "getsubsiding": {
								if (this.DEBUG) console.log('adminui:getsubsiding');
								query = "SELECT * FROM subscriber_siding_categories INNER JOIN siding_information WHERE siding_information.siding_id = subscriber_siding_categories.category_id AND subscriber_id='" + req.body.subscriber_id + "' ORDER BY display_order ASC";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubsiding
							case "getsubsidingcolors": {
								if (this.DEBUG) console.log('adminui:getsubsidingcolors');
								query = "SELECT * FROM subscriber_siding_colors WHERE subscriber_id='" + req.body.subscriber_id + "' ORDER BY display_order ASC";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubsidingcolors
							case "getsubtrimcolors": {
								if (this.DEBUG) console.log('adminui:getsubtrimcolors');
								query = "SELECT * FROM subscriber_trim_colors INNER JOIN colors WHERE colors.color_id = subscriber_trim_colors.color_id AND subscriber_id='" + req.body.subscriber_id + "' ORDER BY display_order ASC";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubtrimcolors
							case "getsubdoorcolors": {
								if (this.DEBUG) console.log('adminui:getsubdoorcolors');
								query = "SELECT * FROM subscriber_door_colors INNER JOIN colors WHERE colors.color_id = subscriber_door_colors.color_id AND subscriber_id='" + req.body.subscriber_id + "' ORDER BY display_order ASC";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubdoorcolors
							case "getsubroofingcat": {
								if (this.DEBUG) console.log('adminui:getsubroofingcat');
								query = "SELECT * FROM subscriber_roofing_categories INNER JOIN roofing_categories WHERE roofing_categories.category_id = subscriber_roofing_categories.category_id AND subscriber_id='" + req.body.subscriber_id + "' ORDER BY display_order ASC";
								if (this.DEBUG) console.log(query);
								// pset = true;
								result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								res.send(result);
								break;
							} // case getsubroofingcat
							case "getsubroofing": {
								if (this.DEBUG) console.log('adminui:getsubroofing');
								query = "SELECT * FROM subscriber_roofing INNER JOIN roofing WHERE subscriber_roofing.roofing_id = roofing.roofing_id AND subscriber_roofing.subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubroofing
							case "getsubdoors": {
								if (this.DEBUG) console.log('adminui:getsubdoors');
								query = "SELECT * FROM subscriber_doors INNER JOIN doors WHERE subscriber_doors.elem_id = doors.elem_id AND subscriber_doors.subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubdoors
							case "getsubhinges": {
								if (this.DEBUG) console.log('adminui:getsubhinges');
								query = "SELECT * FROM subscriber_hinges INNER JOIN hinges WHERE subscriber_hinges.elem_id = hinges.elem_id AND subscriber_hinges.subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubhinges
							case "getsubwindows": {
								if (this.DEBUG) console.log('adminui:getwindows');
								query = "SELECT * FROM subscriber_windows INNER JOIN windows WHERE subscriber_windows.elem_id = windows.elem_id AND subscriber_windows.subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubwindows
							case "getsuboptions": {
								if (this.DEBUG) console.log('adminui:getsuboptions');
								query = "SELECT * FROM subscriber_options INNER JOIN options WHERE subscriber_options.elem_id = options.elem_id AND subscriber_options.subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsuboptions
							case "getsubshelves": {
								if (this.DEBUG) console.log('adminui:getshelves');
								query = "SELECT * FROM subscriber_shelves INNER JOIN shelves WHERE subscriber_shelves.elem_id = shelves.elem_id AND subscriber_shelves.subscriber_id='" + req.body.subscriber_id + "'";
								if (this.DEBUG) console.log(query);
								pset = true;
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								break;
							} // case getsubshelves
							case "getsidingprices": {
								if (this.DEBUG) console.log('adminui:getsidingprices');
								query = "SELECT * FROM subscriber_siding_price WHERE subscriber_id = '" + req.body.subscriber_id + "' AND building_product_id LIKE '%" + req.body.building_id + "%' AND series_code = '" + req.body.series_code + "'";
								if (this.DEBUG) console.log(query);
								let [err, data] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData));
								if (err) {
									console.log("Location: app_admin.js:888, App Error: ", err);
									res.sendStatus(500);
								}
								res.send(data);
								//pset = true;
								//p = this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowData,this.P_ParseMySqlRowsData);
								break;
							} // case getsidingprices

						} // switch (req.body.loaddata)
						if (pset)
							p.then(data => {
								res.send(data);
							}).catch(err => {
								console.log("Location: app_admin.js:680, App Error: ", err);
								res.sendStatus(500);
							});
					} else if (typeof (req.body.action) !== 'undefined') {
						switch (req.body.action) {
							case "csvupdate": {
								// *** TODO:
								if (this.DEBUG) console.log("action:csvupdate");
								let table_to_update = req.body.table_name;
								let csv_data = new CSV(req.body.csv_data).parse();
								let num_keys = Number(req.body.num_keys);
								let key_columns = [];
								for (let i = 0; i < num_keys; i++) {
									key_columns.push(csv_data[0][i]);
								}
								let update_columns = [];
								let json_columns = [];
								for (let i = 0; i < csv_data[0].length; i++) {
									if (i >= num_keys) {
										update_columns.push(csv_data[0][i]);
										if (csv_data[0][i].indexOf(".") > 0) {
											json_columns.push(csv_data[0][i].substring(0, csv_data[0][i].indexOf(".")));
										}
									}
								}
								if (json_columns.length > 0) {
									json_columns = _.uniq(json_columns);
									for (let i = 0; i < json_columns.length; i++) {
										query = `UPDATE ${table_to_update} SET ${json_columns[i]} = "{}" WHERE ${json_columns[i]} IS NULL`;
										[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult));
										if (err) {
											res.send({
												success: false,
												err: err
											});
											return;
										}
									}
								}
								for (let i = 1; i < csv_data.length; i++) {
									let sql_data = "";
									let sql_keys = "";
									for (let j = 0; j < csv_data[1].length; j++) {
										if (j < num_keys) {
											if (j > 0) {
												sql_keys += " AND ";
											}
											sql_keys += `${key_columns[j]} = "${csv_data[i][j]}"`;
										}
										if (j >= num_keys) {
											if (j > num_keys) {
												sql_data += ", ";
											}
											if (csv_data[0][j].indexOf(".") > 0) {
												let jkeys = _.split(csv_data[0][j], ".");
												//let column = csv_data[0][j].substring(0,csv_data[0][j].indexOf("."));
												let column = jkeys[0];
												sql_data += `${column} = JSON_SET(${column},`;
												let parents = "";
												if (jkeys.length > 2) {
													for (let sk = 1; sk < jkeys.length - 1; sk++) {
														sql_data += `"$.${parents}${jkeys[sk]}", IFNULL(${column}->"$.${parents}${jkeys[sk]}",JSON_OBJECT())), ${column} = JSON_SET(${column},`;
														parents += `${jkeys[sk]}.`;
													}
												}
												//let jkey = csv_data[0][j].substring(csv_data[0][j].indexOf("."),csv_data[0][j].length);
												let jkey = jkeys[jkeys.length - 1];
												// sql_data += `${column} = JSON_SET(${column},"$${jkey}","${csv_data[i][j]}")`;
												sql_data += `"$.${parents}${jkey}",${mysql.escape(csv_data[i][j])})`;
											} else {
												sql_data += `${csv_data[0][j]} = ${mysql.escape(csv_data[i][j])}`;
											}
										}

									}
									query = `UPDATE ${table_to_update} SET ${sql_data} WHERE ${sql_keys}`;
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult));
									if (err) {
										res.send({
											success: false,
											err: err
										});
										break;
									}
								}
								res.send(result);
								break;
							} // case csvupdate
							case "createsub": {
								break;
							} // case createsub
							case "removedoorfromsub": {
								// *** TODO: Evaluate results for errors and report
								query = "DELETE FROM subscriber_doors WHERE subscriber_id = '" + req.body.subscriber_id + "' AND elem_id = '" + req.body.product_id + "' AND series_code = '" + req.body.series_code + "'";
								result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
								res.send({
									status: "success",
									success: true
								});
								break;
							} // case removedoorfromsub
							case "removewindowfromsub": {
								// *** TODO: Evaluate results for errors and report
								query = "DELETE FROM subscriber_windows WHERE subscriber_id = '" + req.body.subscriber_id + "' AND elem_id = '" + req.body.product_id + "' AND series_code = '" + req.body.series_code + "'";
								result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
								res.send({
									status: "success",
									success: true
								});
								break;
							} // case removewindowfromsub
							case "updatesubinfo": {
								// *** TODO: Sanitize posted data
								let fieldName = req.body.fieldname;
								let value = req.body.value;
								query = "UPDATE subscribers SET ? WHERE subscriber_id = '" + req.body.subscriber_id + "'";
								let updateData = {};
								updateData[fieldName] = value;
								query = mysql.format(query, updateData);
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult));
								if (err) {
									res.send({
										status: "error",
										success: false,
										err: err
									});
									return;
								}
								res.send({
									status: "success",
									success: true
								});
								break;
							} // case updatesubinfo
							case "deletesub": {
								if (this.DEBUG) {
									console.log("case:deletesub");
								}
								pset = false;
								[err, result] = await to(this.DeleteSubscriber(req.body.currentid));
								if (err) {
									res.status(500).send({
										success: false,
										status: "error",
										err: err
									});
									return;
								}
								res.send(result);
								break;
							} // case deletesub
							case "renamesubid": {
								// *** TODO: need to add cleaning of form data for security
								// *** TODO: add check for error for existing new name  ( Probably using try catch )
								if (this.DEBUG) console.log("start: admin:renamesubid");
								let rename_sid = req.body.sourceid;
								let rename_newid = req.body.newid;
								query = "UPDATE subscribers SET subscriber_id = '" + rename_newid + "' WHERE subscriber_id = '" + rename_sid + "'";
								result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
								query = "UPDATE subscriber_locations SET subscriber_id = '" + rename_newid + "' WHERE subscriber_id = '" + rename_sid + "'";
								result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
								query = "SELECT * FROM admin_data WHERE datakey = 'subidtables'";
								rowdata = await this.dbfunc.P_GetQueryData(query, this.ParseAdminDataRowData);
								let subscriber_tables = JSON.parse(rowdata)[0].data.subscriber_tables;
								// current_subscriber_table = 0;
								for (let subscriber_table of subscriber_tables) {
									query = "update " + subscriber_table + " SET subscriber_id = '" + rename_newid + "' WHERE subscriber_id = '" + rename_sid + "'";
									let [err, result] = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
									if (err) {
										this.logger.error(`app_admin.js:/adminui case: renamesubid -- Error changing subscriber_id: ${err}`);
									}
								}
								res.send({
									status: "success",
									success: true
								});
								break;
							} // case renamesubid
							case "deletesubbuildingid": {
								if (this.DEBUG) {
									console.log("start: admin:deletesubbuildingid");
								}
								query = "SELECT * FROM admin_data WHERE datakey = 'subidtables'";
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseAdminDataRowData));
								let tables = JSON.parse(result)[0].data;
								let transaction_connection;
								deletesubbuildingtransaction: {
									[err, transaction_connection] = await to(this.tcon.getConnection());
									if (err) {
										// TODO: handle error
									}
									query = "START TRANSACTION";
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
									if (err) {
										break deletesubbuildingtransaction;
									}
									for (let i = 0; i < tables.building_id_tables.length; i++) {
										if (this.DEBUG) {
											console.log("Deleting: ", req.body.building_id, " from ", tables.building_id_tables[i].table);
										}
										query = `DELETE FROM ${tables.building_id_tables[i].table} WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND building_id = '${req.body.building_id}'`;
										[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
										if (err) {
											break deletesubbuildingtransaction;
										}
									}
									for (let i = 0; i < tables.product_id_tables.length; i++) {
										if (!tables.product_id_tables[i].withbuilding_id) {
											if (this.DEBUG) {
												console.log("Deleting: ", req.body.building_id, " from ", tables.product_id_tables[i].table);
											}
											query = `DELETE FROM ${tables.product_id_tables[i].table} WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND LEFT(${tables.product_id_tables[i].column},CHAR_LENGTH("${req.body.building_id}")) = "${req.body.building_id}"`;
											[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
											if (err) {
												break deletesubbuildingtransaction;
											}
										}
									}
								}
								if (err) {
									if (this.DEBUG) {
										console.log("Error: rolling back transaction.  err: ", err);
									}
									let errresult = err;
									query = "ROLLBACK";
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
									transaction_connection.release();
									res.send({
										success: false,
										status: "error",
										error: errresult
									});
									break;
								}
								if (this.DEBUG) {
									console.log("Delete successful ... Committing transaction...");
								}
								query = "COMMIT";
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
								transaction_connection.release();
								res.send(result);
								break;
							} // case deletesubbuildingid
							case "refreshtrialdata": {
								// *** TODO: Add error checking
								copySubscriberNewID = req.body.currentid;
								copySubscriberSourceID = req.body.dataid;
								result = await this.DeleteSubscriberBuildingData(req.body.currentid);
								result = await this.P_CopySubscriberData(req.body.sourceid, req.body.newid);
								res.send({
									status: "success",
									success: true
								});
								break;
							} // case refreshtrialdata
							case "copysubdata": {
								if (this.DEBUG) console.log("start: admin:copysubdata");
								// pset = true;
								[err, result] = await to(this.P_CopySubscriber(req.body.sourceid, req.body.newid));
								if (err) {
									console.error("App Error: copysubdata 1",err);
									res.sendStatus(500);
									return;
								}
								[err, result] = await to(this.P_CopySubscriberData(req.body.sourceid, req.body.newid));
								if (err) {
									console.error("App Error: copysubdata 2",err);
									res.sendStatus(500);
									return;
								}
								res.send(result);
								break;
							} // case copysubdata
							case "updateexp": {
								// Possible problem with errors -- if not completed may still return success ... this.DEBUG using invalid subscriber_id
								query = "UPDATE subscribers SET expiration=DATE_ADD(CURDATE(),INTERVAL " + req.body.weekstoadd + " WEEK) WHERE subscriber_id = '" + req.body.subscriber_id + "'";
								p = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
								p.then(data => {
									res.send(data);
								}).catch(err => {
									console.log("Location: app_admin.js:651, App Error: ", err);
									res.sendStatus(500);
								});
								break;
							} // updateexp
							case "updateprice": {
								if (req.body.category_id.length > 0) {
									req.body.price = Dbfunc.CleanInputData(req.body.price, "");
									req.body.std_options_price = Dbfunc.CleanInputData(req.body.std_options_price);
									let updateData = {};
									updateData.price = req.body.price;
									updateData.std_options_price = req.body.std_options_price;
									query = "SELECT * from subscriber_siding_price WHERE subscriber_id = '" + req.body.subscriber_id + "' AND building_product_id = '" + req.body.product_id + "' AND series_code = '" + req.body.series_code + "' AND siding_category_id = '" + req.body.category_id + "'";
									p2 = this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
									p2.then(data => {
										// res.send(data);
										if (this.DEBUG) console.log(data);
										if (data.length < 3) {
											let insertData = {};
											insertData.subscriber_id = req.body.subscriber_id;
											insertData.building_product_id = req.body.product_id;
											insertData.series_code = req.body.series_code;
											insertData.siding_category_id = req.body.category_id;
											insertData.price = req.body.price;
											insertData.std_options_price = req.body.std_options_price;
											query = "INSERT INTO subscriber_siding_price SET ?";
											let pquery = mysql.format(query, [insertData]);
											p = this.dbfunc.P_GetQueryData(pquery, this.ParseMySqlRowData, this.MySQLActionResult);
											p.then(data => {
												res.send(data);
											}).catch(err => {
												console.log("Location: app_admin.js:682, App Error: ", err);
												res.sendStatus(500);
											});
										} else {
											query = "UPDATE subscriber_siding_price SET ? WHERE subscriber_id = '" + req.body.subscriber_id + "' AND building_product_id = '" + req.body.product_id + "' AND series_code = '" + req.body.series_code + "' AND siding_category_id = '" + req.body.category_id + "'";
											let pquery = mysql.format(query, [updateData]);
											p = this.dbfunc.P_GetQueryData(pquery, this.ParseMySqlRowData, this.MySQLActionResult);
											p.then(data => {
												res.send(data);
											}).catch(err => {
												console.log("Location: app_admin.js:691, App Error: ", err);
												res.sendStatus(500);
											});
										}
									}).catch(err => {
										console.log("Location: app_admin.js:696, App Error: ", err);
										res.sendStatus(500);
									});
								} else {
									pset = true;
									req.body.price = Dbfunc.CleanInputData(req.body.price, "");
									req.body.base_std_options_price = Dbfunc.CleanInputData(req.body.base_std_options_price, "");
									let updateData = {};
									updateData.price = req.body.price;
									updateData.base_std_options_price = req.body.base_std_options_price;
									query = "UPDATE subscriber_buildings_sizes SET ? WHERE subscriber_id = '" + req.body.subscriber_id + "' AND product_id = '" + req.body.product_id + "' AND series_code = '" + req.body.series_code + "'";
									let pquery = mysql.format(query, [updateData]);
									p = this.dbfunc.P_GetQueryData(pquery, this.ParseMySqlRowData, this.MySQLActionResult);
								}
								break;
							} // updateprice
							case "deletesubsidingtype": {
								if (this.DEBUG) console.log("adminui:deletesubsidingtype");
								deletesubsidingtypetransaction: {
									query = `DELETE FROM subscriber_siding_categories WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND category_id = '${req.body.siding_id}'`;
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult));
									if (err) {
										break deletesubsidingtypetransaction;
									}
									query = `DELETE FROM subscriber_siding_colors WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND category_id = '${req.body.siding_id}'`;
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult));
									if (err) {
										break deletesubsidingtypetransaction;
									}
									query = `DELETE FROM subscriber_siding_price WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND siding_category_id = '${req.body.siding_id}'`;
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult));
									if (err) {
										break deletesubsidingtypetransaction;
									}
									query = `DELETE FROM subscriber_siding_dimensions_price WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND siding_category_id = '${req.body.siding_id}'`;
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult));
								} // deletesubsidingtypetransaction
								if (err) {
									if (this.DEBUG) {
										console.log("Error: rolling back transaction.  err: ", err);
									}
									let errresult = err;
									query = "ROLLBACK";
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult));
									res.send({
										success: false,
										status: "error",
										error: errresult
									});
									break;
								}
								if (this.DEBUG) {
									console.log("Delete successful ... Committing transaction...");
								}
								query = "COMMIT";
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult));
								res.send(result);
								break;
							} // case deletesubsidingtype
							case "addbuildingsize": {
								if (this.DEBUG) console.log("adminui:addbuildingsize");
								let defaults = {};
								// *** TODO: Evaluate and clean up this code
								// *** TODO: predefined query for security
								let product_id = "";
								// check to see if duplicate entry
								query = `SELECT * FROM subscriber_buildings_sizes WHERE subscriber_id = '${req.body.subscriber_id}' AND product_id LIKE '%${req.body.building_id}-${req.body.width}x${req.body.length}%' AND series_code = '${req.body.series_code}'`;
								result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
								if (result.length > 2) {
									res.send({
										status: "failed",
										success: false,
										reasoncode: "DR1",
										reason: "Size Already Exists"
									});
									break;
								}
								// Get default settings from subscriber_buildings_sizes_defaults
								query = `SELECT * FROM subscriber_buildings_sizes_defaults WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND building_id = '${req.body.building_id}' AND width_display = '${req.body.width}'`;
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData));
								if (err) {
									res.send({
										status: "failed",
										success: false,
										reasoncode: "ERR",
										reason: err
									});
									break;
								}
								if (result.length < 3) {
									// subscriber default doesn't exist, try to pull from system default

									query = `SELECT * FROM buildings_sizes_defaults WHERE building_id = '${req.body.building_id}' AND width_display = '${req.body.width}' AND length_display = '${req.body.length}'`;
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData));
									if (result.length < 3) {
										// add size in system sizes if doesn't exist
										query = `SELECT * FROM buildings_sizes_defaults WHERE building_id = '${req.body.building_id}' AND width_display = '${req.body.width}'`;
										[err,result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData));
										if (err) {
											res.send({
												status: "fail",
												success: false,
												err: err
											});
											break;
										}
										if (result.length < 3) {
											/*res.send({
												status: "failed",
												success: false,
												reasoncode: "ND1",
												reason: "Width Class does not exist. Please add width class first."
											});
											break;*/
											query = `SELECT * FROM subscriber_buildings_sizes WHERE building_id = '${req.body.building_id}' AND width_display = '${req.body.width}' LIMIT 1`;
											[err,result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData));
											if (result.length < 3) {
												res.send({
													status: "failed",
													success: false,
													reasoncode: "ND1",
													reason: "Width Class does not exist. Please add width class first."
												});
												break;
											}
											let row = JSON.parse(result)[0];
											product_id = row.building_id + "-" + req.body.width + "x" + req.body.length;
										} else {
											rowdata = JSON.parse(result);
											let row = rowdata[0];
											delete row.id;
											// query = "INSERT INTO buildings_sizes ("+ this.dbfunc.sqlcolumnsFromRow(row) +") VALUES ?";
											query = "INSERT INTO buildings_sizes_defaults SET ?";
											row.product_id = row.building_id + "-" + req.body.width + "x" + req.body.length;
											product_id = row.product_id;
											row.width = req.body.width;
											row.length = req.body.length;
											row.width_display = req.body.width;
											row.length_display = req.body.length;
											// row = [row];
											let pquery = mysql.format(query, [row]);
											if (this.DEBUG) console.log(pquery);
											//result = await this.dbfunc.P_GetQueryData2(query,this.dbfunc.rowObjToArray(row),null,this.MySQLActionResult);
											[err, result] = await to(this.dbfunc.P_GetQueryData(pquery, null, this.MySQLActionResult));
										}
									} else {
										rowdata = JSON.parse(result);
										product_id = rowdata[0].product_id;
									}
								} else {
									// set defaults from subscriber_building_sizes_defaults
									defaults = JSON.parse(result);
									product_id = defaults[0].building_id + "-" + req.body.width + "x" + req.body.length;
								}
								// check width
								query = `SELECT * FROM subscriber_buildings_sizes WHERE subscriber_id = '${req.body.subscriber_id}' AND product_id LIKE '%${req.body.building_id}-${req.body.width}x%' AND series_code = '${req.body.series_code}' LIMIT 1`;
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData));
								if (result.length > 2) {
									// if existing data
									rowdata = JSON.parse(result);
									let row = rowdata[0];
									delete row.id;
									row.product_id = row.building_id + "-" + req.body.width + "x" + req.body.length;
									row.length = req.body.length;
									row.length_display = req.body.length;
									row.size_options = JSON.stringify(row.size_options);
									row.price = "0";
									// query = "INSERT INTO subscriber_buildings_sizes ("+ this.dbfunc.sqlcolumnsFromRow(row) +") VALUES ?";
									query = "INSERT INTO subscriber_buildings_sizes SET ?";
									let pquery = mysql.format(query, [row]);
									// row = [row];
									if (this.DEBUG) console.log(pquery);
									// result = await this.dbfunc.P_GetQueryData2(query,this.dbfunc.rowObjToArray(row),null,this.MySQLActionResult);
									//[err,result] = await to(this.dbfunc.P_GetQueryData2(query,row,null,this.MySQLActionResult));
									[err, result] = await to(this.dbfunc.P_GetQueryData(pquery, null, this.MySQLActionResult));
									if (err) {
										res.send({
											status: "fail",
											success: false,
											err: err
										});
										break;
									}
								} else {
									// if no existing data
									let row = {};
									row.subscriber_id = req.body.subscriber_id;
									row.series_code = req.body.series_code;
									row.product_id = product_id;
									row.price = "0";
									row.base_std_options_price = "0";
									row.size_options = "{}";
									// row.building_display_name = "";
									// query = "INSERT INTO subscriber_buildings_sizes ("+ this.dbfunc.sqlcolumnsFromRow(row) +") VALUES ?";
									query = "INSERT INTO subscriber_buildings_sizes SET ?";
									let pquery = mysql.format(query, [row]);
									// row = [row];
									if (this.DEBUG) console.log(pquery);
									//result = await this.dbfunc.P_GetQueryData2(query,this.dbfunc.rowObjToArray(row),null,this.MySQLActionResult);
									[err, result] = await to(this.dbfunc.P_GetQueryData(pquery, null, this.MySQLActionResult));
									if (err) {
										res.send({
											status: "fail",
											success: false,
											err: err
										});
										break;
									}
								}
								res.send({
									status: "success",
									success: true
								});
								break;
							} // case addbuildingsize
							case "deletesubbuildingsize": {
								// *** TODO: Add error checking
								if (this.DEBUG) console.log("adminui:deletesubbuildingsize");
								query = "DELETE FROM subscriber_buildings_sizes WHERE subscriber_id = '" + req.body.subscriber_id + "' AND product_id = '" + req.body.product_id + "' AND series_code = '" + req.body.series_code + "'";
								result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
								query = "DELETE FROM subscriber_siding_price WHERE subscriber_id = '" + req.body.subscriber_id + "' AND building_product_id = '" + req.body.product_id + "' AND series_code = '" + req.body.series_code + "'";
								result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
								res.send({
									status: "success",
									success: true,
									product_id: req.body.product_id
								});
								break;
							} // case deletesubbuildingsize
							case "updatesubscriberinfo": {
								break;
							} // case updatesubscriberinfo
							case "renamesubbuildingid": {
								// TODO: check for errors and handle
								query = `SELECT * FROM subscriber_buildings WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND building_id = '${req.body.new_building_id}'`;
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData));
								if (result.length > 2) {
									res.send({
										success: false,
										status: "error",
										error: "new name already exists"
									});
									return;
								}
								query = "SELECT * FROM admin_data WHERE datakey = 'subidtables'";
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseAdminDataRowData));
								let tables = JSON.parse(result)[0].data;
								for (let i = 0; i < tables.building_id_tables.length; i++) {
									query = `UPDATE ${tables.building_id_tables[i].table} SET building_id='${req.body.new_building_id}' WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND building_id = '${req.body.building_id}'`;
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult));
								}
								for (let i = 0; i < tables.product_id_tables.length; i++) {
									query = `UPDATE ${tables.product_id_tables[i].table} SET ${tables.product_id_tables[i].column}=CONCAT("${req.body.new_building_id}",RIGHT(${tables.product_id_tables[i].column},CHAR_LENGTH(${tables.product_id_tables[i].column})-CHAR_LENGTH("${req.body.building_id}"))) WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND LEFT(${tables.product_id_tables[i].column},CHAR_LENGTH("${req.body.building_id}")) = "${req.body.building_id}"`;
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult));
								}
								res.send(result);
								break;
							} // case renamesubbuildingid
							case "updateseriesobject": {
								switch (req.body.objectaction) {
									case "add": {
										switch (req.body.objecttype) {
											case "door": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:door");
												currentTableName = "subscriber_doors";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case door
											case "hinge": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:hinge");
												currentTableName = "subscriber_hinges";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case hinge
											case "roofingtype": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:roofingtype");
												currentTableName = "subscriber_roofing_categories";
												elem_id_field = "category_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case roofing type
											case "roofingcolor": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:roofingcolor");
												currentTableName = "subscriber_roofing";
												elem_id_field = "roofing_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case roofingcolor
											case "sidingtype": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:sidingtype");
												currentTableName = "subscriber_siding_categories";
												elem_id_field = "category_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case sidingtype
											case "sidingcolor": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:sidingcolor");
												currentTableName = "subscriber_siding_colors";
												elem_id_field = "siding_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case sidingcolor
											case "window": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:window");
												currentTableName = "subscriber_windows";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case window
											case "option": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:option");
												currentTableName = "subscriber_options";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case option
											case "shelf": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:shelf");
												currentTableName = "subscriber_shelves";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case shelf
											case "dormer": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:dormer");
												currentTableName = "subscriber_dormers";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case dormer
											case "ramp": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:ramp");
												currentTableName = "subscriber_ramps";
												elem_id_field = "ramp_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case ramp
											case "trimcolor": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:trimcolor");
												currentTableName = "subscriber_trim_colors";
												elem_id_field = "color_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case trimcolor
											case "doorcolor": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:add:doorcolor");
												currentTableName = "subscriber_door_colors";
												let door_id = req.body.objectid.substring(0, req.body.objectid.indexOf(":"));
												let color_id = req.body.objectid.substring(req.body.objectid.indexOf(":") + 1, req.body.objectid.length);
												req.body.objectid = color_id;
												elem_id_field = "door_id = '" + door_id + "' AND color_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=1 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' LIMIT 1";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
													let row = {};
													row = JSON.parse(result);
													delete row[0].id;
													row[0].active = 1;
													row[0].series_code = req.body.series_code;

													query = "INSERT INTO " + currentTableName + " SET ?";
													result = await this.dbfunc.P_GetQueryData2(query, row[0], null, this.MySQLActionResult);
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case doorcolor
										} // switch (req.body.objecttype)
										break;
									} // case add
									case "remove": {
										switch (req.body.objecttype) {
											case "door": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case door
											case "hinge": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case hinge
											case "roofingtype": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case roofingtype
											case "roofingcolor": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case roofingcolor
											case "sidingtype": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case sidingtype
											case "sidingcolor": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case sidingcolor
											case "window": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case window
											case "option": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case option
											case "shelf": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case shelf
											case "dormer": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case dormer
											case "ramp": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case ramp
											case "trimcolor": {
												res.send({
													success: false,
													status: "failed"
												});
												break;
											} // case trimcolor
										} // switch (req.body.objecttype)
										break;
									} // case remove
									case "deactivate": {
										switch (req.body.objecttype) {
											case "door": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:door");
												currentTableName = "subscriber_doors";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case door
											case "hinge": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:hinge");
												currentTableName = "subscriber_hinges";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case hinge
											case "roofingtype": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:roofingtype");
												currentTableName = "subscriber_roofing_categories";
												elem_id_field = "category_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case roofingtype
											case "roofingcolor": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:roofingcolor");
												currentTableName = "subscriber_roofing";
												elem_id_field = "roofing_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case roofingcolor
											case "sidingtype": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:sidingtype");
												currentTableName = "subscriber_siding_categories";
												elem_id_field = "category_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case sidingtype
											case "sidingcolor": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:sidingcolor");
												currentTableName = "subscriber_siding_colors";
												elem_id_field = "siding_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case sidingcolor
											case "window": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:window");
												currentTableName = "subscriber_windows";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case window
											case "option": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:option");
												currentTableName = "subscriber_options";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case option
											case "shelf": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:shelf");
												currentTableName = "subscriber_shelves";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case shelf
											case "dormer": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:dormer");
												currentTableName = "subscriber_dormers";
												elem_id_field = "elem_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case dormer
											case "ramp": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:ramp");
												currentTableName = "subscriber_ramps";
												elem_id_field = "ramp_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case ramp
											case "trimcolor": {
												if (this.DEBUG) console.log("adminui:action:updateseriesobject:deactivate:trimcolor");
												currentTableName = "subscriber_trim_colors";
												elem_id_field = "color_id";
												query = "SELECT * FROM " + currentTableName + " WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
												result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData);
												if (result.length > 2) {
													query = "UPDATE " + currentTableName + " set active=0 WHERE subscriber_id = '" + req.body.subscriber_id + "' AND " + elem_id_field + " = '" + req.body.objectid + "' AND series_code = '" + req.body.series_code + "'";
													result = await this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult);
												} else {
													if (this.DEBUG) console.log("element does not exist to deactivate.");
												}
												res.send({
													success: true,
													status: "success"
												});
												break;
											} // case trimcolor
										} // switch (req.body.objecttype)
										break;
									} // case deactivate
								} // switch (req.body.objectaction)
								break;
							} // case "updateseriesobject"
							case "copysubroofing": {
								this.logger.debug("copyroofing");
								// req.body.sourceid, req.body.newid
								// req.body.source_series, req.body.new_series
								// req.body.category_id
								// tables: subscriber_roofing, subscriber_roofing_categories
								query = `SELECT * FROM subscriber_roofing WHERE subscriber_id = '${req.body.sourceid}' AND series_code = '${req.body.source_series}' AND roofing_id LIKE '%${req.body.category_id}_%'`;
								[err, data] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData));
								if (err) {
									res.send({
										success: false,
										err: err
									});
									break;
								}
								let roofing_data = data;
								query = `SELECT * FROM subscriber_roofing_categories WHERE subscriber_id = '${req.body.sourceid}' AND series_code = '${req.body.source_series}' AND category_id = '${req.body.category_id}'`;
								[err, data] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData));
								if (err) {
									res.send({
										success: false,
										err: err
									});
									break;
								}
								let roofing_categories_data = data;
								let roofing_prepped_data = this.prepDataForNewSubscriberandSeries(roofing_data, req.body.newid, req.body.new_series);
								let roofing_categories_prepped_data = this.prepDataForNewSubscriberandSeries(roofing_categories_data, req.body.newid, req.body.new_series);
								query = `INSERT INTO subscriber_roofing (${roofing_prepped_data.sqlcolumns}) VALUES ?`;
								let pquery = mysql.format(query, [roofing_prepped_data.NewDataArr]);
								[err, insertResult] = await to(this.dbfunc.P_GetQueryData(pquery, null, this.MySQLActionResult));
								if (err) {
									res.send({
										success: false,
										err: err
									});
									break;
								}
								query = `INSERT INTO subscriber_roofing_categories (${roofing_categories_prepped_data.sqlcolumns}) VALUES ?`;
								pquery = mysql.format(query, [roofing_categories_prepped_data.NewDataArr]);
								[err, insertResult] = await to(this.dbfunc.P_GetQueryData(pquery, null, this.MySQLActionResult));
								if (err) {
									res.send({
										success: false,
										err: err
									});
									break;
								}
								res.send({
									success: true
								});
								break;
							} // case copysubroofing
							case "deletesubroofingcategory": {
								if (this.DEBUG) console.log("adminui:case:deletesubroofingcategory");
								// Todo -- copy data into backup table before deleting -- use undo table -- or other general purpose temporary storage
								query = `DELETE FROM subscriber_roofing WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND roofing_id LIKE '%${req.body.category_id}_%'`;
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult));
								if (err) {
									res.send({
										success: false,
										err: err
									});
									break;
								}
								query = `DELETE FROM subscriber_roofing_categories WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND category_id = '${req.body.category_id}'`;
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult));
								if (err) {
									res.send({
										success: false,
										err: err
									});
									break;
								}
								res.send({
									success: true
								});
								break;
							} // case deletesubroofing
							case "copysubbuilding": {
								if (this.DEBUG) console.log("adminui:case:copysubbuilding");
								query = `SELECT * FROM subscriber_buildings WHERE subscriber_id='${req.body.new_subscriber_id}' AND series_code='${req.body.new_series_code}' AND building_id = '${req.body.new_building_id}'`;
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData));
								if (result.length > 2) {
									res.send({
										success: false,
										status: "error",
										error: "new name already exists"
									});
									return;
								}
								query = "SELECT * FROM admin_data WHERE datakey = 'subidtables'";
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseAdminDataRowData));
								let tables = JSON.parse(result)[0].data;
								let transaction_connection;
								copysubbuildingtransaction: {
									[err, transaction_connection] = await to(this.tcon.getConnection());
									if (err) {
										// TODO: handle error
									}
									query = "START TRANSACTION";
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
									if (err) {
										break copysubbuildingtransaction;
									}
									for (let i = 0; i < tables.building_id_tables.length; i++) {
										let tabledata;
										query = `SELECT * FROM ${tables.building_id_tables[i].table} WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND building_id = '${req.body.building_id}'`;
										[err, tabledata] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowDataObj, this.P_ParseMySqlRowsDataObj));
										if (err) {
											break copysubbuildingtransaction;
										}
										if (tabledata.length > 0) {
											for (let i2 = 0; i2 < tabledata.length; i2++) {
												delete tabledata[i2].id;
												tabledata[i2].subscriber_id = req.body.new_subscriber_id;
												tabledata[i2].series_code = req.body.new_series_code;
												tabledata[i2].building_id = req.body.new_building_id;
												if (tables.building_id_tables[i].withproduct_id) {
													tabledata[i2].product_id = tabledata[i2].product_id.replace(req.body.building_id, req.body.new_building_id);
												}
											}

											query = `INSERT INTO ${tables.building_id_tables[i].table} (${this.dbfunc.sqlcolumnsFromRow(tabledata[0])}) VALUES ?`;
											query = mysql.format(query, [this.dbfunc.prepObjectArrayforMySQL(this.dbfunc.rowObjToArray(tabledata))]);
											[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
											if (err) {
												break copysubbuildingtransaction;
											}
										}
									}
									for (let i = 0; i < tables.product_id_tables.length; i++) {
										if (!tables.product_id_tables[i].withbuilding_id) {
											query = `SELECT * FROM ${tables.product_id_tables[i].table} WHERE subscriber_id = '${req.body.subscriber_id}' AND series_code = '${req.body.series_code}' AND LEFT(${tables.product_id_tables[i].column},CHAR_LENGTH("${req.body.building_id}")) = "${req.body.building_id}"`;
											//if(i==4) {this.DEBUGger;}
											[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowDataObj, this.P_ParseMySqlRowsDataObj));
											if (err) {
												break copysubbuildingtransaction;
											}
											if (result.length > 0) {
												for (let i2 = 0; i2 < result.length; i2++) {
													delete result[i2].id;
													result[i2].subscriber_id = req.body.new_subscriber_id;
													result[i2].series_code = req.body.new_series_code;
													result[i2][tables.product_id_tables[i].column] = result[i2][tables.product_id_tables[i].column].replace(req.body.building_id, req.body.new_building_id);
												}

												query = `INSERT INTO ${tables.product_id_tables[i].table} (${this.dbfunc.sqlcolumnsFromRow(result[0])}) VALUES ?`;
												query = mysql.format(query, [this.dbfunc.prepObjectArrayforMySQL(this.dbfunc.rowObjToArray(result))]);
												[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
												if (err) {
													break copysubbuildingtransaction;
												}
											}
										}
									}
								}
								if (err) {
									if (this.DEBUG) {
										console.log("Error: rolling back transaction.  err: ", err);
									}
									let errresult = err;
									query = "ROLLBACK";
									[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
									transaction_connection.release();
									res.send({
										success: false,
										status: "error",
										error: errresult
									});
									break;
								}
								if (this.DEBUG) {
									console.log("Copy successful ... Committing transaction...");
								}
								query = "COMMIT";
								[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
								transaction_connection.release();
								res.send(result);
							} // case copysubbuilding
						} // switch req.body.action
						if (pset)
							p.then(data => {
								res.send(data);
							}).catch(err => {
								console.log("Location: app_admin.js:720, App Error: ", err);
								res.sendStatus(500);
							});
					} else {
						res.render('pages/admin-menu');
					}
				} else {
					if (req.body.interface && req.body.interface === "admin") {
						res.sendFile(path.join(rootdir + '/admin_files/loginform.html'));
						return;
					}
					if (this.DEBUG) console.log("Post - Userdata Defined - Admin Login");
					res.status(401).send("401: Unauthorized content request.");
					return;
					// res.sendFile(path.join(rootdir + '/admin_files/loginform.html'));
				}
			} else {
				if (this.DEBUG) console.log("Post - Userdata Not Defined - Admin Login");
				res.sendFile(path.join(rootdir + '/admin_files/loginform.html'));
			}
		});
	}

	async action(req) {
		let err;
		let result = {};
		switch (req.body.request) {
			case "update3DObject": {
				[err, result] = await to(update3DObject(req));
				break;
			}
			default: {
				err = {
					message: "invalid request"
				};
			}
		}
		if (err) {
			throw err;
		}
		return result;
	}

	ParseAdminDataRowData(rowData) {
		if (this.DEBUG) console.log("ParseAdminDataRowData");
		let AdminData;
		try {
			if (typeof rowData.data === "string") {
				AdminData = JSON.parse(rowData.data);
			} else {
				AdminData = rowData.data;
			}
		} catch (error) {
			AdminData = {
				error: "Error parsing JSON data from database (ParseAdminDataRowData)"
			};
		}
		let AdminDataKey = rowData.datakey;
		let AdminRowID = rowData.id;
		let data = {
			id: AdminRowID,
			datakey: AdminDataKey,
			data: AdminData
		};
		// return JSON.stringify(rowData);
		return JSON.stringify(data);
	}

	async DeleteSubscriber(actionSubscriberId) {

		let err, result, query, transaction_connection;
		if (this.DEBUG) console.log("DeleteSubscriber");
		DeleteSubscriberTransaction: {
			[err, transaction_connection] = await to(this.tcon.getConnection());
			if (err) {
				// TODO: handle error
			}
			query = "START TRANSACTION";
			[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
			if (err) {
				break DeleteSubscriberTransaction;
			}
			query = `DELETE FROM subscribers WHERE subscriber_id = '${actionSubscriberId}'`;
			[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult, transaction_connection));
			if (err) {
				break DeleteSubscriberTransaction;
			}
			query = `DELETE FROM subscriber_locations WHERE subscriber_id = '${actionSubscriberId}'`;
			[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult, transaction_connection));
			if (err) {
				break DeleteSubscriberTransaction;
			}
			[err, result] = await to(this.DeleteSubscriberBuildingData(actionSubscriberId, transaction_connection));
			if (err) {
				break DeleteSubscriberTransaction;
			}
		}
		if (err) {
			if (this.DEBUG) {
				console.log("Error: rolling back transaction.  err: ", err);
			}
			let errresult = err;
			query = "ROLLBACK";
			[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
			transaction_connection.release();
			throw errresult;
		}
		if (this.DEBUG) {
			console.log("Delete successful ... Committing transaction...");
		}
		query = "COMMIT";
		[err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult, transaction_connection));
		transaction_connection.release();
		if (err) {
			throw err;
		}
		return result;
	}

	async DeleteSubscriberBuildingData (actionSubscriberId, transaction_connection) {
		if (this.DEBUG) console.log("DeleteSubscriberBuildingData");
		if (!transaction_connection) {
			transaction_connection = null;
		}
		let query, err, result;
		let dataDeleteSubscriberID = actionSubscriberId;
		// DeleteSubscriberBuildingDataGetTableList();
		query = "SELECT * FROM admin_data WHERE datakey = 'subidtables'";
		[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseAdminDataRowData, null, transaction_connection));
		if (err) {
			throw err;
		}

		if (this.DEBUG) console.log("Deleting Subscriber Data: ", dataDeleteSubscriberID);
		let subscriber_tables = JSON.parse(result)[0].data.subscriber_tables;

		query = "";
		for (let i = 0; i < subscriber_tables.length; i += 1) {
			query += "DELETE FROM " + subscriber_tables[i] + " WHERE subscriber_id = '" + dataDeleteSubscriberID + "';";
		}
		[err, result] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult, transaction_connection));
		if (err) {
			throw err;
		}
		return result;

	};

	convertSubscriberLocationData(rowsData, copySubscriberNewID) {
		if (rowsData.length > 0) {
			let NewDataArr = [];
			let row = [];
			let NewData = JSON.parse(rowsData);
			let CopyColumns = NewData[0];
			delete CopyColumns.id;
			let columns = Object.keys(NewData[0]);

			for (let i = 0; i < NewData.length; i += 1) {
				NewData[i].subscriber_id = copySubscriberNewID;
				delete NewData[i].id;
				row = [];
				for (let i2 = 0; i2 < columns.length; i2 += 1) {
					row[i2] = NewData[i][columns[i2]];
				}
				NewDataArr.push(row);
			}

			columns = Object.keys(NewData[0]);

			let sqlcolumns = "";

			for (i = 0; i < columns.length; i += 1) {
				if (i > 0) sqlcolumns += ",";
				sqlcolumns += columns[i];
			}
			return {
				success: true,
				NewDataArr: NewDataArr,
				sqlcolumns: sqlcolumns
			};
		} else
			return {
				success: false
			};
	}

	async P_CopySubscriber(sourceID, newID) {
		let query, newSubscriberData, NewLocationData, err, data;
		query = "SELECT * FROM subscribers WHERE subscriber_id = ?";
		query = mysql.format(query,[newID]);
		[err, data] = await to(this.P_GetQueryData(query, this.ParseMySqlRowData));
		if (err) {
			throw err;
		}
		if (data.length <= 2) {
			query = "SELECT * FROM subscribers WHERE subscriber_id = ?";
			query = mysql.format(query,[sourceID]);
			[err, data] = await to(this.P_GetQueryData(query, this.ParseMySqlRowData));
			if (err) {
				throw err;
			}
			newSubscriberData = JSON.parse(data)[0];
			if (typeof newSubscriberData.data === "object") {
				newSubscriberData.data = JSON.stringify(newSubscriberData.data);
			}
			newSubscriberData.subscriber_id = newID;
			newSubscriberData.expiration = newSubscriberData.expiration.substr(0, 10);
			query = "INSERT INTO subscribers SET ?";
			query = mysql.format(query, newSubscriberData);
			[err, data] = await to(this.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult));
			if (err) {
				throw err;
			}
			if (!data.success) {
				throw "Create Subscriber Failed EC1";
			}
			query = "SELECT * FROM subscriber_locations WHERE subscriber_id = '" + sourceID + "'";
			[err, data] = await to(this.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData));
			if (err) {
				throw err;
			}
			// NewLocationData = this.convertSubscriberLocationData(data,newID);
			// query = "INSERT INTO subscriber_locations(" + NewLocationData.sqlcolumns + ") VALUES ?";
			// p5 = this.dbfunc.P_GetQueryData2(query,NewLocationData.NewDataArr,this.ParseMySqlRowData,this.MySQLActionResult);
			NewLocationData = JSON.parse(data)[0];
			delete NewLocationData.id;
			NewLocationData.subscriber_id = newID;
			query = "INSERT INTO subscriber_locations SET ?";
			query = mysql.format(query, NewLocationData);
			[err, data] = await to(this.P_GetQueryData(query, this.ParseMySqlRowData, this.MySQLActionResult));
			if (err) {
				throw err;
			}
			return data;
		} else {
			throw "Subscriber ID Already Exists.";
		}
	};

	prepDataForNewSubscriber(sourceData, newID) {
		if (this.DEBUG) console.log("prepDataForNewSubscriber");
		if (sourceData && sourceData.length > 2) {
			// if (this.DEBUG) console.log("Table: ",subscriber_tables[current_subscriber_table]);
			let NewDataArr = [];
			let row = [];
			// let NewData = JSON.parse(JSON.stringify(sourceData));
			let NewData = JSON.parse(sourceData);
			let CopyColumns = NewData[0];
			delete CopyColumns.id;
			let columns = Object.keys(NewData[0]);

			for (let i = 0; i < NewData.length; i += 1) {
				NewData[i].subscriber_id = newID;
				delete NewData[i].id;
				row = [];
				for (let i2 = 0; i2 < columns.length; i2 += 1) {
					row[i2] = NewData[i][columns[i2]];
				}
				NewDataArr.push(row);
			}

			columns = Object.keys(NewData[0]);

			let sqlcolumns = "";
			if (this.DEBUG) console.log(columns);

			for (let i = 0; i < columns.length; i += 1) {
				if (i > 0) sqlcolumns += ",";
				sqlcolumns += columns[i];
			}

			return {
				availableData: true,
				sqlcolumns: sqlcolumns,
				NewDataArr: NewDataArr
			};
			/*
			let query = "INSERT INTO " + subscriber_tables[current_subscriber_table] + "("+sqlcolumns+") VALUES ?";
			if (this.DEBUG) console.log(query);
			current_subscriber_table += 1;
			this.DEBUGQUERY = false;

			GetQueryData2(query,NewDataArr,null,CopySubscriberGetNextTable);
			*/
		} else {
			// if (this.DEBUG) console.log("Error: ",err);
			if (this.DEBUG) console.log("Table: No Subscriber Data.");
			return {
				availableData: false
			};
			/*
			current_subscriber_table += 1;
			CopySubscriberGetNextTable();
			*/
		}
	}

	prepDataForNewSubscriberandSeries(sourceData, newSID, newSeries) {
		if (this.DEBUG) console.log("preDataForNewSeries");
		if (sourceData && sourceData.length > 2) {
			// if (this.DEBUG) console.log("Table: ",subscriber_tables[current_subscriber_table]);
			let NewDataArr = [];
			let row = [];
			// let NewData = JSON.parse(JSON.stringify(sourceData));
			let NewData = JSON.parse(sourceData);
			let CopyColumns = NewData[0];
			delete CopyColumns.id;
			let columns = Object.keys(NewData[0]);

			for (let i = 0; i < NewData.length; i += 1) {
				NewData[i].subscriber_id = newSID;
				NewData[i].series_code = newSeries;
				delete NewData[i].id;
				row = [];
				for (let i2 = 0; i2 < columns.length; i2 += 1) {
					row[i2] = NewData[i][columns[i2]];
				}
				NewDataArr.push(row);
			}

			columns = Object.keys(NewData[0]);

			let sqlcolumns = "";
			if (this.DEBUG) console.log(columns);

			for (let i = 0; i < columns.length; i += 1) {
				if (i > 0) sqlcolumns += ",";
				sqlcolumns += columns[i];
			}

			return {
				availableData: true,
				sqlcolumns: sqlcolumns,
				NewDataArr: NewDataArr
			};
			/*
			let query = "INSERT INTO " + subscriber_tables[current_subscriber_table] + "("+sqlcolumns+") VALUES ?";
			if (this.DEBUG) console.log(query);
			current_subscriber_table += 1;
			this.DEBUGQUERY = false;

			GetQueryData2(query,NewDataArr,null,CopySubscriberGetNextTable);
			*/
		} else {
			if (this.DEBUG) console.log("Table: No Subscriber Data.");
			return {
				availableData: false
			};
		}
	}

	prepDataForNewSubscriber2(sourceData, newID) {
		console.this.DEBUG("prepDataForNewSubscriber2");
		if (sourceData && sourceData.length > 2) {
			let NewData = JSON.parse(sourceData);

			for (let i = 0; i < NewData.length; i += 1) {
				NewData[i].subscriber_id = newID;
				delete NewData[i].id;
			}

			return {
				availableData: true,
				rows: [NewData]
			};
		} else {
			console.this.DEBUG("Table: No Subscriber Data.");
			return {
				availableData: false
			};
		}
	}

	async P_CopySubscriberData (sourceID, newID) {
		let query = "SELECT * FROM admin_data WHERE datakey = 'subidtables'";
		let [err, rowdata] = await to(this.dbfunc.P_GetQueryData(query, this.ParseAdminDataRowData));
		if (err) {
			throw err;
		}
		let subscriber_tables;
		if (typeof rowdata === "string") {
			subscriber_tables = JSON.parse(rowdata)[0].data.subscriber_tables;
		} else {
			subscriber_tables = rowdata[0].data.subscriber_tables;
		}
		// current_subscriber_table = 0;
		for (let subscriber_table of subscriber_tables) {
			query = "select * from " + subscriber_table + " WHERE subscriber_id = '" + sourceID + "'";
			let [err, sourceData] = await to(this.dbfunc.P_GetQueryData(query, this.ParseMySqlRowData, this.P_ParseMySqlRowsData));
			if (err) {
				throw err;
			}
			let newData = this.prepDataForNewSubscriber(sourceData, newID);

			if (newData.availableData) {
				query = "INSERT INTO " + subscriber_table + " (" + newData.sqlcolumns + ") VALUES ?";
				query = mysql.format(query, this.dbfunc.prepObjectArrayforMySQL([newData.NewDataArr]));
				let [err, insertResult] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult));
				if (err) {
					console.error(`app_admin.js:fn:P_CopysubscriberData ERROR inserting data: ${err}`);
				}
			}
		}
		return {
			status: "success",
			success: true
		};

	}

	async update3DObject(req) {
		this.logger.debug("app_master_admin_module:method:update3DObject");

		let p;

		////let objectFile = mysql.escape(request.body.objectFile);
		let id = mysql.escape(req.body.id);

		let pos_x = mysql.escape(req.body.pos_x);
		let pos_y = mysql.escape(req.body.pos_y);
		let pos_z = mysql.escape(req.body.pos_z);

		let rot_x = mysql.escape(req.body.rot_x);
		let rot_y = mysql.escape(req.body.rot_y);
		let rot_z = mysql.escape(req.body.rot_z);

		let scale_x = mysql.escape(req.body.scale_x);
		let scale_y = mysql.escape(req.body.scale_y);
		let scale_z = mysql.escape(req.body.scale_z);

		// response.writeHead(200, { 'Content-Type': 'text/html' });
		res.setHeader('content-type', 'application/json');

		////let query = "UPDATE 3dobjects SET pos_x=" + pos_x + ", pos_y=" + pos_y + ", pos_z=" + pos_z + ", rot_x=" + rot_x + ", rot_y=" + rot_y + ", rot_z=" + rot_z + ", scale_x=" + scale_x + ", scale_y=" + scale_y + ", scale_z=" + scale_z + " WHERE object_file = " + objectFile + " AND subscriber_id = " + subscriber;

		let query = "UPDATE 3dobjects SET pos_x=" + pos_x + ", pos_y=" + pos_y + ", pos_z=" + pos_z + ", rot_x=" + rot_x + ", rot_y=" + rot_y + ", rot_z=" + rot_z + ", scale_x=" + scale_x + ", scale_y=" + scale_y + ", scale_z=" + scale_z + " WHERE id = " + id;

		logger.debug(query);

		p = P_GetQueryData(query, null, ParseUpdate3DObjectsResult);
		p.then(data => {
			res.send(data);
		}).catch(err => {
			console.log("Location: app.js:3181, App Error: ", err);
			res.status(500).send("Internal Server Error: " + err);
		});
	};

	async updateDoorHingePlacement(req) {
		this.logger.debug("/updateDoorHingePlacement");

		let p;

		////let objectFile = mysql.escape(request.body.objectFile);
		let elem_id = mysql.escape(req.body.elem_id);

		let left_hinge_coords = mysql.escape(req.body.left_hinge_coords);
		let right_hinge_coords = mysql.escape(req.body.right_hinge_coords);

		res.setHeader('content-type', 'application/json');

		let query = "UPDATE doors SET left_hinge_coords=" + left_hinge_coords + ", right_hinge_coords=" + right_hinge_coords + " WHERE elem_id = " + elem_id;

		this.logger.debug(query);

		let [err, result] = await to(P_GetQueryData(query, null, ParseUpdateDoorHingePlacementResult));
		if (err) {
			throw err;
		}
		return result;
	}
}
