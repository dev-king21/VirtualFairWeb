/*eslint-env node, es6*/
/*eslint-parserOptions ecmaVersion:2019*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape, no-undef*/

/*This module is for user specific actions */

const THIS_FILE = "app_user_module.mjs";

import Dbfunctions from "./dbfunctions.cjs";
import mysql from "mysql2/promise.js";
import to from "togo";
import WebHooks from 'node-webhooks';
import fillTemplate from 'es6-dynamic-template';
import generatePassword from 'password-generator';
import md5 from 'blueimp-md5';
import moment from "moment";
import { nanoid } from "nanoid";
import deepFind from "deep-find";

import integrate from "./app_integrations.mjs";
import { CleanSubscriberID, getSubscriberData, setUserLastAccess, dateFormat } from "./app.mjs";
import { ParseSavedDesignDataRows, ParseZipCodeRowData, ParseLoginRowData, ParseSavedDesignsData, SelectSubscriberLocation, ParseZipCodeRowsData, ParseLogResult, ParseLoginRowsData, ParseRegistrationResult } from "./app_data_parser_module.mjs";

let logger;
let DEBUG;
let P_GetQueryData;
let serverCfg;
let s3;

/**
 * Returns default registration email message as a template string ready for execution
 * @param {string} msgType html | text
 * @returns {string} template string
 */
function defaultSaveNotificationEmail(msgType) {
	let htmlMsg = {mystring: function(){/*
<b>Design Save Notification</b>
<p>First Name: ${userData.firstname}<br>
<p>Last Name: ${userData.lastname} <br>
EMail Address: ${userData.email}</p>
<p>User ID: ${userData.userid}</p>
<p>Design ID: ${designData.design_id}</p>
<p>Building is a ${designData.series_code} series ${designData.building_size} ${designData.building_style}</p>
<p>User Design Description: ${designData.designNameForWeb}</p>
<p>Click here to view design: https://${info.server_name}/?sc=${userData.subscriber_id}&series=${designData.series_code}&designID=${designData.design_id}</p>
<br><br><p>Do not reply to this e-mail -- this is a notification email only sent to notify you that a customer has saved a design on the 3D Designer.</p>
<p>In order to view the customers design, just click on the link above.</p>
*/}.toString().slice(14,-3)
	};
	let textMsg = {mystring: function(){/*
Design Save Notification

First Name: ${userData.firstname}
Last Name: ${userData.lastname}
EMail Address: ${userData.email}

User ID: ${userData.userid}

Design ID: ${designData.design_id}

Building is a ${designData.series_code} series ${designData.building_size} ${designData.building_style}

User Design Description: ${designData.designNameForWeb}

Click here to view design: https://${info.server_name}/?sc=${userData.subscriber_id}&series=${designData.series_code}&designID=${designData.design_id}

Do not reply to this e-mail -- this is a notification email only sent to notify you that a customer has saved a design on the 3D designer.
*/}.toString().slice(14,-3)
	};
	if (msgType === "html") {
		return htmlMsg.mystring;
	} else {
		return textMsg.mystring;
	}
}

function defaultContactNotificationEmail(msgType) {
	let htmlMsg = {mystring: function(){/*
<b>Contact Request Notification</b>
<p>First Name: ${contactRequestData.first_name}<br>
<p>Last Name: ${contactRequestData.last_name}<br>
EMail Address: ${contactRequestData.email}</p>
<p>Phone Number: ${contactRequestData.phone}</p>
<p>Address: ${contactRequestData.address}</p>
<p>Zipcode: ${contactRequestData.zipcode}</p>
<p>User ID: ${userData.userid}</p>
<p>Message: ${contactRequestData.request}</p>
<br><br><p>Do not reply to this e-mail -- reply directly to the customer. This is a notification email only sent to notify you of the customers contact request.</p>
*/}.toString().slice(14,-3)
	};

	let textMsg = {mystring: function(){/*
Contact Request Notification

First Name: ${contactRequestData.first_name}
Last Name: ${contactRequestData.last_name}
EMail Address: ${contactRequestData.email}

Phone Number: ${contactRequestData.phone}

Address: ${contactRequestData.address}
Zipcode: ${contactRequestData.zipcode}

User ID: ${userData.username}

Message: ${contactRequestData.request}

Do not reply to this e-mail -- reply directly to the customer. This is a notification email only sent to notify you of the customers contact request.
*/}.toString().slice(14,-3)
	};

	if (msgType === "html") {
		return htmlMsg.mystring;
	} else {
		return textMsg.mystring;
	}
}

function defaultQuoteNotificationEmail(msgType) {
	let htmlMsg = {mystring: function(){/*
<b>Quote - Order Request Notification</b>
<p>First Name: ${quoteRequestData.first_name}<br>
<p>Last Name: ${quoteRequestData.last_name}<br>
EMail Address: ${quoteRequestData.email}</p>
<p>Phone Number: ${quoteRequestData.phone}</p>
<p>Delivery Address: ${quoteRequestData.delivery_address}</p>
<p>Delivery Zipcode: ${quoteRequestData.delivery_zipcode}</p>
<p>User ID: ${userData.userid}</p>
<p>Message: ${quoteRequestData.request}</p>

<p>Design ID: ${quoteRequestData.design_id}</p>

<p>Click here to view design: https://${quoteRequestData.host}/?sc=${quoteRequestData.subscriber_id}&series=${quoteRequestData.series_code}&designID=${quoteRequestData.design_id}</p>
<br><br><p>Do not reply to this e-mail -- reply directly to the customer. This is a notification email only sent to notify you of the customers quote / order request.</p>
*/}.toString().slice(14,-3)
	};

	let textMsg = {mystring: function(){/*
Quote - Order Request Notification

First Name: ${quoteRequestData.first_name}
Last Name: ${quoteRequestData.last_name}
EMail Address: ${quoteRequestData.email}

Phone Number: ${quoteRequestData.phone}

Delivery Address: ${quoteRequestData.delivery_address}
Delivery Zipcode: ${quoteRequestData.delivery_zipcode}

User ID: ${userData.username}

Message: ${quoteRequestData.request}

Click here to view design: https://${quoteRequestData.host}/?sc=${quoteRequestData.subscriber_id}&series=${quoteRequestData.series_code}&designID=${quoteRequestData.design_id}

Do not reply to this e-mail -- reply directly to the customer. This is a notification email only sent to notify you of the customers quote / order request.
*/}.toString().slice(14,-3)
	};

	if (msgType === "html") {
		return htmlMsg.mystring;
	} else {
		return textMsg.mystring;
	}
}

function defaultCustomerQuoteNotificationEmail(msgType) {
	let htmlMsg = {mystring: function(){/*
<b>Order Notification</b>
<p>Hello ${quoteRequestData.first_name} ${quoteRequestData.last_name}<br>
<br>
This email is to notify you that an order for a building has been submitted for you.</p>
<p>Delivery Address: ${quoteRequestData.delivery_address}</p>
<p>Delivery Zipcode: ${quoteRequestData.delivery_zipcode}</p>

<p>Comments: ${quoteRequestData.request}</p>

<p>Design ID: ${quoteRequestData.design_id}</p>

<p>Click here to view design: https://${quoteRequestData.host}/?sc=${quoteRequestData.subscriber_id}&series=${quoteRequestData.series_code}&designID=${quoteRequestData.design_id}</p>
<br><br><p>Do not reply to this e-mail -- contact sales directly. This is a automatic notification email only sent to notify you of the order.</p>
*/}.toString().slice(14,-3)
	};

	let textMsg = {mystring: function(){/*
Order Notification

Hello ${quoteRequestData.first_name} ${quoteRequestData.last_name}

This email is to notify you that an order for a building has been submitted for you.

Delivery Address: ${quoteRequestData.delivery_address}
Delivery Zipcode: ${quoteRequestData.delivery_zipcode}

Comments: ${quoteRequestData.request}

Design ID: ${quoteRequestData.design_id}

Click here to view design: https://${quoteRequestData.host}/?sc=${quoteRequestData.subscriber_id}&series=${quoteRequestData.series_code}&designID=${quoteRequestData.design_id}

Do not reply to this e-mail -- contact sales directly. This is a automatic notification email only sent to notify you of the order.
*/}.toString().slice(14,-3)
	};

	if (msgType === "html") {
		return htmlMsg.mystring;
	} else {
		return textMsg.mystring;
	}
}

/**
 * Returns default auto registration email message as a template string ready for execution -- this gets sent to the customer
 * @param {string} msgType html | text
 * @returns {string} template string
 */
function defaultAutoRegistrationNotificationEmail(msgType) {
	let htmlMsg = {mystring: function(){/*
<p>Hello ${userData.firstname},</p><br>
<p>Thank your for submitting an order request. Since you have not registered previously we have automatically created an account for you.</p>
<p>Your user id is: ${userData.email}</p>
<p>Your password is: ${userData.password}</p>
<p>Thank you for your order, one of our sales associates will be contacting you to verify your order.</p>
*/}.toString().slice(14,-3)
	};

	let textMsg = {mystring: function(){/*
Hello ${userData.firstname},

Thank your for submitting an order request. Since you have not registered previously we have automatically created an account for you.

Your user id is: ${userData.email}

Your password is: ${userData.password}

Thank you for your order, one of our sales associates will be contacting you to verify your order.
*/}.toString().slice(14,-3)
	};

	if (msgType === "html") {
		return htmlMsg.mystring;
	} else {
		return textMsg.mystring;
	}
}

/**
 * Returns default registration email message as a template string ready for execution
 * @param {string} msgType html | text
 * @returns {string} template string
 */
function defaultRegistrationNotificationEmail(msgType) {
	let htmlMsg = {mystring: function(){/*
<b>Registration Notification</b>
<p>First Name: ${userData.firstname}<br>
<p>Last Name: ${userData.lastname}<br>
EMail Address: ${userData.email}</p>
<p>User ID: ${userData.userid}</p>
<br><br><p>Do not reply to this e-mail -- this is a notification email only sent to notify you that a new customer has created an account on your building designer.</p>
*/}.toString().slice(14,-3)
	};

	let textMsg = {mystring: function(){/*
Registration Notification

First Name: ${userData.firstname}
Last Name: ${userData.lastname}
EMail Address: ${userData.email}

User ID: ${userData.username}

Do not reply to this e-mail -- this is a notification email only sent to notify you that a new customer has created an account on your building designer.
*/}.toString().slice(14,-3)
	};

	if (msgType === "html") {
		return htmlMsg.mystring;
	} else {
		return textMsg.mystring;
	}
}
export class User {
	constructor(params) {
		serverCfg = params.serverCfg;
		s3 = params.s3;
		this.con = params.mysql_connection;
		this.tcon = params.mysql_transaction_connection;
		this.logger = params.logger;
		this.nodemailerMailgun = params.nodemailerMailgun;
		logger = params.logger;
		this.DEBUG = params.DEBUG;
		DEBUG = this.DEBUG;
		this.dbfunc = new Dbfunctions({mysql_connection:this.con, mysql_transaction_connection:this.tcon, logger:this.logger, DEBUG:this.DEBUG});
		this.P_GetQueryData = this.dbfunc.P_GetQueryData.bind(this.dbfunc);
		P_GetQueryData = this.P_GetQueryData;
		this.P_GetQueryDataReq = this.dbfunc.P_GetQueryDataReq.bind(this.dbfunc);
		this.ParseMySqlRowData = this.dbfunc.ParseMySqlRowData.bind(this.dbfunc);
		this.P_ParseMySqlRowsData = this.dbfunc.P_ParseMySqlRowsData.bind(this.dbfunc);
		this.ParseMySqlRowDataObj = this.dbfunc.ParseMySqlRowDataObj.bind(this.dbfunc);
		this.P_ParseMySqlRowsDataObj = this.dbfunc.P_ParseMySqlRowsDataObj.bind(this.dbfunc);
		this.MySQLActionResult = this.dbfunc.MySQLActionResult.bind(this.dbfunc);
		this.ReturnSingleMySQLRow = this.dbfunc.ReturnSingleMySQLRow.bind(this.dbfunc);

		this.invalidZipCache = [];
	}

	async data(req) {
		let err;
		let result = {};
		switch (req.body.request) {
			case "isLoggedIn": {
				[err, result] = await to(this.isLoggedIn(req));
				break;
			}
			case "getSavedWebDesigns": {
				[err, result] = await to(this.getSavedWebDesigns(req));
				break;
			}
			case "getSavedWebDesign": {
				[err, result] = await to(this.getSavedWebDesign(req));
				break;
			}
			case "getUserData": {
				[err, result] = await to(this.getUserData(req));
				break;
			}
			case "getZipCode": {
				[err, result] = await to(this.getZipCode(req));
				break;
			}
			default: {
				err = {
					message: "invalid request"
				};
			}
		}
		if (err) {
			throw err;
		}
		return result;
	}

	async action(req) {
		let err;
		let result = {};
		req.socket = {
			sendupdate: false,
			updatedata: {}
		};
		switch (req.body.request) {
			case "checkPostalCode": {
				[err, result] = await to(this.checkPostalCode(req));
				break;
			}
			case "quoteRequest": {
				[err, result] = await to(this.quoteRequest(req));
				req.socket.sendupdate = true;
				req.socket.updatedata = {type: "quoteRequest"};
				break;
			}
			case "contactRequest": {
				[err, result] = await to(this.contactRequest(req));
				req.socket.sendupdate = true;
				req.socket.updatedata = {type: "contactRequest"};
				break;
			}
			case "getUserIDbyEmail": {
				[err, result] = await to(this.getUserIDbyEmail(req));
				break;
			}
			case "autoRegister": {
				[err, result] = await to(this.autoRegister(req));
				req.socket.sendupdate = true;
				req.socket.updatedata = {type: "autoRegister"};
				break;
			}
			case "saveDesignToWeb": {
				//req.body = data.formData;
				[err, result] = await to(this.saveDesignToWeb(req));
				req.socket.sendupdate = true;
				req.socket.updatedata = {type: "saveDesignToWeb"};
				break;
			}
			case "register": {
				req.body = req.body.data;
				[err, result] = await to(this.register(req));
				req.socket.sendupdate = true;
				req.socket.updatedata = {type: "register"};
				break;
			}
			case "recordS3SaveResult": {
				[err, result] = await to(this.recordS3SaveResult(req));
				break;
			}
			case "checkDesignID": {
				[err, result] = await to(this.checkDesignID(req));
				break;
			}
			case "login": {
				[err, result] = await to(this.login(req));
				break;
			}
			case "logout": {
				[err, result] = await to(this.logout(req));
				break;
			}
			case "pwrst": {
				[err, result] = await to(this.pwrst(req));
				break;
			}
			case "setZipCode": {
				[err, result] = await to(this.setZipCode(req));
				break;
			}
			default: {
				err = {
					message: "invalid request"
				};
			}
		}
		if (err) {
			throw err;
		}
		return result;
	}

	async checkPostalCode(req) {
		this.logger.debug("app.js:fn:checkPostalCode");
		let query;
		let err;
		let data;

		let subscriber = mysql.escape(await CleanSubscriberID(null,req));

		let postalCode = mysql.escape(req.body.postalCode);

		postalCode = postalCode.substr(1, postalCode.length - 2);

		if (!postalCode || postalCode=="")
		{
			return {validpostalcode: false };
		}
		else
		{
			// Todo: handle multiple countries
			query = "SELECT * FROM uszipcodes WHERE zipcode=?";
			query = mysql.format(query,[postalCode]);

			[err, data] = await to(this.P_GetQueryDataReq(query, ParseZipCodeRowData, ParseZipCodeRowsData, req));
			if(err) {
				console.log("Error Location: app.js/checkPostalCode");
				return {validzip: false, success: false, status: "fail", error: true, err: err};
			}
			if(!data.validzip) {
				return data;
			}
			let postal_code_data = data.postal_code_data;

			query = "SELECT * FROM subscriber_locations WHERE subscriber_id=" + subscriber + " AND active";
			[err, data] = await to(this.P_GetQueryDataReq(query, null, SelectSubscriberLocation,req));
			if(err) {
				logger.error("Error Location: app.js:fn:checkPostalCode",err);
				return {validzip: false, success: false, status: "fail", error: true, err: err};
			}
			data.postal_code_data = postal_code_data;
			return data;
		}
	}

	async quoteRequest(req) {
		this.logger.debug("fn:quoteRequest");
		let err, result, query, prefix;
		let subscriber_id = await CleanSubscriberID(null,req);
		let location_number = mysql.escape(req.body.location_number);
		logger.info(`Quote / Order Request received for ${subscriber_id} Location: ${location_number}`);
		let quoteRequestData = req.body.form_data;
		let fdata = quoteRequestData;

		if (req.session && req.session.subscriber_data) {
			prefix = req.session.subscriber_data.design_prefix;
		} else {
			await getSubscriberData(req, subscriber_id);
			prefix = req.session.subscriber_data.design_prefix;
		}

		query=`SELECT * FROM subscriber_server_data WHERE subscriber_id='${subscriber_id}' AND feature_id='notification'`;
		[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if(err) {
			logger.error(`Order Error 1: ${err} -- quoteRequestData: ${JSON.stringify(quoteRequestData)}`);
			return {success: false, status:"error", cause:"unknown", code:err.code, err: err};
		}
		let notification_settings = {};
		if(result.length > 0) {
			notification_settings = result[0].feature_data;
		}
		query=`SELECT * FROM subscriber_locations WHERE subscriber_id='${subscriber_id}' AND location_number = ${location_number}`;
		[err, result] = await to(this.P_GetQueryData(query, null,this.ReturnSingleMySQLRow));
		if(err) {
			logger.error(`Order Error 2 ${err} -- quoteRequestData: ${JSON.stringify(quoteRequestData)}`);
			return {success: false, status: "error", cause:"unknown", code:err.code, err: err};
		}
		let subscriber_location_data = result;

		// save to database here.

		let quote_record = {};
		quote_record.subscriber_id = subscriber_id;
		quote_record.location_number = location_number;
		if (fdata.fq_user_id) {
			quote_record.user_id = fdata.fq_user_id;
		} else if (req.body.user_id) {
			quote_record.user_id = req.body.user_id;
		}

		/*if (["master","sadmin","admin","staff"].includes(deepFind(req.session,"userdata.usertype"))) {
			if (quote_record.register_customer) {
				let [err,result] = await to(getUserIDbyEmail(req));
				if (err) {
					throw err;
				}
				if (result.user_list.length === 1) {
					quote_record.user_id = result.user_list[0].userid;
				} else {
					let [err,result] = await to(autoRegister(req));
					if (err) {
						throw err;
					}
					quote_record.user_id = result.userid;
				}
			}
		}*/

		if (req.session.userdata && req.session.userdata.userid) {
			if (!quote_record.user_id) {
				if (req.session.userdata.with_prefix) {
					if (req.session.userdata.userid.indexOf(prefix + "_") === 0) {
						quote_record.user_id = req.session.userdata.userid;
					} else {
						quote_record.user_id = prefix + "_" + req.session.userdata.userid;
					}
				} else {
					quote_record.user_id = req.session.userdata.userid;
				}
			}
		} else {
			req.body.email = quote_record.email;
			let [err, result] = await to(getUserIDbyEmail(req));
			if (err) {
				if (!quote_record.user_id) {
					quote_record.user_id = null;
				}
			}
			if (result.success && result.user_list.length === 1) {
				quote_record.user_id = result.user_list[0].userid;
			} else {
				if (!quote_record.user_id) {
					quote_record.user_id = null;
				}
			}
		}

		/* if (req.session.userdata && req.session.userdata.userid) {
			quote_record.user_id = req.session.userdata.userid;
		} else {
			quote_record.user_id = null;
		} */
		let dt = new Date();
		quote_record.contact_time = dt.toISOString().substring(0, 10) + " " + dt.toISOString().substring(11, 19);
		//let fdata = quoteRequestData;
		fdata.location_number = req.body.location_number;
		fdata.series_code = req.body.series_code;
		if (notification_settings.integrate && notification_settings.integrate.orders) {
			fdata[notification_settings.integrate.orders] = integrate[notification_settings.integrate.orders](fdata.detailList);
		}
		quote_record.design_id = fdata.design_id;
		quote_record.data = JSON.stringify(fdata);

		query = "INSERT INTO user_order_requests SET ?";
		query = mysql.format(query,quote_record);
		[err, result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
		if(err) {
			logger.error(`Order Error 3: ${err} -- quoteRequestData: ${JSON.stringify(quoteRequestData)}`);
		}

		let userData = {};
		if (req.session.userdata) {
			if (["master","sadmin","admin","staff"].includes(deepFind(req.session,"userdata.usertype")) && (quote_record.userid != req.session.userid)) {
				let query = "SELECT * FROM users WHERE subscriber_id = ? AND userid = ?"
				query = mysql.format(query,[subscriber_id,quote_record.userid]);
				let err;
				[err,userData] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
				if (err) {
					throw err;
				}
			} else {
				userData = req.session.userdata;
			}
			delete userData.password;
			delete userData.passwordhash;
			delete userData.username;
		}

		if (notification_settings.quote_webhook && notification_settings.quote_webhook_url) {
			let webHook = new WebHooks({
				db: {quoterequest: [notification_settings.quote_webhook_url]}
			});
			let locationData = {};
			locationData.subscriber_id = subscriber_location_data.subscriber_id;
			locationData.location_number = subscriber_location_data.location_number;
			locationData.name = subscriber_location_data.name;
			locationData.address = subscriber_location_data.address;

			webHook.trigger('quoterequest', {locationData: locationData, userData: userData, quoteRequestData: quoteRequestData});
		}
		if (!notification_settings.no_quote_email) {
			if (!notification_settings.quote_html_email_template) {
				notification_settings.quote_html_email_template = defaultQuoteNotificationEmail("html");
			}

			if (!notification_settings.quote_text_email_template) {
				notification_settings.quote_text_email_template = defaultQuoteNotificationEmail("text");
			}
			let subscriber_contact_email = subscriber_location_data.n_email;
			if (deepFind(userData,"data.assigned_rep")) {
				query = "SELECT * FROM subscriber_locations WHERE subscriber_id = ? AND location_number = ?";
				query = mysql.format(query,[userData.subscriber_id,userData.location_number]);
				[err,result] = await to(this.P_GetQueryData(query, null, this.ReturnSingleMySQLRow));
				if (err) {
					logger.error("Error retrieving subscriber_locations",err);
				}
				if (deepFind(result,"data.notifications.available_reps") && result.data.notifications.available_reps.includes[userData.dada.assigned_rep]) {
					subscriber_contact_email = userData.data.assigned_rep;
				} else {
					userData.data.assigned_rep = subscriber_contact_email;
					query = "UPDATE users SET data = ? WHERE userid = ?";
					query = mysql.format(query,[JSON.stringify(userData.data),userData.userid]);
					[err,result] = await to(this.P_GetQueryData(query, null, this.MySQLActionResult));
					if (err) {
						logger.error("Error updating user record",err);
					}
				}
			}
			if (req.headers && req.headers.host) {
				quoteRequestData.host = req.headers.host;
			} else {
				quoteRequestData.host = "mybuilding.3dfish.net";
			}

			let Subject = `3D Customer Building Quote - Order: ${quoteRequestData.first_name} ${quoteRequestData.last_name}`;
			if (notification_settings.quote_email_subject_template) {
				Subject = fillTemplate(notification_settings.quote_email_subject_template,{quoteRequestData: quoteRequestData, userData: userData, subscriber_location_data: subscriber_location_data});
			}
			let htmlMsg = fillTemplate(notification_settings.quote_html_email_template,{quoteRequestData: quoteRequestData, userData: userData});
			let textMsg = fillTemplate(notification_settings.quote_text_email_template,{quoteRequestData: quoteRequestData, userData: userData});

			let email_msg = {
				from: 'sheddesigner@3dfish.net',
				// to: 'info@3dfish.net', // An array if you have multiple recipients.
				to: subscriber_contact_email,
				subject: Subject,
				replyTo: 'noreply@3dfish.net',
				html: htmlMsg,
				text: textMsg
			};
			if (deepFind(subscriber_location_data.data,"notificationcc")) {
				email_msg.cc = subscriber_location_data.data.notificationcc;
			}
			[err, result] = await to(this.nodemailerMailgun.sendMail(email_msg));

			if (quoteRequestData.send_customer_email) {
				if (!notification_settings.customer_quote_html_email_template) {
					notification_settings.customer_quote_html_email_template = defaultCustomerQuoteNotificationEmail("html");
				}

				if (!notification_settings.customer_quote_text_email_template) {
					notification_settings.customer_quote_text_email_template = defaultCustomerQuoteNotificationEmail("text");
				}
				let Subject = `Building Order notification from ${subscriber_location_data.name}`;
				if (notification_settings.customer_quote_email_subject_template) {
					Subject = fillTemplate(notification_settings.customer_quote_email_subject_template,{quoteRequestData: quoteRequestData, userData: userData, subscriber_location_data: subscriber_location_data});
				}
				let htmlMsg = fillTemplate(notification_settings.customer_quote_html_email_template,{quoteRequestData: quoteRequestData, userData: userData});
				let textMsg = fillTemplate(notification_settings.customer_quote_text_email_template,{quoteRequestData: quoteRequestData, userData: userData});

				let email_msg = {
					from: 'sheddesigner@3dfish.net',
					// to: 'info@3dfish.net', // An array if you have multiple recipients.
					to: quoteRequestData.email,
					subject: Subject,
					replyTo: 'noreply@3dfish.net',
					html: htmlMsg,
					text: textMsg
				};
				[err, result] = await to(this.nodemailerMailgun.sendMail(email_msg));
			}
		}

		return {success: true, userid:quote_record.userid};
	}

	async recordS3SaveResult(req) {
		this.logger.debug("fn:recordS3SaveResult");
		let err, result, query;
		if (req.body.err) {
			if (req.body.saveDesignResult && req.body.saveDesignResult.design_id) {
				logger.warn(`Client Error saving to S3`,{subscriber_id: req.session.subscriber_id, design_id: req.body.saveDesignResult.design_id, err: req.body.err});
				query = "UPDATE usersheds SET in_file_bucket = -2 WHERE design_id = ?";
				query = mysql.format(query,req.body.saveDesignResult.design_id);
				[err,result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
				if (err) {
					throw err;
				}
				return result;
			}
		}
		if (req.body.saveDesignResult && req.body.saveDesignResult.design_id) {
			logger.info("Successfully saved to S3",{subscriber_id: req.session.subscriber_id, design_id: req.body.saveDesignResult.design_id})
			query = "UPDATE usersheds SET in_file_bucket = 1 WHERE design_id = ?";
			query = mysql.format(query,req.body.saveDesignResult.design_id);
			[err,result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
			if (err) {
				throw err;
			}
			return result;
		}
		throw "fn:recordS3SaveResult: No design_id to set";
	}

	async saveDesignToWeb (req) {
		this.logger.debug("app.js:fn:saveDesignToWeb");

		let err;
		let urlPrefix = serverCfg.s3.urlDomain + serverCfg.s3.keyprefix;
		let designData;
		let design_prefix;
		let design_id;
		let short_design_id;
		let design_id_checked = false;
		let query, result;
		let subscriber_id = await CleanSubscriberID(null,req);
		// let userDefinedID = false;

		let dfdata = null;
		if (req.formdata && req.formdata.getData) {
			dfdata = await req.formdata.getData(['designData']);
		} else {
			dfdata = req.body.formData;
		}
		// console.log(dfdata);
		let userData = req.session.userdata;
		if (typeof req.session.userdata === "undefined") {
			[err,userData] = await to(this.loadUserData(req,dfdata.userID));
			if (err) {
				logger.error(`Error retrieving userdata: ${err}`);
			}
			if (userData) {
				req.session.userdata = userData;
			} else {
				logger.warn(`No user data retrieved for: ${dfdata.userID}`);
			}
			//console.log("dfdata.userID: ",dfdata.userID," userData: ",userData);
			logger.info(`dfdata.userID: ${dfdata.userID} userData: ${JSON.stringify(userData)}`,{subscriber_id: req.session.subscriber_id, userip: req.session.ip});
		}
		logger.info(`Design Save User Data for ${subscriber_id} - Loc ${req.fd_subscriber_location_number} - ${userData.firstname} ${userData.lastname}`,{userData: userData,subscriber_id: req.session.subscriber_id, userip: req.session.ip});

		query = "SELECT design_prefix FROM subscribers WHERE subscriber_id = '" + subscriber_id + "'";
		[err, result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if(result.length > 0) {
			design_prefix = result[0].design_prefix;
			req.design_prefix = design_prefix;
		} else {
			design_prefix = "";
		}
		/* design_id = design_prefix + "_" + Math.random().toString(36).substr(2, 8);
		req.design_id = design_id; */
		//console.log("design_prefix retrieved.");
		logger.debug("design_prefix retrieved.",{subscriber_id: req.session.subscriber_id, userip: req.session.ip});

		if(!(dfdata.design_id === "undefined") && dfdata.design_id.length > 0){
			// userDefinedID = true;
			short_design_id = dfdata.design_id.replace(/([^a-z0-9\-]+)/gi,"");
			design_id = design_prefix + "_" + short_design_id;
			req.design_id = design_id;
			query = "SELECT * FROM usersheds WHERE design_id = '" + design_id + "'";
			result = await P_GetQueryData(query,this.ParseMySqlRowData,this.P_ParseMySqlRowsData);
			if(result.length > 2) {
				logger.warn(`Attempted to save using existing design id`,{subscriber_id: req.session.subscriber_id, userip: req.session.ip});
				//res.send({result: "ID Exists"});
				return {result: "ID Exists"};
			}
			/* usersheds2 is not currently being used.
			query = "SELECT * FROM usersheds2 WHERE design_id = '" + design_id + "'";
			result = await P_GetQueryData(query,this.ParseMySqlRowData,this.P_ParseMySqlRowsData);
			if(result.length > 2) {
				res.send({result: "ID Exists"});
				return;
			} */
			design_id_checked = true;
		}
		/* req.fd_subscriber = mysql.escape(await CleanSubscriberID(dfdata.subscriber_id));
		req.fd_userID = mysql.escape(dfdata.userID);
		req.fd_subscriber_location_number = mysql.escape(dfdata.location_number);
		req.fd_designNameForWeb = mysql.escape(dfdata.designNameForWeb);
		req.fd_building_type = mysql.escape(dfdata.building_type);
		req.fd_save_as_default_for_building = mysql.escape(dfdata.save_as_default_for_building); */
		req.fd_subscriber = await CleanSubscriberID(dfdata.subscriber_id);
		if(req.session.userdata && req.session.userdata.with_prefix) {
			if (dfdata.userID.indexOf(design_prefix + "_") === 0) {
				req.fd_userID = dfdata.userID;
			} else {
				req.fd_userID = design_prefix + "_" + dfdata.userID;
			}
		} else {
			req.fd_userID = dfdata.userID;
		}
		req.fd_subscriber_location_number = dfdata.location_number;
		req.fd_designNameForWeb = dfdata.designNameForWeb;
		req.fd_building_type = dfdata.building_type;
		req.fd_building_name = dfdata.building_name;
		req.fd_building_width = dfdata.building_width;
		req.fd_building_length = dfdata.building_length;
		req.fd_save_as_default_for_building = dfdata.save_as_default_for_building;
		//req.fd_filename = dfdata.designData.filename;
		//req.fd_path = dfdata.designData.path;
		req.fd_series_code = "Standard";
		if(dfdata.data_format) {
			req.fd_data_format = dfdata.data_format;
		} else {
			req.fd_data_format = "XML";
		}
		if(!(typeof dfdata.series_code === "undefined"))
		{
			req.fd_series_code = dfdata.series_code;
		}

		if (!design_id_checked) {
			query = "SELECT design_id FROM usersheds WHERE design_id = '" + design_id + "'";
			let checkResult = {success: false};
			while (!checkResult.success) {
				({design_id, short_design_id} = this.generateDesignID(req));
				[err, checkResult] = await to(this.P_GetQueryDataReq(query, null, this.CheckDesignIDAvail, req));
				if(err) {
					logger.error(`App.js:/saveDesigntoWeb: unexpected error checking design id. err: ${err}`);
					return {status: "failed", success: false};
				}
			}
			/*query = "SELECT design_id FROM usersheds2 WHERE design_id = '" + design_id + "'";

			checkResult = {success: false};
			while (!checkResult.success) {
				({design_id, short_design_id} = this.generateDesignID(req));
				[err, checkResult] = await to(this.P_GetQueryDataReq(query, null, this.CheckDesignIDAvail, req));
				if(err) {
					// TODO: process error
					console.log("App.js: 4151, unexpected error checking design id.");
				}
			}*/
		}

		let create_date = dateFormat(new Date(), "%Y-%m-%d %H:%M:%S", true);

		let modified_date = create_date;

		/* not used when not sending data to the server but sending to s3 instead.
		if(req.fd_data_format == "JSON") {
			designData = JSON.parse(fs.readFileSync(dfdata.designData.path));
			designData = JSON.stringify(designData);
		} else {
			designData = fs.readFileSync(dfdata.designData.path);
		}
		// designData = mysql.escape(designData);
		*/

		let url = {
			url: urlPrefix + req.design_id + ".json",
			data: dfdata
		};
		let urlJSON = JSON.stringify(url);

		let user_shed = {
			subscriber_id: req.fd_subscriber,
			series_code: req.fd_series_code,
			location_number: req.fd_subscriber_location_number,
			userid: req.fd_userID,
			design_id: req.design_id,
			create_date: create_date,
			modified_date: modified_date,
			shed_name: req.fd_designNameForWeb,
			building_type: req.fd_building_type,
			software_version: process.env.npm_package_version,
			data_format: req.fd_data_format,
			in_file_bucket: -1,
			data: urlJSON
		};

		query = "INSERT INTO usersheds SET ?";
		query = mysql.format(query,user_shed);
		logger.debug(query);
		[err, result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
		if(err) {
			logger.error(`Location: app_user_module.js:/saveDesignToWeb, App Error: ${err}`);
			//res.send({status: "failed", success: false});
			//return err;
			return {status: "failed", success: false};
		}
		if(result.success) {
			logger.debug("getting S3 link");
			/* old method of transmitting data to the server then to s3, changed to better method of creating signed url for browser to upload directly to s3.  This section of code scheduled to be removed.
			let s3params = {
				...serverCfg.s3.options,
				Key: serverCfg.s3.keyprefix + req.design_id + serverCfg.s3.keysuffix,
				Body: designData
			}; */
			let s3urlparams = {
				...serverCfg.s3.options,
				Key: serverCfg.s3.keyprefix + req.design_id + serverCfg.s3.keysuffix
			}
			result = s3.getSignedUrl("putObject", s3urlparams);
			//[err,result] = await to(s3.putObject(s3params).promise());
			if (err) {
				logger.error(`Location: /saveDesignToWeb, App Error: ${err}`);
				return {status: "fail", success: false, errorcode: "E101", error: "saved name to database, s3 save error.", design_id: user_shed.design_id};
			}
			let s3url = result;

			logger.info(`DS url created - ${subscriber_id} - Loc ${req.fd_subscriber_location_number} - ${userData.firstname} ${userData.lastname} - Design ID:${design_id}.`);
			query = "SELECT * FROM subscriber_locations WHERE subscriber_id = ? AND location_number = ?";
			if (isNaN(req.fd_subscriber_location_number) || req.fd_subscriber_location_number < 1) {
				// failsafe -- TODO: need to add code to read location_number from a different source if location_number isn't set
				//console.log("req.fd_subscriber_location_number not set correctly: ",req.fd_subscriber_location_number," setting to 1.");
				let default_location = deepFind(req.session,"subscriber_data.data.default_location") || 1;
				logger.warn(`req.fd_subscriber_location_number not set correctly: ${req.fd_subscriber_location_number} setting to ${default_location}.`);
				req.fd_subscriber_location_number = default_location;
			}
			query = mysql.format(query,[req.fd_subscriber, req.fd_subscriber_location_number]);
			logger.debug(query);
			logger.debug(`req.fd_subscriber: ${req.fd_subscriber} req.fd_subscriber_location_number: ${req.fd_subscriber_location_number}`);
			[err, result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
			[err, result] = await to(this.GetSubscriberEmailAndProcessSavedDesign(err, result, null, req));
			if(err) {
				logger.error(`Location: /saveDesignToWeb, App Error: ${err}`);
				return {status: "partial success", success: true, errorcode: "E100", error: "saved to database, email send error.", design_id: user_shed.design_id, short_design_id: short_design_id, s3url: s3url};
			}
			if (!req.headers) {
				req.headers = {};
				req.headers["user-agent"] = "socket";
			}
			logger.info(`Saved to db - ${subscriber_id} - Loc ${req.fd_subscriber_location_number} - ${userData.firstname} ${userData.lastname} - Design ID:${design_id}.`,{response: result, tdf_version: dfdata.tdf_version, useragent: req.headers["user-agent"], subscriber_id: req.session.subscriber_id, userip: req.session.ip});
			result.s3url = s3url;
			result.short_design_id = short_design_id;
			return result;
		} else {
			// it should not be possible to reach this code
			logger.warn(`Unexpected failure to save`,{subscriber_id: req.session.subscriber_id, userip: req.session.ip});
			return {status: "failed", success: false};
		}

	}

	async getSavedWebDesigns(req) {
		this.logger.debug("fn:getSavedWebDesigns");

		let err, result, domain_userid, query;
		let result1 = [];
		let result2 = [];
		let userID = mysql.escape(req.body.userID);
		let subscriber = mysql.escape(await CleanSubscriberID(null,req));
		let series_code = "Standard";
		if(!(typeof req.body.series_code === "undefined"))
		{
			series_code = mysql.escape(req.body.series_code);
		}
		else
		{
			series_code = mysql.escape(series_code);
		}

		let buildingType = mysql.escape(req.body.building_type);

		//res.setHeader('content-type','application/json');
		[err, result] = await to(getSubscriberData(req));
		if (err) {
			//res.statusMessage = err;
			//res.send(500).end();
			//return;
			throw err;
		}

		if(req.session.userdata && req.session.userdata.with_prefix) {
			if (req.session.userdata.userid.indexOf(req.session.subscriber_data.design_prefix+"_")>-1) {
				domain_userid = `'${req.session.userdata.userid}'`;
			} else {
				domain_userid = `'${req.session.subscriber_data.design_prefix}_${req.session.userdata.userid}'`;
			}
		} else {
			domain_userid = userID;
		}

		query = `SELECT * FROM usersheds WHERE userID=${domain_userid} AND building_type=${buildingType} AND subscriber_id=${subscriber} AND series_code = ${series_code}`;
		[err,result1] = await to(this.P_GetQueryData(query, ParseSavedDesignsData,this.P_ParseMySqlRowsDataObj));
		if(err) {
			console.log("Error: app.js:fn:getSavedWebDesigns");
			//res.status(500).send("Internal Server Error: "+err);
			throw err;
		}
		/*query = `SELECT * FROM usersheds2 WHERE userID=${domain_userid} AND building_type=${buildingType} AND subscriber_id=${subscriber} AND series_code = ${series_code}`;
		[err,result2] = await to(this.P_GetQueryData(query, ParseSavedDesignsData,this.P_ParseMySqlRowsDataObj));
		if(err) {
			console.log("Error: app.js:fn:getSavedWebDesigns");
			//res.status(500).send("Internal Server Error: "+err);
			throw err;
		}
		result = result1.concat(result2);
		return result; */
		return result1;
	}

	async getSavedWebDesign(req) {
		this.logger.debug("app.js:fn:getSavedWebDesign");
		let err, result;
		let data;
		let design_id = mysql.escape(req.body.designID);
		let subscriber_id = await CleanSubscriberID(null,req);
		let fq_design_id = mysql.escape(req.session.subscriber_data.design_prefix + "_" + req.body.designID);
		let subscriber = mysql.escape(subscriber_id);

		let series_code = "Standard";
		if(!(typeof req.body.series_code === "undefined"))
		{
			series_code = mysql.escape(req.body.series_code);
		}
		else
		{
			series_code = mysql.escape(series_code);
		}

		let query = `SELECT * FROM usersheds WHERE subscriber_id = ${subscriber} AND design_id=${design_id}`;
		[err, data] = await to(this.P_GetQueryData(query, null, ParseSavedDesignDataRows));
		if(err) {
			logger.error("Location: app.js:fn:getSavedWebDesign, App Error: ",err);
			throw err;
		}
		if(this.DEBUG) console.log("data response: ",data.success);
		if(!data.success) {
			let query = `SELECT * FROM usersheds WHERE subscriber_id = ${subscriber} AND design_id=${fq_design_id}`;
			[err, data] = await to(this.P_GetQueryData(query, null, ParseSavedDesignDataRows));
			if(err) {
				logger.error("Location: app.js:fn:getSavedWebDesign, App Error: ",err);
				throw err;
			}
			/* if(!data.success) {
				return data;
			} */
		}

		if(!data.success) {
			query = `SELECT * FROM usersheds2 WHERE subscriber_id = ${subscriber} AND design_id=${design_id}`;
			[err, data] = await to(this.P_GetQueryData(query, null, ParseSavedDesignDataRows));
			if(err) {
				logger.error("Location: app.js:fn:getSavedWebDesign, App Error: ",err);
				throw err;
			}
		}
		if(this.DEBUG) console.log("data response: ",data.success);
		if(!data.success) {
			let query = `SELECT * FROM usersheds2 WHERE subscriber_id = ${subscriber} AND design_id=${fq_design_id}`;
			[err, data] = await to(this.P_GetQueryData(query, null, ParseSavedDesignDataRows));
			if(err) {
				logger.error("Location: app.js:fn:getSavedWebDesign, App Error: ",err);
				throw err;
			}
			if(!data.success) {
				return data;
			}
		}

		if(subscriber_id != data.subscriber_id) {
			return {success: false, status: "error", err: "Requested design id does not exist for this company."};
		} else if(series_code === `'${data.series_code}'`) {
			return data;
		} else {
			throw {success: false, status: "error", err: "Series_code doesn't match requested series_code."};
		}
	}

	async login (req) {
		this.logger.debug("fn:login");
		let err, result, subscriber_data;

		let subscriber_id = await CleanSubscriberID(null,req);
		let username = mysql.escape(req.body.username);
		let password = mysql.escape(req.body.password);

		username = username.substr(1, username.length-2);
		password = password.substr(1, password.length-2);

		if (!username || !password)
		{
			//res.send({success: false, response: "login failed!", userdata: ""});
			return {success: false, response: "login failed!", userdata: ""};
		}
		else
		{
			let query = `SELECT * FROM users WHERE (userid='${username}' AND BINARY passwordhash='${password}')`;

			[err, result] = await to(this.P_GetQueryData(query, ParseLoginRowData, ParseLoginRowsData));
			if(err) {
				throw(err);
			} else if(!result.success && result.userdata == "") {
				if (!req.session.subscriber_data) {
					query = `SELECT * FROM subscribers WHERE subscriber_id = '${subscriber_id}'`;
					[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
					if(err) {
						return {success: false, status:"error", cause:"unknown", code:err.code, err: err};
					} else if(result.length == 0) {
						return {success: false, status:"error", cause:"unknown", code:"000", err:"unable to retrieve subscriber data."};
					}
					subscriber_data = result[0];
				} else {
					subscriber_data = req.session.subscriber_data;
				}
				query = `SELECT * FROM users WHERE (userid='${subscriber_data.design_prefix}_${username}' AND BINARY passwordhash='${password}')`;
				[err, result] = await to(this.P_GetQueryData(query, ParseLoginRowData, ParseLoginRowsData));
				if(err) {
					throw(err);
				}
				if(!result.success && username.indexOf("@")>-1) {
					query = `SELECT * FROM users WHERE (email='${username}' AND BINARY passwordhash='${password}' AND subscriber_id='${subscriber_id}')`;
					[err, result] = await to(this.P_GetQueryData(query, ParseLoginRowData, ParseLoginRowsData));
					if(err) {
						throw(err);
					}
					if (result.success) {
						req.body.username = result.userdata.userid;
					}
				}
			}
			if (!result.success) {
				logger.warn(`Login Failed for userid: ${username} for subscriber id: ${subscriber_id}`);
				return result;
			}

			req.session.subscriber_data = subscriber_data;
			req.session.user = req.body.username;
			req.session.userdata = result.userdata;
			req.session.userdata_date = new Date();
			let userData = await this.getUserData(req);
			setUserLastAccess(req);
			LogAccess(req);
			return {success: true, status: "success", userData: userData};
		}
	}

	async logout(req) {
		//req.session.destroy();
		//delete req.session.subscriber_data;
		delete req.session.user;
		delete req.session.userdata;
		return {success: true, status: "success",msg: "logout success!"};
	}

	async pwrst(req) {
		this.logger.debug("pwrst");
		// *** TODO: remove expired requests here
		let result, err, resultType, reset_code, full_userid, user_record;

		let subscriber = mysql.escape(await CleanSubscriberID(null,req));
		if (!subscriber) {
			// status 400
			throw "Invalid Request - Missing data. Error Code: 3DF-PR1";
		}
		if (!req.body.userid) {
			// status 400
			throw "Invalid Request - Missing data. Error Code: 3DF-PR2";
		}
		let userid = mysql.escape(req.body.userid);
		userid = userid.substr(1, userid.length-2);
		let userid_prefix = req.session.subscriber_data.design_prefix + "_" + userid;
		full_userid = userid_prefix;
		// check for userid with prefix
		let query = `SELECT * FROM users WHERE userid = '${userid_prefix}'`;
		[err, result] = await to(this.P_GetQueryData(query, null,this.ReturnSingleMySQLRow));
		if (err) {
			this.logger.error(`${THIS_FILE}:pwrst: Error: ${err}`);
			// status 500
			throw "Internal Server Error. Error Code: 3DF-PR3 Error Message:"+err;
		}
		resultType = "userid";
		user_record = result;
		if (!result) {
			// check for userid without prefix
			full_userid = userid;
			query = `SELECT * FROM users WHERE userid = '${userid}' AND subscriber_id = ${subscriber}`;
			[err, result] = await to(this.P_GetQueryData(query, null,this.ReturnSingleMySQLRow));
			if (err) {
				logger.error(`app.js:/pwrst: Error: ${err}`);
				// status 500
				throw "Internal Server Error. Error Code: 3DF-PR4 Error Message:"+err;
			}
			user_record = result;
			if (!result) {
				resultType = "email";
				query = `SELECT * FROM users WHERE email = '${userid}' AND subscriber_id = ${subscriber}`;
				[err, result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					logger.error(`app.js:/pwrst: Error: ${err}`);
					// status 500
					throw "Internal Server Error. Error Code: 3DF-PR5 Error Message::"+err;
				}
				if (result.length === 0) {
					return {success: false, status: "Failed", err: "User ID / Email not found.", err_code: 1};
				}
				user_record = result;
			}
		}
		if (resultType === "userid") {
			// Send password Reset
			reset_code = nanoid();
			let creation_time = moment().format('YYYY-MM-DD HH:mm:ss');
			let expiration = moment().add(1,'hours').format('YYYY-MM-DD HH:mm:ss');
			query = `INSERT INTO user_password_reset (reset_code, subscriber_id, userid, creation_time, expiration, ip_address) VALUES ('${reset_code}', ${subscriber}, '${full_userid}', '${creation_time}', '${expiration}', '${req.ip}')`;
			[err, result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
			if (err) {
				logger.error(`app.js:/pwrst: Error: ${err}`);
				// status 500
				throw "Internal Server Error. Error Code: 3DF-PR6 Error Message:"+err;
			}
			let Subject = `Password Reset for ${req.headers.host}`;
			let htmlMsg = `<p>A password reset was requested for your account on ${req.headers.host}</p>
			<p>If you did not request this password reset you can ignore this e-mail.</p>
			<p>If you did request a password reset, click on the link below to reset your password. This link will expire in 1 hour</p>
			<p><a href="https://${req.headers.host}/pwrst/${reset_code}">https://${req.headers.host}/pwrst/${reset_code}</a>
			</p><p>Do not reply to this email, this is a send only email address.</p><p>Message PR1-H</p>`;
			let textMsg = `A password reset was requested for your account on ${req.headers.host}

			If you did not request this password reset you can ignore this e-mail.

			If you did request a password reset, click on the link below to reset your password. This link will expire in 1 hour.

			https://${req.headers.host}/pwrst/${reset_code}

			Do not reply to this email, this is a send only email address.

			Message PR1-T`;
			[err, result] = await to(this.nodemailerMailgun.sendMail({
				from: 'sheddesigner@3dfish.net',
				// to: 'info@3dfish.net', // An array if you have multiple recipients.
				to: user_record.email,
				subject: Subject,
				replyTo: 'noreply@3dfish.net',
				html: htmlMsg,
				text: textMsg,
			}
			));
			logger.info(`Password Reset Request: ${full_userid}`);
			return {success: true, status: "success", msg: "Password reset sent."};
		} else {
			// Send userid list
			let userid_list_html = "";
			let userid_list_text = "";
			for (let i=0;i < user_record.length;i++) {
				userid_list_html += `<p>${user_record[0].userid}</p>`;
				userid_list_text += `${user_record[0].userid}

	`;
			}
			let Subject = `Your User ID for ${req.headers.host}`;

			let htmlMsg = `<p>A User ID lookup requested for your account on ${req.headers.host}</p><p>If you did not request this User ID lookup you can ignore this e-mail.</p><p>Here are the User ID's we found for your email address:</p>${userid_list_html}<p>Click the following link to return to the designer: <a href="https://${req.headers.host}">https://${req.headers.host}</a></p><p>Do not reply to this email, this is a send only email address.</p>`;
			let textMsg = `A User ID lookup requested for your account on ${req.headers.host}

			If you did not request this User ID lookup you can ignore this e-mail.

			Here are the User ID's we found for your email address:

			${userid_list_text}

			Click the following link to return to the designer: https://${req.headers.host}

			Do not reply to this email, this is a send only email address.`;
			[err, result] = await to(this.nodemailerMailgun.sendMail({
				from: 'sheddesigner@3dfish.net',
				// to: 'info@3dfish.net', // An array if you have multiple recipients.
				to: user_record.email,
				subject: Subject,
				replyTo: 'noreply@3dfish.net',
				html: htmlMsg,
				text: textMsg
			}
			));
			return {success: true, status: "success", msg: "User id sent."};
		}

	}

	async isLoggedIn(req) {
		this.logger.debug("fn:isLoggedIn");
		if (typeof req === "undefined") {
			throw "fn:isLoggedIn: req is undefined.";
		}
		if (req.session && req.session.userdata && req.session.userdata.userid) {
			req.body.username = req.session.userdata.userid;
			let userData = await this.getUserData(req);
			return userData
		} else
		if (req.session && req.session.user)
		{
			return {userid: req.session.user};
		}
		else
		{
			return "";
		}
	}

	async contactRequest (req) {
		logger.debug("app.js:fn:contactRequest");
		let err, result, query;
		let subscriber_id = await CleanSubscriberID(null,req);
		let location_number = Dbfunctions.CleanInputData(req.body.location_number);
		if (isNaN(location_number) || location_number < 1) {
			// failsafe -- TODO: need to add code to read location_number from a different source if location_number isn't set
			logger.warn("app.js:fn:contactRequest: location_number not set -- setting to 1");
			location_number = 1;
		}
		let contactRequestData = req.body.form_data;

		query=`SELECT * FROM subscriber_server_data WHERE subscriber_id='${subscriber_id}' AND feature_id='notification'`;
		[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if(err) {
			logger.error(`app.js:fn:contactRequest: Error: ${err}`);
			return {success: false, status:"error", cause:"unknown", code:err.code, err: err};
		}
		let notification_settings = {};
		if(result.length > 0) {
			notification_settings = result[0].feature_data;
		}
		query=`SELECT * FROM subscriber_locations WHERE subscriber_id='${subscriber_id}' AND location_number = '${location_number}'`;
		[err, result] = await to(this.P_GetQueryData(query, null,this.ReturnSingleMySQLRow));
		if(err) {
			logger.error(`app.js:fn:contactRequest: Error: ${err.message}`,{subscriber_id: req.session.subscriber_id, err:err});
			return {success: false, status: "error", cause:"unknown", code:err.code, err: err};
		}
		let subscriber_location_data = result;
		if (subscriber_location_data === null) {
			logger.warn(`/contactRequest: Failed to retrieve subscriber_location. subscriber_id: ${subscriber_id} location_number: ${location_number} user ip: ${req.ip}`);
			return {success: false, status:"error", cause:"failure to retrieve subscriber_location"};
		}

		// save to database here.

		let contact_record = {};
		contact_record.subscriber_id = subscriber_id;
		if (req.session.userdata && req.session.userdata.userid) {
			contact_record.user_id = req.session.userdata.userid;
		} else {
			contact_record.user_id = null;
		}
		let dt = new Date();
		contact_record.contact_time = dt.toISOString().substring(0, 10) + " " + dt.toISOString().substring(11, 19);
		let fdata = contactRequestData;
		fdata.location_number = req.body.location_number;
		fdata.series_code = req.body.series_code;
		contact_record.email = fdata.email;
		contact_record.data = JSON.stringify(fdata);

		query = "INSERT INTO user_contact_requests SET ?";
		query = mysql.format(query,contact_record);
		[err, result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
		if(err) {
			logger.error(`app.js:fn:contactRequest: Error saving conact request: ${err}`,{subscriber_id: req.session.subscriber_id, err:err, query: query});
		}

		let userData = {};
		if (req.session.userdata) {
			userData = req.session.userdata;
			delete userData.password;
			delete userData.passwordhash;
			delete userData.username;
		}

		if (notification_settings.contact_webhook && notification_settings.contact_webhook_url) {
			let webHook = new WebHooks({
				db: {contactrequest: [notification_settings.contact_webhook_url]}
			});
			let locationData = {};
			try {
				locationData.location_number = subscriber_location_data.location_number;
				locationData.name = subscriber_location_data.name;
				locationData.address = subscriber_location_data.address;
			}
			catch (err) {
				logger.error(`app.js:fn:contactRequest - Error with subscriber_location_data: ${JSON.stringify(subscriber_location_data)} err: ${err}`);
				logger.warn("setting failsafe values.",{subscriber_id: req.session.subscriber_id});
				let default_location = deepFind(req.session,"subscriber_data.data.default_location") || 1;
				locationData.location_number = default_location;
				locationData.name = "Default";
				locationData.address = "Unable to retrieve location address.";
			}

			webHook.trigger('contactrequest', {locationData: locationData, userData: userData, contactRequestData: contactRequestData});
		}
		if (!notification_settings.no_contact_email) {
			if (!notification_settings.contact_html_email_template) {
				notification_settings.contact_html_email_template = defaultContactNotificationEmail("html");
			}

			if (!notification_settings.contact_text_email_template) {
				notification_settings.contact_text_email_template = defaultContactNotificationEmail("text");
			}
			let subscriber_contact_email = subscriber_location_data.n_email;
			if (deepFind(userData,"data.assigned_rep")) {
				query = "SELECT * FROM subscriber_locations WHERE subscriber_id = ? AND location_number = ?";
				query = mysql.format(query,[userData.subscriber_id,userData.location_number]);
				[err,result] = await to(this.P_GetQueryData(query, null, this.ReturnSingleMySQLRow));
				if (err) {
					logger.error("Error retrieving subscriber_locations",err);
				}
				if (deepFind(result,"data.notifications.available_reps") && result.data.notifications.available_reps.includes[userData.dada.assigned_rep]) {
					subscriber_contact_email = userData.data.assigned_rep;
				} else {
					userData.data.assigned_rep = subscriber_contact_email;
					query = "UPDATE users SET data = ? WHERE userid = ?";
					query = mysql.format(query,[JSON.stringify(userData.data),userData.userid]);
					[err,result] = await to(this.P_GetQueryData(query, null, this.MySQLActionResult));
					if (err) {
						logger.error("Error updating user record",err);
					}
				}
			}

			let Subject = `3D Customer Contact Request: ${contactRequestData.first_name} ${contactRequestData.last_name}`;
			let htmlMsg = fillTemplate(notification_settings.contact_html_email_template,{contactRequestData: contactRequestData, userData: userData});
			let textMsg = fillTemplate(notification_settings.contact_text_email_template,{contactRequestData: contactRequestData, userData: userData});

			let email_msg = {
				from: 'sheddesigner@3dfish.net',
				// to: 'info@3dfish.net', // An array if you have multiple recipients.
				to: subscriber_contact_email,
				subject: Subject,
				replyTo: 'noreply@3dfish.net',
				html: htmlMsg,
				text: textMsg,
			};
			if (deepFind(subscriber_location_data.data,"notificationcc")) {
				email_msg.cc = subscriber_location_data.data.notificationcc;
			}
			[err, result] = await to(this.nodemailerMailgun.sendMail(email_msg));
		}

		return {success: true};

	}

	async getUserIDbyEmail(req) {
		logger.debug("fn:getUserIDbyEmail");
		let email, query, err, result, prefix;
		let subscriber_id = await CleanSubscriberID(null,req);
		if (req.session && req.session.subscriber_data) {
			prefix = req.session.subscriber_data.design_prefix;
		} else {
			[err, result] = await to(getSubscriberData(req, subscriber_id));
			if (err) {
				console.log("app.js:fn:getUserIDbyEMail error: ",err);
				throw err;
			}
			prefix = req.session.subscriber_data.design_prefix;
		}
		if (req.body.email || (req.body.formData && req.body.formData.email)) {
			email = req.body.email || deepFind(req.body,"formData.email");
			email = email.toLowerCase();
		} else {
			return {successs: false, status: "Error", err: "no email address supplied."};
		}
		query = `SELECT userid, with_prefix FROM users WHERE subscriber_id = '${subscriber_id}' AND email = ?`;
		query = mysql.format(query,[email]);
		[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if (err) {
			console.log("app.js:fn:getUserIDbyEMail error: ",err);
			throw err;
		}
		if (result.length > 0) {
			if (result.length === 1) {
				let userData;
				query = `SELECT * FROM users WHERE userid = '${result[0].userid}'`;
				[err,userData] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
				if (err) {
					console.log("app.js:fn:getUserIDbyEMail error: ",err);
					throw err;
				}
				if (["master","sadmin","admin","staff"].includes(deepFind(req,"session.userdata.usertype"))) {
					req.session.userdata = userData;
					req.session.userdata_date = new Date();
				}
			}
			return {success: true, status: "success", user_list: result};
		}
		query = `SELECT userid, with_prefix FROM users WHERE subscriber_id = '${subscriber_id}' AND userid=?`;
		query = mysql.format(query,[prefix+email]);
		[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if (err) {
			console.log("app.js:fn:getUserIDbyEMail error: ",err);
			throw err;
		}
		return {success: true, status: "success", user_list: result};
	}

	async autoRegister(req) {
		logger.debug("app.js:fn:autoRegister");
		let query, err, result, formData, email;
		let userData = {};
		let prefix = "";
		let password = "";
		let subscriber_id = await CleanSubscriberID(null,req);
		if (req.body.formData && req.body.formData.email) {
			email = req.body.formData.email.toLowerCase();
			formData = req.body.formData;
		} else {
			logger.warn(`app.js:fn:autoRegister No email address supplied.`);
			return {successs: false, status: "Error", err: "no email address supplied."};
		}
		if (req.session && req.session.subscriber_data) {
			prefix = req.session.subscriber_data.design_prefix;
		} else {
			await getSubscriberData(req, subscriber_id);
		}
		// check for matching email
		query = `SELECT * FROM users WHERE subscriber_id = '${subscriber_id}' AND email=?`;
		query = mysql.format(query,[email]);
		[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if (err) {
			logger.error(`app.js:fn:autoRegister Error:`,{err:err});
			return {successs: false, status: "Error", err: err};
		}
		if (result.length > 0) {
			return {successs: false, status: "Error", errno: 1, err: "User with this email already exists."};
		}
		// check userid
		query = `SELECT * FROM users WHERE subscriber_id = '${subscriber_id}' AND userid=?`;
		query = mysql.format(query,[prefix+"_"+email]);
		[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if (err) {
			logger.error(`app.js:fn:autoRegister Error: ${err.message}`,{err:err});
			return {successs: false, status: "Error", err: err};
		}
		if (result.length > 0) {
			return {successs: false, status: "Error", errno: 2, err: "User email id already exists."};
		}
		password = generatePassword(6);
		password += generatePassword(3,false,/\d/);
		userData.passwordhash = md5(password);
		userData.userid = prefix + "_" + Dbfunctions.CleanInputData(email);
		userData.firstname = Dbfunctions.CleanInputData(formData.first_name);
		userData.lastname = Dbfunctions.CleanInputData(formData.last_name);
		userData.email = Dbfunctions.CleanInputData(email);
		userData.address = formData.delivery_address ? Dbfunctions.CleanInputData(formData.delivery_address):null;
		userData.city = formData.postal_code_data ? Dbfunctions.CleanInputData(formData.postal_code_data.city):null;
		userData.state = formData.postal_code_data ? Dbfunctions.CleanInputData(formData.postal_code_data.statecode):null;
		userData.phone1 = Dbfunctions.CleanInputData(formData.phone);
		userData.zip = Dbfunctions.CleanInputData(formData.delivery_zipcode);
		userData.usertype = "user";
		userData.with_prefix = 1;
		userData.subscriber_id = subscriber_id;
		userData.data = {};
		if (req.session.location_number) {
			if (req.session.location_number > 0) {
				userData.location_number = req.session.location_number;
			} else {
				let default_location = deepFind(req.session,"subscriber_data.data.default_location") || 1;
				userData.location_number = default_location;
				logger.warn(`app.js:autoRegister - location_number not set (1), setting to ${default_location}`);
			}
		} else {
			let default_location = deepFind(req.session,"subscriber_data.data.default_location") || 1;
			userData.location_number = default_location;
			logger.warn(`app.js:autoRegister - location_number not set (2), setting to ${default_location}`);
		}
		userData.signup_date = dateFormat(new Date (), "%Y-%m-%d", true);
		userData.last_access = dateFormat(new Date (), "%Y-%m-%d %H:%M:%S", true);

		query = "SELECT * FROM subscriber_locations WHERE subscriber_id = ? AND location_number = ?";
		query = mysql.format(query,[subscriber_id,userData.location_number]);
		[err, result] = await to(this.P_GetQueryData(query, null, this.ReturnSingleMySQLRow));
		if (err) {
			throw err;
		}
		if (deepFind(result,"sdata.notifications.list")) {
			userData.data.assigned_rep = result.n_email;
			let currentRep = result.sdata.notifications.list.indexOf(result.n_email);
			if (currentRep >= result.sdata.notifications.list) {
				currentRep = 0;
			} else {
				currentRep++;
			}
			let nextRepEmail = result.sdata.notifications.list[currentRep];
			if (nextRepEmail) {
				query = "UPDATE subscriber_locations SET n_email = ? WHERE subscriber_id = ? AND location_number = ?";
				query = mysql.format(query,[nextRepEmail,subscriber_id,result.location_number]);
				[err, result] = await to(this.P_GetQueryData(query, null, this.MySQLActionResult));
				if (err) {
					logger.error("Error writing new contact rotation",err);
				}
			}
		}

		query = `INSERT INTO users SET ?`;
		userData.data = JSON.stringify(userData.data);
		query = mysql.format(query,[userData]);
		userData.data = JSON.parse(userData.data);
		delete userData.password;

		[err, result] = await to(this.P_GetQueryData(query, null, ParseRegistrationResult));
		if(err) {
			if(err.code == "ER_DUP_ENTRY") {
				logger.warn(`app.js:fn:autoRegister Duplicate record detected.`);
				return {success: false, status:"error", err: err, cause:"duplicate record detected"};  // notify app of duplicate
			} else {
				logger.error(`Location: app.js:/autoRegister, App Error: ${err}`,{err: err});
				throw err;
				//res.send({status:"error", cause:"unknown", code:err.code, err:err});
				//res.status(500).send("Internal Server Error: "+err);
				//return;
			}
		}
		if (!["master","sadmin","admin","staff"].includes(deepFind(req,"session.userdata.usertype"))) {
			req.session.user = userData.userid;
			req.session.userdata = userData;
			req.session.userdata_date = new Date();
		}
		// get server feature notification data
		query=`SELECT * FROM subscriber_server_data WHERE subscriber_id='${subscriber_id}' AND feature_id='notification'`;
		[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if(err) {
			logger.error(`app.js:fn:autoRegister Error: ${err.message}`,{err: err});
			return {success: false, status:"error", cause:"unknown", code:err.code, err: err};
		}
		let notification_settings = {};
		if(result.length > 0) {
			notification_settings = result[0].feature_data;
		}
		// this sets up the info for sending the email
		if (!notification_settings.auto_registration_html_email_template) {
			notification_settings.auto_registration_html_email_template = defaultAutoRegistrationNotificationEmail("html");
		}

		if (!notification_settings.auto_registration_text_email_template) {
			notification_settings.auto_registration_text_email_template = defaultAutoRegistrationNotificationEmail("text");
		}
		userData.password = password;
		//let subscriber_contact_email = data.email;
		let Subject = `Storage Shed Account Password from ${req.session.subscriber_data.name}`;
		let htmlMsg = fillTemplate(notification_settings.auto_registration_html_email_template,{userData: userData});
		let textMsg = fillTemplate(notification_settings.auto_registration_text_email_template,{userData: userData});

		let email_msg = {
			from: 'sheddesigner@3dfish.net',
			// to: 'info@3dfish.net', // An array if you have multiple recipients.
			to: userData.email,
			subject: Subject,
			replyTo: 'noreply@3dfish.net',
			html: htmlMsg,
			text: textMsg
		};
		[err, result] = await to(this.nodemailerMailgun.sendMail(email_msg));
		if (err) {
			logger.error(`app.js:fn:autoRegister Error: ${err}`,{err: err});
		} else {
			//console.log('Response: ' + JSON.stringify(result));
			logger.info('autoRegister Response: ' + JSON.stringify(result));
		}
		return {success: true, userid: userData.userid, userData: userData};
	}

	async register(req) {
		this.logger.debug("app.js:fn:register");
		let userData = {};
		//let subscriber_location_number = "";
		let err, result, regResult, data, query;

		let subscriber_id = await CleanSubscriberID(null,req);
		let subscriber = mysql.escape(subscriber_id);
		//subscriber_location_number = mysql.escape(req.body.location_number);

		userData.signup_date = dateFormat(new Date (), "%Y-%m-%d", true);
		userData.last_access = dateFormat(new Date (), "%Y-%m-%d %H:%M:%S", true);

		const PLUS_CODE = "PLUS_C@";

		req.body.email = req.body.email.replace(new RegExp(PLUS_CODE, "g"), "+");
		//userData.email = mysql.escape(req.body.email.toLowerCase());

		userData.password = req.body.password;

		userData.location_number = Dbfunctions.CleanInputData(req.body.location_number);
		if (userData.location_number < 1) {
			if (req.session.location_number && req.session.location_number > 0) {
				userData.location_number = req.session.location_number;
				logger.warn(`app.js:fn:register: Location number set from session data: ${subscriber_id} - ${req.session.location_number}`);
			} else {
				let default_location = deepFind(req.session,"subscriber_data.data.default_location") || 1;
				userData.location_number = default_location;
				subscriber_location_number = `'${default_location}'`;
				logger.warn(`app.js:fn:register: Location number not set. Setting to ${default_location}.`,{session:req.session, body: req.body});
			}
		}

		userData.username = Dbfunctions.CleanInputData(req.body.username);
		userData.firstname = Dbfunctions.CleanInputData(req.body.firstname);
		userData.lastname = Dbfunctions.CleanInputData(req.body.lastname);
		userData.email = Dbfunctions.CleanInputData(req.body.email.toLowerCase());
		userData.zip = Dbfunctions.CleanInputData(req.body.zip);
		userData.with_prefix = false;
		userData.usertype = "user";

		if (req.session && req.session.postal_code_data) {
			if (req.session.postal_code_data.country_code == "US") {
				userData.city = req.session.postal_code_data.city;
				userData.state = req.session.postal_code_data.statecode;
			}
		}

		userData.username = userData.username.replace(new RegExp(PLUS_CODE, "g"), "+");

		userData.userid = userData.username;

		// check for existing user email
		query=`SELECT * FROM users WHERE email='${userData.email}' AND subscriber_id=${subscriber}`;
		[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if(err) {
			return {success: false, status:"error", cause:"unknown", code:err.code, err: err};
		} else if(result.length > 0) {
			return {status:"error", cause:"existing"};
		}

		// get subscriber data
		query=`SELECT * FROM subscribers WHERE subscriber_id=${subscriber}`;
		[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if(err) {
			console.log("Error checking subscriber_id on register:",err);
			return {success: false, status:"error", cause:"unknown", code:err.code, err: err};
		} else if(result.length == 0) {
			return {success: false, status:"error", cause:"unknown", code:"000", err:"unable to retrieve subscriber data."};
		}
		let subscriber_data = result[0];

		// get server feature notification data
		query=`SELECT * FROM subscriber_server_data WHERE subscriber_id=${subscriber} AND feature_id='notification'`;
		[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if(err) {
			return {success: false, status:"error", cause:"unknown", code:err.code, err: err};
		}
		let notification_settings = {};
		if(result.length > 0) {
			notification_settings = result[0].feature_data;
		}

		// check for existing user id
		query=`SELECT * FROM users WHERE userid='${userData.userid}' OR userid='${subscriber_data.design_prefix}_${userData.userid}'`;
		[err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if(err) {
			return {success: false, status:"error", cause:"unknown", code:err.code, err: err};
		} else if(result.length > 0) {
			return {status:"error", cause:"duplicate"};
		}
		let domain_userid = subscriber_data.design_prefix + "_" + userData.userid;
		userData.subscriber_id = subscriber_data.subscriber_id;
		userData.with_prefix = true;

		if ((!userData.firstname || !userData.lastname || !userData.email || !userData.username || !userData.password) || (userData.firstname.length==0 || userData.lastname.length==0 || userData.email.length==0 || userData.username.length==0 || userData.password.length==0))
		{
			logger.warn("app.js:fn:register: Missing Data",{subscriber_id: req.session.subscriber_id});
			return '{"status": "Error", "Description": "Required Field Missing."}';
		}
		else
		{
			req.body.postalCode = userData.zip;
			[err, result] = await to(this.checkPostalCode(req));
			if ((!err) && result.validzip) {
				userData.city = result.postal_code_data.city;
				userData.state = result.postal_code_data.statecode;
			} else {
				userData.city = null;
				userData.state = null;
			}
			let userRecord = {
				subscriber_id: subscriber_id,
				location_number: userData.location_number,
				zip: userData.zip,
				signup_date: userData.signup_date,
				last_access: userData.last_access,
				firstname: userData.firstname,
				lastname: userData.lastname,
				email: userData.email,
				userID: domain_userid,
				with_prefix: userData.with_prefix,
				usertype: "user",
				passwordhash: userData.password,
				city: userData.city,
				state: userData.state,
				data: {}
			};

			let query = "SELECT * FROM subscriber_locations WHERE subscriber_id = ? AND location_number = ?";
			query = mysql.format(query,[subscriber_id,userData.location_number]);
			let locationData;
			[err, locationData] = await to(this.P_GetQueryData(query, null, this.ReturnSingleMySQLRow));
			if (err) {
				throw err;
			}
			if (deepFind(locationData,"sdata.notifications.list")) {
				userRecord.data = {
					assigned_rep: locationData.n_email
				};
				let currentRep = locationData.sdata.notifications.list.indexOf(locationData.n_email);
				if (currentRep >= locationData.sdata.notifications.list) {
					currentRep = 0;
				} else {
					currentRep++;
				}
				let nextRepEmail = locationData.sdata.notifications.list[currentRep];
				query = "UPDATE subscriber_locations SET n_email = ? WHERE subscriber_id = ? AND location_number = ?";
				query = mysql.format(query,[nextRepEmail,subscriber_id,locationData.location_number]);
				[err, result] = await to(this.P_GetQueryData(query, null, this.MySQLActionResult));
				if (err) {
					logger.error("Error writing new contact rotation",err);
				}
			}

			query = "INSERT INTO users SET ?";
			userRecord.data = JSON.stringify(userRecord.data);
			query = mysql.format(query,[userRecord]);
			userRecord.data = JSON.parse(userRecord.data);
			req.session.userdata = userRecord;
			req.session.userdata_date = new Date();

			[err, regResult] = await to(this.P_GetQueryData(query, null, ParseRegistrationResult));
			if(err) {
				if(err.code == "ER_DUP_ENTRY") {
					return {status:"error", cause:"duplicate"};  // notify app of duplicate
				} else {
					logger.error(`app.js:fn:register, Error: ${err.message}`,err);
					throw err;
				}
			}
			{
				if(regResult.status == "Success") {
					if (!userData.userid) {
						logger.warn("app.js:fn:register: Error - userid not defined.",{subscriber_id: req.session.subscriber_id});
					}
					//let query = `SELECT * FROM subscriber_locations WHERE subscriber_id = ${subscriber} AND location_number = ${userData.location_number}`;
					//logger.debug(query);

					if (notification_settings.register_webhook) {
						let webHook = new WebHooks({
							db: {register: [notification_settings.register_webhook_url]}
						});
						delete userData.password;
						delete userData.username;
						webHook.trigger('register', userData);
					}
					if (!notification_settings.no_registration_email) {
						// this sets up the info for sending the email
						if (!notification_settings.registration_html_email_template) {
							notification_settings.registration_html_email_template = defaultRegistrationNotificationEmail("html");
						}

						if (!notification_settings.registration_text_email_template) {
							notification_settings.registration_text_email_template = defaultRegistrationNotificationEmail("text");
						}
						let subscriber_contact_email = locationData.n_email;
						if (deepFind(userRecord,"data.assigned_rep")) {
							subscriber_contact_email = userRecord.data.assigned_rep;
						}
						let subscriber_contact_ccemail = deepFind(locationData,"data.notificationcc")
						let Subject = `3D Customer Registration: ${userData.firstname} ${userData.lastname}`;
						let htmlMsg = fillTemplate(notification_settings.registration_html_email_template,{userData: userData});
						let textMsg = fillTemplate(notification_settings.registration_text_email_template,{userData: userData});

						let email_msg = {
							from: 'sheddesigner@3dfish.net',
							to: subscriber_contact_email,
							subject: Subject,
							replyTo: 'noreply@3dfish.net',
							html: htmlMsg,
							text: textMsg
						};
						if (subscriber_contact_ccemail) {
							email_msg.cc = subscriber_contact_ccemail;
						}
						[err, result] = await to(this.nodemailerMailgun.sendMail(email_msg));
						if (err) {
							logger.warn(`app.js:fn:register, subscriber_contact_email: ${subscriber_contact_email} - Error: ${err}`, {subscriber_id: req.session.subscriber_id});
						} else {
							logger.info(`Response: ${JSON.stringify(result)}`,{subscriber_id: req.session.subscriber_id});
						}

						req.session.user = userData.username;

						logger.debug("GetSubscriberEmail and Process Registration success!");

						req.session.userdata = userData;
						return {success: true, status: "success", userData: userData};
					} else {
						req.session.userdata = userData;
						return {success: true, status: "success", userData: userData};
					}
				}
			}
		}

	}

	async getUserData(req) {
		logger.debug("fn:getUserData");

		let username = mysql.escape(req.body.username);
		username = username.substr(1, username.length-2);

		if (req.session && req.session.userdata && req.session.userdata.userid) {
			if ((req.session.userdata.userid === username) || (username === req.session.userdata.userid.substring(req.session.userdata.userid.indexOf("_")+1,req.session.userdata.userid.length)));
			{
				if (req.session.userdata_date && (!req.session.userdata_date.getTime)) {
					req.session.userdata_date = new Date(req.session.userdata_date);
				}
				if (req.session.userdata_date && ((new Date().getTime() - req.session.userdata_date.getTime()) / 60000 < 5)) {
					logger.debug("less than 5 minutes since userdata update.");
					let sessionUserData = req.session.userdata;
					sessionUserData.passwordhash = '';
					return sessionUserData;
				} else {
					logger.debug("userdata over 5 minutes old ... refreshing...");
					let [err,userData] = await to(this.loadUserData(req,req.session.userdata.userid));
					if (err) {
						throw err;
					}
					if (userData === null) {
						logger.warn("app.js:fn:getUserData: Unable to find userid: req.session.userdata.userid: ",req.session.userdata.userid);
						delete req.session.userdata;
						return "";
					}
					req.session.userdata = userData;
					let sessionUserData = req.session.userdata;
					req.session.userdata_date = new Date();
					sessionUserData.passwordhash = '';
					return sessionUserData;
				}
				/* let sessionUserData = req.session.userdata;
				sessionUserData.passwordhash = '';
				return sessionUserData; */
			}
		} else
		if (req.session && req.session.user)
		{
			if (req.session.user === username)
			{
				let sessionUserData = req.session.userdata;
				if (sessionUserData) {
					sessionUserData.passwordhash = '';
				} else {
					logger.warn("app.js:fn:getUserData: req.session.user is set, but req.session.userdata is undefined.", req.session);
				}
				return sessionUserData;
			}
			else
			{
				return "";
			}
		}
		else
		{
			return "";
		}
	}

	async setZipCode(req) {
		logger.debug("app.js:fn:setZipCode");
		let query;
		let err;
		let data;

		let subscriber = mysql.escape(await CleanSubscriberID(null,req));

		let zipCode = mysql.escape(req.body.zipCode);

		zipCode = zipCode.substr(1, zipCode.length - 2);

		if (!zipCode || zipCode=="")
		{
			return {validzip: false, reason: "no postal code submitted." };
		}
		else
		{
			if (this.invalidZipCache.includes(zipCode)) {
				return {validzip: false, success: false, status: "fail", error: false, cached: true};
			}
			query = "SELECT * FROM uszipcodes WHERE zipcode='" + zipCode + "'";

			[err, data] = await to(this.P_GetQueryDataReq(query, ParseZipCodeRowData, ParseZipCodeRowsData, req));
			if(err) {
				console.log("Error Location: app.js:fn:setZipCode");
				return {validzip: false, success: false, status: "fail", error: true, err: err};
			}
			if(!data.validzip) {
				data.zip = zipCode;
				if (this.invalidZipCache.length > 100) {
					this.invalidZipCache.shift();
				}
				this.invalidZipCache.push(zipCode);
				return data;
			}
			let postal_code_data = data.postal_code_data;
			req.session.zipCode = req.body.zipCode;

			req.session.postal_code_data = postal_code_data;

			req.session.latitude = postal_code_data.latitude;
			req.session.longitude = postal_code_data.longitude;

			query = "SELECT * FROM subscriber_locations WHERE subscriber_id=" + subscriber + " AND active";
			[err, data] = await to(this.P_GetQueryDataReq(query, null, SelectSubscriberLocation,req));
			if(err) {
				console.log("Error Location: app.js/setZipCode");
				return {validzip: false, success: false, status: "fail", error: true, err: err};
			}
			data.postal_code_data = postal_code_data;

			if (req.session.userdata && !req.session.userdata.zip) {
				// set zipcode in user record if zipcode missing for logged in user
				//console.log(req.session.userdata);
				let result;
				query = "UPDATE users SET zip = ? WHERE userid = ?";
				query = mysql.format(query,[req.body.zipCode,req.session.userdata.userid]);
				[err, result] = await to(this.P_GetQueryData(query, null, this.MySQLActionResult));
				req.session.userdata.zip = req.body.zipCode;
			}
			return data;
		}
	}

	async getZipCode(req) {
		logger.debug("fn:getZipCode");
		let subscriber_id = await CleanSubscriberID(null,req);

		if (req.session && req.session.zipCode)
		{
			if (this.invalidZipCache.includes(req.session.zipCode)) {
				return {validzip: false, success: false, status: "fail", error: false, cached: true};
			}
			let query = `SELECT * FROM subscriber_locations WHERE subscriber_id='${subscriber_id}' AND active`;
			let [err, data] = await to(this.P_GetQueryDataReq(query, null, SelectSubscriberLocation,req));
			if(err) {
				logger.error(`Error Location: ${THIS_FILE}/getZipCode`,{err:err});
				// res.send({validzip: false, success: false, status: "fail", error: true, err: err});
				return {validzip: false, success: false, status: "fail", error: true, err: err};
			}
			data.zipCode = req.session.zipCode;
			data.postal_code = data.zipCode;

			if(req.session && req.session.postal_code_data) {
				data.postal_code_data = req.session.postal_code_data;
			} else {
				let result;
				query = "SELECT * FROM uszipcodes WHERE zipcode = ?";
				query = mysql.format(query,req.session.zipCode);
				[err, result] = await to(this.P_GetQueryDataReq(query, ParseZipCodeRowData, ParseZipCodeRowsData, req));
				if(err) {
					logger.error(`Error Location: ${THIS_FILE}/getZipCode`,{err:err});
					// res.send({validzip: false, success: false, status: "fail", error: true, err: err});
					return {validzip: false, success: false, status: "fail", error: true, err: err};
				}
				if(!result.validzip) {
					if (this.invalidZipCache.length > 100) {
						this.invalidZipCache.shift();
					}
					this.invalidZipCache.push(req.session.zipCode);
					return data;
				}
				data.postal_code_data = result.postal_code_data;
				req.session.postal_code_data = data.postal_code_data;
			}

			if (!req.session.master_test) {
				LogAccess(req);
			}
			return data;
		}
		else
		{
			return {validzip: false, success: false, status: "fail", error: true, err: "No zipcode stored for session."};
		}
	}

	async GetSubscriberEMail(err, rows, currentDataRowParser) {
		if (DEBUG) {
			logger.debug("GetSubscriberEmail");
			if (currentDataRowParser) {
				logger.warn("currentDataRowParser parameter set -- This is unused.");
			}
		}

		try {
			if (!err && rows && rows.length > 0) {
				let subscriber_contact_email = rows[0].n_email;
				return {
					status: "Success",
					email: subscriber_contact_email
				};
			} else {
				if (err) {
					logger.error(`GetSubscriberEmail error: ${err}`);
				} else {
					logger.debug("Subscriber EMail not found.")
				}

				return {
					status: "Error",
					description: "No record found."
				};
			}
		} catch (ex) {
			logger.error(`GetSubscriberEmail exception: ${ex}`);
			return {
				status: "Error",
				description: "Registration Exception!"
			};
		}
	};

	async GetSubscriberEmailAndProcessSavedDesign(err, rows, currentDataRowParser, req) {
		logger.debug("GetSubscriberEmailAndProcessSavedDesign");
		if (err) {
			logger.error(`Error passed to GetSubscriberEmailAndProcessSavedDesign: ${err}`);
		}
		let errResult, result, query;
		let userData = req.session.userdata;
		//console.log("fn:GetSubscriberEmailAndProcessSavedDesign:userData",userData);
		if (typeof userData !== "object") {
			userData = null;
		}
		if (userData === null) {
			logger.warn(`fn:GetSubscriberEmailAndProcessSavedDesign - loading user data: ${req.fd_userID}`);
			[errResult, userData] = await to(this.loadUserData(req, req.fd_userID));
			if (errResult) {
				logger.error(`fn:GetSubscriberEmailAndProcessSavedDesign - Error loading User Data. Subscriber_id: ${req.session.subscriber_id} userid: ${req.fd_userID}`);
				userData = {};
				userData.subscriber_id = req.session.subscriber_id;
				userData.firstname = "Error";
				userData.lastname = "Retrieving";
				userData.email = "info@3dfish.net";
				userData.userid = req.fd_userID;
			} else {
				req.session.userdata = userData;
			}
		}
		let design_id = req.design_id;
		let building_style = req.fd_building_name;
		let building_size = req.fd_building_width + "x" + req.fd_building_length;
		let designData = {};
		designData.design_id = design_id;
		designData.building_style = building_style;
		designData.building_size = building_size;
		designData.design_id = design_id;
		designData.designNameForWeb = req.fd_designNameForWeb;
		designData.series_code = req.fd_series_code;
		designData.subscriber_id = req.session.subscriber_id;

		userData.username = userData.firstname + " " + userData.lastname;

		if (userData.data && userData.data.prevent_save_notification) {
			logger.info("user save notification disabled for this user -- no notification sent.");
			return {
				result: "save success!",
				design_id: design_id,
				status: "success",
				success: true
			};
		}

		try {
			if (!err && rows && rows.length > 0) {
				// get server feature notification data
				query = `SELECT * FROM subscriber_server_data WHERE subscriber_id='${userData.subscriber_id}' AND feature_id='notification'`;
				[errResult, result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (errResult) {
					return {
						success: false,
						status: "error",
						cause: "unknown",
						code: err.code,
						err: errResult
					};
				}
				let notification_settings = {};
				if (result.length > 0) {
					notification_settings = result[0].feature_data;
				}

				if (notification_settings.design_save_webhook) {
					let webHook = new WebHooks({
						db: {
							designsave: [notification_settings.design_save_webhook_url]
						}
					});
					delete userData.password;
					delete userData.passwordhash;
					delete userData.username;
					webHook.trigger('designsave', {
						userData: userData,
						designData: designData
					});
				}

				if (!notification_settings.no_design_save_email) {
					if (!notification_settings.server_name) {
						notification_settings.server_name = "mybuilding.3dfish.net";
					}

					if (!notification_settings.design_save_html_email_template) {
						notification_settings.design_save_html_email_template = defaultSaveNotificationEmail("html");
					}

					if (!notification_settings.design_save_text_email_template) {
						notification_settings.design_save_text_email_template = defaultSaveNotificationEmail("text");
					}

					let subscriber_contact_email = rows[0].n_email;
					if (deepFind(userData,"data.assigned_rep")) {
						query = "SELECT * FROM subscriber_locations WHERE subscriber_id = ? AND location_number = ?";
						query = mysql.format(query,[userData.subscriber_id,userData.location_number]);
						[err,result] = await to(this.P_GetQueryData(query, null, this.ReturnSingleMySQLRow));
						if (err) {
							logger.error("Error retrieving subscriber_locations",err);
						}
						if (deepFind(result,"data.notifications.available_reps") && result.data.notifications.available_reps.includes[userData.dada.assigned_rep]) {
							subscriber_contact_email = userData.data.assigned_rep;
						} else {
							userData.data.assigned_rep = subscriber_contact_email;
							query = "UPDATE users SET data = ? WHERE userid = ?";
							query = mysql.format(query,[JSON.stringify(userData.data),userData.userid]);
							[err,result] = await to(this.P_GetQueryData(query, null, this.MySQLActionResult));
							if (err) {
								logger.error("Error updating user record",err);
							}
						}
					}
					let subscriber_cc_email = deepFind(rows[0].data, "notificationcc");

					// this sets up the info for sending the email
					let Subject = '3D Customer Design Saved: ' + design_id;
					let htmlMsg = fillTemplate(notification_settings.design_save_html_email_template, {
						userData: userData,
						designData: designData,
						info: notification_settings
					});
					let textMsg = fillTemplate(notification_settings.design_save_text_email_template, {
						userData: userData,
						designData: designData,
						info: notification_settings
					});

					let email_msg = {
						from: 'sheddesigner@3dfish.net',
						// to: 'info@3dfish.net', // An array if you have multiple recipients.
						to: subscriber_contact_email,
						subject: Subject,
						replyTo: 'noreply@3dfish.net',
						html: htmlMsg,
						text: textMsg
					}
					if (subscriber_cc_email) {
						email_msg.cc = subscriber_cc_email;
					}
					[errResult, result] = await to(this.nodemailerMailgun.sendMail(email_msg));
					if (errResult) {
						// TODO: Process error sending email
						logger.error(`fn:GetSubscriberEmailAndProcessSavedDesign - Error sending email: ${errResult}`);
					}
					logger.debug(`email send result: ${JSON.stringify(result)}`);
				}

				req.session.user = userData.username;

				logger.debug("GetSubscriberEmailAndProcessSaveDesign success!");

				return {
					result: "save success!",
					design_id: design_id,
					status: "success",
					success: true
				};
			} else {
				if (err) {
					logger.error("fn:GetSubscriberEmailAndProcessSaveDesign error received from calling function: ${err}");
				} else {
					logger.warn(`fn:GetSubscriberEmailAndProcessSaveDesign no row data received from calling function.`);
				}

				return {
					result: "save design error!",
					design_id: design_id,
					status: "failed",
					success: false
				};
			}
		} catch (ex) {
			logger.error(`fn:GetSubscriberEmailAndProcessSaveDesign exception: ${ex.toString()}`);

			return {
				result: "save design exception!",
				design_id: design_id,
				status: "failed",
				success: false
			};
		}
	};

	/**
	 * Load the user data for a userid
	 * @param {object} req request record
	 * @param {string} user_id user id string with or without prefix
	 * @returns {object} user record when userid found
	 * @returns {null} null when userid not found
	 * @throws {object} on sql error
	 */
	async loadUserData(req, user_id) {
		logger.debug("fn:loadUserData");
		let query, result, err;
		query = `SELECT * FROM users WHERE userid = ?`;
		query = mysql.format(query, user_id);
		[err, result] = await to(this.P_GetQueryData(query, null, this.ReturnSingleMySQLRow));
		if (err) {
			throw err;
		}
		if (result) {
			return result;
		}
		if (user_id.indexOf(req.session.subscriber_data.design_prefix + "_") === -1) {
			user_id = req.session.subscriber_data.design_prefix + "_" + user_id;
		}
		query = `SELECT * FROM users WHERE userid = ?`;
		query = mysql.format(query, user_id);
		[err, result] = await to(this.P_GetQueryData(query, null, this.ReturnSingleMySQLRow));
		if (err) {
			throw err;
		}
		return result;
	}

	async checkDesignID(req) {
		logger.debug("app.js:fn:checkDesignID");
		let userData = req.session.userdata;

		let query = "SELECT design_prefix FROM subscribers WHERE subscriber_id = ?";
		query = mysql.format(query, [userData.subscriber_id]);
		let [err, result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowData,this.P_ParseMySqlRowsData));
		if (err) {
			throw err;
		}
		let design_prefix = JSON.parse(result)[0].design_prefix;
		let design_id = design_prefix + "_" + req.body.design_id.replace(/([^a-z0-9\-]+)/gi, "");

		query = "SELECT * FROM usersheds WHERE design_id = ?";
		query = mysql.format(query, [design_id]);
		[err, result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowData,this.P_ParseMySqlRowsData));
		if (result.length > 2) {
			return {
				available: false,
				result: "ID Exists"
			};
		} else {
			return {
				available: true,
				result: "ID Not Found"
			};
		}
		/* 	query = "SELECT * FROM usersheds2 WHERE design_id = '" + design_id + "'";
		[err,result] = await to(P_GetQueryData(query,ParseMySqlRowData,P_ParseMySqlRowsData));
		if(result.length > 2) {
			return {result: "ID Exists"};
		} else {
			return {result: "ID Not Found"};
		} */
	}

	CheckDesignIDAvail(err, rows, currentDataRowParser, req) {
		logger.debug("CheckDesignIDAvail");

		if (rows.length == 0) {
			return {
				status: "Success",
				success: true
			};
		} else {
			return {
				status: "Fail",
				success: false
			}
		}
	};

	generateDesignID (req) {
		let short_design_id = Math.random().toString(36).substr(2, 8);
		let design_id = req.design_prefix + "_" + short_design_id;
		req.design_id = design_id;
		return {design_id: design_id, short_design_id: short_design_id};
	};
}

export async function LogAccess (req)
{
	logger.debug("LogAccess");
	let dt = new Date();
	let t = dt.toISOString().substring(11, 19);
	let d = dt.toISOString().substring(0, 10);
	let user_id = "none";
	let latitude = 0;
	let longitude = 0;
	let distance = 0;
	let cleanZip;
	if (typeof req.ip === "undefined") {
		req.ip = req.session.ip;
	}
	if (req.session.zipCode) {
		// remove all non-digits
		// needs to be changed when supporting alpha-numeric postal-codes
		// db needs to be changed to text field in access_log for postal code when this is done.
		cleanZip = req.session.zipCode.replace(/\D/g,'');
	}
	if (req.session && req.session.user)
	{
		user_id = req.session.user;
		if(user_id.length > 60) {
			console.log("user_id too long: ",user_id);
			user_id = user_id.substring(0,24);
		}
	}
	if (req.session && req.session.latitude)
	{
		latitude = req.session.latitude;
	}
	if (req.session && req.session.longitude)
	{
		longitude = req.session.longitude;
	}
	if (req.session && req.session.location_distance)
	{
		distance = req.session.location_distance;
	}
	let query = `INSERT INTO access_log (ip_address, subscriber_id, user_id, date, time, latitude, longitude, distance, zipcode) VALUES ('${req.ip}' ,'${req.session.subscriber_id}', '${user_id}', '${d}', '${t}', '${latitude}', '${longitude}', '${distance}', '${cleanZip}')`;

	if (req.session.master_test)
	{
		logger.debug("Not Logging - Master Test");
	}
	else
	{
		logger.debug(query);
		let [err, result] = await to(P_GetQueryData(query, null, ParseLogResult));
		if (err) {
			logger.error(`app.js:fn: LogAccess error: ${err}`);
			return;
		}
		return;
	}
};
