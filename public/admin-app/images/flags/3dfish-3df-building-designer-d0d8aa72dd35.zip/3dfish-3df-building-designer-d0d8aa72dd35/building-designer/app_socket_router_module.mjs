/*eslint-env node, es6*/
/*eslint-parserOptions ecmaVersion:2019*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape, no-undef*/

const THIS_FILE = "app_socket_router_module.mjs";

import Dbfunctions from "./dbfunctions.cjs";
import mysql from "mysql2/promise.js";
import to from "togo";
import deepFind from "deep-find";
import _ from "lodash";

import tdfserver from "../package.json";
import { getHostMap, setUserLastAccess } from "./app.mjs";

export class SocketRouterModule {
	constructor(params) {
		this.io = params.io;
		this.designer = params.designerModule;
		this.admin = params.subscriberAdminModule;
		this.master = params.masterAdminModule;
		this.user = params.userModule;
		this.con = params.mysql_connection; // mysql_connection;
		this.tcon = params.mysql_transaction_connection; //mysql_transaction_connection;
		this.logger = params.logger;
		this.DEBUG = params.DEBUG;
		this.redisAdapterActive = params.redisAdapterActive;
		this.mongoAdapterActive = params.mongoAdapterActive;
		this.serverAdapterActive = params.serverAdapterActive;
		this.processID = params.processID;

		this.sessions = {};

		if (this.serverAdapterActive) {
			this.io.of('/').adapter.customHook = (data, cb) => {
				let userData = {};
				this.logger.debug(`customRequest received: ${data.request} processID: ${data.processID}`);
				if (data.processID === this.processID) {
					//cb({processID:processID});
					return;
				}
				if (this.DEBUG) {
					this.io.to("master").emit("serverlog-received", {
						data: data
					});
				}
				if (data && data.request) {
					switch (data.request) {
						case "update": {
							if (!this.sessions[data.subscriber_id]) {
								this.sessions[data.subscriber_id] = {};
							}
							this.sessions[data.subscriber_id][data.socket_id] = data.sessionData;
							break;
						}
						case "connect": {
							if (!this.sessions[data.subscriber_id]) {
								this.sessions[data.subscriber_id] = {};
							}
							this.sessions[data.subscriber_id][data.socket_id] = data.sessionData;
							break;
						}
						case "disconnect": {
							if (this.sessions[data.subscriber_id] && this.sessions[data.subscriber_id][data.socket_id]) {
								delete this.sessions[data.subscriber_id][data.socket_id];
							}
							break;
						}
						case "sessions": {
							cb({
								processID: this.processID,
								sessions: this.sessions
							});
							return;
						}
						case "serverstatus": {
							cb({
								processID: this.processID,
								sessioncount: this.io.engine.clientsCount
							})
						}
					}
				}
				cb({
					processID: this.processID
				});
			}

			this.getSessionsFromServers();
		}

		let connectionCBF = async function (socket) {
			//if (this.DEBUG) console.log('socket.io user connected - ',socket.request.session);
			this.logger.debug('socket.io user connected');
			let userData = {};
			let sessionData = {};
			socket.emit('version', {
				version: tdfserver.version || process.env.npm_package_version || "3.4.1"
			});
			socket.emit('servertime', {
				servertime: new Date()
			});
			if (typeof socket.request.session.subscriber_id === "undefined") {
				sessionData = {
					handshake: socket.handshake
				};
				let [err, hostmap] = await to(getHostMap(socket.request));
				if (err) {
					sessionData.err = err;
				} else {
					this.logger.debug("checking host map");
					if (hostmap) {
						//hostdata.customhost = true;
						let host = socket.handshake.headers.host;
						if (host.indexOf(":") > -1) {
							host = host.substring(0, host.indexOf(":"));
						}
						if (hostmap.host.indexOf(host) > -1) {
							let hostindex = hostmap.host.indexOf(host);
							socket.request.session.host = host;
							let hostdata = {
								...hostmap.data[hostindex]
							};
							//ejsdata.hostdata = hostdata;
							socket.request.session.subscriber_id = hostdata.subscriber_id;
						}
					}
				}
			}
			if (!this.sessions[socket.request.session.subscriber_id]) {
				this.sessions[socket.request.session.subscriber_id] = {};
			}
			if (socket.request.session.user) {
				userData.userid = socket.request.session.user;
			}
			if (socket.request.session.userdata) {
				userData.firstname = socket.request.session.userdata.firstname;
				userData.lastname = socket.request.session.userdata.lastname;
				userData.location_number = socket.request.session.userdata.location_number;
				userData.postal_code = socket.request.session.userdata.zip ? socket.request.session.userdata.zip : socket.request.session.zipCode;
			} else {
				userData.postal_code = socket.request.session.zipCode;
				userData.location_number = socket.request.session.location_number;
			}
			socket.join(socket.request.session.subscriber_id);
			let ip = socket.request.session.ip ? socket.request.session.ip : socket.handshake.address;
			sessionData = {
				...{
					processID: this.processID,
					ip: ip,
					postal_code: userData.postal_code,
					userid: userData.userid,
					firstname: userData.firstname,
					lastname: userData.lastname,
					location_number: userData.location_number,
					appStatus: {}
				}
			};
			this.sessions[socket.request.session.subscriber_id][socket.id] = sessionData;
			this.sendConnectNotice(socket.id, socket.request.session.subscriber_id, sessionData);
			let err, result;
			let req = {
				socket: {
					updatedata: {},
					sendupdate: false
				},
				body: {
					request: "isLoggedIn"
				},
				session: socket.request.session,
				headers: socket.request.headers
			};
			[err, result] = await to(this.user.data(req));
			if (err) {
				console.log("Location: app.js:socket:isLoggedIn, App Error: ", err);
				//fn({error:true,err:err}); -- this will be removed -- there is no fn at this point
				return;
			}
			if (result.usertype && result.usertype === "sadmin") {
				socket.join(socket.request.session.subscriber_id + "-sadmin");
				socket.join(socket.request.session.subscriber_id + "-admin");
			}
			if (result.usertype && result.usertype === "admin") {
				socket.join(socket.request.session.subscriber_id + "-admin");
			}
			if (result.usertype && result.usertype === "master") {
				//if (this.DEBUG) console.log("master joined admin rooms");
				this.logger.debug("master joined admin rooms");
				socket.join(socket.request.session.subscriber_id + "-admin");
				socket.join(socket.request.session.subscriber_id + "-sadmin");
				socket.join("master");
			}
			this.sendOnlineUserCount(socket.request.session.subscriber_id);

			let dataRequestCBF = async (data, fn) => {
				this.logger.debug("socket:dataRequest");
				let req = {
					socket: {
						updatedata: {},
						sendupdate: false
					},
					body: data,
					session: socket.request.session,
					headers: socket.request.headers
				};
				if (!data.request) {
					fn({
						sucess: false,
						err: "No request received."
					});
					return;
				}
				let [err,result] = await to(this.designer.data(req));
				if (err) {
					this.logger.error(`Location: app.js:socket:dataRequest, request: ${data.request} App Error: ${err.message}`, {
						subscriber_id: req.session.subscriber_id,
						data: data,
						err: err
					});
					fn({
						error: true,
						err: err
					});
					return;
				}
				socket.request.session.save();
				fn(result);
			};
			let dataRequestCB = dataRequestCBF.bind(this);
			socket.on('dataRequest', dataRequestCB);

			let userDataRequestCBF = async (data, fn) => {
				this.logger.debug("socket:userDataRequest");
				let req = {
					socket: {
						updatedata: {},
						sendupdate: false
					},
					body: data,
					session: socket.request.session,
					headers: socket.request.headers
				};
				if (!data.request) {
					fn({
						sucess: false,
						err: "No request received."
					});
					return;
				}
				let [err,result] = await to(this.user.data(req));
				if (err) {
					this.logger.error(`Location: app.js:socket:userDataRequest, request: ${data.request} App Error: ${err.message}`, {
						subscriber_id: req.session.subscriber_id,
						data: data,
						err: err
					});
					fn({
						error: true,
						err: err
					});
					return;
				}
				switch (req.body.request) {
					case "isLoggedIn": {
						if (result.usertype && result.usertype === "sadmin") {
							socket.join(socket.request.session.subscriber_id + "-sadmin");
							socket.join(socket.request.session.subscriber_id + "-admin");
						}
						if (result.usertype && result.usertype === "admin") {
							socket.join(socket.request.session.subscriber_id + "-admin");
						}
						if (result.usertype && result.usertype === "master") {
							socket.join(socket.request.session.subscriber_id + "-admin");
							socket.join(socket.request.session.subscriber_id + "-sadmin");
							socket.join("master");
						}
						break;
					}
					case "login": {
						if (result.userData && result.userData.usertype && result.userData.usertype === "sadmin") {
							socket.join(socket.request.session.subscriber_id + "-sadmin");
							socket.join(socket.request.session.subscriber_id + "-admin");
						}
						if (result.userData && result.userData.usertype && result.userData.usertype === "admin") {
							socket.join(socket.request.session.subscriber_id + "-admin");
						}
						if (result.userData && result.userData.usertype && result.userData.usertype === "master") {
							socket.join(socket.request.session.subscriber_id + "-admin");
							socket.join(socket.request.session.subscriber_id + "-sadmin");
							socket.join("master");
						}
						if (result.success) {
							userData = result.userData;
							userData.postal_code = userData.zip;
							this.sessions[socket.request.session.subscriber_id][socket.id] = {
								ip: socket.handshake.address,
								postal_code: userData.postal_code,
								userid: userData.userid,
								firstname: userData.firstname,
								lastname: userData.lastname,
								location_number: userData.location_number,
								appStatus: {
									visible: true,
									active: true
								}
							};
						} else {
							this.logger.warn(`Failed login attempt: subscriber_id: ${req.session.subscriber_id} userid: ${req.body.username}`);
						}
						this.sendUpdatetoServers(socket.id, socket.request.session.subscriber_id);
						this.includessendOnlineUserCount(socket.request.session.subscriber_id);
						break;
					}
					case "logout": {
						this.sessions[socket.request.session.subscriber_id][socket.id].userid = null;
						this.sessions[socket.request.session.subscriber_id][socket.id].firstname = null;
						this.sessions[socket.request.session.subscriber_id][socket.id].lastname = null;
						this.sendUpdatetoServers(socket.id, socket.request.session.subscriber_id);
						this.sendOnlineUserCount(socket.request.session.subscriber_id);
						break;
					}
				}
				socket.request.session.save();
				if (typeof fn !== "function") {
					this.logger.error("socket request without defined function (userDataRequest)", {
						session: req.session,
						data: data
					});
					return;
				}
				fn(result);
			};
			let userDataRequestCB = userDataRequestCBF.bind(this);
			socket.on('userDataRequest', userDataRequestCB);

			let adminDataRequestCBF = async (data, fn) => {
				this.logger.debug("socket:adminDataRequest");
				let err, result;
				let req = {
					socket: {
						updatedata: {},
						sendupdate: false
					},
					body: data,
					session: socket.request.session,
					headers: socket.request.headers
				};
				if (!data.request) {
					fn({
						sucess: false,
						err: "No request received."
					});
					return;
				}
				switch (data.request) {
					case "getCurrentUsersList": {
						if (socket.request.session.subscriber_id.indexOf("MASTER") > -1) {
							fn({
								sessions: this.sessions
							});
						} else {
							fn({
								sessions: this.sessions[socket.request.session.subscriber_id]
							});
						}
					}
					case "getOnlineUserCount": {
						let userCount = 0;
						userCount = Object.keys(this.sessions[socket.request.session.subscriber_id]).length;
						result = [{
							subscriber_id: socket.request.session.subscriber_id,
							onlineUserCount: userCount
						}];
						break;
					}
					default: {
						[err, result] = await to(this.admin.loadData(req));
					}
				}
				if (err) {
					this.logger.error(`Location: app.js:socket:adminDataRequest, request: ${data.request} App Error: ${err.message}`, {
						subscriber_id: req.session.subscriber_id,
						data: data,
						err: err
					});
					fn({
						error: true,
						err: err
					});
					return;
				}
				socket.request.session.save();
				fn(result);
			};
			let adminDataRequestCB = adminDataRequestCBF.bind(this);
			socket.on('adminDataRequest', adminDataRequestCB);

			let userActionCBF = async (data, fn) => {
				// *** TODO: rename to actionRequest
				this.logger.debug("socket:userAction");
				let req = {
					socket: {
						sendupdate: false
					},
					body: data,
					session: socket.request.session,
					headers: socket.request.headers
				};
				let err, result;
				if (!data.request) {
					fn({
						sucess: false,
						err: "No request received."
					});
					return;
				}
				[err, result] = await to(this.user.action(req));
				if (err) {
					this.logger.error(`Location: app.js:socket:userAction, request: ${data.request} App Error: ${err.message}`, {
						subscriber_id: req.session.subscriber_id,
						data: data,
						err: err
					});
					fn({
						error: true,
						err: err
					});
					return;
				}
				switch (req.body.request) {
					case "setZipCode": {
						if (typeof this.sessions[socket.request.session.subscriber_id][socket.id] === "undefined") {
							this.sessions[socket.request.session.subscriber_id][socket.id] = {};
						}
						if (result.validzip) {
							this.sessions[socket.request.session.subscriber_id][socket.id].postal_code = result.postal_code_data.zipcode;
							this.sessions[socket.request.session.subscriber_id][socket.id].city = result.postal_code_data.city;
							this.sessions[socket.request.session.subscriber_id][socket.id].region = result.postal_code_data.state;
							this.sessions[socket.request.session.subscriber_id][socket.id].region_code = result.postal_code_data.statecode;
							//console.log("set zip to:",result.postal_code_data.zipcode);
						} else {
							if (!result.cached) {
								this.logger.warn(`invalid zip: ${result.zip}, Subscriber:${socket.request.session.subscriber_id}`, {
									response: result,
									subscriber_id: socket.request.session.subscriber_id,
									user_ip: socket.request.session.ip
								});
							}
						}
						if (socket.request.session.location_number) {
							this.sessions[socket.request.session.subscriber_id][socket.id].location_number = socket.request.session.location_number;
						}
						if (result.validzip) {
							this.sendUpdatetoServers(socket.id, socket.request.session.subscriber_id);
							this.sendOnlineUserCount(socket.request.session.subscriber_id);
						}
						break;
					}
				}
				socket.request.session.save();
				if (req.socket.sendupdate) {
					this.io.to(req.session.subscriber_id + "-sadmin").emit("update", req.socket.updatedata);
					this.io.to(req.session.subscriber_id + "-admin").emit("update", req.socket.updatedata);
				}
				fn(result);
			};
			let userActionCB = userActionCBF.bind(this);
			socket.on('userAction', userActionCB);

			let adminActionWorkerCBF = async (data) => {
				this.logger.debug("socket:adminActionWorker");
				let updatedata = {};
				let sendupdate = false;
				let err, result;
				let req = {
					body: data,
					session: socket.request.session,
					headers: socket.request.headers
				};
				if (!data.request) {
					socket.emit("adminActionResponse", {
						sucess: false,
						err: "No request received."
					});
					return;
				}
				switch (data.request) {
					case "get_db_design_list": {
						let query = "SELECT design_id, data_format, in_file_bucket FROM usersheds WHERE in_file_bucket = 0";
						[err, result] = await to(P_GetQueryData(query, ParseMySqlRowDataObj, P_ParseMySqlRowsDataObj));
						if (err) {
							socket.emit("adminActionResponse", {
								request: "get_db_design_list",
								err: err
							});
							return;
						}
						socket.emit("adminActionResponse", {
							request: "get_db_design_list",
							design_list: result
						});
						break;
					}
					case "save_design": {
						if (data.design_id) {
							if (!data.designdata) {
								query = "UPDATE usersheds SET in_file_bucket = -1, data = ? WHERE design_id = ?";
								query = mysql.format(query, ["{}", data.design_id]);
								[err, result] = await to(P_GetQueryData(query, null, MySQLActionResult));
								if (err) {
									socket.emit("adminActionResponse", {
										request: "save_design",
										design_id: data.design_id,
										saved: false,
										err: err
									});
									return;
								}
								socket.emit("adminActionResponse", {
									request: "save_design",
									design_id: data.design_id,
									saved: true
								});
								return;
							}

							[err, result] = await to(writeFileAsync(__dirname + "/../public/designs/" + data.design_id + "." + data.data_format.toLowerCase(), data.designdata));
							if (err) {
								socket.emit("adminActionResponse", {
									request: "save_design",
									design_id: data.design_id,
									saved: false,
									err: err
								});
								return;
							}
							query = "UPDATE usersheds SET in_file_bucket = 2, data = ? WHERE design_id = ?";
							query = mysql.format(query, [JSON.stringify({
								file_name: data.design_id + "." + data.data_format.toLowerCase()
							}), data.design_id]);
							[err, result] = await to(P_GetQueryData(query, null, MySQLActionResult));
							if (err) {
								socket.emit("adminActionResponse", {
									request: "save_design",
									design_id: data.design_id,
									saved: false,
									err: err
								});
								return;
							}
							socket.emit("adminActionResponse", {
								request: "save_design",
								design_id: data.design_id,
								saved: true
							});
						}
						break;
					}
					default: {
						err = {
							message: "invalid request"
						};
					}
				}
				if (err) {
					this.logger.error(`Location: app.js:socket:adminActionWorker, request: ${data.request} App Error: ${err.message}`, {
						subscriber_id: req.session.subscriber_id,
						data: data,
						err: err
					});
					socket.emit("adminActionResponse", {
						error: true,
						err: err
					});
					return;
				}
			};
			let adminActionWorkerCB = adminActionWorkerCBF.bind(this);
			socket.on('adminActionWorker', adminActionWorkerCB);

			let adminActionCBF = async (data, fn) => {
				this.logger.debug("socket:adminAction");
				let err, result;
				let req = {
					socket: {
						updatedata: {},
						sendupdate: false
					},
					body: data,
					session: socket.request.session,
					headers: socket.request.headers
				};
				if (!data.request) {
					fn({
						sucess: false,
						err: "No request received."
					});
					return;
				}

				if (["admin", "sadmin", "master"].includes(req.session.userdata.usertype)) {
					[err, result] = await to(this.admin.action(req));
				} else {
					err = {
						name: "unauthorized",
						message: "Unauthorized request."
					};
					this.logger.warn(`Unauthorized data request. Subscriber_id: ${req.session.subscriber_id} - User ID: ${req.session.user} - ip: {req.session.ip}`);
				}

				if (err) {
					if (err.message) {
						this.logger.error(`Location: app.js:socket:getAdminData, Subscriber: ${req.session.subscriber_id}, Request: ${data.request}, App Error: ${err.message}`, {
							subscriber_id: req.session.subscriber_id,
							data: data,
							err: err
						});
					} else {
						this.logger.error(`Location: app.js:socket:getAdminData, Subscriber: ${req.session.subscriber_id}, Request: ${data.request}, App Error: ${err}`, {
							subscriber_id: req.session.subscriber_id,
							data: data,
							err: err
						});
					}
					fn({
						error: true,
						err: err
					});
					return;
				}
				socket.request.session.save();
				if (req.socket.sendupdate) {
					this.io.to(req.session.subscriber_id + "-sadmin").emit("update", req.socket.updatedata);
					this.io.to(req.session.subscriber_id + "-admin").emit("update", req.socket.updatedata);
				}
				fn(result);
			};
			let adminActionCB = adminActionCBF.bind(this);
			socket.on('adminAction', adminActionCB);

			let masterActionCBF = async (data, fn) => {
				this.logger.debug("socket:masterAction");
				let updatedata = {};
				let sendupdate = false;
				let err, result;
				let req = {
					socket: {
						updatedata: {},
						sendupdate: false
					},
					body: data,
					session: socket.request.session,
					headers: socket.request.headers
				};
				if (!data.request) {
					fn({
						sucess: false,
						err: "No request received."
					});
					return;
				}
				[err, result] = await to(this.master.action(req));
				if (err) {
					this.logger.error(`Location: ${THIS_FILE}:socket:masterAction, request: ${data.request} App Error: ${err.message}`, {
						subscriber_id: req.session.subscriber_id,
						data: data,
						err: err
					});
					fn({
						error: true,
						err: err
					});
					return;
				}
				socket.request.session.save();
				if (result.sendupdate || req.socket.sendupdate) {
					let updatedata = result.updatedata || req.socket.updatedata;
					this.io.to(req.session.subscriber_id + "-sadmin").emit("update", updatedata);
					this.io.to(req.session.subscriber_id + "-admin").emit("update", updatedata);
				}
				fn(result);
			};
			let masterActionCB = masterActionCBF.bind(this);
			socket.on('masterAction', masterActionCB);

			let userInfoCBF = async (data) => {
				this.logger.debug("socket:userInfo");
				let updatedata = {};
				let sendupdate = false;
				let err, result;
				let req = {
					socket: {
						updatedata: {},
						sendupdate: false
					},
					body: data,
					session: socket.request.session,
					headers: socket.request.headers
				};
				if (!data.info) {
					this.logger.warn("userInfo socket without valid data", data);
					return;
				}
				switch (data.info) {
					case "appStatus": {
						let update = false;
						if (typeof this.sessions[socket.request.session.subscriber_id] === "undefined") {
							this.logger.warn(`Missing sessions for ${socket.request.session.subscriber_id}`);
							return;
						}
						if (typeof this.sessions[socket.request.session.subscriber_id][socket.id] === "undefined") {
							this.logger.warn(`Missing sessions for ${socket.request.session.subscriber_id} - ${socket.id}`);
							return;
						}
						if (typeof this.sessions[socket.request.session.subscriber_id][socket.id].appStatus === "undefined") {
							this.sessions[socket.request.session.subscriber_id][socket.id].appStatus = {};
						}
						if (typeof data.visible !== "undefined") {
							this.sessions[socket.request.session.subscriber_id][socket.id].appStatus.visible = data.visible;
							update = true;
						}
						if (typeof data.active !== "undefined") {
							this.sessions[socket.request.session.subscriber_id][socket.id].appStatus.active = data.active;
							update = true;
						}
						if (update) {
							this.sendUpdatetoServers(socket.id, socket.request.session.subscriber_id);
						}
					}
				}
			};
			let userInfoCB = userInfoCBF.bind(this);
			socket.on('userInfo', userInfoCB);

			let disconnectCBF = async (reason) => {
				this.logger.debug("socket disconnected.");
				let req = {};
				req.body = {
					socket: {
						updatedata: {},
						sendupdate: false
					},
					session: socket.request.session,
					headers: socket.request.headers
				};
				setUserLastAccess(req);
				this.sendDisconnectNoticetoServers(socket.id, socket.request.session.subscriber_id);
				if (this.sessions[socket.request.session.subscriber_id] && this.sessions[socket.request.session.subscriber_id][socket.id]) {
					delete this.sessions[socket.request.session.subscriber_id][socket.id];
				}
				this.sendOnlineUserCount(socket.request.session.subscriber_id);
				/* if (this.redisAdapterActive || this.mongoAdapterActive) {
					delayedUserCount(socket.request.session.subscriber_id);
				} */
			};
			let disconnectCB = disconnectCBF.bind(this);
			socket.on('disconnect', disconnectCB);
		};
		let connectionCB = connectionCBF.bind(this);
		this.io.on('connection', connectionCB);
		}

	async delayedUserCount(subscriber_id) {
		let roomCount = 0;
		await sleep(2000);
		roomCount = await this.getOnlineUserCount(subscriber_id);
		this.io.to(subscriber_id + "-sadmin").emit("update", [{
			processID: this.processID,
			subscriber_id: this.socket.request.session.subscriber_id,
			onlineUserCount: roomCount
		}]);
		this.io.to(subscriber_id + "-admin").emit("update", [{
			processID: this.processID,
			subscriber_id: this.socket.request.session.subscriber_id,
			onlineUserCount: roomCount
		}]);
	}

	async sendUpdatetoServers(socket_id, subscriber_id) {
		if (this.serverAdapterActive) {
			let sessionData = this.sessions[subscriber_id][socket_id];
			let dataPacket = {
				request: "update",
				processID: this.processID,
				subscriber_id: subscriber_id,
				socket_id: socket_id,
				sessionData: sessionData
			};
			this.io.to("master").emit("serverlog", {
				data: dataPacket
			});
			this.io.to(subscriber_id + "-sadmin").emit("serverlog", {
				data: dataPacket
			});
			this.io.to(subscriber_id + "-admin").emit("serverlog", {
				data: dataPacket
			});
			let cbf = function (err, replies) {
				if (err) {
					if (err.message && err.message.indexOf("timeout") > -1) {
						this.logger.debug("No response to update notification.");
					} else {
						this.logger.error(`app.js:fn:setUpdatetoServers customRequest error ${err}`);
					}
				}
			};
			let cb = cbf.bind(this);
			this.io.of('/').adapter.customRequest(dataPacket, cb);
		}
	}

	getSessionsFromServers() {
		if (this.serverAdapterActive) {
			let cbf = function (err, replies) {
				if (err) {
					if (err.message && err.message.indexOf("timeout") > -1) {
						this.logger.debug("No response to sessions request.");
					} else {
						this.logger.error(`customRequest sessions error ${err}`);
					}
					return;
				}
				this.logger.debug(`customRequest response: ${replies} replies.length: ${replies.length}`);
				//let newSessions = JSON.parse(JSON.stringify(this.sessions));
				for (let i = 0; i < replies.length; i++) {
					if (this.DEBUG) console.log("Loop:", i, "processID:", this.processID, "[i].processID", replies[i].processID);
					if (this.processID !== replies[i].processID) {
						if (this.DEBUG) console.log("merging...");
						this.sessions = _.merge(this.sessions, replies[i].sessions);
					}
				}
				//let currentSessions = this.redisSessionList(null);

				this.logger.debug(`updated sessions: ${this.sessions}`);
			};
			let cb = cbf.bind(this);
			this.io.of('/').adapter.customRequest({
				request: "sessions",
				processID: this.processID
			}, cb);
		}
	}

	redisSessionList(room) {
		let cbf = function (resolve, reject) {
			if (room) {
				if (!Array.isArray(room)) {
					room = [room];
				}
			}
			this.io.of('/').adapter.clients(room, function (err, clients) {
				if (err) {
					reject(err);
				}
				resolve(clients);
			});
		};
		let cb = cbf.bind(this);
		return new Promise(cb);
	}

	async redisRoomCount(room) {
		let err, result;
		[err, result] = await to(this.redisSessionList(room));
		if (err) {
			throw err;
		}
		return result.length;
	}

	async getOnlineUserCount(subscriber_id) {
		let err;
		let userCount = 0;
		if (typeof subscriber_id === "undefined") {
			return userCount;
		}
		// if (this.redisAdapterActive || this.mongoAdapterActive) {
		if (this.redisAdapterActive) {
			[err, userCount] = await to(this.redisRoomCount(subscriber_id));
			if (err) {
				if (JSON.stringify(err).indexOf("timeout") > -1) {
					userCount = Object.keys(this.sessions[subscriber_id]).length;
				} else {
					this.logger.error(`app.js:fn:getOnlineUserCount: error received from redisRoomCount: ${err}`);
				}
			}
			this.logger.debug(`${subscriber_id} Online User Count: ${userCount}`);
		} else {
			if (this.mongoAdapterActive) {
				if (subscriber_id.indexOf("MASTER") > -1) {
					userCount = this.io.engine.clientsCount;
				} else {
					if (typeof this.sessions[subscriber_id] === "object") {
						userCount = Object.keys(this.sessions[subscriber_id]).length;
					} else {
						this.logger.warn(`app.js:fn:getOnlineUserCount: Sessions key missing for ${subscriber_id}`);
					}
				}
			} else {
				if (subscriber_id.indexOf("MASTER") > -1) {
					userCount = this.io.engine.clientsCount;
				} else {
					if (typeof this.io.sockets.adapter.rooms[subscriber_id] === "object") {
						userCount = this.io.sockets.adapter.rooms[subscriber_id].length;
					} else {
						this.logger.warn(`app.js:fn:getOnlineUserCount: Room missing for ${subscriber_id}`);
					}
				}
			}
			return userCount;
		}

		if (this.serverAdapterActive && (userCount < Object.keys(this.sessions[subscriber_id]).length)) {
			let keys = Object.keys(this.sessions[subscriber_id]);
			let currentSessions = this.redisSessionList(subscriber_id);
			for (let i = 0; i < keys.length; i++) {
				if ((!currentSessions[keys[i]]) && (this.processID !== this.sessions[subscriber_id][keys[i]].processID)) {
					delete this.sessions[subscriber_id][keys[i]];
				}
			}
		}
		if (this.io.sockets.adapter.rooms[subscriber_id]) {
			let localUserCount = this.io.sockets.adapter.rooms[subscriber_id].length;
			if (this.serverAdapterActive && (localUserCount < Object.keys(this.sessions[subscriber_id]).length)) {
				let keys = Object.keys(this.sessions[subscriber_id]);
				let localSessions = this.io.sockets.adapter.rooms[subscriber_id];
				for (let i = 0; i < keys.length; i++) {
					if ((!localSessions[keys[i]]) && (this.processID === this.sessions[subscriber_id][keys[i]].processID)) {
						delete this.sessions[subscriber_id][keys[i]];
					}
				}
			}
		}
		return userCount;
	}

	async sendDisconnectNoticetoServers(socket_id, subscriber_id) {
		if (this.serverAdapterActive) {
			let dataPacket = {
				request: "disconnect",
				processID: this.processID,
				subscriber_id: subscriber_id,
				socket_id: socket_id
			};
			this.io.to("master").emit("serverlog", {
				data: dataPacket
			});
			this.io.to(subscriber_id + "-sadmin").emit("serverlog", {
				data: dataPacket
			});
			this.io.to(subscriber_id + "-admin").emit("serverlog", {
				data: dataPacket
			});
			let customRequestCBF = function (err, replies) {
				if (err) {
					if (err.message && err.message.indexOf("timeout") > -1) {
						this.logger.debug("No response to disconnect notification.");
					} else {
						this.logger.error(`app.js:fn:sendDisconnectNoticetoServers customRequest disconnect error ${err}`);
					}
				}
			};
			let customRequestCB = customRequestCBF.bind(this);
			this.io.of('/').adapter.customRequest(dataPacket, customRequestCB);
		}
	}

	async sendOnlineUserCount(subscriber_id) {
		if (typeof subscriber_id === "undefined") {
			return;
		}
		let userCount = await this.getOnlineUserCount(subscriber_id);
		this.logger.debug(`Sending Update to: ${subscriber_id}-sadmin (UserCount: ${userCount})`);
		this.io.to(subscriber_id + "-sadmin").emit("update", [{
			processID: this.processID,
			subscriber_id: subscriber_id,
			onlineUserCount: userCount,
			sessions: this.sessions[subscriber_id]
		}]);
		this.io.to(subscriber_id + "-admin").emit("update", [{
			processID: this.processID,
			subscriber_id: subscriber_id,
			onlineUserCount: userCount,
			sessions: this.sessions[subscriber_id]
		}]);
	}

	async sendConnectNotice(socket_id, subscriber_id, sessionData) {
		if (this.serverAdapterActive) {
			let dataPacket = {
				request: "connect",
				processID: this.processID,
				subscriber_id: subscriber_id,
				socket_id: socket_id,
				sessionData: sessionData
			};
			this.io.to("master").emit("serverlog", {
				data: dataPacket
			});
			this.io.to(subscriber_id + "-sadmin").emit("serverlog", {
				data: dataPacket
			});
			this.io.to(subscriber_id + "-admin").emit("serverlog", {
				data: dataPacket
			});
			let customRequestCBF = function (err, replies) {
				if (err) {
					if (err.message && err.message.indexOf("timeout") > -1) {
						this.logger.debug("No response to connect notification.");
					} else {
						this.logger.error(`this.io.on:connection:customRequest error ${err}`);
					}
				}
			};
			let customRequestCB = customRequestCBF.bind(this);
			this.io.of('/').adapter.customRequest(dataPacket, customRequestCB);
		}
	}

	}

