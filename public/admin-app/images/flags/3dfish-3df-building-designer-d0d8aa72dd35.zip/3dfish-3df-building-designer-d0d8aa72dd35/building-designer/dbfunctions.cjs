const mysql = require("mysql2/promise");
const to = require("togo");

class Dbfunctions {
	constructor(params) {
		this.con = params.mysql_connection;
		this.tcon = params.mysql_transaction_connection;
		this.logger = params.logger;
		this.DEBUG = params.DEBUG;
		// see https://stackoverflow.com/questions/58173270 for more information
		// other option is to bind when setting the alias i.e. const P_GetQueryData = dbfunc.P_GetQueryData.bind(dbfunc);
		//this.P_GetQueryData = this.P_GetQueryData.bind(this);
	}

	sqlcolumnsFromRow(sourceData) {
		let columns = Object.keys(sourceData);

		let sqlcolumns = "";
		if (this.DEBUG) console.log(columns);

		for (let i = 0; i < columns.length; i += 1) {
			if (i > 0) sqlcolumns += ",";
			sqlcolumns += columns[i];
		}

		return sqlcolumns;
	}

	rowObjToArray(sourceData) {
		let row = [];
		let NewDataArr = [];
		let columns = Object.keys(sourceData[0]);
		for (let i = 0; i < sourceData.length; i += 1) {
			row = [];
			for (let i2 = 0; i2 < columns.length; i2 += 1) {
				row[i2] = sourceData[i][columns[i2]];
			}
			NewDataArr.push(row);
		}
		return NewDataArr;
	}

	P_ParseDataCallback(err, rows, currentDataRowParser) {
		let logger = this.logger;
		logger.silly("dbfunctions.js:P_ParseDataCallback");

		let returndata;

		try {
			if (!err) {
				returndata = "[";
				for (let i = 0; i < rows.length; i++) {
					if (i > 0)
						returndata += ", ";

					let rowData = currentDataRowParser(rows[i]);
					if (typeof rowData === "string") {
						returndata += rowData;
					} else {
						returndata += JSON.stringify(rowData);
					}
				}

				returndata += "]";

				return returndata;
			} else {
				logger.error(`dbfunctions.js:fn:P_ParseDataCallback Error: ${err}`);
				return null;
			}

		} catch (ex) {
			logger.error(`dbfunctions.js:fn:P_ParseDataCallback Exception: ${ex}`);
			return null;
		}
	};

	async P_GetQueryData(query, dataRowParser, parseDataCallbackFunction, useConnection) {
			let logger = this.logger;
			logger.silly("P_GetQueryData");
			// check for passed mysql connection, otherwise use the global connection.
			let connection;
			if (typeof useConnection === "undefined") {
				connection = this.con;
			} else {
				connection = useConnection;
			}

			let currentDataRowParser = dataRowParser;

			if (parseDataCallbackFunction == null || parseDataCallbackFunction == undefined)
				parseDataCallbackFunction = this.P_ParseDataCallback.bind(this);

			try {
				let [err, data] = await to(connection.query(query));
				if (err) {
					throw err;
				} else {
					let rows;
					if (Array.isArray(data)) {
					rows = data[0];
					} else {
						rows = data;
					}
					let result = parseDataCallbackFunction(err,rows,currentDataRowParser);
					return result;
				}
			} catch (ex) {
				logger.error("Location: dbfunctions.js:P_GetQueryData App Exception: ",ex);
				throw `GetQueryData error - ${ex}`;
			}

	};

	async P_GetQueryDataReq (query, dataRowParser, parseDataCallbackFunction, req) {
			let logger = this.logger;
			logger.debug("P_GetQueryDataReq");

			let connection;
			if (typeof useConnection === "undefined") {
				connection = this.con;
			} else {
				connection = useConnection;
			}

			let currentDataRowParser = dataRowParser;

			if (parseDataCallbackFunction == null || parseDataCallbackFunction == undefined)
				parseDataCallbackFunction = this.P_ParseDataCallback.bind(this);

			try {
				let [err, data] = await to(connection.query(query));
				if (err) {
					throw err;
				} else {
					let rows;
					if (Array.isArray(data)) {
						rows = data[0];
					} else {
						rows = data;
					}
					let result = parseDataCallbackFunction(err,rows,currentDataRowParser,req);
					return result;
				}
			} catch (ex) {
				console.log("Location: dbfunctions.js:P_GetQueryDataReq, App Exception: ",ex);
				throw new Error("P_GetQueryDataReq error");
			}

	};

	async P_GetQueryData2Req (query, insertdata, dataRowParser, parseDataCallbackFunction, req) {
			logger.debug("P_GetQueryData");
			let logger = this.logger;
			logger.debug("P_GetQueryDataReq");

			let connection;
			if (typeof useConnection === "undefined") {
				connection = this.con;
			} else {
				connection = useConnection;
			}

			if(!Array.isArray(insertdata)) insertdata = [insertdata];

			let currentDataRowParser = dataRowParser;

			if (parseDataCallbackFunction == null || parseDataCallbackFunction == undefined)
				parseDataCallbackFunction = this.P_ParseDataCallback.bind(this);

			try {
				let [err, data] = await to(connection.query(query, insertdata));
				if (err) {
					throw err;
				} else {
					let rows;
					if (Array.isArray(data)) {
						rows = data[0];
					} else {
						rows = data;
					}
					let result = parseDataCallbackFunction(err,rows,currentDataRowParser,req);
					return result;
				}
			} catch (ex) {
				logger.error("Location: dbfunctions.js:P_GetQueryData2Req, App Exception: ",ex);
				throw new Error("P_GetQueryData2Req error");
			}
	};

	ParseMySqlRowData(rowData) {
		this.logger.silly("ParseMySqlRowData");
		return JSON.stringify(rowData);
	}

	ParseMySqlRowDataObj(rowData) {
		this.logger.silly("ParseMySqlRowDataObj");
		return rowData;
	}

	P_ParseMySqlRowsData(err, rows, currentDataRowParser) {
		let logger = this.logger;
		logger.silly("P_ParseMySqlRowsData");

		let MySQLRows;

		try {
			if (!err) {
				MySQLRows = "[";
				for (let i = 0; i < rows.length; i++) {
					if (i > 0)
						MySQLRows += ", ";

					MySQLRows += currentDataRowParser(rows[i]);
				}

				MySQLRows += "]";

				logger.silly("return row data");
				return MySQLRows;
			}

		} catch (ex) {
			logger.error(`P_ParseMySQLRowsData: ERROR: ${ex}`);
			return null;
		}
	};

	P_ParseMySqlRowsDataObj(err, rows, currentDataRowParser) {
		let logger = this.logger;
		logger.silly("P_ParseMySqlRowsDataObj");

		let MySQLRows = [];

		try {
			if (!err && rows && rows.length > 0)
			{
				for (let i = 0; i < rows.length; i++)
				{
					MySQLRows.push(currentDataRowParser(rows[i]));
				}

				return MySQLRows;
			}
		} catch (ex) {
			logger.error(`P_ParseMySQLRowsDataObj: ERROR: ${ex}`);
			return null;
		}
		return [];
	};

	P_ParseDataCallbackObj (err, rows, currentDataRowParser) {
		let logger = this.logger;
		let DEBUG = this.DEBUG;
		logger.debug("P_ParseDataCallbackObj");

		let returndata = [];

		try
		{
			if (!err)
			{
				for (let i = 0; i < rows.length; i++) {
					returndata.push(currentDataRowParser(rows[i]));
				}
				return returndata;
			}
			else
			{
				if (DEBUG) console.log("dbfunctions.js:P_ParseDataCallbackObj, Error: ", err);
				return null;
			}

		}
		catch (ex)
		{
			if (DEBUG) console.log("adbfunctions.js:P_ParseDataCallbackObj, Exception: ", ex);
			return null;
		}
}	;

	ReturnSingleMySQLRow(err, rows, currentDataRowParser) {
		let logger = this.logger;
		logger.silly("ReturnSingleMySQLRow");
		if (rows.length > 0) {
			return rows[0];
		} else {
			return null;
		}
	};

	MySQLActionResult (err,rows,currentDataRowParser){
		let logger = this.logger;
		let DEBUG = this.DEBUG;
		if(DEBUG) {
			logger.debug("MySQLActionResult");
			if(currentDataRowParser) {
				logger.warn("app.js:fn:MySQLActionResult -- currentDataRowParser parameter set -- This is unused.");
			}
		}
		if(!err) {
			return {status: "Success", success:true};
		} else {
			// It should not be possible to have an error passed to this function
			// Any errors should be caught before this function is called.
			logger.error(`app.js:fn:MySQLActionResult err passed to function: ${err}`);
			throw err;
		}
	};

	prepObjectArrayforMySQL(dataArray) {
		if (Array.isArray(dataArray)) {
			for (let i=0;i<dataArray.length;i++) {
				if (Array.isArray(dataArray[i])) {
					for (let j=0;j<dataArray[i].length;j++) {
						if (Array.isArray(dataArray[i][j])) {
							for (let k=0;k<dataArray[i][j].length;k++) {
								if (typeof dataArray[i][j][k] === "object") {
									dataArray[i][j][k] = JSON.stringify(dataArray[i][j][k]);
								}
							}
						} else {
							if (typeof dataArray[i][j] === "object") {
								dataArray[i][j] = JSON.stringify(dataArray[i][j]);
							}
						}
					}
				} else {
					if (typeof dataArray[i] === "object") {
						dataArray[i] = JSON.stringify(dataArray[i]);
					}
				}
			}
		}
		return dataArray;
	}

	static CleanInputData(data, options)
{
	if (typeof data === "number") {
		return data;
	}
	if(typeof data === "undefined") {
		data = "";
	}
	data = mysql.escape(data);
	data = data.substr(1, data.length-2);
	return data;
}
}

module.exports = Dbfunctions;