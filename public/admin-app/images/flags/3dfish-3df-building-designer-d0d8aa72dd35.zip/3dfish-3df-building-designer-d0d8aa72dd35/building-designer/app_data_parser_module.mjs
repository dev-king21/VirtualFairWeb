/*eslint-env node, es6*/
/*eslint-parserOptions sourceType:"module", ecmaVersion:2019*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape, no-undef*/

import dist from 'afar';

import { LogAccess } from "./app_user_module.mjs";

let logger;
let DEBUG = false;

export function InitDataParserModule(params) {
	logger = params.logger;
	DEBUG = params.DEBUG;
}

export function ParseInterfaceData(rowData)
{
	let loginDataStr = '{ "interface_html": "' + rowData.interface_html + '" }';

	return loginDataStr;
}

export function ParseLoginRowData(rowData)
{
	let loginDataStr = '{ "userID": "' + rowData.userID + ' }';

	return loginDataStr;
}

export function ParseSubscriberLocationRowData(rowData)
{
	logger.debug("ParseSubscriberLocationRowData");

	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.sdata;

	logger.debug("Location: ", rowData.location_number);

	return rowData;
}

export function ParseSubscriberLocationData(err, rowsData, currentDataRowParser)
{
	let returndata = [];
	if (DEBUG) {
		logger.debug("ParseSubscriberLocationData");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}
	if (!err && rowsData && rowsData.length > 0)
	{
		logger.debug("Processing Subscriber Data");

		for (let rowData of rowsData)
		{
			returndata.push(ParseSubscriberLocationRowData(rowData))
		}

		return returndata;
	}
	else
	{
		logger.debug(`Location: app.js:291, App Error: ${err}`);
		logger.debug("Subscriber NOT Found");

		returndata = '["Subscriber ID NOT Found"]';
		return JSON.parse(returndata);
	}
}

export function ParseActiveFeatures(err, rowsData, currentDataRowParser)
{
	let returndata;
	if (DEBUG) {
		logger.debug("ParseActiveFeatures");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}
	if (!err && rowsData && rowsData.length > 0)
	{
		logger.debug("Processing Subscriber Data");
		returndata = "[";
		for (let i = 0; i < rowsData.length; i++)
		{
			if (i > 0)
				returndata += ", ";

			returndata += ParseMySqlRowData(rowsData[i]);
		}

		returndata += "]";
		return JSON.parse(returndata);

	}
	else
	{
		logger.debug(`Location: app.js:321, App Error: ${err}`);
		logger.debug("Subscriber NOT Found");

		returndata = "Subscriber ID NOT Found";
		return returndata;
	}
}

export function ParseFeatureData(err, rowsData, currentDataRowParser)
{
	let returndata;
	if (DEBUG) {
		logger.debug("ParseFeatureData");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}
	if (!err && rowsData && rowsData.length > 0)
	{
		logger.debug("Processing Feature Data");
		returndata = "{";
		for (let i = 0; i < rowsData.length; i++)
		{
			if (i > 0)
				returndata += ", ";

			returndata += ParseFeatureRowData(rowsData[i]);
		}

		returndata += "}";
		return returndata;
	}
	else
	{
		logger.debug(`Location: app.js:350, App Error: ${err}`);
		logger.debug("No Feature Data for Subscriber Found");

		returndata ={none:"none"};
		return returndata;
	}
}

export function ParseFeatureDataObj(err, rowsData, currentDataRowParser)
{
	let returndata = {};
	if (DEBUG) {
		logger.debug("ParseFeatureData");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}
	if (!err && rowsData && rowsData.length > 0)
	{
		logger.debug("Processing Feature Data");
		for (let i = 0; i < rowsData.length; i++)
		{
			returndata = {...returndata,...ParseFeatureRowDataObj(rowsData[i])};
		}

		return returndata;
	}
	else
	{
		logger.debug(`Location: app.js:350, App Error: ${err}`);
		logger.debug("No Feature Data for Subscriber Found");

		// returndata ={none:"none"};
		return returndata;
	}
}

export function SelectSubscriberLocation(err, rowsData, currentDataRowParser, req)
{
	logger.debug("SelectSubscriberLocation");
	let returndata = " ";
	let distance, shortestdistance, locationnum, service_range;
	if (!err && rowsData && rowsData.length > 0)
	{
		logger.debug("Processing Subscriber Data");

		for (let i = 0; i < rowsData.length; i++)
		{
			distance = dist(rowsData[i].latitude, rowsData[i].longitude, req.session.latitude, req.session.longitude);
			if (i == 0)
			{
				shortestdistance = distance;
				locationnum = rowsData[i].location_number;
				service_range = rowsData[i].service_range;
			}
			if ((distance < shortestdistance) && (distance < rowsData[i].service_range))
			{
				locationnum = rowsData[i].location_number;
				shortestdistance = distance;
				service_range = rowsData[i].service_range;
			}
		}
		req.session.location_number = locationnum;
		distance = distance / 1.60934;  // convert kilometers to miles
		req.session.location_distance = distance;
		if((distance <= service_range) || req.session.master_test) {
			returndata = {validzip: true, error: false, inrange: true, closest_location: locationnum, location_distance: distance};
		} else {
			returndata = {validzip: true, error: false, inrange: false, closest_location: locationnum, location_distance: distance};
		}
		if (!req.session.master_test) {
			LogAccess(req);
			return returndata;
		} else {
			return returndata;
		}
	}
	else
	{
		if (err) {
			logger.error(`Location: app.js:fn:SelectSubscriberLocation, App Error: ${err}`);
		} else {
			logger.warn("Subscriber NOT Found");
		}

		return {validzip: true, error: true, errortype: "Subscriber ID NOT Found" };
	}
}

export function ParseBuildingsData(rowData)
{
	delete rowData.active;
	delete rowData.building_type;
	delete rowData.display_order;
	if((rowData.options !== null) && (typeof rowData.options === "string")) {
		try {
			rowData.options = JSON.parse(rowData.options);
		} catch (error) {
			// TODO: send error report instead of sending to console.log
			rowData.options = null;
			logger.error(`Error parsing subscriber_buildings.options for RowID ${rowData.id} subscriber: ${rowData.subscriber_id}`);
		}
	}
	delete rowData.id;
	delete rowData.subscriber_id;

	return rowData;
}

export function ParseBackgroundData(rowData) {
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.building_type;
	return rowData;
}

export function ParseRafterData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	if (typeof rowData.rafter_spec === "string") {
		rowData.rafter_spec = JSON.parse("["+rowData.rafter_spec+"]");
	}
	if (typeof rowData.front_wall_attach_coord === "string") {
		rowData.front_wall_attach_coord = JSON.parse("["+rowData.front_wall_attach_coord+"]");
	}
	if (typeof rowData.rear_wall_attach_coord === "string") {
		rowData.rear_wall_attach_coord = JSON.parse("["+rowData.rear_wall_attach_coord+"]");
	}
	if (typeof rowData.lean_to_attach_coord === "string") {
		rowData.lean_to_attach_coord = JSON.parse("["+rowData.lean_to_attach_coord+"]");
	}
	if (typeof rowData.front_height_extension_attach_coord === "string") {
		rowData.front_height_extension_attach_coord = JSON.parse("["+rowData.front_height_extension_attach_coord+"]");
	}
	if (typeof rowData.rear_height_extension_attach_coord === "string") {
		rowData.rear_height_extension_attach_coord = JSON.parse("["+rowData.rear_height_extension_attach_coord+"]");
	}
	if (typeof rowData.truss_strut_ratio_coords === "string") {
		rowData.truss_strut_ratio_coords = JSON.parse("["+rowData.truss_strut_ratio_coords+"]");
	}
	return rowData;
}

export function ParseLeanToPriceData(rowData)
{
	let leanToStr = '{ "price": ' + rowData.price + ' }';

	return JSON.parse(leanToStr);
}

export function ParseDoorData(rowData)
{
	if(!(typeof rowData.override_button_file === "undefined") && rowData.override_button_file.length > 0) {
		rowData.button_file = rowData.override_button_file;
	}

	delete rowData.override_button_file;
	// object3D_ID has been depricated to make data consistent all references need to be changed to object3D_name.
	rowData.object3D_ID = rowData.object3D_name;
	if(rowData.available_hinges && (typeof rowData.available_hinges === "string")) {
		try {
			rowData.available_hinges = JSON.parse(rowData.available_hinges);
		} catch (error) {
			rowData.available_hinges = null;
		}
	}
	if(rowData.left_hinge_coords && (typeof rowData.left_hinge_coords === "string")) {
		try {
			rowData.left_hinge_coords = JSON.parse(rowData.left_hinge_coords);
		} catch (error) {
			rowData.left_hinge_coords = null;
		}
	}
	if(rowData.right_hinge_coords && (typeof rowData.right_hinge_coords === "string")) {
		try {
			rowData.right_hinge_coords = JSON.parse(rowData.right_hinge_coords);
		} catch (error) {
			rowData.right_hinge_coords = null;
		}
	}
	if(rowData.options && (typeof rowData.options === "string")) {
		try {
			rowData.options = JSON.parse(rowData.options);
		} catch (error) {
			// *** TODO: report any errors from malformed JSON data
			rowData.options = null;
		}
	}

	return rowData;
}

export function ParseHingeData(rowData)
{
	if (rowData.linked_product_id === null) {
		rowData.linked_product_id = "";
	}
	let hingeStr = `{ "belongs_to_category": "${rowData.belongs_to_category}", "category": "${rowData.category}", "elem_ID": "${rowData.elem_id}", "admin_only": ${rowData.admin_only}, "button_file": "${rowData.button_file}", "element_name": "${rowData.element_name}", "linked_product_id": "${rowData.linked_product_id}", "object3D_ID": "${rowData.object3D_name}", "width": ${rowData.width}, "height": ${rowData.height}, "width_display": "${rowData.width_display}", "height_display": "${rowData.height_display}", "price": ${rowData.price} }`;

	return JSON.parse(hingeStr);
}

export function ParseWindowData(rowData)
{
	if (rowData.override_button_file) {
		rowData.button_file = rowData.override_button_file;
	}
	if (rowData.linked_product_id === null) {
		rowData.linked_product_id = "";
	}
	let window = rowData;
	if (window.options) {
		window.window_options = window.options;
	} else {
		window.options = window.window_options;
	}
	window.elem_ID = window.elem_id;
	window.object3D_ID = window.object3D_name;
	delete window.id;
	delete window.subscriber_id;
	delete window.series;
	//let window_options = JSON.stringify(rowData.window_options);
	//let windowStr = `{ "elem_ID": "${rowData.elem_id}", "button_file": "${rowData.button_file}", "element_name": "${rowData.element_name}", "linked_product_id": "${rowData.linked_product_id}", "object3D_ID": "${rowData.object3D_name}", "width": ${rowData.width}, "height": ${rowData.height}, "width_display": "${rowData.width_display}", "height_display": "${rowData.height_display}", "max_number": ${rowData.max_number}, "price": ${rowData.price}, "admin_only": ${rowData.admin_only}, "user_specifiable_trim_color": ${rowData.user_specifiable_trim_color}, "removal_discount": ${rowData.removal_discount}, "no_extra_cost": ${rowData.no_extra_cost}, "wall_cutout_mode": ${rowData.wall_cutout_mode}, "window_options": ${window_options}}`;

	//return JSON.parse(windowStr);
	return window;
}

export function ParseOptionData(rowData)
{
	if (rowData.override_button_file) {
		rowData.button_file = rowData.override_button_file;
	}
	if (rowData.linked_product_id === null) {
		rowData.linked_product_id = "";
	}
	// elem_ID is depricated -- scheduled to be removed leaving elem_id
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	let option = {
		elem_ID: rowData.elem_id,
		object3D_ID: rowData.object3D_name,
		...rowData
	};

	return option;
}

export function ParseShelfData(rowData)
{
	if(!(typeof rowData.override_button_file === "undefined") && rowData.override_button_file.length > 0) {
		rowData.button_file = rowData.override_button_file;
	}
	if (rowData.linked_product_id === null) {
		rowData.linked_product_id = "";
	}
	rowData.elem_ID = rowData.elem_id;

	//return JSON.stringify(rowData);
	return rowData;
}

export function ParseWallData(rowData)
{
	let partition = {
		wallID: rowData.wall_id,
		button_file: rowData.button_file,
		display_name: rowData.display_name
	};
	//let partitionStr = '{ "wallID": "' + rowData.wall_id + '", "button_file": "' + rowData.button_file + '",  "display_name": "' + rowData.display_name + '" }';

	return partition;
}

export function ParsePartitionData(rowData)
{
	let partition = {
		partitionID: rowData.partition_id,
		button_file: rowData.button_file,
		price: rowData.price
	};
	//let partitionStr = '{ "partitionID": "' + rowData.partition_id + '", "button_file": "' + rowData.button_file + '", "price": ' + rowData.price + ' }';

	return partition;
}

export function Parse3DObjectData(rowData)
{
	rowData.object3D_ID = rowData.object_name;
	rowData.objectType = rowData.object_type;
	rowData.objectFile = rowData.object_file;
	rowData.textureName = rowData.texture_name;
	return rowData;
}

export function ParseUpdateDoorHingePlacementResult(err)
{
	logger.debug("ParseUpdateDoorHingePlacementResult");

	try
	{
		if (!err)
		{
			logger.debug("updateDoorHingePlacement Success!");

			return "Success!";
		}
		else
		{
			logger.debug("updateDoorHingePlacement Fail!");
			logger.debug(`Location: app.js:ParseUpdateDoorHingePlacementResult, App Error: ${err}`);

			return "Failed!";
		}
	}
	catch (ex)
	{
		logger.error(`Location: app.js:511, App Exception: ${ex}`);

		return "Failed!";
	}

};

export function ParseUpdate3DObjectsResult (err)
{
	logger.debug("ParseUpdate3DObjectsResult");

	try
	{
		if (!err)
		{
			logger.debug("Update3DObjects Success!");
			return "Success!";
		}
		else
		{
			logger.error("Update3DObjects Fail!");
			logger.error(`Location: app.js:ParseUpdate3DObjectsResult, App Error: ${err}`);
			return "Failed!";
		}
	}
	catch (ex)
	{
		logger.error(`Location: app.js:ParseUpdate3DObjectsResult, App Exception: ${ex}`);

		return "Failed!";
	}
};

export function ParseTextureData(rowData)
{
	delete rowData.id;
	rowData.textureName = rowData.texture_name;
	rowData.textureFile = rowData.texture_file_name;
	rowData.realWorldWidth = rowData.real_world_width;
	rowData.realWorldHeight = rowData.real_world_height;
	return rowData;
}

export function ParseKickBoardData(rowData)
{
	let data = {
		texture: rowData.texture
	};

	return data;
}

export function ParseColorData(rowData)
{
	/*let colorData = {
		color_id: rowData.color_id,
		color_name: rowData.color_name,
		color: rowData.color
	};

	return colorData;*/
	delete rowData.mfg_id;
	delete rowData.calibrated_color;
	delete rowData.sort_string;
	return rowData;
}

export function ParseDoorColorData(rowData)
{
	let colorData = {
		color_id: rowData.color_id,
		door_id: rowData.door_id,
		price: rowData.price
	};

	return colorData;
}

export function ParseBuildingSizeData(rowData)
{
	// TODO: rename id in 3D web app to building_id so that we dont' have to rename it here.
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	rowData.id = rowData.building_id;
	if (typeof rowData.porch_dimensions === "string") {
		rowData.porch_dimensions = JSON.parse("["+rowData.porch_dimensions+"]");
	}
	return rowData;
}

export function ParseSidingCategoryData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	rowData.profile_points = JSON.parse(`[${rowData.profile_points}]`);
	rowData.profile_texture_coordinates = JSON.parse(`[${rowData.profile_texture_coordinates}]`);

	return rowData;

}

export function ParseSidingColorData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;

	return rowData;
}

export function ParseRoofingCategoryData(rowData)
{
	return rowData;
}

export function ParseRoofingData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	if (rowData.override_button_file) {
		rowData.button_file = rowData.override_button_file;
	}
	rowData.textureFile = rowData.texture_file;
	rowData.realWorldWidth = rowData.texture_width;
	rowData.realWorldHeight = rowData.texture_height;
	return rowData;
}

export function ParseProfileData(rowData)
{
	let profileData = {
		horizontal_profile: JSON.parse("["+rowData.horizontal_profile+"]"),
		vertical_profile: JSON.parse("["+rowData.vertical_profile+"]")
	};

	return profileData;
}


export function ParseRoofingPriceData(rowData)
{
	let roofingPriceDataStr = '{ "price": ' + rowData.price + ' }';

	return JSON.parse(roofingPriceDataStr);
}

export function ParseSidingPriceData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	delete rowData.building_product_id;
	delete rowData.siding_category_id;
	return rowData;
}

export function ParseSidingDimensionPriceData(rowData)
{
	let sidingDimensionPriceData = {
		price: rowData.price
	};

	return sidingDimensionPriceData;
}


export function ParseDormerData(rowData)
{
	let dormer = {
		elem_ID: rowData.elem_id,
		element_name: rowData.dormer_name,
		object3D_ID: rowData.object3D_name,
		...rowData
	};

	delete dormer.id;
	delete dormer.subscriber_id;
	delete dormer.series_code;

	return dormer;
}

export function ParseTrimColorsData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;

	return rowData;
}

export function ParseSavedDesignsData(rowData)
{
	logger.silly('fn:ParseSavedDesignsData');
	// let create_date, modified_date, order_date, build_date, delivery_date, fq_design_id;
	rowData.fq_design_id = rowData.design_id;
	rowData.design_id = rowData.design_id.substring(rowData.design_id.indexOf("_")+1);
	// if(rowData.create_date) create_date = moment(rowData.create_date).format("YYYY-MM-DD");
	// if(rowData.modified_date) modified_date = moment(rowData.modified_date).format("YYYY-MM-DD");
	// if(rowData.order_date) order_date = moment(rowData.order_date).format("YYYY-MM-DD");
	// if(rowData.build_date) build_date = moment(rowData.build_date).format("YYYY-MM-DD");
	// if(rowData.delivery_date) delivery_date = moment(rowData.delivery_date).format("YYYY-MM-DD");
	rowData.shedName = rowData.shed_name;
	delete rowData.data;
	return rowData;
}

export function ParseSavedDesignData(rowData)
{
	let dataStr = "" + rowData.data;

	dataStr = dataStr.replace(/"/g, '\\"');

	// let savedDesignDataStr = '{ designData": "' + dataStr + '" }';

	//return savedDesignDataStr;
	if(rowData.data.length > 0) {
		let savedDesignData = {success: true, series_code: rowData.series_code, designData: dataStr};
		return savedDesignData; }
	else {
		return {success: false, status: "error", err: "Design Build Data Missing (record empty)"};
	}
}

export function ParseSavedDesignDataRows(err, rowsData, rowDataParser)
{
	if(rowsData.length > 0) {
		let rowData = rowsData[0];
		let dataStr = "" + rowData.data;

		if(rowData.data_format == "XML") {
			dataStr = dataStr.replace(/"/g, '\\"');
		}

		// let savedDesignDataStr = '{ designData": "' + dataStr + '" }';

		//return savedDesignDataStr;
		if(rowData.data.length > 0) {
			delete rowData.data;
			delete rowData.id;
			let savedDesignData = {success: true, designData: dataStr};
			savedDesignData = {...savedDesignData, ...rowData};
			return savedDesignData; }
		else {
			return {success: false, status: "error", err: "Design Build Data Missing (record empty)"};
		}
	}
	return {success: false, status: "error", err: "Design ID Requested does not exist in database"};
}

export function ParseDefaultSettings(rowData)
{
	logger.debug("ParseDefaultSettings");

	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	delete rowData.default_settings_id;

	return rowData;

}

export function ParseFloorConstructionDetails(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;

	return rowData;
}


export function ParseZipCodeRowData(rowData)
{
	rowData.zipCode = rowData.zipcode;
	rowData.country_code = "US";

	return zipCodeDataStr;
}

export function ParseRampData(rowData)
{

	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;

	return rowData;
}

export function ParseFeatureRowData(rowData)
{
	logger.debug("ParseFeatureRowData");

	let rowObject = '"' + rowData.feature_id + '":' + rowData.feature_data;
	return rowObject;
}

export function ParseFeatureRowDataObj(rowData)
{
	logger.debug("ParseFeatureRowData");
	let rowObject = {};

	if (typeof rowData.feature_data === "string") {
		try {
			rowObject[rowData.feature_id] = JSON.parse(rowData.feature_data);
		} catch (error) {
			logger.error(`app.js:fn:ParseFeaturerowDataObj error: ${error}`);
			rowObject[rowData.feature_id] = {
				error: "JSON Parse error trying to parse data in database field (ParseFeatureRowData)"
			};
		}
	} else {
		try {
			rowObject[rowData.feature_id] = rowData.feature_data;
		} catch (error) {
			rowObject[rowData.feature_id] = {
				error: "unable to assign feature data to object"
			};
		}
	}

	return rowObject;
}

export function ParseUsersRowDataObj(rowData)
{
	logger.silly("ParseMySqlRowDataObj");
	delete rowData.passwordhash;
	return rowData;
}

// callback function for zip code rows
export function ParseZipCodeRowsData (err, rows, currentDataRowParser, req)
{
	logger.debug("app.js/fn:ParseZipCodeRowsData");

	try
	{
		if (!err && rows && rows.length > 0)
		{
			// req.session.zipCode = req.body.zipCode;

			let postal_code_data = rows[0];
			postal_code_data.country_code = "US";
			// req.session.postal_code_data = postal_code_data;

			// req.session.latitude = rows[0].latitude;
			// req.session.longitude = rows[0].longitude;

			logger.debug(`latitude: ${req.session.latitude}`);

			logger.debug(`zip code success: ${req.session.zipCode}`);
			return {validzip: true, success: true, status: "Success", postal_code_data: postal_code_data};

		}
		else
		{
			logger.debug("invalid zip code!");
			return {validzip: false, error: false, reason: "Code not in database." };
		}
	}
	catch (ex)
	{
		logger.error(`ParseZipCodeRowsData exception: ${ex.toString()}`);
		return {validzip: false, error: true, errortype: "exception", err: ex.toString() };
	}
};

export function ParseLogResult (err,rows,currentDataRowParser)
{
	if (DEBUG) {
		logger.debug("ParseLogResult");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}


	if (!err)
		{
			logger.debug("Log Success!");
			return {success: true, status: "Success"};
		}
		else
		{
			logger.error(`fn:ParseLogResult Error:${err}`);
			return {success: false, status: "Error"};
		}

};

export function ParseLoginRowsData (err, rows, currentDataRowParser)
{
	if (DEBUG){
		logger.debug("ParseLoginRowsData");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}

	//let returndata;
	let userdata;

	try
	{
		if (!err && rows && rows.length > 0)
		{
			//req.session.user = req.body.username;

			//req.session.userdata = JSON.parse(JSON.stringify(rows[0]));
			userdata = JSON.parse(JSON.stringify(rows[0]));
			logger.debug('userdata set');

			logger.debug("login success!");

			if(userdata.with_prefix) {
				userdata.userid = userdata.userid.substring(userdata.userid.indexOf("_")+1);
			}
			return {success: true, response: "login success!", userdata: userdata};
		}
		else
		{
			if (err) {
				logger.error(`app.js:fn:ParseLoginRowsData error: ${err}`)
			} else {
				logger.debug("app.js:fn:ParseLoginRowsData:login failed!");
			}
			return {success: false, response: "login failed!", userdata: ""};
		}
	}
	catch (ex)
	{
		logger.error(`ParseLoginRowsData exception: ${ex.toString()}`);
		return {success: false, response: "login failed, exception!", userdata: ""};
	}

};

export function ParseSetDesignAsDefaultForBuilding (err, rows, currentDataRowParser) {
	if (DEBUG) {
		logger.debug("ParseSetDesignAsDefaultForBuilding");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}

	if (!err) {
		logger.debug("success");

		return "success";
	} else {
		logger.error(`SetDesignAsDefaultForBuilding failed: ${err}`);

		return "SetDesignAsDefaultForBuilding failed: ";
	}
};

export function ParseRegistrationResult (err,rows,currentDataRowParser)
{
	if (DEBUG) {
		logger.debug("ParseRegistrationResult");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}
	let returndata;

	if (!err) {
		return {
			status: "Success"
		};
	} else {
		logger.warn("ParseRegistrationResult: registration failed!");
		logger.error(`fn:ParseRegistrationResult error: ${err}`);
		returndata = {
			status: "Error",
			Description: "User record creation failed."
		};
		return returndata;
	}

};
