/*eslint-env node, es6*/
/*eslint-parserOptions ecmaVersion:2020*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape, no-undef*/

/*This module is for integrations with third party web apps */

const integrations = {
	EBMS: function(items) {
		let details = [];
		let building = -1;
		for (item of items) {
			if (item.class && item.linked_product_id) {
				if (["building"].includes(item.class))
				details.push({
				NO_ACC: true,
				NO_COMP: true,
				M_QUAN_VIS: 1,
				INVEN: item.linked_product_id.toUpperCase(),
				DESC: item.item,
				Materials: [{
					NO_ACC: true,
					NO_COMP: true,
					M_QUAN_VIS: 1,
					INVEN: "B"+item.linked_product_id.toUpperCase(),
					Materials: []
				}],
				UNIT_VIS: item.price
				});
				if (item.class === "building") {
					building = details.length - 1;
				}
				if (["roofing"].includes(item.class)) {
					details[building].Materials.push({
						NO_ACC: true,
						NO_COMP: true,
						M_QUAN_VIS: 1,
						INVEN: "03-SHINGLE OPTIONS",
						Materials: [{
							NO_ACC: true,
							NO_COMP: true,
							M_QUAN_VIS: 1,
							INVEN: "ARCHITECTURAL",
							Materials: [{
								//NO_ACC: true,
								//NO_COMP: true,
								M_QUAN_VIS: 1,
								INVEN: item.linked_product_id.toUpperCase(),
								UNIT_VIS: item.price,
								DESC: item.item
							}]
						}]
					});
				}
				if (["siding"].includes(item.class)) {
					details[building].Materials[0].Materials.push({
						NO_ACC: true,
						NO_COMP: true,
						M_QUAN_VIS: 1,
						INVEN: "01-BARN COLOR OPTIONS",
						Materials: [{
							//NO_ACC: true,
							//NO_COMP: true,
							M_QUAN_VIS: 1,
							INVEN: item.linked_product_id.toUpperCase(),
							UNIT_VIS: item.price,
							DESC: item.item
						}]
					});
				}
				if (["trim_color"].includes(item.class)) {
					details[building].Materials[0].Materials.push({
						NO_ACC: true,
						NO_COMP: true,
						M_QUAN_VIS: 1,
						INVEN: "02-TRIM COLOR OPTION",
						Materials: [{
							//NO_ACC: true,
							//NO_COMP: true,
							M_QUAN_VIS: 1,
							INVEN: item.linked_product_id.toUpperCase(),
							UNIT_VIS: item.price,
							DESC: item.item
						}]
					});
				}
				if (["door"].includes(item.class)) {
					if (item.options && item.options.EBMS && item.options.EBMS.parent) {
						let existingParent = details[building].Materials.find(element => element.INVEN === item.options.EBMS.parent)
						if (existingParent) {
							// parent already exists
							existingParent.Materials.push({
								M_QUAN_VIS: 1,
								INVEN: item.toUpperCase(),
								UNIT_VIS: item.price,
								DESC: item.item
							});
						} else {
							details[building].Materials[0].Materials.push({
								M_QUAN_VIS: 1,
							INVEN: item.options.EBMS.parent,
							Materials: [{
								NO_ACC: true,
								NO_COMP: true,
								M_QUAN_VIS: 1,
								INVEN: item.linked_product_id.toUpperCase(),
								UNIT_VIS: item.price,
								DESC: item.item
							}]
							});
						}
					}
				}
				if (["window"].includes(item.class)) {
					//
				}
				if (["option"].includes(item.class)) {
					//
				}
				if (["shelf"].includes(item.class)) {
					//
				}
			}
		}
		return details;
	}
};

export { integrations as default };
