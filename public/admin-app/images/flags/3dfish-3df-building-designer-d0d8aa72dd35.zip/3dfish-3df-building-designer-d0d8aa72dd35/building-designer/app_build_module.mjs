/*eslint-env node, es6*/
/*eslint-parserOptions ecmaVersion:2020*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape, no-undef*/

/*This module is for creating the build files */

import fs from "fs";

import UglifyJS from "terser";

import { dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

//compileCodeBase block
export function build({buildVersion, threejsVer, logger, DEBUG, buildDeactive} = {}) {

	logger.debug("app.js:compileJSCode:");
	// let compileCodeBase = "";
	let codeBaseArrays = [];
	let codeToBeLoadedArray = [];
	// make global
	// let codeBaseArrays = {};
	let compileList = [];
	let codeFile = {};
	let srcFile = {};
	let mapURL = {};
	codeFile["Sheds"] = __dirname + "/../public/code/build/shed_designer_code" + buildVersion + ".js";
	codeFile["Carports"] = __dirname + "/../public/code/build/carport_designer_code" + buildVersion + ".js";
	codeFile["Horsebarns"] = __dirname + "/../public/code/build/horsebarn_designer_code" + buildVersion + ".js";
	codeFile["Login"] = __dirname + "/../public/code/build/dashboard_login_code" + buildVersion + ".js";
	codeFile["Dashboard"] = __dirname + "/../public/code/build/dashboard_code" + buildVersion + ".js";
	srcFile["Sheds"] = __dirname + "/../public/code/build/src/shed_designer_code" + buildVersion + ".js";
	srcFile["Carports"] = __dirname + "/../public/code/build/src/carport_designer_code" + buildVersion + ".js";
	srcFile["Horsebarns"] = __dirname + "/../public/code/build/src/horsebarn_designer_code" + buildVersion + ".js";
	srcFile["Login"] = __dirname + "/../public/code/build/src/dashboard_login_code" + buildVersion + ".js";
	srcFile["Dashboard"] = __dirname + "/../public/code/build/src/dashboard_code" + buildVersion + ".js";
	mapURL["Sheds"] = "/code/build/src/shed_designer_code" + buildVersion + ".js.map";
	mapURL["Carports"] = "/code/build/src/carport_designer_code" + buildVersion + ".js.map";
	mapURL["Horsebarns"] = "/code/build/src/horsebarn_designer_code" + buildVersion + ".js.map";
	mapURL["Login"] = "/code/build/src/dashboard_login_code" + buildVersion + ".js.map";
	mapURL["Dashboard"] = "/code/build/src/dashboard_code" + buildVersion + ".js.map";

	// Compile code if compiled file is missing
	if (!buildDeactive) {
		if (!fs.existsSync(codeFile["Sheds"])) {compileList.push("Sheds");}
		if (!fs.existsSync(codeFile["Carports"])) {compileList.push("Carports");}
		if (!fs.existsSync(codeFile["Horsebarns"])) {compileList.push("Horsebarns");}
		if (!fs.existsSync(codeFile["Login"])) {compileList.push("Login");}
		if (!fs.existsSync(codeFile["Dashboard"])) {compileList.push("Dashboard");}
	}

	codeToBeLoadedArray.push("code/vendor/feature/feature.min.js");
	codeToBeLoadedArray.push("code/buildingdesigner/browsercheck.js");

	codeToBeLoadedArray.push(`code/vendor/three-js-${threejsVer}/three.js`);
	codeToBeLoadedArray.push(`code/vendor/three-js-${threejsVer}/exporters/OBJExporter.js`);

	codeToBeLoadedArray.push(`code/vendor/three-js-${threejsVer}/effects/StereoEffect.js`);
	codeToBeLoadedArray.push(`code/vendor/three-js-${threejsVer}/controls/DeviceOrientationControls.js`);
	codeToBeLoadedArray.push("code/vendor/jquery-plugins/jquery.serialize-object.min.js");

	codeToBeLoadedArray.push("code/custom/camera-controls/camera-controls.js");

	codeToBeLoadedArray.push("code/vendor/currency/currency.min.js");
	codeToBeLoadedArray.push("code/buildingdesigner/globals.js");
	codeToBeLoadedArray.push("code/buildingdesigner/mathutilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/progress_bar.js");
	codeToBeLoadedArray.push("code/buildingdesigner/fileio.js");
	codeToBeLoadedArray.push("code/buildingdesigner/auxutilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/nodejsutilities.js");

	codeToBeLoadedArray.push("code/buildingdesigner/guidatautilities.js");

	codeToBeLoadedArray.push("code/buildingdesigner/scriptloader.js");

	codeToBeLoadedArray.push(`code/vendor/three-js-${threejsVer}/loaders/STLLoader.js`);
	codeToBeLoadedArray.push(`code/vendor/three-js-${threejsVer}/stats/stats.min.js`);
	codeToBeLoadedArray.push(`code/vendor/three-js-${threejsVer}/loaders/OBJLoader.js`);

	codeToBeLoadedArray.push("code/vendor/md5/js/md5.js");
	codeToBeLoadedArray.push("code/vendor/node-lz4/lz4.js");

	codeToBeLoadedArray.push("code/buildingdesigner/gui_controls.js");

	codeToBeLoadedArray.push("code/buildingdesigner/login.js");

	codeToBeLoadedArray.push("code/buildingdesigner/buildingdesigner.js");

	codeToBeLoadedArray.push("code/buildingdesigner/analytics.js");
	codeToBeLoadedArray.push("code/buildingdesigner/index_db.js");

	codeToBeLoadedArray.push("code/buildingdesigner/error_text.js");
	codeToBeLoadedArray.push("code/buildingdesigner/printutilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/register.js");
	codeToBeLoadedArray.push("code/buildingdesigner/loading_saving_utilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/axis.js");
	codeToBeLoadedArray.push("code/buildingdesigner/subscriberdatautilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/adminutilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/userdatautilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/textdatautilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/objectdatautilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/profileutilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/geometryutilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/meshutilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/texturesdatautilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/colorsdatautilities.js");
	codeToBeLoadedArray.push("code/buildingdesigner/material.js");
	codeToBeLoadedArray.push("code/buildingdesigner/gui_input_events.js");
	codeToBeLoadedArray.push("code/buildingdesigner/background.js");
	codeToBeLoadedArray.push("code/buildingdesigner/ground.js");
	codeToBeLoadedArray.push("code/buildingdesigner/environment.js");
	codeToBeLoadedArray.push("code/buildingdesigner/camera.js");
	codeToBeLoadedArray.push("code/buildingdesigner/ruler.js");
	codeToBeLoadedArray.push("code/buildingdesigner/line_guide.js");
	codeToBeLoadedArray.push("code/buildingdesigner/floor.js");
	codeToBeLoadedArray.push("code/buildingdesigner/wall.js");
	codeToBeLoadedArray.push("code/buildingdesigner/walls.js");
	codeToBeLoadedArray.push("code/buildingdesigner/componentobject.js");
	codeToBeLoadedArray.push("code/buildingdesigner/componentobjects.js");
	codeToBeLoadedArray.push("code/buildingdesigner/element.js");
	codeToBeLoadedArray.push("code/buildingdesigner/elements.js");
	codeToBeLoadedArray.push("code/buildingdesigner/door.js");
	codeToBeLoadedArray.push("code/buildingdesigner/hinge.js");
	codeToBeLoadedArray.push("code/buildingdesigner/window.js");
	codeToBeLoadedArray.push("code/buildingdesigner/option.js");

	codeToBeLoadedArray.push("code/buildingdesigner/rafter.js");
	codeToBeLoadedArray.push("code/buildingdesigner/rafters.js");

	codeToBeLoadedArray.push("code/buildingdesigner/roof.js");
	codeToBeLoadedArray.push("code/buildingdesigner/building.js");

	codeToBeLoadedArray.push("code/buildingdesigner/lights.js");
	codeToBeLoadedArray.push("code/buildingdesigner/gui_elements_menu.js");
	codeToBeLoadedArray.push(`code/vendor/ThreeCSG/ThreeCSG.js`);

	codeToBeLoadedArray.push("code/buildingdesigner/logo.js");


	// if (compileList.indexOf("Sheds")>-1)
	{
		codeBaseArrays["Sheds"] = [...codeToBeLoadedArray];
		codeBaseArrays["Sheds"].push("code/buildingdesigner/shed_buildingdesigner.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/trim.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/hip_roof.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/porch_ceiling.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/porch_railings.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/porch_decking.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/porch_trim.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/porch.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/coated_floor.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/wall_extension.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/anchors.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/ramp.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/ridge_vent.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/cupola.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/shelf.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/metal_building_roof.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/shed_building.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/dormer.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/manor_shed_building.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/wood_framing.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/base.js");
		codeBaseArrays["Sheds"].push("code/buildingdesigner/metal_framing.js");
	}
	// if (compileList.indexOf("Carports")>-1)
	{
		codeBaseArrays["Carports"] = [...codeToBeLoadedArray];
		codeBaseArrays["Carports"].push("code/buildingdesigner/metal_buildingdesigner.js");
		codeBaseArrays["Carports"].push("code/buildingdesigner/carport_trim.js");
		codeBaseArrays["Carports"].push("code/buildingdesigner/carport_wall.js");
		codeBaseArrays["Carports"].push("code/buildingdesigner/carport_walls.js");
		codeBaseArrays["Carports"].push("code/buildingdesigner/leg_braces.js");
		codeBaseArrays["Carports"].push("code/buildingdesigner/metal_framing.js");
		codeBaseArrays["Carports"].push("code/buildingdesigner/metal_building_roof.js");
		codeBaseArrays["Carports"].push("code/buildingdesigner/metal_building.js");
		codeBaseArrays["Carports"].push("code/buildingdesigner/ground_beneath_building.js");
	}
	// if (compileList.indexOf("Horsebarns")>-1)
	{
		codeBaseArrays["Horsebarns"] = [...codeToBeLoadedArray];
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/horsebarn_buildingdesigner.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/horsebarn_trim.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/partition.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/kickboard.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/stallkickboards.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/stall.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/stalls.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/run_in.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/wood_framing.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/metal_building_roof.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/horsebarn_building.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/horsebarn_hook.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/horsebarn_base.js");
		codeBaseArrays["Horsebarns"].push("code/buildingdesigner/ground_beneath_building.js");
	}
	{
		codeBaseArrays["Login"] = [];
		codeBaseArrays["Login"].push("code/vendor/feature/feature.min.js");
		codeBaseArrays["Login"].push("code/buildingdesigner/browsercheck.js");
		codeBaseArrays["Login"].push("code/vendor/jquery-plugins/jquery.serialize-object.min.js");

		codeBaseArrays["Login"].push("code/buildingdesigner/globals.js");
		codeBaseArrays["Login"].push("code/buildingdesigner/mathutilities.js");
		codeBaseArrays["Login"].push("code/buildingdesigner/fileio.js");
		codeBaseArrays["Login"].push("code/buildingdesigner/auxutilities.js");
		codeBaseArrays["Login"].push("code/buildingdesigner/nodejsutilities.js");

		codeBaseArrays["Login"].push("code/buildingdesigner/scriptloader.js");

		codeBaseArrays["Login"].push("code/buildingdesigner/subscriberdatautilities.js");
		codeBaseArrays["Login"].push("code/buildingdesigner/userdatautilities.js");
		codeBaseArrays["Login"].push("code/vendor/md5/js/md5.js");
		codeBaseArrays["Login"].push("code/vendor/node-lz4/lz4.js");
		codeBaseArrays["Login"].push("code/buildingdesigner/dashboard/dblogin.js");
	}
	{
		codeBaseArrays["Dashboard"] = [];
		codeBaseArrays["Dashboard"].push("code/vendor/feature/feature.min.js");
		codeBaseArrays["Dashboard"].push("code/buildingdesigner/browsercheck.js");
		codeBaseArrays["Dashboard"].push("code/vendor/jquery-plugins/jquery.serialize-object.min.js");

		codeBaseArrays["Dashboard"].push("code/buildingdesigner/globals.js");
		codeBaseArrays["Dashboard"].push("code/buildingdesigner/mathutilities.js");
		codeBaseArrays["Dashboard"].push("code/buildingdesigner/fileio.js");
		codeBaseArrays["Dashboard"].push("code/buildingdesigner/auxutilities.js");
		codeBaseArrays["Dashboard"].push("code/buildingdesigner/nodejsutilities.js");
		codeBaseArrays["Dashboard"].push("code/buildingdesigner/guidatautilities.js");

		codeBaseArrays["Dashboard"].push("code/buildingdesigner/scriptloader.js");

		codeBaseArrays["Dashboard"].push("code/buildingdesigner/adminutilities.js");
		codeBaseArrays["Dashboard"].push("code/buildingdesigner/subscriberdatautilities.js");
		codeBaseArrays["Dashboard"].push("code/buildingdesigner/userdatautilities.js");
		codeBaseArrays["Dashboard"].push("code/vendor/md5/js/md5.js");
		codeBaseArrays["Dashboard"].push("code/vendor/node-lz4/lz4.js");
		codeBaseArrays["Dashboard"].push("code/buildingdesigner/dashboard/dblogin.js");
	}

	if (compileList.length == 0)
	{
		return codeBaseArrays;
	}

	for (let i=0; i < compileList.length; i++)
	{
		logger.debug(`Creating ${codeFile[compileList[i]]}`);
		let currentDate = new Date();
		let scripts = `console.log("${buildVersion} compiled ${currentDate}");console.log("Copyright (C) 3D Fish, LLC, all rights reserved.");`;

		for(let i2=0; i2<codeBaseArrays[compileList[i]].length;i2++)
		{
			scripts += fs.readFileSync(__dirname + "/../public/" + codeBaseArrays[compileList[i]][i2]);
		}

		let options =
		{
			warnings: true,
			mangle: true,
			compress: {
				sequences: true,
				dead_code: true,
				conditionals: true,
				booleans: true,
				unused: true,
				if_return: true,
				join_vars: true,
				drop_console: false
			}
		};
		if (DEBUG) {
			options = {...options,
			sourceMap: {
				filename: codeFile[compileList[i]],
				root: "src",
				url: mapURL[compileList[i]]
			}};
		}
		/*
		let options2 =
		{
			warnings: true
		};
		*/

		let result = UglifyJS.minify(scripts, options);

		if(typeof result.error === "undefined") {
			logger.info("No errors");
		}
		else {
			logger.error(result.error);
		}
		if(typeof result.warnings === "undefined") {logger.info("No Warnings");}
		else {
			logger.warn(`${result.warnings.length} Warnings`);
		}

		fs.writeFileSync(codeFile[compileList[i]],result.code);
		if (DEBUG && process.env.map) {
			fs.writeFileSync(codeFile[compileList[i]]+".map",result.map);
			fs.writeFileSync(srcFile[compileList[i]],scripts);
		}

	}

	return codeBaseArrays;
}
