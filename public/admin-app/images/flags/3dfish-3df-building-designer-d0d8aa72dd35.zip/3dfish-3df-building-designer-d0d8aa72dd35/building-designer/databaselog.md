Dan 4/27/2017:

Added table:  subscriber_transactions
Purpose:  To record subscriber billing and payments

Columns:

id  int 11  primary key auto increment
subscriber_id  vc 20
txdate    date
debit     decimal(7,2)
credit    decimal(7,2)
memo      vc(100)


Add column to buildings_sizes table

window_height  float


Clint 5/05/2017:

Added table: roofing_price
Purpose: To store the price of roofing per building and roofing category
		 building_product_id is the ID of the building with width,length and height information
		 For example: GW_ST1_ELITEDUTCH_BARN-12x16x7
		 roofing_category_id is the category ID for roofing, i.e, GAFTL


CREATE TABLE `roofing_price` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `building_product_id` varchar(100) NOT NULL,
  `roofing_category_id` varchar(7) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`id`)
)

Dan 5/09/2017:

Added table: subscriber_siding_price
Purpose: to store the price of siding per building and siding category
         building_product_id is the ID of the building with width,length and height information
		 For example: GW_ST1_ELITEDUTCH_BARN-12x16x7
		 siding_category_id is the category ID for siding, i.e, GP4TV

CREATE TABLE `subscriber_siding_price` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `building_product_id` varchar(100) NOT NULL,
  `siding_category_id` varchar(7) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`id`)
)


Clint 5/09/2017:

roofing_price table renamed to subscriber_roofing_price

New field for the default_settings table:

default_length VARCHAR(45)

Purpose: contains "SHORTEST", "LONGEST" or the numeric value of the default length


subscriber_id and data for TEST1 deleted from the windows, options and shelves table.

Reason: unused data from the original database

Dan 5/15/2017:

Added table: subscribers
Purpose: To store the main subscriber records.  This is a duplicate of the subscribers table from the old database
Changed display_prices field to default to 0  (to not display prices by default)

Dan 5/16/2017:

Added table: subscriber_feature_data
Purpose:  This table is used to storage data for optional subscriber features.  The datafield will contain the data in json format to enable the storing of a diverse data for each optional feature.  The first feature to use this is an optional financing price and a text blurb that goes just after the price in the price/details list.  This has been implimented on the Shed Designer version 1 and I plan to impliment it on version 2 shortly.

CREATE TABLE `subscriber_feature_data` (
    `id` int(10) NOT NULL AUTO_INCREMENT,
    `subscriber_id` varchar(20) NOT NULL,
    `feature_id` varchar(20) NOT NULL,
    `feature_data` varchar(256) NOT NULL,
    PRIMARY KEY (`id`)
)

Dan 5/23/2017:

Added Table:  clr_mfgs  (Color manufactures)
Purpose:  To give names to the manufacture id codes for the colors

mfg_id vchar20 primary index
mfg_name  vchar50

Dan 5/30/2017:

Added id column to trim_colors table so it is editable.

ALTER TABLE `trim_colors` ADD `id` INT NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`id`);


Dan 6/2/2017:

Added table for leanto pricing data

CREATE TABLE `tdfdesigner`.`subscriber_leanto_price` ( `id` INT NOT NULL AUTO_INCREMENT , `leanto_id` VARCHAR(30) NOT NULL , `length` INT NOT NULL , `price` DECIMAL(10,2) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARACTER SET ascii COLLATE ascii_general_ci;


Clint 6/10/2017:

Modified `subscriber_leanto_price` table:

CREATE TABLE `subscriber_leanto_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `rafter_id` varchar(45) NOT NULL,
  `length` float NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


`price` column deleted from `subscriber_siding` table.

Reason: used in 'subscriber_siding_price' table where we also have the building product id, the siding category id and the subscriber


Added table for siding prices based on dimensions:

CREATE TABLE `subscriber_siding_dimensions_price` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `width` float NOT NULL,
  `height` float NOT NULL,
  `siding_category_id` varchar(7) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130063 DEFAULT CHARSET=ascii;


Removed `price` column from the `walls` table.

Reason: the price is now in the `subscriber_siding_dimensions_price` table where it's determined from the specified width, height, siding_category_id and subscriber

Dan 6/13/2017:

Modified subscriber_locations

added a digit to the latitude and longitude fields --  Was 9,6  now 10,7

Reason:  Google lat/long numbers have 7 digits of precision.



Clint 6/19/2017:

Added table for selectable ramps:

CREATE TABLE `ramps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(45) DEFAULT NULL,
  `ramp_id` varchar(45) DEFAULT NULL,
  `width` float DEFAULT NULL,
  `length` float DEFAULT NULL,
  `height` float DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
)


Clint 6/28/2017:

Added table for kickboard data:

CREATE TABLE `kickboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(45) NOT NULL,
  `texture` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
)


Clint 7/04/2017:

Added a default_door_id column to the default_settings table so that the default stall door for horse barns can be specified.

Dan 7/11/2017:

Renamed table door_colors to subscriber_door_colors

Clint 7/12/2017:

Added bent_bow column to rafters table

ALTER TABLE `rafters` ADD `bend_bow` TINYINT(1) NULL AFTER `inner_trim`;

Dan 7/13/2017:

Added table for access logs

CREATE TABLE `tdfdesigner`.`access_log` ( `id` INT NOT NULL AUTO_INCREMENT , `ip_address` VARCHAR(39) NOT NULL , `subscriber_id` VARCHAR(20) NOT NULL , `date` DATE NOT NULL , `time` TIME NOT NULL , `latitude` DECIMAL(9,6) NOT NULL , `longitude` DECIMAL(9,6) NOT NULL , `distance` INT NOT NULL , `zipcode` INT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

Dan 7/14/2017:

Addit user_id column to access logs

ALTER TABLE `access_log` ADD `user_id` VARCHAR(20) NOT NULL AFTER `subscriber_id`;


Clint 7/26/2017:

Add a roofing profiles table for the geometry specification of the profiles.

CREATE TABLE `roofing_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(45) NOT NULL,
  `profile` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

Dan 7/20/2017

Add subscriber_dormers table

Copied structure from subscriber_doors

This is to specify any dormers that the customer is using so that the object loader can load them.

Dan 7/30/2017

Drop unused / previously renamed column -- type_description  ( was replaced by building_display_name previously ) from table buildings_sizes

ALTER TABLE `buildings_sizes` DROP `type_description`;

Clint 7/29/2017:

Add columns to buildings table:

siding_always_sets_eve_trim_color   tinyint
siding_always_sets_corner_trim_color  tinyint
eve_trim_uses_siding_color_setting   tinyint
corner_trim_uses_siding_color_setting  tinyint

Dan 7/31/2017:

renamed table trim_colors to subscriber_trim_colors
increase size of category_id column to 10
ALTER TABLE `roofing` CHANGE `category_id` `category_id` VARCHAR(10) NOT NULL;

Dan 8/1/2017:

Copied table descriptions from v1 shed designer to subscriber_descriptions table

id    int(11) AUTO_INCREMENT Primary Key
subscriber_id  varchar(20)
category_id    varchar(20)
object_id      varchar(90)
display_name   varchar(20)
short_description  varchar(80)
long_description    text


Clint 8/05/2017:

Added columns to the `roofing_profiles` table so that we can have horizontal and vertical profiles.

New create stament is:

CREATE TABLE `roofing_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(45) NOT NULL,
  `horizontal_profile` varchar(500) DEFAULT NULL,
  `vertical_profile` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


Added columns to the `roofing` table. `metal_roof` and `roof_style`, so that we can specify whether roofs are metal and their style, vertical or horizontal.

CREATE TABLE `roofing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `roofing_id` varchar(45) DEFAULT NULL,
  `category_id` varchar(10) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `display_name` varchar(40) NOT NULL,
  `color_name` varchar(256) DEFAULT NULL,
  `color_id` varchar(45) DEFAULT NULL,
  `texture_file` varchar(256) DEFAULT NULL,
  `texture_width` float DEFAULT NULL,
  `texture_height` float DEFAULT NULL,
  `texture_file_interior` varchar(256) DEFAULT NULL,
  `texture_width_interior` float DEFAULT NULL,
  `texture_height_interior` float DEFAULT NULL,
  `button_file` varchar(256) DEFAULT NULL,
  `metal_roof` tinyint(1) DEFAULT '0',
  `roof_style` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1971 DEFAULT CHARSET=ascii;

Dan 8/8/2017:

Add column to subscriber_siding_price table.   std_options_price float default 0
This is for the admin interface to help with pricing

Add column to building_types table.   base_siding_id  vc 45 null
This lets us know what siding type is included in the base price

Change the size of the tax percent column in subscriber_locations so that it can accept tax percentages to 3 decimal places.

ALTER TABLE `subscriber_locations` CHANGE `tax_percent` `tax_percent` DECIMAL(5,3) NOT NULL;

Change the data type of the data column in usersheds table to TEXT ( was BLOB ) for better useability.

ALTER TABLE `usersheds` CHANGE `data` `data` TEXT NULL DEFAULT NULL;


Clint 8/11/2017:

Changed object3D_id' to 'object3D_name' in the dormers table to correspond with the other tables.

Clint 8/12/2017:

Added and inserted data for subscriber_buildings, subscriber_buildings_sizes, subscriber_default_settings, subscriber_dormers and subscriber_partitions tables:

CREATE TABLE `subscriber_buildings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `building_id` varchar(45) NOT NULL,
  `building_type` varchar(45) NOT NULL DEFAULT 'SHED',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=ascii;

CREATE TABLE `subscriber_buildings_sizes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `product_id` varchar(45) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2559 DEFAULT CHARSET=utf8;

CREATE TABLE `subscriber_default_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `building_id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

CREATE TABLE `subscriber_partitions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `partition_id` varchar(45) NOT NULL,
  `price` float DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


Also added a column to the `roofing_profiles` table so that we can have horizontal and vertical profiles.


Clint 8/21/2017:

New table for the siding profiles

CREATE TABLE `siding_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(45) NOT NULL,
  `profile_points` varchar(500) DEFAULT NULL,
  `profile_texture_coordinates` varchar(500) DEFAULT NULL,
  `vertical_siding` tinyint(1) DEFAULT '0',
  `texture_name` varchar(256) DEFAULT NULL,
  `flat_base` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;



Clint 8/28/2017:

New table for the siding category buttons.

Purpose: the buttons were stored with the siding colors in the siding table, however if a subscriber did not have that particular color then the siding button wouldn't show

So now we have a siding categories table that contains the button image and also other information specific to a category, such as set_eve_trim_color and set_corner_trim_color

CREATE TABLE `siding_categories` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(45) NOT NULL,
  `category_id` varchar(7) NOT NULL,
  `button_file` varchar(256) DEFAULT 'SmartPanelGray_btn.jpg',
  `set_eve_trim_color` tinyint(1) DEFAULT '0',
  `set_corner_trim_color` tinyint(1) DEFAULT '0',
  `display_order` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=260 DEFAULT CHARSET=utf8;



The `siding_profiles` table now has the `texture_name_interior`, `texture_width_interior` and `texture_height_interior` columns there from the `siding` table.

This is because the `siding_profiles` table contains the texture coordinates and the texture name for the exterior siding profile, so we should also store the interior texture data there.

It's also preferable that it's there since those are defined on a per siding category basis like the profiles, rather than per color data which should be in the `siding` table.

The new create statement is:

CREATE TABLE `siding_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` varchar(45) NOT NULL,
  `profile_points` varchar(500) DEFAULT NULL,
  `profile_texture_coordinates` varchar(500) DEFAULT NULL,
  `vertical_siding` tinyint(1) DEFAULT '0',
  `texture_name` varchar(256) DEFAULT NULL,
  `flat_base` tinyint(1) DEFAULT '1',
  `texture_name_interior` varchar(256) DEFAULT NULL,
  `texture_width_interior` float DEFAULT NULL,
  `texture_height_interior` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8;


The `siding` table has now also being renamed to `siding_colors` because it now contains essentially just the color data.

The new create statement is:

CREATE TABLE `siding_colors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siding_id` varchar(45) NOT NULL,
  `category_id` varchar(7) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `display_name` varchar(40) DEFAULT NULL,
  `color_name` varchar(256) DEFAULT NULL,
  `color_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `siding_id` (`siding_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6826 DEFAULT CHARSET=ascii;

So it now contains essentially just the color data.


Dan 8/30/2017:

Drop the price field from table buildings_sizes  ( subscriber_buildings_sizes has the price field which is where it should be.)


Clint 8/31/2017:

The `default_settings` table now has a default_settings_id column so that subscribers can reference unique settings for a building, instead of them all referencing the same default building data based on the building_id.

So also renamed the building_id column to default_settings_id in the `subscribers_default_settings` table.

Modified the default_settings_table so that it has a default_window_id column for the horsebarn stalls.

Deleted the subscriber_id from the `default_settings` table, since we now use the `subscriber_default_settings` table to reference this data.


Clint 9/23/2017:

The `default_settings` table now has a `default_elements` column for the horsebarn's and shed's default elements defined in a JSON object array.

The `default_door_id` and `default_window_id` columns for horsebarns were removed since were now using the `default_elements` column which contains the element id's and other data.

CREATE TABLE `default_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `default_settings_id` varchar(45) DEFAULT NULL,
  `name` varchar(256) DEFAULT NULL,
  `building_id` varchar(45) DEFAULT NULL,
  `siding_id` varchar(45) DEFAULT NULL,
  `roofing_id` varchar(45) DEFAULT NULL,
  `trim_color_id` varchar(45) DEFAULT NULL,
  `default_length` varchar(45) NOT NULL,
  `default_elements` varchar(1000) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=237 DEFAULT CHARSET=ascii;


Dan 10/5/2017:

Add fields to subscriber_siding_dimensions_price so that the end walls on carports can be priced correctly.

ALTER TABLE `subscriber_siding_dimensions_price` ADD `building_height` INT NOT NULL AFTER `height`, ADD `wall_type` INT NOT NULL AFTER `building_height`;


Clint 10/12/2017:

The `walls` table now has a `display_order` column so that we can order the buttons

CREATE TABLE `walls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `wall_id` varchar(45) NOT NULL,
  `button_file` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
  `display_name` varchar(45) CHARACTER SET latin1 DEFAULT '',
  `display_order` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=ascii;

Dan 10/9/2017:

Add table admin_data for general admin data in json format.

CREATE TABLE `tdfdesigner`.`admin_data` ( `id` INT NOT NULL AUTO_INCREMENT , `key` VARCHAR(15) NOT NULL , `data` TEXT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

Dan 10/11/2017:

Rename column because of keyword conflict.

ALTER TABLE `admin_data` CHANGE `key` `datakey` VARCHAR(15) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL;

Dan 10/13/2017:

Rename Table walls to subscriber_walls

Rename Table siding_categories to subscriber_siding_categories



Clint 10/18/2017:

The `buildings_sizes` table now has a `combo_building_length` column specifying the length for combo unit carports.

CREATE TABLE `buildings_sizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `building_id` varchar(45) NOT NULL,
  `building_display_name` varchar(255) DEFAULT 'Barn',
  `product_id` varchar(45) NOT NULL,
  `width` float DEFAULT NULL,
  `height` float DEFAULT NULL,
  `length` float DEFAULT NULL,
  `width_display` varchar(45) DEFAULT NULL,
  `height_display` varchar(45) DEFAULT NULL,
  `length_display` varchar(45) DEFAULT NULL,
  `window_height` float DEFAULT '0',
  `stall_count` varchar(45) DEFAULT '0',
  `combo_building_length` float DEFAULT '-1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1155 DEFAULT CHARSET=ascii;

Dan 10/29/2017:

Add the flags field to the users table (version 1 funcationality)

ALTER TABLE `users` ADD `flags` VARCHAR(256) NULL AFTER `usertype`;

(changed it to default to null) (11/12/2017)  -- was preventing new registrations



Clint 10/30/2017:

The `options` table now has a `adjust_for_building` column to specify that the element changes based on the building size.

Used for longer leg braces on higher builds.

CREATE TABLE `options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `elem_id` varchar(45) NOT NULL,
  `belongs_to_category` varchar(45) CHARACTER SET latin1 NOT NULL,
  `element_name` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
  `width` float DEFAULT NULL,
  `height` float DEFAULT NULL,
  `button_file` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
  `texture_name` varchar(45) CHARACTER SET latin1 DEFAULT '',
  `object3D_name` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
  `wall_cutout_mode` tinyint(1) DEFAULT '1',
  `max_number` int(2) DEFAULT '-1',
  `width_display` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `height_display` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `building_type` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `adjust_for_building` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=ascii;



Clint 11/22/2017:

`user_specifiable_trim_color` column for the `subscriber_doors` and `subscriber_windows` tables so that users can specify their trim colors.


Clint 11/30/2017:

Changed the `data` column in the `usersheds` table from `text` to `longtext` because we need more storage now that we're generating self contained save files


Clint 12/04/2017:

Now using LONGBLOB for the `data` column in the `usersheds` table because we're sending the shed design and storing it as a blob.


Clint 12/11/2017:

The `subscriber_default_settings` table now has columns for the new default settings system:

`building_id`, `width` and `design_id`

These are used to get the default design for a building based on the building_id and the width.

The `subscriber_doors` and the `subscriber_windows` tables also have columns for whether an element has an extra cost or whether the cost is included in the building price and if there's a discount for removing the element

CREATE TABLE `subscriber_default_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `default_settings_id` varchar(45) DEFAULT NULL,
  `building_id` varchar(45) DEFAULT NULL,
  `design_id` varchar(20) DEFAULT NULL,
  `width` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


CREATE TABLE `subscriber_doors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `elem_id` varchar(45) NOT NULL,
  `price` float DEFAULT NULL,
  `building_type` varchar(45) DEFAULT 'SHED',
  `user_specifiable_trim_color` tinyint(1) DEFAULT '0',
  `removal_discount` float DEFAULT '0',
  `no_extra_cost` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=237 DEFAULT CHARSET=ascii;


CREATE TABLE `subscriber_windows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `elem_id` varchar(20) NOT NULL,
  `price` float DEFAULT NULL,
  `building_type` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `user_specifiable_trim_color` tinyint(1) DEFAULT '0',
  `removal_discount` float DEFAULT '0',
  `no_extra_cost` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=ascii;

Dan 2/7/2018

Drop column subscriber_id from 3dobjects

That column is not needed and has not been used in a long time.

Clint 02/16/2018:

The `buildings_sizes` table now has a porch_dimensions column for inset porches and their sizes.

A negative width indicates that the porch is on the left of the right wall, positive indicates that it is on the right.

CREATE TABLE `buildings_sizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `building_id` varchar(45) NOT NULL,
  `building_display_name` varchar(255) DEFAULT 'Barn',
  `product_id` varchar(45) NOT NULL,
  `width` float DEFAULT NULL,
  `height` float DEFAULT NULL,
  `length` float DEFAULT NULL,
  `width_display` varchar(45) DEFAULT NULL,
  `height_display` varchar(45) DEFAULT NULL,
  `length_display` varchar(45) DEFAULT NULL,
  `window_height` float DEFAULT '0',
  `stall_count` varchar(45) DEFAULT '0',
  `combo_building_length` float DEFAULT '-1',
  `porch_dimensions` varchar(45) DEFAULT '[0,0]',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1159 DEFAULT CHARSET=ascii;

Dan 2/23/2018:
DROP TABLE `siding_categories`

This table was no longer being used ... it was replaced by subscriber_siding_categories

Dan 2/27/2018:
ALTER TABLE `subscriber_buildings_sizes` ADD `base_std_options_price` FLOAT NOT NULL DEFAULT '0' AFTER `price`, ADD `base_siding_category_id` VARCHAR(7) NULL AFTER `base_std_options_price`;

These fields are to aid with the admin interface user experience to easily add prices without having to do extra calculations.


Dan 2/28/2018:
Move subscriber fields from buildings to subscriber_buildings

ALTER TABLE `subscriber_buildings` ADD `display_order` INT NOT NULL AFTER `building_type`, ADD `display_name` VARCHAR(45) NOT NULL AFTER `display_order`, ADD `button_file` VARCHAR(50) NOT NULL AFTER `display_name`, ADD `series_code` VARCHAR(45) NULL DEFAULT 'Standard' AFTER `button_file`, ADD `siding_always_sets_eve_trim_color` TINYINT NOT NULL DEFAULT '0' AFTER `series_code`, ADD `siding_always_sets_corner_trim_color` TINYINT NOT NULL DEFAULT '0' AFTER `siding_always_sets_eve_trim_color`, ADD `eve_trim_uses_siding_color_setting` TINYINT NOT NULL DEFAULT '1' AFTER `siding_always_sets_corner_trim_color`, ADD `corner_trim_uses_siding_color_setting` TINYINT NOT NULL DEFAULT '1' AFTER `eve_trim_uses_siding_color_setting`, ADD `user_can_override_trim_color` TINYINT NOT NULL DEFAULT '0' AFTER `corner_trim_uses_siding_color_setting`;

UPDATE `subscriber_buildings` INNER JOIN buildings ON subscriber_buildings.building_id = buildings.building_id SET subscriber_buildings.display_order = buildings.display_order, subscriber_buildings.display_name = buildings.display_name, subscriber_buildings.button_file=buildings.button_file, subscriber_buildings.series_code=buildings.series_code, subscriber_buildings.siding_always_sets_eve_trim_color=buildings.siding_always_sets_eve_trim_color, subscriber_buildings.siding_always_sets_corner_trim_color=buildings.siding_always_sets_corner_trim_color, subscriber_buildings.eve_trim_uses_siding_color_setting=buildings.eve_trim_uses_siding_color_setting, subscriber_buildings.corner_trim_uses_siding_color_setting=buildings.corner_trim_uses_siding_color_setting, subscriber_buildings.user_can_override_trim_color=buildings.user_can_override_trim_color WHERE 1

ALTER TABLE `buildings`
  DROP `display_order`,
  DROP `display_name`,
  DROP `button_file`,
  DROP `series_code`,
  DROP `siding_always_sets_eve_trim_color`,
  DROP `siding_always_sets_corner_trim_color`,
  DROP `eve_trim_uses_siding_color_setting`,
  DROP `corner_trim_uses_siding_color_setting`,
  DROP `user_can_override_trim_color`;

  Move subscriber field from buildings_sizes to subscriber_building_sizes

  ALTER TABLE `subscriber_buildings_sizes` ADD `building_display_name` VARCHAR(100) NULL DEFAULT 'Barn' AFTER `base_siding_category_id`;

 UPDATE `subscriber_buildings_sizes` INNER JOIN buildings_sizes ON subscriber_buildings_sizes.product_id = buildings_sizes.product_id SET subscriber_buildings_sizes.building_display_name = buildings_sizes.building_display_name WHERE 1

 ALTER TABLE `buildings_sizes` DROP `building_display_name`;


Clint 03/03/2018:

The `rafters` table now has a `width` column for the rafters.

CREATE TABLE `rafters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rafter_id` varchar(45) NOT NULL,
  `building_id` varchar(45) NOT NULL,
  `sub_type` varchar(45) DEFAULT NULL,
  `bld_mfg_id` varchar(20) NOT NULL DEFAULT '123',
  `rafter_spec` varchar(500) NOT NULL DEFAULT '[0,0]',
  `front_wall_attach_coord` varchar(45) NOT NULL DEFAULT '',
  `rear_wall_attach_coord` varchar(45) NOT NULL DEFAULT '',
  `roof_overhang` float DEFAULT NULL,
  `units` varchar(20) NOT NULL DEFAULT 'inches',
  `lean_to` tinyint(1) DEFAULT NULL,
  `lean_to_attach_coord` varchar(45) DEFAULT NULL,
  `lean_to_width` float DEFAULT NULL,
  `lean_to_width_display` varchar(45) DEFAULT NULL,
  `extra_cost` float DEFAULT NULL,
  `thickness` float DEFAULT '0.125',
  `width` float DEFAULT '0.292',
  `material_type` varchar(45) DEFAULT 'wood',
  `max_gap` float DEFAULT '1.328',
  `wall_height_segment_on_rafter` float DEFAULT '0',
  `front_height_extension_attach_coord` varchar(45) DEFAULT '',
  `rear_height_extension_attach_coord` varchar(45) DEFAULT '',
  `wall_roof_connection_angle` float DEFAULT '0',
  `curved_wall_roof_connection` tinyint(1) DEFAULT '0',
  `soffit_board` tinyint(1) DEFAULT '0',
  `soffit_board_width` float DEFAULT '0.01',
  `inner_trim` tinyint(1) DEFAULT '0',
  `bent_bow` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

Dan 03/13/2018:

Add active flag to siding_categories so that a siding category can be disabled without deleting it from the database.

ALTER TABLE `subscriber_siding_categories` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `display_order`;


Dan 03/20/2018:

Add table for subscriber roofing categories

CREATE TABLE `tdfdesigner`.`subscriber_roofing_categories` ( `id` INT NOT NULL AUTO_INCREMENT , `subscriber_id` VARCHAR(20) NOT NULL , `category_id` VARCHAR(10) NOT NULL , `active` BOOLEAN NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

Add table for system roofing categories

CREATE TABLE `tdfdesigner`.`roofing categories` ( `id` INT NOT NULL AUTO_INCREMENT , `category_id` VARCHAR(10) NOT NULL , `category_name` VARCHAR(45) NOT NULL , `button_file` VARCHAR(45) NOT NULL , `building_type` VARCHAR(45) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

Dan 4/5/2018:

Add table rafter_notes  -- this is for design notes on specific rafter designs so we can note the origens of the rafter and any related information.

CREATE TABLE `tdfdesigner`.`rafter_notes` ( `id` INT NOT NULL AUTO_INCREMENT , `rafter_id` VARCHAR(45) NOT NULL , `building_id` VARCHAR(45) NOT NULL , `sub_type` VARCHAR(45) NOT NULL , `notes` MEDIUMTEXT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

Clint 04/06/2018:

Created tables `hinges` and `subscriber_hinges` so that we can define hinges as elements to be placed on the doors.

CREATE TABLE `hinges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `elem_id` varchar(45) NOT NULL,
  `belongs_to_category` varchar(45) CHARACTER SET latin1 DEFAULT '',
  `category` varchar(45) CHARACTER SET latin1 DEFAULT '',
  `element_name` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
  `width` float DEFAULT NULL,
  `height` float DEFAULT NULL,
  `button_file` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
  `object3D_name` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
  `width_display` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `height_display` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `subscriber_hinges` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `elem_id` varchar(45) NOT NULL,
  `price` float DEFAULT NULL,
  `building_type` varchar(45) DEFAULT 'SHED',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;


Also created `left_hinge_coords` and `right_hinge_coords` columns for the `doors` table so that the hinges position can be specifed on the doors.

CREATE TABLE `doors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `elem_id` varchar(45) NOT NULL,
  `belongs_to_category` varchar(45) CHARACTER SET latin1 DEFAULT '',
  `category` varchar(45) CHARACTER SET latin1 NOT NULL,
  `element_name` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
  `width` float DEFAULT NULL,
  `height` float DEFAULT NULL,
  `button_file` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
  `object3D_name` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
  `available_colors_elem_id` varchar(20) CHARACTER SET latin1 DEFAULT '',
  `wall_cutout_mode` tinyint(1) DEFAULT '1',
  `max_number` int(2) DEFAULT '-1',
  `width_display` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `height_display` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
  `double_door` tinyint(1) DEFAULT '0',
  `double_door_from_single_door` tinyint(1) DEFAULT '0',
  `left_right_opening` tinyint(1) NOT NULL DEFAULT '1',
  `available_hinges` varchar(255) DEFAULT '[''STANDARD_HINGE'']',
  `left_hinge_coords` varchar(255) DEFAULT '[[0,0,0],[0,0,0],[0,0,0]]',
  `right_hinge_coords` varchar(255) DEFAULT '[[0,0,0],[0,0,0],[0,0,0]]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;



Dan 4/10/2018:

rename table floor_construction to subscriber_floor_construction and added to subscriber table list

rename table ramps to subscriber_ramps and added to subscriber table list

rename table kickboards to subscriber_kickboards and added to subscriber table list

Add table for series definitions -- this table will also be used to determine valid series types:

CREATE TABLE `tdfdesigner`.`subscriber_series` ( `id` INT NOT NULL AUTO_INCREMENT , `subscriber_id` VARCHAR(20) NOT NULL , `series_code` VARCHAR(45) NOT NULL , `building_type` VARCHAR(45) NOT NULL , `description` VARCHAR(200) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

Add series_code support to subscriber tables:

ALTER TABLE `subscriber_buildings_sizes` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_default_settings` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_descriptions` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_doors` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_door_colors` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_dormers` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_floor_construction` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_hinges` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_kickboards` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_leanto_price` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_options` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_partitions` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_ramps` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_roofing` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_roofing_price` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_shelves` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_siding` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_siding_categories` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_siding_dimensions_price` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_siding_price` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_trim_colors` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_walls` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_windows` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `usersheds` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

Dan 4/11/2018:

Add display name to series

ALTER TABLE `subscriber_series` ADD `display_name` VARCHAR(45) NOT NULL AFTER `series_code`;

Clint 04/13/2018:

Created table `subscriber_backgrounds` so that subscribers can specify the background texture to be used that's defined in the `textures` table.

CREATE TABLE `subscriber_backgrounds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subscriber_id` varchar(20) NOT NULL,
  `texture` varchar(45) DEFAULT 'sheddesigner_background',
  `color` varchar(45) DEFAULT 'rgb(255,255,255,255)',
  `building_type` varchar(45) NOT NULL DEFAULT 'SHED',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;


Dan 4/15/2018:

Change uszipcodes table to innodb -- recommended engine for Amazon RDS

Switch to Amazon Arora MySQL

The following tables were dropped as they were previously replaced with subscriber_ versions.

DROP TABLE floor_construction

DROP TABLE kickboards

Add active field to subscriber_buildings to allow for in-active building types that are currently being worked on or otherwise shouldn't be displayed.
ALTER TABLE `subscriber_buildings` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `building_id`;

Add field for buildings that should only be shown as an option for admin users.
ALTER TABLE `subscriber_buildings` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

Dan 4/17/2018:

Change id field to auto-increment for 3dobjects table
ALTER TABLE `3dobjects` CHANGE `id` `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT;

Add shortcode definition to subscriber_series table
ALTER TABLE `subscriber_series` ADD `series_shortcode` VARCHAR(6) NOT NULL AFTER `series_code`;


Clint 04/20/2018:

Modified table `rafters` to use a `truss_strut_ratio_coords` column for defining trusses. Contains an array of coords [bottom, top] defined as the ratio of the length from the apex for each strut.

CREATE TABLE `rafters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rafter_id` varchar(45) NOT NULL,
  `building_id` varchar(45) NOT NULL,
  `sub_type` varchar(45) DEFAULT NULL,
  `bld_mfg_id` varchar(20) NOT NULL DEFAULT '123',
  `rafter_spec` varchar(500) NOT NULL DEFAULT '[0,0]',
  `front_wall_attach_coord` varchar(45) NOT NULL DEFAULT '',
  `rear_wall_attach_coord` varchar(45) NOT NULL DEFAULT '',
  `truss_strut_ratio_coords` varchar(255) DEFAULT '',
  `roof_overhang` float DEFAULT NULL,
  `units` varchar(20) NOT NULL DEFAULT 'inches',
  `lean_to` tinyint(1) DEFAULT NULL,
  `lean_to_attach_coord` varchar(45) DEFAULT NULL,
  `lean_to_width` float DEFAULT NULL,
  `lean_to_width_display` varchar(45) DEFAULT NULL,
  `extra_cost` float DEFAULT NULL,
  `thickness` float DEFAULT '0.125',
  `width` float NOT NULL DEFAULT '0.292',
  `material_type` varchar(45) DEFAULT 'wood',
  `max_gap` float DEFAULT '1.328',
  `wall_height_segment_on_rafter` float DEFAULT '0',
  `front_height_extension_attach_coord` varchar(45) DEFAULT '',
  `rear_height_extension_attach_coord` varchar(45) DEFAULT '',
  `wall_roof_connection_angle` float DEFAULT '0',
  `curved_wall_roof_connection` tinyint(1) DEFAULT '0',
  `soffit_board` tinyint(1) DEFAULT '0',
  `soffit_board_width` float DEFAULT '0.01',
  `inner_trim` tinyint(1) DEFAULT '0',
  `bent_bow` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;


Dan 4/23/2018:

Add design_prefix to subscribers table for a subscriber unique design id prefix for saving designs.

ALTER TABLE `subscribers` ADD `design_prefix` VARCHAR(4) NOT NULL AFTER `subscriber_id`;

Dan 4/24/2018:

Make id column auto-increment

ALTER TABLE `hinges` CHANGE `id` `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT;

Move subscriber fields from doors to subscriber_doors

ALTER TABLE `subscriber_doors` ADD `available_hinges` VARCHAR(255) NULL AFTER `building_type`;

UPDATE `subscriber_doors` INNER JOIN doors ON subscriber_doors.elem_id = doors.elem_id SET subscriber_doors.available_hinges = doors.available_hinges WHERE 1

ALTER TABLE `doors` DROP `available_hinges`;

Dan 4/26/2018:

Remove subscriber_id column from dormers table

ALTER TABLE `dormers` DROP `subscriber_id`;


Clint 04/30/2018:

Modified table `rafters` to use a `truss_base_height_from_wall_height` column for defining the height of the horizontal beam offset from the wall attachment coordinate on the rafter.

ALTER TABLE `rafters` ADD `truss_base_height_from_wall_height` FLOAT AFTER `truss_strut_ratio_coords`;

Dan 5/3/2018:

Add active flag to the following:

ALTER TABLE `subscriber_doors` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `price`;

ALTER TABLE `subscriber_door_colors` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `color_id`;

ALTER TABLE `subscriber_hinges` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `elem_id`;

ALTER TABLE `subscriber_windows` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `elem_id`;

ALTER TABLE `subscriber_shelves` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `elem_id`;

ALTER TABLE `subscriber_ramps` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `ramp_id`;

ALTER TABLE `subscriber_roofing` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `roofing_id`;

ALTER TABLE `subscriber_options` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `elem_id`;

ALTER TABLE `subscriber_siding` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `siding_id`;

ALTER TABLE `subscriber_trim_colors` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `color_id`;

ALTER TABLE `subscriber_dormers` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `elem_id`;

Add display_order to subscriber_roofing_categories to be able to set the roofing button display order.

ALTER TABLE `subscriber_roofing_categories` ADD `display_order` TINYINT NOT NULL AFTER `category_id`;

Add series_code to subscriber_roofing_categories

ALTER TABLE `subscriber_roofing_categories` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

ALTER TABLE `subscriber_roofing_categories` ADD `series_code` VARCHAR(45) NOT NULL DEFAULT 'Standard' AFTER `subscriber_id`;

Fix name of roofing categories table

RENAME TABLE `roofing categories` TO `roofing_categories`;

Add display_order to siding colors and trim colors

ALTER TABLE `subscriber_siding` ADD `display_order` TINYINT NOT NULL AFTER `siding_id`;

ALTER TABLE `subscriber_trim_colors` ADD `display_order` TINYINT NOT NULL AFTER `color_id`;

Removed old unused trim_colors table

DROP TABLE trim_colors;

Change settings for price field to default to 0 and don't allow null -- this is to enable easier processing of field. Available hinges to default to ""

ALTER TABLE `subscriber_doors` CHANGE `price` `price` FLOAT NOT NULL DEFAULT '0';

ALTER TABLE `subscriber_doors` CHANGE `available_hinges` `available_hinges` VARCHAR(255) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL DEFAULT '';

ALTER TABLE `subscriber_door_colors` ADD `display_order` TINYINT NOT NULL AFTER `active`;

Create table for door color categories

CREATE TABLE `door_color_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `door_id` varchar(20) NOT NULL,
  `description` varchar(70) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

Dan 5/9/2018:

create subscriber_rafters table this is to be able to seperate the rafter from the building_id so that multiple buildings can use the same rafter

CREATE TABLE `tdfdesigner`.`subscriber_rafters` ( `id` INT NOT NULL AUTO_INCREMENT , `subscriber_id` VARCHAR(20) NOT NULL , `building_id` VARCHAR(45) NOT NULL , `series_code` VARCHAR(45) NOT NULL , `rafter_id` VARCHAR(45) NOT NULL , `wall_roof_connection_angle` FLOAT NULL DEFAULT '0' , `curved_wall_roof_connection` TINYINT NULL DEFAULT '0' , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

Dan 5/17/2018:

Add field to keep track of the calibrated digital color before any adjustments were made to get the color to render correctly.

ALTER TABLE `colors` ADD `calibrated_color` VARCHAR(32) NOT NULL AFTER `color`;

Dan 6/18/2018:

Update subscriber_rafters table:

ALTER TABLE `subscriber_rafters` ADD `sub_type` VARCHAR(45) NOT NULL AFTER `series_code`;
ALTER TABLE `subscriber_rafters` ADD `roof_overhang` FLOAT NULL DEFAULT NULL AFTER `rafter_id`, ADD `extra_cost` FLOAT NOT NULL DEFAULT '0' AFTER `roof_overhang`, ADD `max_gap` FLOAT NOT NULL DEFAULT '1.328' AFTER `extra_cost`;
ALTER TABLE `subscriber_rafters` ADD `soffit_board` TINYINT NULL DEFAULT '0' AFTER `curved_wall_roof_connection`, ADD `soffit_board_width` FLOAT NULL DEFAULT '0.01' AFTER `soffit_board`, ADD `inner_trim` TINYINT NULL DEFAULT '0' AFTER `soffit_board_width`;
ALTER TABLE `rafters_new3` ADD UNIQUE(`rafter_id`);

removed the above columns from the rafters table.   Split the data and populated the subscriber_rafters table.

Here is the new layout of the rafters table:
CREATE TABLE `rafters` (
  `id` int(10) UNSIGNED NOT NULL,
  `rafter_id` varchar(45) NOT NULL,
  `bld_mfg_id` varchar(20) NOT NULL DEFAULT '123',
  `rafter_spec` varchar(500) NOT NULL DEFAULT '[0,0]',
  `front_wall_attach_coord` varchar(45) NOT NULL DEFAULT '',
  `rear_wall_attach_coord` varchar(45) NOT NULL DEFAULT '',
  `truss_strut_ratio_coords` varchar(255) NOT NULL,
  `truss_base_height_from_wall_height` float NOT NULL DEFAULT '0',
  `units` varchar(20) NOT NULL DEFAULT 'inches',
  `lean_to` tinyint(1) DEFAULT NULL,
  `lean_to_attach_coord` varchar(45) DEFAULT NULL,
  `lean_to_width` float DEFAULT NULL,
  `lean_to_width_display` varchar(45) DEFAULT NULL,
  `thickness` float DEFAULT '0.125',
  `width` float NOT NULL DEFAULT '0.292',
  `material_type` varchar(45) DEFAULT 'wood',
  `wall_height_segment_on_rafter` float DEFAULT '0',
  `front_height_extension_attach_coord` varchar(45) DEFAULT '',
  `rear_height_extension_attach_coord` varchar(45) DEFAULT '',
  `bent_bow` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

Dan 7/3/2018:
Add column to suberscriber_doors

ALTER TABLE `subscriber_doors` ADD `override_button_file` VARCHAR(256) NOT NULL AFTER `no_extra_cost`;

This is to provide the ability to override the default door button.

Dan 8/29/2018:

Add active column to subscriber_series

ALTER TABLE `subscriber_series` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `display_name`;

Dan 9/10/2018:

Add design_archived to usersheds

ALTER TABLE `usersheds` ADD `design_archived` BOOLEAN NOT NULL DEFAULT FALSE AFTER `design_locked`;

Set default values on boolean fields

ALTER TABLE `usersheds` CHANGE `design_locked` `design_locked` TINYINT(1) NOT NULL DEFAULT '0';

ALTER TABLE `usersheds` CHANGE `design_ordered` `design_ordered` TINYINT(1) NOT NULL DEFAULT '0';

ALTER TABLE `usersheds` CHANGE `design_built` `design_built` TINYINT(1) NOT NULL DEFAULT '0';

ALTER TABLE `usersheds` CHANGE `design_delivered` `design_delivered` TINYINT(1) NOT NULL DEFAULT '0';

Add table user_deleted_sheds for deleted designs

CREATE TABLE `user_deleted_sheds` (
  `id` int(10) UNSIGNED NOT NULL,
  `subscriber_id` varchar(20) DEFAULT NULL,
  `series_code` varchar(45) NOT NULL DEFAULT 'Standard',
  `location_number` int(11) DEFAULT NULL,
  `userid` varchar(25) DEFAULT NULL,
  `design_id` varchar(20) DEFAULT NULL,
  `deleted_date` date NOT NULL,
  `create_date` date DEFAULT NULL,
  `software_version` varchar(20) DEFAULT NULL,
  `modified_date` date DEFAULT NULL,
  `design_locked` tinyint(1) NOT NULL DEFAULT '0',
  `design_archived` tinyint(1) NOT NULL DEFAULT '0',
  `design_ordered` tinyint(1) NOT NULL DEFAULT '0',
  `invoice_number` varchar(20) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `design_built` tinyint(1) NOT NULL DEFAULT '0',
  `build_date` date DEFAULT NULL,
  `design_delivered` tinyint(1) NOT NULL DEFAULT '0',
  `delivery_date` date DEFAULT NULL,
  `shed_name` varchar(256) DEFAULT NULL,
  `data` longblob,
  `building_type` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

ALTER TABLE `user_deleted_sheds`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`),
  ADD KEY `userid` (`userid`);

ALTER TABLE `user_deleted_sheds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

Dan 10/14/2018:

ALTER TABLE `usersheds` ADD `data_format` VARCHAR(20) NOT NULL DEFAULT 'XML' AFTER `shed_name`;

Dan 10/22/2018:

Add new fields for selected interface and type of subscription record

ALTER TABLE `subscribers` ADD `interface_id` INT NOT NULL DEFAULT '2' AFTER `interface_html`, ADD `building_type` VARCHAR(45) NOT NULL DEFAULT 'SHED' AFTER `interface_id`;

Add table for interface definitions

CREATE TABLE `tdfdesigner`.`interfaces` ( `id` INT NOT NULL AUTO_INCREMENT , `interface_id` INT NOT NULL , `building_type` VARCHAR(45) NOT NULL , `interface_file` VARCHAR(45) NOT NULL , `description` VARCHAR(256) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

Add data_format to user_deleted_sheds
ALTER TABLE `user_deleted_sheds` ADD `data_format` VARCHAR(20) NOT NULL DEFAULT 'XML' AFTER `shed_name`;

Dan 10/24/2018:
Fix length of userid in access_log to correct length

ALTER TABLE `access_log` CHANGE `user_id` `user_id` VARCHAR(25) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL;

Dan 10/29/2018:

Move subscriber specific data from buildings_sizes to subscriber_buildings_sizes

Add fields to subscriber_buildings_sizes

ALTER TABLE `subscriber_buildings_sizes` ADD `width` FLOAT NULL AFTER `building_display_name`, ADD `height` FLOAT NULL AFTER `width`, ADD `length` FLOAT NULL AFTER `height`, ADD `width_display` VARCHAR(45) NULL AFTER `length`, ADD `height_display` VARCHAR(45) NULL AFTER `width_display`, ADD `length_display` VARCHAR(45) NULL AFTER `height_display`, ADD `window_height` FLOAT NOT NULL DEFAULT '0' AFTER `length_display`, ADD `stall_count` VARCHAR(45) NULL AFTER `window_height`, ADD `combo_building_length` FLOAT NOT NULL DEFAULT '-1' AFTER `stall_count`, ADD `porch_dimensions` VARCHAR(45) NOT NULL DEFAULT '0,0' AFTER `combo_building_length`;

Move data from buildings_sizes

UPDATE `subscriber_buildings_sizes_new` INNER JOIN buildings_sizes ON subscriber_buildings_sizes.product_id = buildings_sizes.product_id SET subscriber_buildings_sizes_new.width = buildings_sizes.width, subscriber_buildings_sizes_new.height = buildings_sizes.height, subscriber_buildings_sizes_new.length = buildings_sizes.length, subscriber_buildings_sizes_new.width_display = buildings_sizes.width_display, subscriber_buildings_sizes_new.height_display = buildings_sizes.height_display, subscriber_buildings_sizes_new.length_display = buildings_sizes.length_display, subscriber_buildings_sizes_new.window_height = buildings_sizes.window_height, subscriber_buildings_sizes_new.stall_count = buildings_sizes.stall_count, subscriber_buildings_sizes_new.combo_building_length = buildings_sizes.combo_building_length, subscriber_buildings_sizes_new.porch_dimensions = buildings_sizes.porch_dimensions WHERE 1

Remove columns from buildings_sizes
ALTER TABLE `buildings_sizes`
  DROP `width`,
  DROP `height`,
  DROP `length`,
  DROP `width_display`,
  DROP `height_display`,
  DROP `length_display`,
  DROP `window_height`,
  DROP `stall_count`,
  DROP `combo_building_length`,
  DROP `porch_dimensions`;

Create buildings_sizes_defaults

Create subscriber_buildings_sizes_defaults

Add building_id field to subscriber_buildings_sizes_defaults
ALTER TABLE `subscriber_buildings_sizes_defaults` ADD `building_id` VARCHAR(45) NULL AFTER `series_code`;

11/2/2018 Dan:

Add display_order to subscriber_roofing table
ALTER TABLE `subscriber_roofing` ADD `display_order` TINYINT NOT NULL DEFAULT '0' AFTER `price`;

11/5/2018 Dan:
Removed various transition tables from the database.  rafters_old, rafters_new, rafters_new2, rafters_new3, buildings_old, dormers_old, sessions_old, subscriber_rafters_join, subscriber_rafters_join2, siding2, siding_old

11/7/2018 Dan:
Add field for link header to the interfaces table and Code Base field.

ALTER TABLE `interfaces` ADD `production_link_header` VARCHAR(256) NULL AFTER `interface_file`;

ALTER TABLE `interfaces` ADD `codebase_to_load` VARCHAR(25) NULL AFTER `interface_file`;

11/8/2018 Dan:
Make row id field auto-increment for the Doors table

ALTER TABLE `doors` CHANGE `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT;

11/20/2018 Dan:
Add comment to field

ALTER TABLE `options` CHANGE `wall_cutout_mode` `wall_cutout_mode` TINYINT(1) NULL DEFAULT '1' COMMENT '0: rectangle cutout, 1: no cutout, 2:curved cutout';

Create table for subscriber viewable update log

CREATE TABLE `tdfdesigner`.`update_log` ( `id` INT NOT NULL AUTO_INCREMENT , `date` DATETIME NOT NULL , `version` INT NOT NULL , `commit` VARCHAR(10) NOT NULL , `description` TEXT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

11/21/2018 Dan:
ALTER TABLE `subscriber_doors` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

ALTER TABLE `subscriber_windows` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

ALTER TABLE `subscriber_options` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

ALTER TABLE `subscriber_hinges` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

ALTER TABLE `subscriber_roofing_categories` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

ALTER TABLE `subscriber_roofing` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

ALTER TABLE `subscriber_siding_categories` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

ALTER TABLE `subscriber_siding` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

ALTER TABLE `subscriber_trim_colors` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

ALTER TABLE `subscriber_shelves` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

ALTER TABLE `subscriber_series` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

CREATE TABLE handles LIKE hinges;

i.e.:

CREATE TABLE `handles` (
 `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
 `elem_id` varchar(45) NOT NULL,
 `belongs_to_category` varchar(45) CHARACTER SET latin1 DEFAULT '',
 `category` varchar(45) CHARACTER SET latin1 DEFAULT '',
 `element_name` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
 `width` float DEFAULT NULL,
 `height` float DEFAULT NULL,
 `button_file` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
 `object3D_name` varchar(256) CHARACTER SET latin1 DEFAULT NULL,
 `width_display` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
 `height_display` varchar(45) CHARACTER SET latin1 DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8

CREATE TABLE subscriber_handles LIKE subscriber_hinges

i.e.:

CREATE TABLE `subscriber_handles` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `subscriber_id` varchar(20) NOT NULL,
 `series_code` varchar(45) NOT NULL DEFAULT 'Standard',
 `elem_id` varchar(45) NOT NULL,
 `active` tinyint(1) NOT NULL DEFAULT '1',
 `admin_only` tinyint(1) NOT NULL DEFAULT '0',
 `price` float NOT NULL,
 `building_type` varchar(45) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii

11/23/2018 Dan:

Add options field for JSON data

ALTER TABLE `subscriber_doors` ADD `options` TEXT NULL COMMENT 'JSON data: See the key \"door_options\" in the admin_data table for valid options' AFTER `override_button_file`;

Change type on version field
ALTER TABLE `update_log` CHANGE `version` `version` VARCHAR(11) NOT NULL;

11/25/2018 Dan:
Create table for Building Manufactures

CREATE TABLE building_mfgs LIKE clr_mfgs

12/5/2018 Dan:
Add field for JSON option data for buildings.

ALTER TABLE `subscriber_buildings` ADD `options` TEXT NULL COMMENT 'JSON data: See the key \"buildings_options\" in the admin_data table for valid options' AFTER `user_can_override_trim_color`;

ALTER TABLE `admin_data` CHANGE `datakey` `datakey` VARCHAR(20) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL;

12/7/2018 Dan:

Move building_id into subscriber_buildings_sizes from builds_sizes as it no longer makes sense for the table buildings_sizes to exist.

ALTER TABLE `subscriber_buildings_sizes` ADD `building_id` VARCHAR(45) NULL AFTER `series_code`;

UPDATE `subscriber_buildings_sizes` INNER JOIN buildings_sizes ON subscriber_buildings_sizes.product_id = buildings_sizes.product_id SET subscriber_buildings_sizes.building_id = buildings_sizes.building_id WHERE 1

12/18/2018 Dan:

Increase sie of feature_data field for longer data

ALTER TABLE `subscriber_feature_data` CHANGE `feature_data` `feature_data` TEXT CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL;

ALTER TABLE `subscriber_feature_data` CHANGE `feature_data` `feature_data` TEXT CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL COMMENT 'Must be valid JSON data';

12/19/2018 Dan:
ALTER TABLE `admin_data` CHANGE `datakey` `datakey` VARCHAR(40) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL;

ALTER TABLE `admin_data` CHANGE `data` `data` TEXT CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL COMMENT 'Must be valid JSON data';

Remove obsolete tables
DROP TABLE `buildings`;

DROP TABLE `buildings_sizes`;

12/23/2018 Dan:

Increase size of userid field

ALTER TABLE `users` CHANGE `userid` `userid` VARCHAR(40) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL;

ALTER TABLE `usersheds` CHANGE `userid` `userid` VARCHAR(40) CHARACTER SET ascii COLLATE ascii_general_ci NULL DEFAULT NULL;

ALTER TABLE `user_deleted_sheds` CHANGE `userid` `userid` VARCHAR(40) CHARACTER SET ascii COLLATE ascii_general_ci NULL DEFAULT NULL;

ALTER TABLE `access_log` CHANGE `user_id` `user_id` VARCHAR(40) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL;

ALTER TABLE `change_log` CHANGE `userid` `userid` VARCHAR(40) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL;

Add field to record status of userid prefix
ALTER TABLE `users` ADD `with_prefix` BOOLEAN NOT NULL DEFAULT FALSE AFTER `userid`;

12/31/2018 Dan:
Add sort string field to colors for inteligent color sorting

ALTER TABLE `colors` ADD `sort_string` varchar(32) COLLATE 'ascii_general_ci' NOT NULL;

1/4/2018 Dan:

Increase size of design_prefix field
ALTER TABLE `subscribers` CHANGE `design_prefix` `design_prefix` varchar(6) COLLATE 'ascii_general_ci' NOT NULL AFTER `subscriber_id`;

1/7/2019 Dan:

Add last_access date field to users table
ALTER TABLE `users` ADD `last_access` date NULL AFTER `signup_date`;

1/10/2019 Dan:

Create table subscriber_server_data for feature data to only expose to the server and not the client.
CREATE TABLE `tdfdesigner`.`subscriber_server_data` ( `id` INT NOT NULL AUTO_INCREMENT , `subscriber_id` VARCHAR(20) NOT NULL , `feature_id` VARCHAR(20) NOT NULL , `feature_data` JSON NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

1/11/2019 Dan:

Add override_button_file field to subscriber_shelves
ALTER TABLE `subscriber_shelves` ADD `override_button_file` varchar(256) COLLATE 'ascii_general_ci' NOT NULL AFTER `elem_id`,
CHANGE `building_type` `building_type` varchar(45) COLLATE 'ascii_general_ci' NULL AFTER `price`;

1/13/2019 Dan:

add json options column to subscribwer_floor_construction
ALTER TABLE `subscriber_floor_construction` ADD `options` json NOT NULL;

1/14/2019 Dan:
add json options column to subscriber_roofing_categories
ALTER TABLE `subscriber_roofing_categories` ADD `options` json NOT NULL;

1/16/2019 Dan:
create table for available backgrounds

CREATE TABLE `tdfdesigner`.`backgrounds` ( `id` INT NOT NULL AUTO_INCREMENT , `texture_name` VARCHAR(45) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

1/17/2019 Dan:

CREATE TABLE `tdfdesigner`.`user_contact_requests` ( `id` INT NOT NULL AUTO_INCREMENT , `subscriber_id` VARCHAR(20) NOT NULL , `user_id` VARCHAR(40) NULL , `contact_time` DATETIME NULL , `data` JSON NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

1/20/2019 Dan:

Add JSON option column to subscriber_options
ALTER TABLE `subscriber_options` CHANGE `building_type` `building_type` varchar(45) COLLATE 'ascii_general_ci' NULL AFTER `price`,
ADD `options` json NOT NULL;

Add elem_type to specify the element type instead of using the elem_id to allow for multiple elements of a specific type without having to modify the code.
ALTER TABLE `options` ADD `elem_type` varchar(45) COLLATE 'ascii_general_ci' NOT NULL AFTER `belongs_to_category`;
UPDATE options SET elem_type = elem_id WHERE 1;

1/24/2019 Clint:
Add cross_member column to subscriber_buildings to create a horizontal cross member support
ALTER TABLE `tdfdesigner`.`subscriber_buildings`
ADD COLUMN `cross_member` INT(1) NULL DEFAULT '0';

1/25/2019 Dan:

CREATE TABLE `tdfdesigner`.`user_order_requests` ( `id` INT NOT NULL AUTO_INCREMENT , `subscriber_id` VARCHAR(20) NOT NULL , `user_id` VARCHAR(40) NULL , `contact_time` DATETIME NULL , `data` JSON NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

1/27/2019 Dan:

ALTER TABLE `subscriber_default_settings` ADD `siding_id` varchar(45) NOT NULL, ADD `roofing_id` varchar(45) NULL AFTER `siding_id`, ADD `trim_color_id` varchar(45) NULL AFTER `roofing_id`, ADD `default_length` varchar(45) NULL AFTER `trim_color_id`, ADD `default_elements` varchar(1000) NOT NULL AFTER `default_length`;

UPDATE `subscriber_default_settings` INNER JOIN default_settings ON subscriber_default_settings.default_settings_id = default_settings.default_settings_id SET subscriber_default_settings.siding_id = default_settings.siding_id, subscriber_default_settings.roofing_id = default_settings.roofing_id, subscriber_default_settings.trim_color_id = default_settings.trim_color_id, subscriber_default_settings.default_length = default_settings.default_length, subscriber_default_settings.default_elements = default_settings.default_elements WHERE 1

ALTER TABLE `subscriber_default_settings`
CHANGE `default_elements` `default_elements` varchar(1000) COLLATE 'utf8_general_ci' NOT NULL DEFAULT '[\"\"]' AFTER `default_length`;

ALTER TABLE `subscriber_default_settings`
CHANGE `default_elements` `default_elements` json NOT NULL AFTER `default_length`;

ALTER TABLE `subscriber_default_settings`
ADD `options` json NOT NULL;

1/28/2019 Dan:
ALTER TABLE `subscriber_doors` ADD `display_order` int NOT NULL DEFAULT '1' AFTER `active`;

Increase size of userid to 60
ALTER TABLE `users` CHANGE `userid` `userid` varchar(60) COLLATE 'ascii_general_ci' NOT NULL AFTER `location_number`;
ALTER TABLE `usersheds` CHANGE `userid` `userid` varchar(60) COLLATE 'ascii_general_ci' NULL AFTER `location_number`;
ALTER TABLE `user_deleted_sheds` CHANGE `userid` `userid` varchar(60) COLLATE 'ascii_general_ci' NULL AFTER `location_number`;
ALTER TABLE `user_contact_requests` CHANGE `user_id` `user_id` varchar(60) COLLATE 'ascii_general_ci' NULL AFTER `subscriber_id`;
ALTER TABLE `user_order_requests` CHANGE `user_id` `user_id` varchar(60) COLLATE 'ascii_general_ci' NULL AFTER `subscriber_id`;
ALTER TABLE `access_log` CHANGE `user_id` `user_id` varchar(60) COLLATE 'ascii_general_ci' NOT NULL AFTER `subscriber_id`;
ALTER TABLE `change_log` CHANGE `userid` `userid` varchar(60) COLLATE 'ascii_general_ci' NOT NULL AFTER `subscriber_id`;

1/30/2019 Dan:
ALTER TABLE `rafters` ADD `options` json NOT NULL;

2/4/2019 Dan:
ALTER TABLE `subscriber_dormers` ADD `display_order` int NOT NULL DEFAULT '0' AFTER `active`;
ALTER TABLE `subscriber_windows` ADD `display_order` int NOT NULL DEFAULT '0' AFTER `active`;

2/7/2019 Dan:

CREATE TABLE `subscriber_building_templates` (`id` int NOT NULL AUTO_INCREMENT PRIMARY KEY, `subscriber_id` varchar(20) NOT NULL, `series_code` varchar(45) NOT NULL, `building_id` varchar(45) NOT NULL, `template_id` varchar(45) NOT NULL, `template` json NOT NULL);

ALTER TABLE `subscriber_feature_data` CHANGE `feature_data` `feature_data` json NOT NULL COMMENT 'Must be valid JSON data' AFTER `feature_id`;

2/8/2019 Dan:
Added linked_product_id -- this is for the subscriber's internal product id to facilitate automatic price updates between the subscribers system and the shed designer.
ALTER TABLE `subscriber_buildings_sizes` ADD `linked_product_id` varchar(45) NULL AFTER `product_id`;

2/13/2019 Dan:
ALTER TABLE `3dobjects` ADD `units` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `object_file`;
ALTER TABLE `3dobjects_hinges` ADD `units` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `object_file`;
ALTER TABLE `doors` ADD `units` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `element_name`;
ALTER TABLE `dormers` ADD `units` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `dormer_name`;
ALTER TABLE `handles` ADD `units` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `element_name`;
ALTER TABLE `hinges` ADD `units` varchar(20) COLLATE 'latin1_swedish_ci' NULL AFTER `element_name`;
ALTER TABLE `options` ADD `units` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `element_name`;
ALTER TABLE `ramps` ADD `units` varchar(20) COLLATE 'utf8_general_ci' NULL AFTER `ramp_id`;
ALTER TABLE `roofing` ADD `units` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `texture_file`;
ALTER TABLE `shelves` ADD `units` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `element_name`;
ALTER TABLE `windows` ADD `units` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `element_name`;

2/17/2019 Dan:
Create table for Canadian postal codes

CREATE TABLE `tdfdesigner`.`ca_postal_codes` ( `postal_codes` VARCHAR(6) NOT NULL , `fas` VARCHAR(3) NOT NULL , `latitute` DECIMAL(9,6) NOT NULL , `longitude` DECIMAL(9,6) NOT NULL , `place_name` VARCHAR(50) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL , `fas1` VARCHAR(1) NOT NULL , `fas_province` INT NOT NULL , `area_type` VARCHAR(25) NOT NULL , PRIMARY KEY (`postal_codes`)) ENGINE = InnoDB;


2/21/2019 Clint:
Added x, y and z offset columns for the dormers, so that their positions can be adjusted

ALTER TABLE `tdfdesigner`.`dormers`
ADD COLUMN `x_offset` FLOAT NULL DEFAULT '0' AFTER `attached_y_pos`,
ADD COLUMN `y_offset` FLOAT NULL DEFAULT '0' AFTER `x_offset`,
ADD COLUMN `z_offset` FLOAT NULL DEFAULT '0' AFTER `y_offset`;

2/25/2018 Dan:

CREATE TABLE `tdfdesigner`.`user_password_reset` ( `id` INT NOT NULL AUTO_INCREMENT , `reset_code` VARCHAR(22) NOT NULL , `subscriber_id` VARCHAR(20) NOT NULL , `userid` VARCHAR(60) NOT NULL , `creation_time` DATETIME NOT NULL , `expiration` DATETIME NOT NULL , `ip_address` VARCHAR(39) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

2/26/2018 Dan:

ALTER TABLE `subscriber_roofing_categories` ADD `override_button_file` varchar(256) NULL AFTER `display_order`;

ALTER TABLE `subscriber_siding` ADD `color_options` json NOT NULL;

ALTER TABLE `subscriber_windows` ADD `window_options` json NOT NULL;

3/5/2019 Dan:
ALTER TABLE `subscriber_options` ADD `override_button_file` varchar(256) COLLATE 'ascii_general_ci' NULL AFTER `elem_id`;

3/7/2019 Dan:
ALTER TABLE `subscriber_windows` ADD `override_button_file` varchar(256) COLLATE 'ascii_general_ci' NULL AFTER `elem_id`;

3/20/2019 Dan:
ALTER TABLE `subscriber_doors` ADD `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL AFTER `elem_id`;

ALTER TABLE `subscriber_dormers` ADD `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL AFTER `elem_id`;

ALTER TABLE `subscriber_handles`ADD `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL AFTER `elem_id`;

ALTER TABLE `subscriber_hinges` ADD `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL AFTER `elem_id`;

ALTER TABLE `subscriber_options` ADD `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL AFTER `elem_id`;

ALTER TABLE `subscriber_windows` ADD `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL AFTER `elem_id`;

ALTER TABLE `subscriber_shelves` ADD `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL AFTER `elem_id`;

ALTER TABLE `subscriber_ramps` ADD `linked_product_id` varchar(45) COLLATE 'utf8_general_ci' NULL AFTER `ramp_id`;

3/21/2019 Dan:
Add general purpose json data field to users table. Remove un-used flags field
ALTER TABLE `users` DROP `flags`, ADD `data` json NULL;

4/5/2019 Dan:
Increase size of category column for siding.

ALTER TABLE `subscriber_siding_categories` CHANGE `category_id` `category_id` varchar(10) COLLATE 'utf8_general_ci' NOT NULL AFTER `series_code`;
ALTER TABLE `siding_colors` CHANGE `category_id` `category_id` varchar(10) COLLATE 'ascii_general_ci' NULL AFTER `siding_id`;
ALTER TABLE `subscriber_siding_price` CHANGE `siding_category_id` `siding_category_id` varchar(10) COLLATE 'ascii_general_ci' NOT NULL AFTER `building_product_id`;

4/9/2019 Dan:
Add per product_id (size) json options field

ALTER TABLE `subscriber_buildings_sizes` ADD `size_options` json NULL;

4/17/2019 Dan:

CREATE TABLE `webhook_log` (`id` int NOT NULL AUTO_INCREMENT PRIMARY KEY, `ip_address` varchar(39) NOT NULL, ADD `date` date NOT NULL,
ADD `time` time NOT NULL, `data` json NOT NULL) ENGINE='InnoDB' COLLATE 'ascii_general_ci';

4/29/2019 Dan:
ALTER TABLE `usersheds` ADD `in_file_bucket` tinyint(1) NOT NULL DEFAULT '0' AFTER `data_format`;

5/1/2019 Dan:
ALTER TABLE `subscribers` ADD `data` JSON NULL AFTER `building_type`;

5/7/2019 Dan:
CREATE TABLE `tdfdesigner`.`email_validation` ( `id` INT NOT NULL AUTO_INCREMENT , `email` VARCHAR(50) NOT NULL , `validation_date` DATE NOT NULL , `is_valid` BOOLEAN NOT NULL , `response` JSON NOT NULL , `validation_source_id` VARCHAR(10) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

CREATE TABLE `tdfdesigner`.`email_validation_providers` ( `id` INT NOT NULL AUTO_INCREMENT , `validation_source_id` VARCHAR(10) NOT NULL , `data` JSON NOT NULL ,PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=ascii COLLATE ascii_general_ci;

5/8/2019 Dan:
ALTER TABLE `subscriber_buildings_sizes` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `product_id`;

5/15/2019 Dan:
ALTER TABLE `subscriber_buildings_sizes` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

5/16/2019 Dan:
CREATE TABLE `tdfdesigner`.`subscriber_api_keys` ( `id` INT NOT NULL AUTO_INCREMENT , `subscriber_id` VARCHAR(20) NOT NULL , `api_key` VARCHAR(22) NOT NULL , `data` JSON NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

ALTER TABLE `subscriber_ramps` ADD `admin_only` BOOLEAN NOT NULL DEFAULT FALSE AFTER `active`;

6/5/2019 Dan:
ALTER TABLE `shelves` ADD `class` VARCHAR(20) NOT NULL DEFAULT 'shelf' AFTER `elem_id`;

ALTER TABLE `usersheds` ADD INDEX(`design_id`);

ALTER TABLE `usersheds2` ADD INDEX(`design_id`);

ALTER TABLE `3dobjects` ADD INDEX(`object_type`);

ALTER TABLE `3dobjects` ADD INDEX(`object_name`);

ALTER TABLE `3dobjects_hinges` ADD INDEX(`object_type`);

ALTER TABLE `3dobjects_hinges` ADD INDEX(`object_name`);

ALTER TABLE `admin_data` ADD INDEX(`datakey`);

ALTER TABLE `doors` ADD INDEX(`elem_id`);

ALTER TABLE `doors` ADD INDEX(`belongs_to_category`);

ALTER TABLE `doors` ADD INDEX(`category`);

ALTER TABLE `door_categories` ADD INDEX(`category_name`);

ALTER TABLE `door_color_categories` ADD INDEX(`door_id`);

ALTER TABLE `dormers` ADD INDEX(`type`);

ALTER TABLE `dormers` ADD INDEX(`elem_id`);

ALTER TABLE `email_validation` ADD INDEX(`email`);

ALTER TABLE `email_validation_providers` ADD INDEX(`validation_source_id`);

ALTER TABLE `handles` ADD INDEX(`elem_id`);

ALTER TABLE `handles` ADD INDEX(`belongs_to_category`);

ALTER TABLE `handles` ADD INDEX(`category`);

ALTER TABLE `hinges` ADD INDEX(`elem_id`);

ALTER TABLE `hinges` ADD INDEX(`belongs_to_category`);

ALTER TABLE `hinges` ADD INDEX(`category`);

ALTER TABLE `interfaces` ADD INDEX(`interface_id`);

ALTER TABLE `interfaces` ADD INDEX(`building_type`);

ALTER TABLE `options` ADD INDEX(`elem_id`);

ALTER TABLE `options` ADD INDEX(`belongs_to_category`);

ALTER TABLE `options` ADD INDEX(`elem_type`);

ALTER TABLE `partitions` ADD INDEX(`partition_id`);

ALTER TABLE `rafters` ADD INDEX(`rafter_id`);

ALTER TABLE `rafters` ADD INDEX(`bld_mfg_id`);

ALTER TABLE `rafter_notes` ADD INDEX(`rafter_id`);

ALTER TABLE `rafter_notes` ADD INDEX(`building_id`);

ALTER TABLE `ramps` ADD INDEX(`ramp_id`);

ALTER TABLE `roofing` ADD INDEX(`roofing_id`);

ALTER TABLE `roofing` ADD INDEX(`category_id`);

ALTER TABLE `roofing` ADD INDEX(`color_id`);

ALTER TABLE `roofing_categories` ADD INDEX(`category_id`);

ALTER TABLE `roofing_profiles` ADD INDEX(`category_id`);

ALTER TABLE `sessions` ADD INDEX(`expires`);

ALTER TABLE `shelves` ADD INDEX(`elem_id`);

ALTER TABLE `siding_colors` ADD INDEX(`siding_id`);

ALTER TABLE `siding_colors` ADD INDEX(`category_id`);

ALTER TABLE `siding_colors` ADD INDEX(`color_id`);

ALTER TABLE `siding_information` ADD INDEX(`siding_id`);

ALTER TABLE `siding_profiles` ADD INDEX(`category_id`);

ALTER TABLE `subscriber_api_keys` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_backgrounds` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_buildings` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_buildings` ADD INDEX(`building_id`);

ALTER TABLE `subscriber_buildings` ADD INDEX(`active`);

ALTER TABLE `subscriber_buildings` ADD INDEX(`building_type`);

ALTER TABLE `subscriber_buildings` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_buildings_sizes` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_buildings_sizes` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_buildings_sizes` ADD INDEX(`building_id`);

ALTER TABLE `subscriber_buildings_sizes` ADD INDEX(`product_id`);

ALTER TABLE `subscriber_buildings_sizes` ADD INDEX(`active`);

ALTER TABLE `subscriber_buildings_sizes` ADD INDEX(`linked_product_id`);

ALTER TABLE `subscriber_building_templates` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_building_templates` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_building_templates` ADD INDEX(`template_id`);

ALTER TABLE `subscriber_building_templates` ADD INDEX(`building_id`);

LTER TABLE `subscriber_change_log` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_change_log` ADD INDEX(`userid`);

ALTER TABLE `subscriber_change_log` ADD INDEX(`datetime`);

ALTER TABLE `subscriber_default_settings` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_default_settings` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_default_settings` ADD INDEX(`default_settings_id`);

ALTER TABLE `subscriber_default_settings` ADD INDEX(`building_id`);

ALTER TABLE `subscriber_default_settings` ADD INDEX(`design_id`);

ALTER TABLE `subscriber_descriptions` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_descriptions` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_descriptions` ADD INDEX(`category_id`);

ALTER TABLE `subscriber_descriptions` ADD INDEX(`object_id`);

ALTER TABLE `subscriber_doors` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_doors` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_doors` ADD INDEX(`elem_id`);

ALTER TABLE `subscriber_doors` ADD INDEX(`linked_product_id`);

ALTER TABLE `subscriber_doors` ADD INDEX(`active`);

ALTER TABLE `subscriber_door_colors` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_door_colors` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_door_colors` ADD INDEX(`door_id`);

ALTER TABLE `subscriber_door_colors` ADD INDEX(`color_id`);

ALTER TABLE `subscriber_door_colors` ADD INDEX(`active`);

ALTER TABLE `subscriber_dormers` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_dormers` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_dormers` ADD INDEX(`elem_id`);

ALTER TABLE `subscriber_dormers` ADD INDEX(`linked_product_id`);

ALTER TABLE `subscriber_dormers` ADD INDEX(`active`);

ALTER TABLE `subscriber_feature_data` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_feature_data` ADD INDEX(`feature_id`);

ALTER TABLE `subscriber_floor_construction` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_floor_construction` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_handles` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_handles` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_handles` ADD INDEX(`elem_id`);

ALTER TABLE `subscriber_handles` ADD INDEX(`linked_product_id`);

ALTER TABLE `subscriber_handles` ADD INDEX(`active`);

ALTER TABLE `subscriber_handles` ADD INDEX(`building_type`);

ALTER TABLE `subscriber_hinges` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_hinges` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_hinges` ADD INDEX(`elem_id`);

ALTER TABLE `subscriber_hinges` ADD INDEX(`linked_product_id`);

ALTER TABLE `subscriber_hinges` ADD INDEX(`active`);

ALTER TABLE `subscriber_hinges` ADD INDEX(`building_type`);

ALTER TABLE `subscriber_kickboards` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_kickboards` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_leanto_price` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_leanto_price` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_leanto_price` ADD INDEX(`rafter_id`);

ALTER TABLE `subscriber_locations` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_options` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_options` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_options` ADD INDEX(`elem_id`);

ALTER TABLE `subscriber_options` ADD INDEX(`linked_product_id`);

ALTER TABLE `subscriber_options` ADD INDEX(`active`);

ALTER TABLE `subscriber_partitions` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_partitions` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_partitions` ADD INDEX(`partition_id`);

ALTER TABLE `subscriber_rafters` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_rafters` ADD INDEX(`building_id`);

ALTER TABLE `subscriber_rafters` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_rafters` ADD INDEX(`sub_type`);

ALTER TABLE `subscriber_rafters` ADD INDEX(`rafter_id`);

ALTER TABLE `subscriber_ramps` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_ramps` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_ramps` ADD INDEX(`ramp_id`);

ALTER TABLE `subscriber_ramps` ADD INDEX(`linked_product_id`);

ALTER TABLE `subscriber_ramps` ADD INDEX(`active`);

ALTER TABLE `subscriber_roofing` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_roofing` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_roofing` ADD INDEX(`roofing_id`);

ALTER TABLE `subscriber_roofing` ADD INDEX(`active`);

ALTER TABLE `subscriber_roofing_categories` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_roofing_categories` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_roofing_categories` ADD INDEX(`category_id`);

ALTER TABLE `subscriber_roofing_categories` ADD INDEX(`active`);

ALTER TABLE `subscriber_roofing_price` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_roofing_price` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_roofing_price` ADD INDEX(`building_product_id`);

ALTER TABLE `subscriber_roofing_price` ADD INDEX(`roofing_category_id`);

ALTER TABLE `subscriber_series` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_series` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_series` ADD INDEX(`series_shortcode`);

ALTER TABLE `subscriber_series` ADD INDEX(`active`);

ALTER TABLE `subscriber_series` ADD INDEX(`building_type`);

ALTER TABLE `subscriber_server_data` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_server_data` ADD INDEX(`feature_id`);

ALTER TABLE `subscriber_shelves` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_shelves` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_shelves` ADD INDEX(`elem_id`);

ALTER TABLE `subscriber_shelves` ADD INDEX(`linked_product_id`);

ALTER TABLE `subscriber_shelves` ADD INDEX(`active`);

ALTER TABLE `subscriber_siding` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_siding` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_siding` ADD INDEX(`siding_id`);

ALTER TABLE `subscriber_siding` ADD INDEX(`active`);

ALTER TABLE `subscriber_siding_categories` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_siding_categories` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_siding_categories` ADD INDEX(`category_id`);

ALTER TABLE `subscriber_siding_categories` ADD INDEX(`active`);

ALTER TABLE `subscriber_siding_dimensions_price` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_siding_dimensions_price` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_siding_dimensions_price` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_siding_price` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_siding_price` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_siding_price` ADD INDEX(`building_product_id`);

ALTER TABLE `subscriber_siding_price` ADD INDEX(`siding_category_id`);

ALTER TABLE `subscriber_transactions` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_transactions` ADD INDEX(`txdate`);

ALTER TABLE `subscriber_trim_colors` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_trim_colors` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_trim_colors` ADD INDEX(`color_id`);

LTER TABLE `subscriber_trim_colors` ADD INDEX(`active`);

ALTER TABLE `subscriber_walls` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_walls` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_walls` ADD INDEX(`wall_id`);

ALTER TABLE `subscriber_windows` ADD INDEX(`subscriber_id`);

ALTER TABLE `subscriber_windows` ADD INDEX(`series_code`);

ALTER TABLE `subscriber_windows` ADD INDEX(`elem_id`);

ALTER TABLE `subscriber_windows` ADD INDEX(`linked_product_id`);

ALTER TABLE `subscriber_windows` ADD INDEX(`active`);

ALTER TABLE `subscriber_windows` ADD INDEX(`building_type`);

ALTER TABLE `textures` CHANGE `texture_name` `texture_name` VARCHAR(45) CHARACTER SET ascii COLLATE ascii_general_ci NULL DEFAULT NULL;

ALTER TABLE `textures` ADD INDEX(`texture_name`);

ALTER TABLE `update_log` ADD INDEX(`date`);

ALTER TABLE `users` ADD INDEX(`subscriber_id`);

ALTER TABLE `users` ADD INDEX(`location_number`);

ALTER TABLE `users` ADD INDEX(`email`);

ALTER TABLE `usersheds` ADD INDEX(`subscriber_id`);

ALTER TABLE `usersheds` ADD INDEX(`series_code`);

ALTER TABLE `usersheds` ADD INDEX(`location_number`);

ALTER TABLE `usersheds` ADD INDEX(`invoice_number`);

ALTER TABLE `usersheds2` ADD INDEX(`subscriber_id`);

ALTER TABLE `usersheds2` ADD INDEX(`series_code`);

ALTER TABLE `usersheds2` ADD INDEX(`location_number`);

ALTER TABLE `usersheds2` ADD INDEX(`invoice_number`);

ALTER TABLE `user_contact_requests` ADD INDEX(`subscriber_id`);

ALTER TABLE `user_contact_requests` ADD INDEX(`user_id`);

ALTER TABLE `user_contact_requests` ADD INDEX(`contact_time`);

ALTER TABLE `user_deleted_sheds` ADD INDEX(`subscriber_id`);

ALTER TABLE `user_deleted_sheds` ADD INDEX(`series_code`);

ALTER TABLE `user_deleted_sheds` ADD INDEX(`location_number`);

ALTER TABLE `user_deleted_sheds` ADD INDEX(`design_id`);

ALTER TABLE `user_order_requests` ADD INDEX(`subscriber_id`);

ALTER TABLE `user_order_requests` ADD INDEX(`user_id`);

ALTER TABLE `user_order_requests` ADD INDEX(`contact_time`);

ALTER TABLE `windows` ADD INDEX(`elem_id`);

ALTER TABLE `windows` ADD INDEX(`belongs_to_category`);

ALTER TABLE `tdfdesigner`.`usersheds` ADD INDEX (`building_type`);

ALTER TABLE `usersheds` CHANGE `in_file_bucket` `in_file_bucket` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '-2 missing, -1 unverified, 0 in db, 1 verified';

ALTER TABLE `subscriber_locations` ADD `active` BOOLEAN NOT NULL DEFAULT TRUE AFTER `location_number`, ADD INDEX (`active`);

2019-07-12 Dan:

ALTER TABLE `users` CHANGE `last_access` `last_access` DATETIME NULL DEFAULT NULL;

2019-07-16 Dan:
ALTER TABLE `subscriber_default_settings` CHANGE `design_id` `design_id` VARCHAR(30) CHARACTER SET ascii COLLATE ascii_general_ci NOT NULL;

ALTER TABLE `usersheds` CHANGE `design_id` `design_id` VARCHAR(30) CHARACTER SET ascii COLLATE ascii_general_ci NULL DEFAULT NULL;

ALTER TABLE `usersheds2` CHANGE `design_id` `design_id` VARCHAR(30) CHARACTER SET ascii COLLATE ascii_general_ci NULL DEFAULT NULL;

2019-07-27 Dan:

ALTER TABLE `subscriber_change_log` CHANGE `action` `action` json NOT NULL AFTER `userid`;

2019-07-29 Dan:
CREATE TABLE `tdfdesigner`.`subscriber_tickets` ( `id` INT NOT NULL AUTO_INCREMENT , `subscriber_id` VARCHAR(20) NOT NULL , `create_date` DATETIME NOT NULL , `last_update` DATETIME NOT NULL , `status` INT NOT NULL DEFAULT '1' , `summary` VARCHAR(100) NOT NULL , `data` JSON NOT NULL , PRIMARY KEY (`id`), INDEX (`subscriber_id`), INDEX (`create_date`), INDEX (`last_update`), INDEX (`status`)) ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_general_ci;

ALTER TABLE `subscriber_tickets` ADD `ticket_number` INT NOT NULL AFTER `subscriber_id`;
ALTER TABLE `tdfdesigner`.`subscriber_tickets` ADD INDEX (`ticket_number`);

2019-07-30 Dan: set default to blank instead of null to address an issue when copying records
ALTER TABLE `subscriber_options`
CHANGE `linked_product_id` `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL DEFAULT '' AFTER `elem_id`,
CHANGE `override_button_file` `override_button_file` varchar(256) COLLATE 'ascii_general_ci' NULL DEFAULT '' AFTER `linked_product_id`;

ALTER TABLE `subscriber_windows`
CHANGE `linked_product_id` `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL DEFAULT '' AFTER `elem_id`,
CHANGE `override_button_file` `override_button_file` varchar(256) COLLATE 'ascii_general_ci' NULL DEFAULT '' AFTER `linked_product_id`;

ALTER TABLE `subscriber_roofing_categories`
CHANGE `override_button_file` `override_button_file` varchar(256) COLLATE 'ascii_general_ci' NULL DEFAULT '' AFTER `display_order`;

ALTER TABLE `subscriber_ramps`
CHANGE `linked_product_id` `linked_product_id` varchar(45) COLLATE 'utf8_general_ci' NULL DEFAULT '' AFTER `ramp_id`;

ALTER TABLE `subscriber_shelves`
CHANGE `linked_product_id` `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL DEFAULT '' AFTER `elem_id`,
CHANGE `override_button_file` `override_button_file` varchar(256) COLLATE 'ascii_general_ci' NOT NULL DEFAULT '' AFTER `linked_product_id`;

ALTER TABLE `subscriber_hinges`
CHANGE `linked_product_id` `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL DEFAULT '' AFTER `elem_id`;

ALTER TABLE `subscriber_handles`
CHANGE `linked_product_id` `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL DEFAULT '' AFTER `elem_id`;

ALTER TABLE `subscriber_dormers`
CHANGE `linked_product_id` `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL DEFAULT '' AFTER `elem_id`;

ALTER TABLE `subscriber_doors`
CHANGE `linked_product_id` `linked_product_id` varchar(45) COLLATE 'ascii_general_ci' NULL DEFAULT '' AFTER `elem_id`;

ALTER TABLE `subscriber_buildings_sizes`
CHANGE `linked_product_id` `linked_product_id` varchar(45) COLLATE 'utf8_general_ci' NULL DEFAULT '' AFTER `admin_only`,
CHANGE `base_siding_category_id` `base_siding_category_id` varchar(7) COLLATE 'utf8_general_ci' NULL DEFAULT '' AFTER `base_std_options_price`;

2019-07-31 Dan:
ALTER TABLE `users` CHANGE `phone1` `phone1` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `zip`, CHANGE `phone2` `phone2` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `phone1`, CHANGE `phone3` `phone3` varchar(20) COLLATE 'ascii_general_ci' NULL AFTER `phone2`;

2019-08-06 Dan:
ALTER TABLE `user_contact_requests` ADD `location_number` INT NOT NULL DEFAULT '1' AFTER `subscriber_id`, ADD INDEX (`location_number`);
ALTER TABLE `user_order_requests` ADD `location_number` INT NOT NULL DEFAULT '1' AFTER `subscriber_id`, ADD INDEX (`location_number`);
ALTER TABLE `usersheds` CHANGE `create_date` `create_date` DATETIME NULL DEFAULT NULL;
ALTER TABLE `usersheds` CHANGE `modified_date` `modified_date` DATETIME NULL DEFAULT NULL;

2019-08-07 Dan:
ALTER TABLE `webhook_log` ADD `webhook` VARCHAR(30) NULL AFTER `id`;

2019-08-12 Dan:
ALTER TABLE `subscriber_doors` CHANGE `options` `options` JSON NULL DEFAULT NULL COMMENT 'JSON data: See the key \"door_options\" in the admin_data table for valid options';

2019-08-13 Dan:
ALTER TABLE `usersheds` CHANGE `data` `data` LONGTEXT NULL DEFAULT NULL;

2019-09-03 Dan:
ALTER TABLE `subscriber_roofing` ADD `linked_product_id` varchar(45) NULL AFTER `roofing_id`;

ALTER TABLE `subscriber_siding` ADD `linked_product_id` varchar(45) NULL AFTER `siding_id`;

ALTER TABLE `subscriber_trim_colors` ADD `linked_product_id` varchar(45) NULL AFTER `color_id`;

2019-09-23 Dan:
ALTER TABLE `rafters` DROP `options`;

ALTER TABLE `subscriber_rafters` ADD `options` JSON NULL AFTER `inner_trim`;

2019-09-30 Clint:
ALTER TABLE `subscriber_locations` ADD `logo_file_name` VARCHAR(255) NULL AFTER `n_email`;

2019-09-26 Dan:
ALTER TABLE `doors` ADD `data` JSON NULL AFTER `right_hinge_coords`;

2019-10-10 Dan:
ALTER TABLE `subscriber_options` ADD `display_order` TINYINT NOT NULL DEFAULT '0' AFTER `active`;

ALTER TABLE `subscriber_shelves` ADD `display_order` INT NOT NULL DEFAULT '0' AFTER `active`;

2019-10-23 Dan:
ALTER TABLE `subscriber_locations` ADD `data` JSON NULL AFTER `logo_file_name`;

2019-20-29 Dan:
ALTER TABLE `user_order_requests` ADD `design_id` VARCHAR(30) NULL AFTER `contact_time`;
ALTER TABLE `tdfdesigner`.`user_order_requests` ADD INDEX (`design_id`);

UPDATE user_order_requests SET design_id = JSON_UNQUOTE(`data`->"$.design_id")

2019-12-1 Dan:
ALTER TABLE `subscriber_change_log` ADD `category` VARCHAR(45) NULL AFTER `userid`, ADD `series_code` VARCHAR(45) NULL AFTER `category`, ADD `product_id` VARCHAR(45) NULL AFTER `series_code`, ADD INDEX (`category`), ADD INDEX (`series_code`), ADD INDEX (`product_id`);

2019-12-5 Dan:
ALTER TABLE `subscriber_siding_colors` ADD `category_id` VARCHAR(10) NULL DEFAULT NULL AFTER `siding_id`, ADD INDEX (`category_id`);

ALTER TABLE `subscriber_siding_colors` ADD `color_id` VARCHAR(10) NULL DEFAULT NULL AFTER `category_id`, ADD INDEX (`color_id`);

ALTER TABLE `tdfdesigner`.`subscriber_siding_colors` ADD INDEX (`linked_product_id`);

ALTER TABLE `subscriber_siding_colors` ADD `name` VARCHAR(256) NULL AFTER `display_order`, ADD `display_name` VARCHAR(40) NULL AFTER `name`, ADD `color_name` VARCHAR(256) NULL AFTER `display_name`;

UPDATE `subscriber_siding_colors` INNER JOIN siding_colors ON subscriber_siding_colors.siding_id = siding_colors.siding_id SET subscriber_siding_colors.category_id = siding_colors.category_id, subscriber_siding_colors.name = siding_colors.name, subscriber_siding_colors.display_name = siding_colors.display_name, subscriber_siding_colors.color_name = siding_colors.color_name, subscriber_siding_colors.color_id = siding_colors.color_id WHERE 1

2019-12-10 Dan:

ALTER TABLE `subscriber_siding_colors` ADD `price` float NOT NULL DEFAULT '0' AFTER `linked_product_id`;

ALTER TABLE `siding_information` ADD `button_file` varchar(256) COLLATE 'ascii_general_ci' NULL AFTER `display_name`;

ALTER TABLE `subscriber_trim_colors` ADD `trim_set_id` varchar(10) COLLATE 'ascii_general_ci' NOT NULL DEFAULT 'Paint' AFTER `series_code`;

ALTER TABLE `subscriber_trim_colors` ADD INDEX `trim_set_id` (`trim_set_id`);

ALTER TABLE `subscriber_siding_categories` ADD `trim_set_id` varchar(10) COLLATE 'utf8_general_ci' NOT NULL DEFAULT 'Paint' AFTER `category_id`;

2019-12-12 Dan:
ALTER TABLE `siding_information` CHANGE `button_file` `default_button_file` varchar(256) COLLATE 'ascii_general_ci' NULL AFTER `display_name`;

2019-12-17 Dan:
ALTER TABLE `subscriber_rafters` CHANGE `extra_cost` `extra_charge` float NOT NULL DEFAULT '0' AFTER `roof_overhang`;

2019-12-19 Dan:
ALTER TABLE `admin_data` CHANGE `data` `data` json NOT NULL COMMENT 'Must be valid JSON data' AFTER `datakey`;

2019-12-27 Dan:
ALTER TABLE `subscriber_shelves` ADD `options` JSON NULL AFTER `building_type`;

2020-01-20 Dan:
CREATE TABLE `tdfdesigner`.`user_event_log` ( `id` INT NOT NULL AUTO_INCREMENT , `subscriber_id` VARCHAR(20) NOT NULL , `userid` VARCHAR(60) NOT NULL , `event_date_time` DATETIME NOT NULL , `data` JSON NULL , PRIMARY KEY (`id`), INDEX (`subscriber_id`), INDEX (`userid`)) ENGINE = InnoDB;

2020-01-26 Dan:
ALTER TABLE `siding_information` ADD `available` BOOLEAN NOT NULL DEFAULT TRUE AFTER `siding_id`, ADD INDEX (`available`);

ALTER TABLE `subscriber_series` ADD `options` JSON NULL AFTER `description`;

2020-02-13 Dan:
Notes: This table was replaced with subscriber_siding_colors
DROP TABLE `subscriber_siding`

2020-02-20 Dan:
ALTER TABLE `subscriber_change_log` ADD `change_type` varchar(45) COLLATE 'ascii_general_ci' NULL AFTER `product_id`;
ALTER TABLE `subscriber_change_log` ADD INDEX `change_type` (`change_type`);

2020-02-23 Dan:
ALTER TABLE `subscriber_windows` CHANGE `window_options` `options` JSON NULL;

2020-02-27 Dan:
ALTER TABLE `tdfdesigner`.`subscriber_siding_price` ADD UNIQUE `uniqueset` (`subscriber_id`, `series_code`, `building_product_id`, `siding_category_id`);

ALTER TABLE `subscriber_buildings` CHANGE `options` `options` JSON NULL DEFAULT NULL COMMENT 'JSON data: See the key \"buildings_options\" in the admin_data table for valid options';

2020-03-04 Dan:
ALTER TABLE `subscriber_ramps` ADD `display_size` varchar(8) COLLATE 'utf8_general_ci' NULL AFTER `linked_product_id`;

ALTER TABLE `options` ADD `element_base_name` varchar(64) COLLATE 'ascii_general_ci' NULL AFTER `element_name`;

ALTER TABLE `subscriber_siding_categories` ADD `options` JSON NULL AFTER `admin_only`;

ALTER TABLE `colors` ADD `color_texture_name` varchar(50) COLLATE 'ascii_general_ci' NULL;

2020-04-08 Dan:
ALTER TABLE `windows` ADD `data` JSON NULL AFTER `building_type`;

2020-04-10 Dan:
ALTER TABLE `usersheds` ADD `design_class` tinyint NOT NULL DEFAULT '0' COMMENT '0 customer, 1 built, 2 default, 3 reference, 4 gallery, 5 stock, 6 sold stock' AFTER `modified_date`;

ALTER TABLE `usersheds` ADD INDEX `design_class` (`design_class`);

2020-04-29 Dan:
CREATE TABLE `access_summary` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `subscriber_id` varchar(20) NOT NULL,
  `date` date NOT NULL,
  `count` int NOT NULL
) ENGINE='InnoDB' COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `access_summary`
ADD INDEX `subscriber_id` (`subscriber_id`),
ADD INDEX `date` (`date`);

2020-05-11 Dan:
CREATE TABLE `color_notes` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `color_id` varchar(10) NOT NULL,
  `date` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `notes` mediumtext NOT NULL
) ENGINE='InnoDB' COLLATE 'utf8mb4_unicode_ci';

ALTER TABLE `color_notes`
ADD INDEX `color_id` (`color_id`);

2020-05-19 Dan:

remove old unused tables

DROP TABLE `carport_types`;
DROP TABLE `carports`;
DROP TABLE `buildings_old`;
DROP TABLE `buildings_sizes_old`;
DROP TABLE `default_settings`;
DROP TABLE `subscriber_buildings_sizes_old`;
DROP TABLE `subscriber_buildings_sizes_cp`;
DROP TABLE `change_log`;


2020-05-24 Dan:

CREATE TABLE `subscriber_subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `subscriber_id` varchar(20) NOT NULL,
  `plan_id` varchar(20) NOT NULL,
  `active` tinyint NOT NULL DEFAULT '1',
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `data` json NULL
) ENGINE='InnoDB' COLLATE 'utf8mb4_general_ci';

ALTER TABLE `subscriber_subscriptions`
ADD INDEX `subscriber_id` (`subscriber_id`),
ADD INDEX `plan_id` (`plan_id`),
ADD INDEX `active` (`active`);

2020-06-03 Dan:

ALTER TABLE `subscriber_subscriptions` ADD `bill_day` tinyint NOT NULL DEFAULT '1' AFTER `end_date`;

2020-06-11 Dan:

ALTER TABLE `subscriber_dormers` ADD `options` json NULL;


2020-06-17 Dan:

ALTER TABLE `dormers`
CHANGE `elem_id` `elem_id` varchar(45) NULL AFTER `type`,
CHANGE `dormer_name` `dormer_name` varchar(256) NULL AFTER `elem_id`,
CHANGE `units` `units` varchar(20) NULL AFTER `dormer_name`,
CHANGE `button_file` `button_file` varchar(256) NULL AFTER `height`,
CHANGE `object3D_name` `object3D_name` varchar(45) NULL AFTER `price`,
CHANGE `width_display` `width_display` varchar(45) NULL AFTER `max_number`,
DROP `attached_element`,
DROP `attached_x_pos`,
DROP `attached_y_pos`;

2020-08-02 Dan:

ALTER TABLE `subscriber_buildings` CHANGE `options` `options` JSON NULL DEFAULT NULL COMMENT 'JSON data: See the key \"buildings_options\" in the admin_data table for valid options';

2020-08-20 Dan:

add json column for sensitive server only data.

ALTER TABLE `subscriber_locations` ADD `sdata` JSON NULL DEFAULT NULL COMMENT 'Sensitive Server Only Data' AFTER `data`;

2020-08-23 Dan:

Add email column to user_contact_requests to enable linking non-user contacts to users when they register.

ALTER TABLE `user_contact_requests` ADD `email` varchar(50) COLLATE 'ascii_general_ci' NULL AFTER `user_id`;
ALTER TABLE `user_contact_requests` ADD INDEX `email` (`email`);
