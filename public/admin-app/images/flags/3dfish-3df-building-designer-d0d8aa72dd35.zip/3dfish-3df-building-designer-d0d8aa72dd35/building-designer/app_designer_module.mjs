/*eslint-env node, es6*/
/*eslint-parserOptions ecmaVersion:2019*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape, no-undef*/

/*This module is for public building designer actions */

import Dbfunctions from "./dbfunctions.cjs";
import mysql from "mysql2/promise.js";
import to from "togo";
import deepFind from "deep-find";

import tdfserver from "../package.json";
import { CleanSubscriberID, getSubscriberLocationData } from "./app.mjs";

let logger, DEBUG, dbfunc;

export class Designer {
	constructor(params) {
		this.con = params.mysql_connection;
		this.tcon = params.mysql_transaction_connection;
		this.logger = params.logger;
		this.app = params.app;
		logger = params.logger;
		DEBUG = params.DEBUG;
		this.DEBUG = params.DEBUG;

		this.dbfunc = new Dbfunctions({mysql_connection:this.con, mysql_transaction_connection:this.tcon, logger:this.logger, DEBUG:this.DEBUG});
		dbfunc = this.dbfunc;
		this.P_GetQueryData = this.dbfunc.P_GetQueryData.bind(this.dbfunc);
		this.ParseMySqlRowData = this.dbfunc.ParseMySqlRowData.bind(this.dbfunc);
		this.ParseMySqlRowDataObj = this.dbfunc.ParseMySqlRowDataObj.bind(this.dbfunc);
		this.P_ParseMySqlRowsDataObj = this.dbfunc.P_ParseMySqlRowsDataObj.bind(this.dbfunc);
		this.MySQLActionResult = this.dbfunc.MySQLActionResult.bind(this.dbfunc);
		this.ReturnSingleMySQLRow = this.dbfunc.ReturnSingleMySQLRow.bind(this.dbfunc);
		this.P_ParseDataCallbackObj = this.dbfunc.P_ParseDataCallbackObj.bind(this.dbfunc);

	}

	async data(req) {
		let err;
		let result = {};
		switch (req.body.request) {
			case "isDebugVersion": {
				[err, result] = await to(this.isDebugVersion(req));
				break;
			}
			case "getDefaultSettings": {
				[err, result] = await to(this.getDefaultSettings(req));
				break;
			}
			case "getBackground": {
				[err, result] = await to(this.getBackground(req));
				break;
			}
			case "getComponent3DObjectData": {
				[err, result] = await to(this.getComponent3DObjectData(req));
				break;
			}
			case "getBuildings": {
				[err, result] = await to(this.getBuildings(req));
				break;
			}
			case "getBuildingSizes": {
				[err, result] = await to(this.getBuildingSizes(req));
				break;
			}
			case "getRafter": {
				[err, result] = await to(this.getRafter(req));
				break;
			}
			case "getFloorConstructionDetails": {
				[err, result] = await to(this.getFloorConstructionDetails(req));
				break;
			}
			case "getHinges": {
				[err, result] = await to(this.getHinges(req));
				break;
			}
			case "getWindows": {
				[err, result] = await to(this.getWindows(req));
				break;
			}
			case "getDoors": {
				[err, result] = await to(this.getDoors(req));
				break;
			}
			case "getDormers": {
				[err, result] = await to(this.getDormers(req));
				break;
			}
			case "getShelves": {
				[err, result] = await to(this.getShelves(req));
				break;
			}
			case "getOptions": {
				[err, result] = await to(this.getOptions(req));
				break;
			}
			case "getRamps": {
				[err, result] = await to(this.getRamps(req));
				break;
			}
			case "getWalls": {
				[err, result] = await to(this.getWalls(req));
				break;
			}
			case "getTextures": {
				[err, result] = await to(this.getTextures(req));
				break;
			}
			case "get3DObjects": {
				[err, result] = await to(this.get3DObjects(req));
				break;
			}
			case "getColors": {
				[err, result] = await to(this.getColors(req));
				break;
			}
			case "getDoorColors": {
				[err, result] = await to(this.getDoorColors(req));
				break;
			}
			case "getSidingColors": {
				[err, result] = await to(this.getSidingColors(req));
				break;
			}
			case "getTrimColors": {
				[err, result] = await to(this.getTrimColors(req));
				break;
			}
			case "getSidingCategories": {
				[err, result] = await to(this.getSidingCategories(req));
				break;
			}
			case "getSidingDimensionPrice": {
				[err, result] = await to(this.getSidingDimensionPrice(req));
				break;
			}
			case "getSidingPrice": {
				[err, result] = await to(this.getSidingPrice(req));
				break;
			}
			case "getRoofing": {
				[err, result] = await to(this.getRoofing(req));
				break;
			}
			case "getRoofingProfile": {
				[err, result] = await to(this.getRoofingProfile(req));
				break;
			}
			case "getRoofingCategories": {
				[err, result] = await to(this.getRoofingCategories(req));
				break;
			}
			case "getRoofingPrice": {
				[err, result] = await to(this.getRoofingPrice(req));
				break;
			}
			case "getKickboardData": {
				[err, result] = await to(this.getKickboardData(req));
				break;
			}
			case "getLeanToPrice": {
				[err, result] = await to(this.getLeanToPrice(req));
				break;
			}
			case "getPartitions": {
				[err, result] = await to(this.getPartitions(req));
				break;
			}
			case "getSubscriberLocationData":
			case "getSubscriberData": {
				[err, result] = await to(getSubscriberLocationData(req));
				break;
			}
			case "getActiveFeatures": {
				[err, result] = await to(this.getActiveFeatures(req));
				break;
			}
			case "getFeatureData": {
				[err, result] = await to(this.getFeatureData(req));
				break;
			}
			case "getDescriptions": {
				[err, result] = await to(this.getDescriptions(req));
				break;
			}
			case "getServerVersion": {
				[err, result] = await to(this.getServerVersion(req));
				break;
			}
			case "getPopup": {
				[err, result] = await to(this.getPopup(req));
				break;
			}
			default: {
				err = {
					message: "Invalid request"
				};
			}
		}
if (err) {
			throw err;
		}
		return result;
	}

	async isDebugVersion(req) {
		req.session.subscriber_id = mysql.escape(await CleanSubscriberID(null,req));
		req.session.subscriber_id = req.session.subscriber_id.substr(1, req.session.subscriber_id.length-2);
		this.logger.debug(`session.subscriber_id: ${req.session.subscriber_id}`);
		if (this.DEBUG)
		{
			return 'true';
		} else {
			return 'false';
		}
	}

	async getDefaultSettings(req) {
		this.logger.debug("app.js:fn:getDefaultSettings");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_default_settings WHERE building_id = ? AND width=? AND subscriber_id=? AND series_code = ?";
		query = mysql.format(query,[req.body.buildingID,req.body.width,subscriber_id,series_code]);

		this.logger.silly(query);

		let [err, result] = await to(this.P_GetQueryData(query, ParseDefaultSettings,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		if (result.length > 0) {
			return result;
		}
		query = "SELECT * FROM subscriber_default_settings WHERE building_id = ? AND width=? AND subscriber_id=? AND series_code = ?";
		query = mysql.format(query,[req.body.buildingID,0,subscriber_id,series_code]);
		[err, result] = await to(this.P_GetQueryData(query, ParseDefaultSettings,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		if (result.length > 0) {
			return result;
		}
		query = "SELECT * FROM subscriber_default_settings WHERE building_id = ? AND width=? AND subscriber_id=? AND series_code = ?";
		query = mysql.format(query,["",req.body.width,subscriber_id,series_code]);
		[err, result] = await to(this.P_GetQueryData(query, ParseDefaultSettings,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		if (result.length > 0) {
			return result;
		}
		query = "SELECT * FROM subscriber_default_settings WHERE building_id = ? AND width=? AND subscriber_id=? AND series_code = ?";
		query = mysql.format(query,["",0,subscriber_id,series_code]);
		[err, result] = await to(this.P_GetQueryData(query, ParseDefaultSettings,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getBackground(req) {
		this.logger.debug("fn:getBackground");

		let subscriber_id = await CleanSubscriberID(null,req);

		let query = "SELECT * FROM subscriber_backgrounds WHERE subscriber_id=? AND building_type = ?";
		query = mysql.format(query,[subscriber_id,req.body.building_type]);

		let [err, result] = await to(this.P_GetQueryData(query, ParseBackgroundData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getComponent3DObjectData(req) {
		this.logger.debug("app.js:fn:getComponent3DObjectData");

		let query = "SELECT * FROM 3dobjects WHERE object_name = ?";
		query = mysql.format(query,[req.body.object_name]);

		this.logger.silly(query);

		let [err,result] = await to(this.P_GetQueryData(query, Parse3DObjectData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getBuildings(req) {
		this.logger.debug("app_designer_module.js:method:getBuildings");
		let subscriber_id = await CleanSubscriberID(null,req);

		let series_code = "Standard";
		if(!(typeof req.body.series_code === "undefined"))
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_buildings WHERE subscriber_id=? AND building_type=? AND series_code = ? AND active ORDER BY display_order ASC";
		query = mysql.format(query,[subscriber_id,req.body.building_type,series_code]);

		let [err, result] = await to(this.P_GetQueryData(query, ParseBuildingsData,this.P_ParseDataCallbackObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getBuildingSizes(req) {
		this.logger.debug("/app.js:fn:getBuildingSizes");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined") {
			series_code = req.body.series_code;
		}

		let query = `SELECT * FROM subscriber_buildings_sizes WHERE building_id = ? AND subscriber_buildings_sizes.subscriber_id=? AND subscriber_buildings_sizes.series_code = ? AND active ORDER BY building_id, width ASC, length ASC, height ASC`;
		query = mysql.format(query,[req.body.buildingID,subscriber_id,series_code]);

		let [err,result] = await to(this.P_GetQueryData(query, ParseBuildingSizeData,this.P_ParseDataCallbackObj));
		if(err) {
			throw err;
		}
		return result;
	}

	async getActiveFeatures(req) {
		logger.debug("app.js:fn:getActiveFeatures");

		let subscriber_id = await CleanSubscriberID(null,req);

		let query = "SELECT active_features, design_prefix FROM subscribers WHERE subscriber_id=?";
		query = mysql.format(query,[subscriber_id]);
		let [err, result] = await to(this.P_GetQueryData(query, null, ParseActiveFeatures));
		if (err) {
			throw err;
		}
		return result;
	}

	async getFeatureData(req) {
		logger.debug("/getFeatureData");

		let subscriber_id = await CleanSubscriberID(null,req);

		let query = "SELECT feature_id, feature_data FROM subscriber_feature_data WHERE subscriber_id=?";
		query = mysql.format(query,[subscriber_id]);
		let [err, result] = await to(this.P_GetQueryData(query, null, ParseFeatureDataObj));
		if(err) {
			throw err;
		}
		return result;
	}

	async getTextures(req) {
		// *** todo: add building type field and only load textures that will be needed by the current building type
		logger.debug("app.js:fn:getTextures");

		let query = "SELECT * FROM textures";
		let [err, result] = await to(this.P_GetQueryData(query, ParseTextureData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getKickboardData(req) {
		logger.debug("app.js:fn:getKickboardData");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_kickboards WHERE subscriber_id= ? AND series_code = ?";
		query = mysql.format(query,[subscriber_id,series_code]);

		let [err, result] = await to(this.P_GetQueryData(query, ParseKickBoardData));
		if (err) {
			throw err;
		}
		return result;
	}

	async getColors(req) {
		logger.debug("fn:getColors");

		let query;
		let data, roofColors, sidingColors, doorColors, trimColors;
		let err;

		let subscriber = mysql.escape(await CleanSubscriberID(null,req));
		let series_code = "Standard";
		if(!(typeof req.body.series_code === "undefined"))
		{
			series_code = mysql.escape(req.body.series_code);
		}
		else
		{
			series_code = mysql.escape(series_code);
		}

		// get roofing colors
		query = `SELECT * FROM colors LEFT OUTER JOIN roofing ON colors.color_id = roofing.color_id LEFT OUTER JOIN subscriber_roofing ON roofing.roofing_id = subscriber_roofing.roofing_id WHERE subscriber_roofing.subscriber_id = ${subscriber} AND subscriber_roofing.series_code = ${series_code}`;
		[err,data] = await to(this.P_GetQueryData(query, ParseColorData));
		if(err) {
			data = "[]";
		}
		if (data === null) {
			data = "[]";
			logger.warn("No roofing colors returned.");
		}
		roofColors = JSON.parse(data);

		//query = `SELECT * FROM colors LEFT OUTER JOIN siding_colors ON colors.color_id = siding_colors.color_id LEFT OUTER JOIN subscriber_siding ON siding_colors.siding_id = subscriber_siding.siding_id WHERE subscriber_siding.subscriber_id = ${subscriber} AND subscriber_siding.series_code = ${series_code}`;
		query = `SELECT * FROM colors LEFT OUTER JOIN subscriber_siding_colors ON colors.color_id = subscriber_siding_colors.color_id WHERE subscriber_siding_colors.subscriber_id = ${subscriber} AND subscriber_siding_colors.series_code = ${series_code}`;
		[err,data] = await to(this.P_GetQueryData(query, ParseColorData));
		if(err) {
			data = "[]";
		}
		if (data === null) {
			data = "[]";
			logger.warn("No siding colors returned.");
		}
		sidingColors = JSON.parse(data);

		query = `SELECT * FROM colors LEFT OUTER JOIN subscriber_door_colors ON colors.color_id = subscriber_door_colors.color_id WHERE subscriber_door_colors.subscriber_id = ${subscriber} AND subscriber_door_colors.series_code = ${series_code}`;
		[err,data] = await to(this.P_GetQueryData(query, ParseColorData));
		if(err) {
			data = "[]";
		}
		if (data === null) {
			data = "[]";
			logger.warn("No door colors returned.");
		}
		doorColors = JSON.parse(data);

		query = `SELECT * FROM colors LEFT OUTER JOIN subscriber_trim_colors ON colors.color_id = subscriber_trim_colors.color_id WHERE subscriber_trim_colors.subscriber_id = ${subscriber} AND subscriber_trim_colors.series_code = ${series_code}`;
		[err,data] = await to(this.P_GetQueryData(query, ParseColorData));
		if(err) {
			data = "[]";
		}
		if (data === null) {
			data = "[]";
			logger.warn("No trim colors returned.");
		}
		trimColors = JSON.parse(data);
		let dataset = {};
		// merge the 4 arrays into 1
		dataset.data = [...new Set([...roofColors, ...sidingColors, ...doorColors, ...trimColors])];
		// remove duplicates
		dataset.data = dataset.data.filter((data, index, self) => self.findIndex(t => t.color_id === data.color_id && t.color_id === data.color_id) === index);
		return dataset.data;
	}

	async getDoorColors(req) {
		logger.debug("app.js:fn:getDoorColors");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_door_colors WHERE subscriber_id=? AND series_code = ? AND active";
		query = mysql.format(query,[subscriber_id,series_code]);
		let [err,result] = await to (this.P_GetQueryData(query, ParseDoorColorData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getSidingCategories(req) {
		logger.debug("app.js:fn:getSidingCategories");

		let subscriber = mysql.escape(await CleanSubscriberID(null,req));
		let series_code = "Standard";
		if(!(typeof req.body.series_code === "undefined"))
		{
			series_code = mysql.escape(req.body.series_code);
		}
		else
		{
			series_code = mysql.escape(series_code);
		}

		let query = "SELECT * FROM subscriber_siding_categories INNER JOIN siding_profiles WHERE siding_profiles.category_id = subscriber_siding_categories.category_id AND subscriber_id=" + subscriber + " AND subscriber_siding_categories.series_code = " + series_code + " AND active ORDER BY display_order ASC";

		let [err, result] = await to(this.P_GetQueryData(query, ParseSidingCategoryData,this.P_ParseMySqlRowsDataObj));
		if(err) {
			throw err;
		}
		return result;
	}

	async getSidingColors(req) {
		logger.debug("app.js:fn:getSidingColors");

		let subscriber = mysql.escape(await CleanSubscriberID(null,req));
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = mysql.escape(req.body.series_code);
		}
		else
		{
			series_code = mysql.escape(series_code);
		}


		//let query = "SELECT * FROM subscriber_siding INNER JOIN siding_colors WHERE subscriber_siding.siding_id = siding_colors.siding_id AND subscriber_siding.subscriber_id=" + subscriber + " AND subscriber_siding.series_code = " + series_code + " AND subscriber_siding.active GROUP BY subscriber_siding.siding_id ORDER BY subscriber_siding.display_order ASC";
		let query = `SELECT * FROM subscriber_siding_colors WHERE subscriber_id=${subscriber} AND series_code = ${series_code} AND active GROUP BY siding_id ORDER BY display_order ASC`;
		logger.silly(query);

		let [err, result] = await to(this.P_GetQueryData(query, ParseSidingColorData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getRoofingCategories(req) {
		logger.debug("app.js:fn:getRoofingCategories");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}
		let query = "SELECT * FROM subscriber_roofing_categories INNER JOIN roofing_categories WHERE subscriber_roofing_categories.category_id = roofing_categories.category_id AND subscriber_roofing_categories.subscriber_id=? AND subscriber_roofing_categories.series_code = ? AND subscriber_roofing_categories.active ORDER BY display_order";
		query = mysql.format(query,[subscriber_id,series_code]);
		let [err, result] = await to(this.P_GetQueryData(query, ParseRoofingCategoryData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			res.status(500).send("Internal Server Error: "+err);
			return;
		}
		return result;
	}

	async getRoofing(req) {
		logger.debug("app.js:fn:getRoofing");

		let subscriber = mysql.escape(await CleanSubscriberID(null,req));
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = mysql.escape(req.body.series_code);
		}
		else
		{
			series_code = mysql.escape(series_code);
		}

		//let query = "SELECT * FROM subscriber_roofing INNER JOIN roofing WHERE subscriber_roofing.roofing_id = roofing.roofing_id AND subscriber_roofing.subscriber_id=" + subscriber + " AND subscriber_roofing.series_code = " + series_code + " AND subscriber_roofing.active ORDER BY display_order";
		let query = `SELECT * FROM subscriber_roofing INNER JOIN roofing ON subscriber_roofing.roofing_id = roofing.roofing_id INNER JOIN subscriber_roofing_categories ON roofing.category_id = subscriber_roofing_categories.category_id INNER JOIN roofing_categories ON subscriber_roofing_categories.category_id = roofing_categories.category_id WHERE subscriber_roofing.subscriber_id=${subscriber} AND subscriber_roofing_categories.subscriber_id=${subscriber} AND subscriber_roofing.series_code = ${series_code} AND subscriber_roofing_categories.series_code = ${series_code} AND subscriber_roofing_categories.active AND subscriber_roofing.active ORDER BY subscriber_roofing_categories.display_order, subscriber_roofing.display_order`;
		let [err, result] = await to(this.P_GetQueryData(query, ParseRoofingData,this.P_ParseMySqlRowsDataObj));
		if (err)
		{
			throw err;
		}
		return result;
	}

	async getRoofingProfile(req) {
		logger.debug("/getRoofingProfile");

		let query = "SELECT * FROM roofing_profiles WHERE category_id=?";
		query = mysql.format(query,[req.body.categoryID]);

		let [err, result] = await to(this.P_GetQueryData(query, ParseProfileData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getRoofingPrice(req) {
		logger.debug("fn:getRoofingPrice");

		let subscriber_id = await CleanSubscriberID(null,req);

		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_roofing_price WHERE building_product_id = ? AND roofing_category_id = ? AND subscriber_id= ? AND series_code = ?";
		query = mysql.format(query,[req.body.buildingProductID,req.body.categoryID,subscriber_id,series_code]);

		let [err,result] = await to(this.P_GetQueryData(query, ParseRoofingPriceData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw(err);
		}
		return result;
	}

	async getSidingPrice(req) {
		logger.debug("app.js:fn:getSidingPrice");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_siding_price WHERE building_product_id = ? AND siding_category_id = ? AND subscriber_id=? AND series_code = ?";
		query = mysql.format(query,[req.body.buildingProductID,req.body.categoryID,subscriber_id,series_code]);

		let [err,result] = await to(this.P_GetQueryData(query, ParseSidingPriceData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getSidingDimensionPrice(req) {
		logger.debug("app.js:fn:getSidingDimensionPrice");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_siding_dimensions_price WHERE width = ? AND height = ? AND siding_category_id = ? AND wall_type = ? AND subscriber_id= ? AND series_code = ?";
		query = mysql.format(query,[req.body.width,req.body.height,req.body.categoryID,req.body.walltype,subscriber_id,series_code])
		logger.debug(query);

		let [err, result] = await to(this.P_GetQueryData(query, ParseSidingDimensionPriceData));
		if (err) {
			throw err;
		}
		return result;
	}

	async getDormers(req) {
		logger.debug("app.js:fn:getDormers");

		let subscriber_id = await CleanSubscriberID(null,req);
		let building_type = "SHED";
		if(typeof req.body.building_type !== "undefined")
		{
			building_type = req.body.building_type;
		}
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_dormers INNER JOIN dormers WHERE subscriber_dormers.elem_id = dormers.elem_id AND subscriber_dormers.subscriber_id=? AND subscriber_dormers.series_code = ? AND subscriber_dormers.building_type=? AND subscriber_dormers.active ORDER BY display_order ASC";
		query = mysql.format(query,[subscriber_id,series_code,building_type])

		let [err, result] = await to(this.P_GetQueryData(query, ParseDormerData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getDescriptions(req) {
		logger.debug("app.js:fn:getDescriptions");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_descriptions WHERE subscriber_id=? AND series_code = ?";
		query = mysql.format(query,[subscriber_id,series_code]);

		let [err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getTrimColors(req) {
		logger.debug("app.js:fn:getTrimColors");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = `SELECT * FROM subscriber_trim_colors WHERE subscriber_id=? AND series_code = ? AND active ORDER BY display_order ASC`;
		query = mysql.format(query,[subscriber_id,series_code]);

		let [err, result] = await to(this.P_GetQueryData(query, ParseTrimColorsData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getRafter(req) {
		logger.debug("fn:getRafter");

		let subscriber_id = await CleanSubscriberID(null,req);

		let width = String(req.body.width);
		if (width.length==1)
			width = "0" + width;
		let sub_type = "ST_WIDTH_" + width;

		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_rafters LEFT JOIN rafters ON subscriber_rafters.rafter_id = rafters.rafter_id WHERE subscriber_id = ? AND building_id = ? AND series_code = ? AND sub_type = ?";
		query = mysql.format(query,[subscriber_id,req.body.buildingID,series_code,sub_type]);

		let [err,result] = await to(this.P_GetQueryData(query, ParseRafterData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw {status: 500, msg: "Internal Server Error: "+err, err: err};
		}
		return result;

	}

	async getLeanToPrice(req) {
		logger.debug("app.js:fn:getLeanToPrice");

		let subscriber_id = await CleanSubscriberID(null,req);

		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM `subscriber_leanto_price` WHERE subscriber_id = ? AND series_code = ? AND rafter_id = ? AND length = ?";
		query = mysql.format(query,[subscriber_id,series_code,req.body.rafterID,req.body.length]);

		let [err, result] = await to(this.P_GetQueryData(query, ParseLeanToPriceData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getDoors(req) {
		logger.debug("app.js:fn:getDoors");
		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_doors INNER JOIN doors WHERE subscriber_doors.elem_id = doors.elem_id AND subscriber_doors.subscriber_id=? AND subscriber_doors.series_code = ? AND subscriber_doors.building_type=? AND subscriber_doors.active ORDER BY display_order";
		query = mysql.format(query,[subscriber_id,series_code,req.body.building_type]);

		let [err, result] = await to(this.P_GetQueryData(query, ParseDoorData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getHinges(req) {
		logger.debug("app.js:fn:getHinges");
		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_hinges INNER JOIN hinges WHERE subscriber_hinges.elem_id = hinges.elem_id AND subscriber_hinges.subscriber_id=? AND subscriber_hinges.series_code = ? AND subscriber_hinges.building_type=? AND subscriber_hinges.active";
		query = mysql.format(query,[subscriber_id,series_code,req.body.building_type]);
		let [err, result] = await to(this.P_GetQueryData(query, ParseHingeData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getWindows(req) {
		logger.debug("/getWindows");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(!(typeof req.body.series_code === "undefined"))
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_windows INNER JOIN windows WHERE subscriber_windows.elem_id = windows.elem_id AND subscriber_windows.subscriber_id=? AND subscriber_windows.series_code=? AND subscriber_windows.building_type=? AND windows.building_type=? AND subscriber_windows.active ORDER BY display_order ASC";
		query = mysql.format(query,[subscriber_id,series_code,req.body.building_type,req.body.building_type]);
		let [err, result] = await to(this.P_GetQueryData(query, ParseWindowData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getOptions(req) {
		logger.debug("app.js:fn:getOptions");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_options INNER JOIN options WHERE subscriber_options.elem_id = options.elem_id AND subscriber_options.subscriber_id=? AND subscriber_options.series_code = ? AND subscriber_options.building_type=? AND options.building_type=? AND subscriber_options.active ORDER BY display_order ASC";
		query = mysql.format(query,[subscriber_id,series_code,req.body.building_type,req.body.building_type])

		let [err, result] = await to(this.P_GetQueryData(query, ParseOptionData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getShelves(req) {
		logger.debug("app.js:fn:getShelves");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(!(typeof req.body.series_code === "undefined"))
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_shelves INNER JOIN shelves WHERE subscriber_shelves.elem_id = shelves.elem_id AND subscriber_shelves.subscriber_id= ? AND subscriber_shelves.series_code = ? AND subscriber_shelves.building_type=? AND shelves.building_type=? AND subscriber_shelves.active";
		query = mysql.format(query,[subscriber_id,series_code,req.body.building_type,req.body.building_type]);

		let [err, result] = await to(this.P_GetQueryData(query, ParseShelfData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getWalls(req) {
		logger.debug("app.js:fn:getWalls");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_walls WHERE subscriber_id=? AND series_code = ? ORDER BY display_order";
		query = mysql.format(query,[subscriber_id,series_code]);
		let [err, result] = await to(this.P_GetQueryData(query, ParseWallData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getPartitions(req) {
		logger.debug("app.js:fn:getPartitions");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_partitions INNER JOIN partitions WHERE subscriber_partitions.partition_id = partitions.partition_id AND subscriber_partitions.subscriber_id=? AND subscriber_partitions.series_code = ?";
		query = mysql.format(query,[subscriber_id,series_code]);

		let [err, result] = await to(this.P_GetQueryData(query, ParsePartitionData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async get3DObjects(req) {
		logger.debug("app.js:fn:get3DObjects");
		let err, result;
		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(!(typeof req.body.series_code === "undefined"))
		{
			series_code = req.body.series_code;
		}
		let objectdata;

		// doors
		let query = "SELECT 3dobjects.id, object_type, object_name, object_file, pos_x, pos_y, pos_z, rot_x, rot_y, rot_z, scale_x, scale_y, scale_z, color, texture_name, trimColorFromBarnEnabled, guiDefinedColorEnabled, colorFromBarnEnabled, interiorVisibility, affectsWallCutout, usedInDimensions, configurationMode, sizedTextureCoordinates FROM 3dobjects JOIN (doors, subscriber_doors) ON (3dobjects.object_name = doors.object3D_name AND subscriber_doors.elem_id = doors.elem_id AND subscriber_doors.subscriber_id = ? AND subscriber_doors.series_code = ?) GROUP BY 3dobjects.id";
		query = mysql.format(query,[subscriber_id,series_code]);
		logger.silly(query);

		[err, objectdata] = await to(this.P_GetQueryData(query, Parse3DObjectData,this.P_ParseDataCallbackObj));
		if (err) {
			throw err;
		}

		// hinges
		query = "SELECT 3dobjects.id, object_type, object_name, object_file, pos_x, pos_y, pos_z, rot_x, rot_y, rot_z, scale_x, scale_y, scale_z, color, texture_name, trimColorFromBarnEnabled, guiDefinedColorEnabled, colorFromBarnEnabled, interiorVisibility, affectsWallCutout, usedInDimensions, configurationMode, sizedTextureCoordinates FROM 3dobjects JOIN (hinges, subscriber_hinges) ON (3dobjects.object_name = hinges.object3D_name AND subscriber_hinges.elem_id = hinges.elem_id AND subscriber_hinges.subscriber_id = ? AND subscriber_hinges.series_code = ?) GROUP BY 3dobjects.id";
		query = mysql.format(query,[subscriber_id,series_code]);
		[err, result] = await to(this.P_GetQueryData(query, Parse3DObjectData,this.P_ParseDataCallbackObj));
		if (err) {
			throw err;
		}
		objectdata = [...objectdata, ...result];

		// windows
		query = "SELECT 3dobjects.id, object_type, object_name, object_file, pos_x, pos_y, pos_z, rot_x, rot_y, rot_z, scale_x, scale_y, scale_z, color, texture_name, trimColorFromBarnEnabled, guiDefinedColorEnabled, colorFromBarnEnabled, interiorVisibility, affectsWallCutout, usedInDimensions, configurationMode, sizedTextureCoordinates FROM 3dobjects JOIN (windows, subscriber_windows) ON (3dobjects.object_name = windows.object3D_name AND subscriber_windows.elem_id = windows.elem_id AND subscriber_windows.subscriber_id = ? AND subscriber_windows.series_code = ?) GROUP BY 3dobjects.id";
		query = mysql.format(query,[subscriber_id,series_code]);
		[err, result] = await to(this.P_GetQueryData(query, Parse3DObjectData,this.P_ParseDataCallbackObj));
		if (err) {
			throw err;
		}
		objectdata = [...objectdata, ...result];

		// Options
		query = "SELECT 3dobjects.id, object_type, object_name, object_file, pos_x, pos_y, pos_z, rot_x, rot_y, rot_z, scale_x, scale_y, scale_z, color, options.texture_name, trimColorFromBarnEnabled, guiDefinedColorEnabled, colorFromBarnEnabled, interiorVisibility, affectsWallCutout, usedInDimensions, configurationMode, sizedTextureCoordinates FROM 3dobjects JOIN (options, subscriber_options) ON (3dobjects.object_name = options.object3D_name AND subscriber_options.elem_id = options.elem_id AND subscriber_options.subscriber_id = ? AND subscriber_options.series_code = ?) GROUP BY 3dobjects.id";
		query = mysql.format(query,[subscriber_id,series_code]);
		[err, result] = await to(this.P_GetQueryData(query, Parse3DObjectData,this.P_ParseDataCallbackObj));
		if (err) {
			throw err;
		}
		objectdata = [...objectdata, ...result];

		// Dormers
		query = "SELECT 3dobjects.id, object_type, object_name, object_file, pos_x, pos_y, pos_z, rot_x, rot_y, rot_z, scale_x, scale_y, scale_z, color, texture_name, trimColorFromBarnEnabled, guiDefinedColorEnabled, colorFromBarnEnabled, interiorVisibility, affectsWallCutout, usedInDimensions, configurationMode, sizedTextureCoordinates FROM 3dobjects JOIN (dormers, subscriber_dormers) ON (3dobjects.object_name = dormers.object3D_name AND subscriber_dormers.elem_id = dormers.elem_id AND subscriber_dormers.subscriber_id = ? AND subscriber_dormers.series_code = ?) GROUP BY 3dobjects.id";
		query = mysql.format(query,[subscriber_id,series_code]);
		[err, result] = await to(this.P_GetQueryData(query, Parse3DObjectData,this.P_ParseDataCallbackObj));
		if (err) {
			throw err;
		}
		objectdata = [...objectdata, ...result];

		// Partitions
		query = "SELECT 3dobjects.id, object_type, object_name, object_file, pos_x, pos_y, pos_z, rot_x, rot_y, rot_z, scale_x, scale_y, scale_z, color, texture_name, trimColorFromBarnEnabled, guiDefinedColorEnabled, colorFromBarnEnabled, interiorVisibility, affectsWallCutout, usedInDimensions, configurationMode, sizedTextureCoordinates FROM 3dobjects JOIN (partitions, subscriber_partitions) ON (3dobjects.object_name = partitions.partition_id AND subscriber_partitions.partition_id = partitions.partition_id AND subscriber_partitions.subscriber_id = ? AND subscriber_partitions.series_code = ?) GROUP BY 3dobjects.id";
		query = mysql.format(query,[subscriber_id,series_code]);
		[err, result] = await to(this.P_GetQueryData(query, Parse3DObjectData,this.P_ParseDataCallbackObj));
		if (err) {
			throw err;
		}
		objectdata = [...objectdata, ...result];

		return objectdata;
	}

	async getFloorConstructionDetails(req) {
		this.logger.debug("fn:getFloorConstructionDetails");

		let err, result;

		let subscriber = mysql.escape(await CleanSubscriberID(null,req));
		let series_code = "Standard";
		if(!(typeof req.body.series_code === "undefined"))
		{
			series_code = mysql.escape(req.body.series_code);
		}
		else
		{
			series_code = mysql.escape(series_code);
		}

		//res.setHeader('content-type', 'application/json');

		let query = `SELECT * FROM subscriber_floor_construction WHERE subscriber_id = ${subscriber} AND series_code = ${series_code} LIMIT 1`;

		[err, result] = await to(this.P_GetQueryData(query, ParseFloorConstructionDetails,this.P_ParseMySqlRowsDataObj));
		if (err) {
			console.log("Error: app.js:fn:getFloorConstructionDetails -- err:",err);
			throw err;
			//res.status(500).send("Internal Server Error: "+err);
			//return;
		}
		return result;
	}

	async getServerVersion (req) {
		return tdfserver.version || process.env.npm_package_version;
	};

	async getRamps(req) {
		logger.debug("app.js:fn:getRamps");

		let subscriber_id = await CleanSubscriberID(null,req);
		let series_code = "Standard";
		if(typeof req.body.series_code !== "undefined")
		{
			series_code = req.body.series_code;
		}

		let query = "SELECT * FROM subscriber_ramps WHERE subscriber_id= ? AND series_code = ? AND active ORDER BY width ASC";
		query = mysql.format(query,[subscriber_id,series_code]);

		let [err,result] = await to(this.P_GetQueryData(query, ParseRampData,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		return result;
	}

	async getPopup(req) {
		logger.debug("app.js:fn:getPopup");
		let err, result, result2, query;
		let ejsdata = {};
		if (req.body.type && req.body.type === "form") {
			if (req.body) {
				ejsdata = req.body;
			}
			[err,result2] = await(to(P_Render(`partials/${req.body.file}`,{data: ejsdata}, this.app)));
			if (err) {
				throw err;
			}
			return {html: result2};
		} else {
			query = "SELECT * FROM admin_data WHERE datakey = ?";
			query = mysql.format(query,req.body.content_key);
			[err,result] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
			if (err) {
				throw err;
			}
			ejsdata = req.body;
			if (typeof result.data === "string") {
				ejsdata.content = JSON.parse(result.data).content;
			} else {
				ejsdata.content = result.data.content;
			}
			[err,result2] = await(to(P_Render("partials/popup.ejs",{data: ejsdata},this.app)));
			if (err) {
				throw err;
			}
			return {html: result2};
		}
	}
}

function P_Render (view, viewData, app) {
	let cbf = function(resolve, reject) {
		app.render(view,viewData, function(err, data) {
			if (err) {
				reject(err);
			} else {
				resolve(data);
			}
		})
	};
	let cb = cbf.bind(this);
	return new Promise(cb);
};


function ParseSubscriberLocationRowData(rowData)
{
	logger.debug("ParseSubscriberLocationRowData");

	delete rowData.id;
	delete rowData.subscriber_id;

	logger.debug("Location: ", rowData.location_number);

	return rowData;
}

function ParseSubscriberLocationData(err, rowsData, currentDataRowParser)
{
	let returndata = [];
	if (DEBUG) {
		logger.debug("ParseSubscriberLocationData");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}
	if (!err && rowsData && rowsData.length > 0)
	{
		logger.debug("Processing Subscriber Data");

		for (let rowData of rowsData)
		{
			returndata.push(ParseSubscriberLocationRowData(rowData))
		}

		return returndata;
	}
	else
	{
		logger.debug(`Location: app.js:291, App Error: ${err}`);
		logger.debug("Subscriber NOT Found");

		returndata = '["Subscriber ID NOT Found"]';
		return JSON.parse(returndata);
	}
}

function ParseActiveFeatures(err, rowsData, currentDataRowParser)
{
	let returndata;
	if (DEBUG) {
		logger.debug("ParseActiveFeatures");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}
	if (!err && rowsData && rowsData.length > 0)
	{
		logger.debug("Processing Subscriber Data");
		returndata = "[";
		for (let i = 0; i < rowsData.length; i++)
		{
			if (i > 0)
				returndata += ", ";

			returndata += dbfunc.ParseMySqlRowData(rowsData[i]);
		}

		returndata += "]";
		return JSON.parse(returndata);

	}
	else
	{
		logger.debug(`Location: app.js:321, App Error: ${err}`);
		logger.debug("Subscriber NOT Found");

		returndata = "Subscriber ID NOT Found";
		return returndata;
	}
}

function ParseFeatureData(err, rowsData, currentDataRowParser)
{
	let returndata;
	if (DEBUG) {
		logger.debug("ParseFeatureData");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}
	if (!err && rowsData && rowsData.length > 0)
	{
		logger.debug("Processing Feature Data");
		returndata = "{";
		for (let i = 0; i < rowsData.length; i++)
		{
			if (i > 0)
				returndata += ", ";

			returndata += ParseFeatureRowData(rowsData[i]);
		}

		returndata += "}";
		return returndata;
	}
	else
	{
		logger.debug(`Location: app.js:350, App Error: ${err}`);
		logger.debug("No Feature Data for Subscriber Found");

		returndata ={none:"none"};
		return returndata;
	}
}

function ParseFeatureDataObj(err, rowsData, currentDataRowParser)
{
	let returndata = {};
	if (DEBUG) {
		logger.debug("ParseFeatureData");
		if(currentDataRowParser) {
			logger.warn("currentDataRowParser parameter set -- This is unused.");
		}
	}
	if (!err && rowsData && rowsData.length > 0)
	{
		logger.debug("Processing Feature Data");
		for (let i = 0; i < rowsData.length; i++)
		{
			returndata = {...returndata,...ParseFeatureRowDataObj(rowsData[i])};
		}

		return returndata;
	}
	else
	{
		logger.debug(`Location: app.js:350, App Error: ${err}`);
		logger.debug("No Feature Data for Subscriber Found");

		// returndata ={none:"none"};
		return returndata;
	}
}

function ParseBuildingsData(rowData)
{
	delete rowData.active;
	delete rowData.building_type;
	delete rowData.display_order;
	if((rowData.options !== null) && (typeof rowData.options === "string")) {
		try {
			rowData.options = JSON.parse(rowData.options);
		} catch (error) {
			// TODO: send error report instead of sending to console.log
			rowData.options = null;
			logger.error(`Error parsing subscriber_buildings.options for RowID ${rowData.id} subscriber: ${rowData.subscriber_id}`);
		}
	}
	delete rowData.id;
	delete rowData.subscriber_id;

	return rowData;
}

function ParseBackgroundData(rowData) {
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.building_type;
	return rowData;
}

function ParseRafterData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	if (typeof rowData.rafter_spec === "string") {
		rowData.rafter_spec = JSON.parse("["+rowData.rafter_spec+"]");
	}
	if (typeof rowData.front_wall_attach_coord === "string") {
		rowData.front_wall_attach_coord = JSON.parse("["+rowData.front_wall_attach_coord+"]");
	}
	if (typeof rowData.rear_wall_attach_coord === "string") {
		rowData.rear_wall_attach_coord = JSON.parse("["+rowData.rear_wall_attach_coord+"]");
	}
	if (typeof rowData.lean_to_attach_coord === "string") {
		rowData.lean_to_attach_coord = JSON.parse("["+rowData.lean_to_attach_coord+"]");
	}
	if (typeof rowData.front_height_extension_attach_coord === "string") {
		rowData.front_height_extension_attach_coord = JSON.parse("["+rowData.front_height_extension_attach_coord+"]");
	}
	if (typeof rowData.rear_height_extension_attach_coord === "string") {
		rowData.rear_height_extension_attach_coord = JSON.parse("["+rowData.rear_height_extension_attach_coord+"]");
	}
	if (typeof rowData.truss_strut_ratio_coords === "string") {
		rowData.truss_strut_ratio_coords = JSON.parse("["+rowData.truss_strut_ratio_coords+"]");
	}
	return rowData;
}

function ParseLeanToPriceData(rowData)
{
	let leanToStr = '{ "price": ' + rowData.price + ' }';

	return JSON.parse(leanToStr);
}

function ParseDoorData(rowData)
{
	if(!(typeof rowData.override_button_file === "undefined") && rowData.override_button_file.length > 0) {
		rowData.button_file = rowData.override_button_file;
	}

	delete rowData.override_button_file;
	// object3D_ID has been depricated to make data consistent all references need to be changed to object3D_name.
	rowData.object3D_ID = rowData.object3D_name;
	if(rowData.available_hinges && (typeof rowData.available_hinges === "string")) {
		try {
			rowData.available_hinges = JSON.parse(rowData.available_hinges);
		} catch (error) {
			rowData.available_hinges = null;
		}
	}
	if(rowData.left_hinge_coords && (typeof rowData.left_hinge_coords === "string")) {
		try {
			rowData.left_hinge_coords = JSON.parse(rowData.left_hinge_coords);
		} catch (error) {
			rowData.left_hinge_coords = null;
		}
	}
	if(rowData.right_hinge_coords && (typeof rowData.right_hinge_coords === "string")) {
		try {
			rowData.right_hinge_coords = JSON.parse(rowData.right_hinge_coords);
		} catch (error) {
			rowData.right_hinge_coords = null;
		}
	}
	if(rowData.options && (typeof rowData.options === "string")) {
		try {
			rowData.options = JSON.parse(rowData.options);
		} catch (error) {
			// *** TODO: report any errors from malformed JSON data
			rowData.options = null;
		}
	}
	let doorStr = JSON.stringify(rowData);

	//return doorStr;
	return rowData;
}

function ParseHingeData(rowData)
{
	if (rowData.linked_product_id === null) {
		rowData.linked_product_id = "";
	}
	let hingeStr = `{ "belongs_to_category": "${rowData.belongs_to_category}", "category": "${rowData.category}", "elem_ID": "${rowData.elem_id}", "admin_only": ${rowData.admin_only}, "button_file": "${rowData.button_file}", "element_name": "${rowData.element_name}", "linked_product_id": "${rowData.linked_product_id}", "object3D_ID": "${rowData.object3D_name}", "width": ${rowData.width}, "height": ${rowData.height}, "width_display": "${rowData.width_display}", "height_display": "${rowData.height_display}", "price": ${rowData.price} }`;

	return JSON.parse(hingeStr);
}

function ParseWindowData(rowData)
{
	if (rowData.override_button_file) {
		rowData.button_file = rowData.override_button_file;
	}
	if (rowData.linked_product_id === null) {
		rowData.linked_product_id = "";
	}
	let window = rowData;
	if (window.options) {
		window.window_options = window.options;
	} else {
		window.options = window.window_options;
	}
	window.elem_ID = window.elem_id;
	window.object3D_ID = window.object3D_name;
	delete window.id;
	delete window.subscriber_id;
	delete window.series;
	//let window_options = JSON.stringify(rowData.window_options);
	//let windowStr = `{ "elem_ID": "${rowData.elem_id}", "button_file": "${rowData.button_file}", "element_name": "${rowData.element_name}", "linked_product_id": "${rowData.linked_product_id}", "object3D_ID": "${rowData.object3D_name}", "width": ${rowData.width}, "height": ${rowData.height}, "width_display": "${rowData.width_display}", "height_display": "${rowData.height_display}", "max_number": ${rowData.max_number}, "price": ${rowData.price}, "admin_only": ${rowData.admin_only}, "user_specifiable_trim_color": ${rowData.user_specifiable_trim_color}, "removal_discount": ${rowData.removal_discount}, "no_extra_cost": ${rowData.no_extra_cost}, "wall_cutout_mode": ${rowData.wall_cutout_mode}, "window_options": ${window_options}}`;

	//return JSON.parse(windowStr);
	return window;
}

function ParseOptionData(rowData)
{
	let optionsJSON = JSON.stringify(rowData.options);
	if (rowData.override_button_file) {
		rowData.button_file = rowData.override_button_file;
	}
	if (rowData.linked_product_id === null) {
		rowData.linked_product_id = "";
	}
	// elem_ID is depricated -- scheduled to be removed leaving elem_id
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	let option = {
		elem_ID: rowData.elem_id,
		object3D_ID: rowData.object3D_name,
		...rowData
	};

	return option;
}

function ParseShelfData(rowData)
{
	if(!(typeof rowData.override_button_file === "undefined") && rowData.override_button_file.length > 0) {
		rowData.button_file = rowData.override_button_file;
	}
	if (rowData.linked_product_id === null) {
		rowData.linked_product_id = "";
	}
	rowData.elem_ID = rowData.elem_id;

	//return JSON.stringify(rowData);
	return rowData;
}

function ParseWallData(rowData)
{
	let partition = {
		wallID: rowData.wall_id,
		button_file: rowData.button_file,
		display_name: rowData.display_name
	};
	//let partitionStr = '{ "wallID": "' + rowData.wall_id + '", "button_file": "' + rowData.button_file + '",  "display_name": "' + rowData.display_name + '" }';

	return partition;
}

function ParsePartitionData(rowData)
{
	let partition = {
		partitionID: rowData.partition_id,
		button_file: rowData.button_file,
		price: rowData.price
	};
	//let partitionStr = '{ "partitionID": "' + rowData.partition_id + '", "button_file": "' + rowData.button_file + '", "price": ' + rowData.price + ' }';

	return partition;
}

function Parse3DObjectData(rowData)
{
	rowData.object3D_ID = rowData.object_name;
	rowData.objectType = rowData.object_type;
	rowData.objectFile = rowData.object_file;
	rowData.textureName = rowData.texture_name;
	return rowData;
}

function ParseTextureData(rowData)
{
	delete rowData.id;
	rowData.textureName = rowData.texture_name;
	rowData.textureFile = rowData.texture_file_name;
	rowData.realWorldWidth = rowData.real_world_width;
	rowData.realWorldHeight = rowData.real_world_height;
	return rowData;
}

function ParseKickBoardData(rowData)
{
	let data = {
		texture: rowData.texture
	};

	return data;
}

function ParseColorData(rowData)
{
	/*let colorData = {
		color_id: rowData.color_id,
		color_name: rowData.color_name,
		color: rowData.color
	};

	return colorData;*/
	delete rowData.mfg_id;
	delete rowData.calibrated_color;
	delete rowData.sort_string;
	return rowData;
}

function ParseDoorColorData(rowData)
{
	let colorData = {
		color_id: rowData.color_id,
		door_id: rowData.door_id,
		price: rowData.price
	};

	return colorData;
}

function ParseBuildingSizeData(rowData)
{
	// TODO: rename id in 3D web app to building_id so that we dont' have to rename it here.
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	rowData.id = rowData.building_id;
	if (typeof rowData.porch_dimensions === "string") {
		rowData.porch_dimensions = JSON.parse("["+rowData.porch_dimensions+"]");
	}
	return rowData;
}

function ParseSidingCategoryData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	rowData.profile_points = JSON.parse(`[${rowData.profile_points}]`);
	rowData.profile_texture_coordinates = JSON.parse(`[${rowData.profile_texture_coordinates}]`);

	return rowData;

}

function ParseSidingColorData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;

	return rowData;
}

function ParseRoofingCategoryData(rowData)
{
	return rowData;
}

function ParseRoofingData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	if (rowData.override_button_file) {
		rowData.button_file = rowData.override_button_file;
	}
	rowData.textureFile = rowData.texture_file;
	rowData.realWorldWidth = rowData.texture_width;
	rowData.realWorldHeight = rowData.texture_height;
	return rowData;
}

function ParseProfileData(rowData)
{
	let profileData = {
		horizontal_profile: JSON.parse("["+rowData.horizontal_profile+"]"),
		vertical_profile: JSON.parse("["+rowData.vertical_profile+"]")
	};

	return profileData;
}


function ParseRoofingPriceData(rowData)
{
	let roofingPriceDataStr = '{ "price": ' + rowData.price + ' }';

	return JSON.parse(roofingPriceDataStr);
}

function ParseSidingPriceData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	delete rowData.building_product_id;
	delete rowData.siding_category_id;
	return rowData;
}

function ParseSidingDimensionPriceData(rowData)
{
	let sidingDimensionPriceData = {
		price: rowData.price
	};

	return sidingDimensionPriceData;
}


function ParseDormerData(rowData)
{
	let dormer = {
		elem_ID: rowData.elem_id,
		element_name: rowData.dormer_name,
		object3D_ID: rowData.object3D_name,
		...rowData
	};

	delete dormer.id;
	delete dormer.subscriber_id;
	delete dormer.series_code;

	return dormer;
}

function ParseTrimColorsData(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;

	return rowData;
}

function ParseDefaultSettings(rowData)
{
	logger.debug("ParseDefaultSettings");

	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;
	delete rowData.default_settings_id;

	return rowData;

}

function ParseFloorConstructionDetails(rowData)
{
	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;

	return rowData;
}

function ParseRampData(rowData)
{

	delete rowData.id;
	delete rowData.subscriber_id;
	delete rowData.series_code;

	return rowData;
}

function ParseFeatureRowData(rowData)
{
	logger.debug("ParseFeatureRowData");

	let rowObject = '"' + rowData.feature_id + '":' + rowData.feature_data;
	return rowObject;
}

function ParseFeatureRowDataObj(rowData)
{
	logger.debug("ParseFeatureRowData");
	let rowObject = {};

	if (typeof rowData.feature_data === "string") {
		try {
			rowObject[rowData.feature_id] = JSON.parse(rowData.feature_data);
		} catch (error) {
			logger.error(`app.js:fn:ParseFeaturerowDataObj error: ${error}`);
			rowObject[rowData.feature_id] = {
				error: "JSON Parse error trying to parse data in database field (ParseFeatureRowData)"
			};
		}
	} else {
		try {
			rowObject[rowData.feature_id] = rowData.feature_data;
		} catch (error) {
			rowObject[rowData.feature_id] = {
				error: "unable to assign feature data to object"
			};
		}
	}

	return rowObject;
}
