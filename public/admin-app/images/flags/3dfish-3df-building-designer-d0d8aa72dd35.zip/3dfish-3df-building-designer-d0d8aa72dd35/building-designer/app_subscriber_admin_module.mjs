/*eslint-env node, es6*/
/*eslint-parserOptions ecmaVersion:2019*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape */

/*This module is for subscriber system admin, admin, staff and driver actions */

import _ from "lodash";
import Dbfunctions from "./dbfunctions.cjs";
import mysql from "mysql2/promise.js";
import to from "togo";
import deepFind from "deep-find";

import { CleanSubscriberID } from "./app.mjs";

import { ParseUsersRowDataObj, ParseSetDesignAsDefaultForBuilding } from "./app_data_parser_module.mjs";

let logger, DEBUG;

export class Admin {
	constructor(params) {
		this.con = params.mysql_connection;
		this.tcon = params.mysql_transaction_connection;
		this.logger = params.logger;
		logger = this.logger;
		this.DEBUG = params.DEBUG;
		DEBUG = this.DEBUG;
		this.dbfunc = new Dbfunctions({mysql_connection:this.con, mysql_transaction_connection:this.tcon, logger:this.logger, DEBUG:this.DEBUG});
		this.P_GetQueryData = this.dbfunc.P_GetQueryData.bind(this);
		this.ParseMySqlRowDataObj = this.dbfunc.ParseMySqlRowDataObj.bind(this.dbfunc);
		this.P_ParseMySqlRowsDataObj = this.dbfunc.P_ParseMySqlRowsDataObj.bind(this.dbfunc);
		this.MySQLActionResult = this.dbfunc.MySQLActionResult.bind(this.dbfunc);
		this.ReturnSingleMySQLRow = this.dbfunc.ReturnSingleMySQLRow.bind(this.dbfunc);

	}

	async logAction(params) {
		/* Example action record:
			{
				class: "record_change",
				change_type: "price",
				type: "location",
				table: "subscriber_locations",
				description: "Update Record",
				details: {
					previous_row: oldrow,
					new_row: updateRecord
				}
			}

		change_type: one of the following:
		price, access, settings
		*/
		let dt = new Date();
		let t = dt.toISOString().substring(11, 19);
		let d = dt.toISOString().substring(0, 10);
		params.product_id = params.product_id ? params.product_id:"";
		params.series_code = params.series_code ? params.series_code:"";
		params.category = params.category ? params.category:"UPDATE";
		params.action = params.action ? params.action:{};
		params.change_type = params.change_type ? params.change_type:null;
		if (!params.req.session.user) {
			this.logger.warn('userid not set. app_subscriber_admin_module.js:logAction',{params:params});
			params.req.session.user = params.req.session.subscriber_id;
		}
		let change_log = {
			datetime: d + " " + t,
			subscriber_id: params.req.session.subscriber_id,
			userid: params.req.session.user,
			category: params.category,
			series_code: params.series_code,
			product_id: params.product_id,
			change_type: params.change_type,
			action: JSON.stringify(params.action)
		};
		let query = "INSERT INTO subscriber_change_log SET ?";
		query = mysql.format(query,change_log);
		let [err,result] = await to(this.dbfunc.P_GetQueryData(query,null,this.MySQLActionResult));
		if (err) {
			this.logger.error("Error saving subscriber_change_log",{err: err,change_log:change_log,params:params})
			throw err;
		}
	}

	async logUserEvent(params) {
		/* Example params object:
			{
				req: req,
				userid: userid,
				data: {
					editorid: useridofeditor,
					previous_row: oldrow,
					new_row: updateRecord
				}
			}
		*/
		let dt = new Date();
		let t = dt.toISOString().substring(11, 19);
		let d = dt.toISOString().substring(0, 10);
		let change_log = {
			event_date_time: d + " " + t,
			userid: params.userid,
			subscriber_id: params.req.session.subscriber_id,
			data: JSON.stringify(params.data)
		};
		let query = "INSERT INTO user_event_log SET ?";
		query = mysql.format(query,change_log);
		let [err,result] = await to(this.dbfunc.P_GetQueryData(query,null,this.MySQLActionResult));
		if (err) {
			throw err;
		}

	}

	async loadData(req) {
		let err, result;
		switch (req.body.request) {
			case "getRegisteredUserCount": {
				[err, result] = await to(this.getRegisteredUserCount(req));
				break;
			}
			case "getSavedDesignCount": {
				[err, result] = await to(this.getSavedDesignCount(req));
				break;
			}
			case "getTotalContactRequestCount": {
				[err, result] = await to(this.getTotalContactRequestCount(req));
				break;
			}
			case "getTotalOrdersCount": {
				[err, result] = await to(this.getTotalOrderCount(req));
				break;
			}
			case "getOrdersList": {
				[err, result] = await to(this.getOrdersList(req));
				break;
			}
			case "getContactRequest": {
				[err, result] = await to(this.getContactRequest(req));
				break;
			}
			case "getDesignsList": {
				[err, result] = await to(this.getDesignsList(req));
				break;
			}
			case "getContactRequestsList": {
				[err, result] = await to(this.getContactRequestsList(req));
				break;
			}
			case "getDesignData": {
				[err, result] = await to(this.getDesignData(req));
				break;
			}
			case "getOrderData": {
				[err, result] = await to(this.getOrderData(req));
				break;
			}
			case "getUsers": {
				[err, result] = await to(this.getUsers(req));
				break;
			}
			case "getStaff": {
				[err, result] = await to(this.getStaff(req));
				break;
			}
			case "getLast10Updates": {
				[err, result] = await to(this.getLast10Updates(req));
				break;
			}
			case "getBuildings": {
				let query = `SELECT * FROM subscriber_buildings WHERE subscriber_id=? ORDER BY display_order ASC`;
				query = mysql.format(query,[req.session.subscriber_id]);
				[err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				break;
			}
			case "getBuildingPricing": {
				result={};
				let series;
				let query = "SELECT * FROM subscriber_series WHERE subscriber_id=? AND series_code=?";
				query = mysql.format(query,[req.session.subscriber_id,req.body.series_code]);
				[err, series] = await to(this.dbfunc.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
				if (err) {
					throw err;
				}
				result.series_data = series;
				let buildingSize;
				query = "SELECT * FROM subscriber_buildings_sizes WHERE subscriber_id=? AND series_code=? AND product_id=?";
				query = mysql.format(query,[req.session.subscriber_id,req.body.series_code,req.body.product_id]);
				[err, buildingSize] = await to(this.dbfunc.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
				if (err) {
					throw err;
				}
				result.building_size_data = buildingSize;
				let building;
				query = "SELECT * FROM subscriber_buildings WHERE subscriber_id = ? AND series_code = ? AND building_id=?";
				query = mysql.format(query,[req.session.subscriber_id,req.body.series_code,buildingSize.building_id]);
				[err, building] = await to(this.dbfunc.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
				if (err) {
					throw err;
				}
				result.building_data = building;
				query = "SELECT category_id, active, admin_only, display_name FROM subscriber_siding_categories LEFT OUTER JOIN siding_information ON subscriber_siding_categories.category_id = siding_information.siding_id WHERE subscriber_id=? AND series_code=? ORDER BY display_order";
				query = mysql.format(query,[req.session.subscriber_id,req.body.series_code]);
				let siding_categories = {};
				[err, siding_categories] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				let exclude_list = deepFind(building.options, "siding.unavailable") || [];
				let siding_list = [];
				for (let category of siding_categories) {
					if (!exclude_list.includes(category.category_id)) {
						siding_list.push(category.category_id);
					}
				}
				result.siding_list = siding_list;
				let siding_prices;
				query = "SELECT siding_category_id, price, std_options_price FROM subscriber_siding_price WHERE subscriber_id=? AND series_code=? AND building_product_id=?";
				query = mysql.format(query,[req.session.subscriber_id,req.body.series_code,req.body.product_id]);
				[err, siding_prices] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				for (let siding of siding_categories) {
					let price = siding_prices.find(element => element.siding_category_id === siding.category_id);
					siding.price = price ? price.price:0;
					siding.std_options_price = price ? price.std_options_price:0;
				}
				result.siding_prices = siding_categories;
				return result;
				break;
			}
			case "getElementPricing": {
				let objectTypeLookup = {
					door: {
						table: "subscriber_doors",
						lookup_table: "doors",
						source_link: "subscriber_doors.elem_id",
						target_link: "doors.elem_id"
					},
					window: {
						table: "subscriber_windows",
						lookup_table: "windows",
						source_link: "subscriber_windows.elem_id",
						target_link: "windows.elem_id"
					},
					option: {
						table: "subscriber_options",
						lookup_table: "options",
						source_link: "subscriber_options.elem_id",
						target_link: "options.elem_id"
					},
					shelve: {
						table: "subscriber_shelves",
						lookup_table: "shelves",
						source_link: "subscriber_shelves.elem_id",
						target_link: "shelves.elem_id"
					}
				};
				if (!objectTypeLookup[req.body.objectType]) {
					throw "app_subscriber_admin_module.js:loadData:getElementPricing - Requested Object Type not recognized.";
				}
				let query = "SELECT * FROM ?? INNER JOIN ?? WHERE ?? = ?? AND subscriber_id = ? AND series_code = ? AND ?? = ?";
				let obj = objectTypeLookup[req.body.objectType];
				query = mysql.format(query,[obj.table,obj.lookup_table,obj.source_link,obj.target_link,req.session.subscriber_id,req.body.series_code,obj.source_link,req.body.elem_id]);
				//console.log(query);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
				if (err) {
					throw err;
				}
				return result;
			}
			case "getStyleData": {
				let query = `SELECT * FROM subscriber_buildings WHERE subscriber_id=? AND building_id = ? AND series_code = ?`;
				query = mysql.format(query,[req.session.subscriber_id,req.body.building_id,req.body.series_code]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				let building_data = result[0];
				query = `SELECT * FROM subscriber_buildings_sizes WHERE subscriber_id = ? AND building_id = ? AND series_code = ?`;
				query = mysql.format(query,[req.session.subscriber_id,req.body.building_id,req.body.series_code]);
				[err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				return { building_data: building_data, building_sizes: result };
				break;
			}
			case "getSeries": {
				let query = `SELECT * FROM subscriber_series WHERE subscriber_id=?`;
				query = mysql.format(query,[req.session.subscriber_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				return result;
				break;
			}
			case "getSiding": {
				//let query = `SELECT * FROM subscriber_siding_categories WHERE subscriber_id=?`;
				//let query = "SELECT * FROM subscriber_siding_categories INNER JOIN siding_profiles WHERE siding_profiles.category_id = subscriber_siding_categories.category_id AND subscriber_id=? ORDER BY display_order ASC";
				let query = "SELECT * FROM subscriber_siding_categories INNER JOIN siding_information WHERE siding_information.siding_id = subscriber_siding_categories.category_id AND subscriber_id=? ORDER BY display_order ASC";
				query = mysql.format(query,[req.session.subscriber_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				return result;
				break;
			}
			case "getRoofing": {
				//let query = `SELECT * FROM subscriber_roofing WHERE subscriber_id=?`;
				let query = "SELECT * FROM subscriber_roofing_categories INNER JOIN roofing_categories WHERE subscriber_roofing_categories.category_id = roofing_categories.category_id AND subscriber_roofing_categories.subscriber_id=? ORDER BY display_order";
				query = mysql.format(query,[req.session.subscriber_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				return result;
				break;
			}
			case "getDoors": {
				//let query = `SELECT * FROM subscriber_doors WHERE subscriber_id=?`;
				let query = `SELECT * FROM subscriber_doors INNER JOIN doors WHERE subscriber_doors.elem_id = doors.elem_id AND subscriber_doors.subscriber_id=? ORDER BY display_order`;
				query = mysql.format(query,[req.session.subscriber_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				return result;
				break;
			}
			case "getWindows": {
				//let query = `SELECT * FROM subscriber_windows WHERE subscriber_id=?`;
				let query = "SELECT * FROM subscriber_windows INNER JOIN windows WHERE subscriber_windows.elem_id = windows.elem_id AND subscriber_windows.subscriber_id=? ORDER BY display_order ASC";
				query = mysql.format(query,[req.session.subscriber_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				return result;
				break;
			}
			case "getOptions": {
				//let query = `SELECT * FROM subscriber_options WHERE subscriber_id=?`;
				let query = "SELECT * FROM subscriber_options INNER JOIN options WHERE subscriber_options.elem_id = options.elem_id AND subscriber_options.subscriber_id=? ORDER BY display_order";
				query = mysql.format(query,[req.session.subscriber_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				return result;
				break;
			}
			case "getShelves": {
				//let query = `SELECT * FROM subscriber_shelves WHERE subscriber_id=?`;
				let query = "SELECT * FROM subscriber_shelves INNER JOIN shelves WHERE subscriber_shelves.elem_id = shelves.elem_id AND subscriber_shelves.subscriber_id= ? ORDER BY display_order";
				query = mysql.format(query,[req.session.subscriber_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				return result;
				break;
			}
			case "getHinges": {
				let query = `SELECT * FROM subscriber_hinges WHERE subscriber_id=?`;
				query = mysql.format(query,[req.session.subscriber_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				return result;
				break;
			}
			case "getHandles": {
				let query = `SELECT * FROM subscriber_handles WHERE subscriber_id=?`;
				query = mysql.format(query,[req.session.subscriber_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				return result;
				break;
			}
			case "getDesignUserInfo": {
				let err, result, query;
				let orderData = {
					data: {}
				};
				let userData = {};
				let subscriber_id = req.session.subscriber_id;
				if (req.session.userData && req.session.userData.user_type === "master" && req.body.subscriber_id) {
					subscriber_id = req.body.subscriber_id;
				}
				query = "SELECT * FROM user_order_requests WHERE subscriber_id = ? AND design_id = ?";
				query = mysql.format(query,[req.session.subscriber_id,req.body.design_id]);
				[err,result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				orderData = result[0] || orderData;
				query = "SELECT * from usersheds WHERE subscriber_id=? AND design_id=?";
				query = mysql.format(query,[req.session.subscriber_id,req.body.design_id]);
				[err,result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				query = "SELECT * FROM users WHERE subscriber_id=? AND userid = ?";
				query = mysql.format(query,[req.session.subscriber_id,result[0].userid]);
				[err,result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err) {
					throw err;
				}
				userData = result[0] || userData;
				try {
					userData.delivery_address = orderData.data.delivery_address ? orderData.data.delivery_address:null;
					userData.delivery_zip = orderData.data.delivery_zipcode ? orderData.data.delivery_zipcode:null;
					userData.delivery_city = orderData.data.postal_code_data ? orderData.data.postal_code_data.city:null;
					userData.delivery_state = orderData.data.postal_code_data ? orderData.data.postal_code_data.statecode:null;
					userData.address = userData.address ? userData.address:userData.delivery_address;
					userData.zip = userData.zip ? userData.zip:userData.delivery_zipcode;
					userData.city = userData.city ? userData.city:userData.delivery_city;
					userData.state = userData.state ? userData.state:userData.delivery_state;
				}
				catch(err) {
					throw err; //`admin.js:loadData:getDesignUserInfo - Error setting userdata: ${err}`;
				}
				return userData;
				break;
			}
			default: {
				err = {message: "invalid request"};
				throw err;
			}
		}
		if (err) {
			throw err;
		}
		return result;
	}

	async action(req) {
		let table_name = "";
		let id_field = "";
		if (["activate_product","deactivate_product","set_product_admin_only","unset_product_admin_only"].includes(req.body.request)) {
			switch (req.body.category) {
				case "window": {
					table_name = "subscriber_windows";
					id_field = "elem_id";
					break;
				}
				case "door": {
					table_name = "subscriber_doors";
					id_field = "elem_id";
					break;
				}
				case "option": {
					table_name = "subscriber_options";
					id_field = "elem_id";
					break;
				}
				case "siding": {
					table_name = "subscriber_siding_categories";
					id_field = "category_id";
					break;
				}
				case "siding_color": {
					table_name = "subscriber_siding";
					id_field = "siding_id";
					break;
				}
				case "roofing": {
					table_name = "subscriber_roofing_categories";
					id_field = "category_id";
					break;
				}
				case "buildingsize": {
					table_name = "subscriber_buildings_sizes";
					id_field = "product_id";
					break;
				}
				case "style": {
					table_name = "subscriber_buildings";
					id_field = "building_id";
					break;
				}
				case "shelve": {
					table_name = "subscriber_shelves";
					id_field = "elem_id";
					break;
				}
				case "series": {
					table_name = "subscriber_series";
					id_field = "series_code";
				}
			}
		}
		let err, result;
		switch (req.body.request) {
			case "get_design_data": {
				let query = "SELECT data_format, data FROM usersheds WHERE design_id = ?";
				query = mysql.format(query, [data.design_id]);
				[err, result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.ReturnSingleMySQLRow));
				break;
			}
			case "add_location": {
				req.socket.sendupdate = true;
				req.socket.updatedata.type = "add_location";
				[err, result] = await to(this.addLocation(req));
				if (!err) {
					req.socket.updatedata.location_data = result;
				}
				break;
			}
			case "get_location_record": {
				if (["admin", "sadmin", "master"].includes(req.session.userdata.usertype) === false) {
					err = {
						name: "unauthorized",
						message: "Unauthorized request."
					};
					this.logger.warn(`Unauthorized data request. Subscriber_id: ${req.session.subscriber_id} - User ID: ${req.session.user} - ip: {req.session.ip}`);
					break;
				}
				let query = "SELECT * FROM subscriber_locations WHERE subscriber_id = ? AND location_number = ?";
				query = mysql.format(query, [req.session.subscriber_id, req.body.location_number]);
				[err, result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				break;
			}
			case "activate_location": {
				req.socket.sendupdate = true;
				req.socket.updatedata.type = "activate_location";
				req.socket.updatedata.location_data = {
					location_number: req.body.location_number,
					active: 1
				};
				[err, result] = await to(this.activateLocation(req));
				break;
			}
			case "deactivate_location": {
				req.socket.sendupdate = true;
				req.socket.updatedata.type = "deactivate_location";
				req.socket.updatedata.location_data = {
					location_number: req.body.location_number,
					active: 0
				};
				[err, result] = await to(this.deactivateLocation(req));
				break;
			}
			case "update_location_record": {
				req.socket.sendupdate = true;
				req.socket.updatedata.type = "update_location";
				[err, result] = await to(this.updateLocation(req));
				if (!err) {
					req.socket.updatedata.location_data = result;
				}
				break;
			}
			case "get_user_record": {
				if (["admin", "sadmin", "master"].includes(req.session.userdata.usertype) === false) {
					err = {
						name: "unauthorized",
						message: "Unauthorized request."
					};
					this.logger.warn(`Unauthorized data request. Subscriber_id: ${req.session.subscriber_id} - User ID: ${req.session.user} - ip: {req.session.ip}`);
					break;
				}
				let query = "SELECT * FROM users WHERE subscriber_id = ? AND userid = ?";
				query = mysql.format(query, [req.session.subscriber_id, req.body.userid]);
				[err, result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				break;
			}
			case "status_check": {
				if (["master"].includes(req.session.userdata.usertype) === false) {
					err = {
						name: "unauthorized",
						message: "Unauthorized request."
					};
					this.logger.warn(`Unauthorized data request. Subscriber_id: ${req.session.subscriber_id} - User ID: ${req.session.user} - ip: {req.session.ip}`);
					break;
				}
				this.io.to(data.socket_id).emit("status_check", {
					reply_to: socket.id
				}, function (data) {
					this.io.to(data.reply_to).emit("status_response", data)
				})
				break;
			}
			case "activate_product": {
				let query = `UPDATE ${table_name} SET active = 1 WHERE subscriber_id = ? AND series_code = ? AND ${id_field} = ?`;
				query = mysql.format(query,[req.session.subscriber_id,req.body.series,req.body.product_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.MySQLActionResult));
				if (err) {
					throw err;
				}
				let [err2, result2] = await to(this.logAction({req: req, product_id: req.body.product_id, series_code: req.body.series, category: req.body.category, action:{description:"Activate Product", table: table_name, columns: {active: 1}}}));
				return result;
			}
			case "deactivate_product": {
				let query = `UPDATE ${table_name} SET active = 0 WHERE subscriber_id = ? AND series_code = ? AND ${id_field} = ?`;
				query = mysql.format(query,[req.session.subscriber_id,req.body.series,req.body.product_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.MySQLActionResult));
				if (err) {
					throw err;
				}
				let [err2, result2] = await to(this.logAction({req: req, product_id: req.body.product_id, series_code: req.body.series, category: req.body.category, action:{description:"Deactivate Product", table: table_name, columns: {active: 0}}}));
				return result;
			}
			case "set_product_admin_only": {
				let query = `UPDATE ${table_name} SET admin_only = 1 WHERE subscriber_id = ? AND series_code = ? AND ${id_field} = ?`;
				query = mysql.format(query,[req.session.subscriber_id,req.body.series,req.body.product_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.MySQLActionResult));
				if (err) {
					throw err;
				}
				let [err2, result2] = await to(this.logAction({req: req, product_id: req.body.product_id, series_code: req.body.series, category: req.body.category, action:{description:"Set Admin Only", table: table_name, columns: {admin_only: 1}}}));
				return result;
			}
			case "unset_product_admin_only": {
				let query = `UPDATE ${table_name} SET admin_only = 0 WHERE subscriber_id = ? AND series_code = ? AND ${id_field} = ?`;
				query = mysql.format(query,[req.session.subscriber_id,req.body.series,req.body.product_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.MySQLActionResult));
				if (err) {
					throw err;
				}
				let [err2, result2] = await to(this.logAction({req: req, product_id: req.body.product_id, series_code: req.body.series, category: req.body.category, action:{description:"Unset Admin Only", table: table_name, columns: {admin_only: 0}}}));
				return result;
			}
			case "set_base_siding": {
				let query = "SELECT * FROM subscriber_series WHERE subscriber_id = ? AND series_code = ?";
				query = mysql.format(query,[req.session.subscriber_id, req.body.series_code]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
				if (err) {
					throw err;
				}
				let options;
				if (result.options === null) {
					options = {base_siding: req.body.category_id};
				} else {
					options.base_siding = req.body.category_id;
				}
				query = "UPDATE subscriber_series SET options = ? WHERE subscriber_id = ? AND series_code = ?";
				query = mysql.format(query,[JSON.stringify(options),req.session.subscriber_id,req.body.series_code]);
				[err, result] = await to(this.dbfunc.P_GetQueryData(query,null,this.MySQLActionResult));
				if (err) {
					throw err;
				}
				let [err2, result2] = await to(this.logAction({req: req, series_code: req.body.series_code, category_id: req.body.category_id, action:{description:"Set Series Base Siding", table: "subscriber_series", columns: {options: {base_siding: req.body.category_id}}}}));
				return result;
			}
			case "update_user": {
				// TODO: make this a transaction
				let userid = req.body.user_data.userid;
				delete req.body.user_data.userid;
				let query = "SELECT * from users WHERE subscriber_id = ? AND userid = ?";
				query = mysql.format(query,[req.session.subscriber_id,userid]);
				let [err, old_user_req] = await to(this.dbfunc.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
				if (err) {
					throw err;
				}
				query = "UPDATE users SET ? WHERE subscriber_id = ? AND userid = ?";
				query = mysql.format(query,[req.body.user_data,req.session.subscriber_id,userid]);
				[err, result] = await to(this.dbfunc.P_GetQueryData(query,null,this.MySQLActionResult));
				if (err) {
					throw err;
				}
				let updateResult = result;
				let [err2, result2] = await to(this.logUserEvent({req: req, userid: userid, data:{editorid: req.session.userid,previous_req: old_user_req,updated_fields:req.body.user_data}}));
				if (old_user_req.location_number != req.body.user_data.location_number) {
					query = "UPDATE usersheds SET location_number = WHERE subscriber_id = ? AND userid = ?";
					query = mysql.format(query,[req.body.user_data.location_number,req.session.subscriber_id,userid]);
					[err, result] = await to(this.dbfunc.P_GetQueryData(query,null,this.MySQLActionResult));
					if (err) {
						throw err;
					}
					query = "UPDATE user_order_requests SET location_number = WHERE subscriber_id = ? AND userid = ?";
					query = mysql.format(query,[req.body.user_data.location_number,req.session.subscriber_id,userid]);
					[err, result] = await to(this.dbfunc.P_GetQueryData(query,null,this.MySQLActionResult));
					if (err) {
						throw err;
					}
					query = "UPDATE user_contact_requests SET location_number = WHERE subscriber_id = ? AND userid = ?";
					query = mysql.format(query,[req.body.user_data.location_number,req.session.subscriber_id,userid]);
					[err, result] = await to(this.dbfunc.P_GetQueryData(query,null,this.MySQLActionResult));
					if (err) {
						throw err;
					}
				}
				return updateResult;
			}
			case "update_building_size_prices": {
				let query = "UPDATE subscriber_buildings_sizes SET price = ? WHERE subscriber_id = ? AND series_code = ? AND product_id = ?";
				query = mysql.format(query,[req.body.price,req.session.subscriber_id,req.body.series_code,req.body.product_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,null,this.MySQLActionResult));
				if (err) {
					if (typeof err === "object") {
						err.query = query;
					} else {
						err = err + ", query: " + query;
					}
					throw err;
				}
				let [err2, result2] = await to(this.logAction({req: req, series_code: req.body.series_code, product_id: req.body.product_id, action:{description:"Update price", table: "subscriber_buildings_sizes", columns: {price: req.body.price}}}));

				if (req.body.siding) {
					for (const siding_category_id in req.body.siding) {
						//query = "UPDATE subscriber_siding_price SET price = ? WHERE subscriber_id = ? AND series_code = ? AND building_product_id = ? AND siding_category_id = ?";
						query = "INSERT INTO subscriber_siding_price (subscriber_id, series_code, building_product_id, siding_category_id, price) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE price = ?";
						query = mysql.format(query,[req.session.subscriber_id,req.body.series_code,req.body.product_id,siding_category_id,req.body.siding[siding_category_id],req.body.siding[siding_category_id]]);
						[err, result] = await to(this.dbfunc.P_GetQueryData(query,null,this.MySQLActionResult));
						if (err) {
							throw err;
						}
					}
					[err2, result2] = await to(this.logAction({req: req, series_code: req.body.series_code, product_id: req.body.product_id, action:{description:"Update siding prices", table: "subscriber_buildings_sizes", columns: {price: req.body.price}}}));
				}
				return result;
			}
			case "update_element_price": {
				let objectTypeLookup = {
					door: {
						table: "subscriber_doors"
					},
					window: {
						table: "subscriber_windows"
					},
					option: {
						table: "subscriber_options"
					},
					shelve: {
						table: "subscriber_shelves"
					}
				};
				if (!objectTypeLookup[req.body.objectType]) {
					throw "app_subscriber_admin_module.js:action:update_element_price - Submitted Object Type not recognized.";
				}
				let default_options = {
					pricePerSqFt: false,
					priceAddOn: 0,
					priceByParameterFt: false,
					priceByLength: false,
					priceByWidth: false
				}
				let query = "SELECT elem_id, price, options FROM ?? WHERE subscriber_id = ? AND series_code = ? AND elem_id = ?";
				query = mysql.format(query,[objectTypeLookup[req.body.objectType].table,req.session.subscriber_id,req.body.series_code,req.body.elem_id]);
				let [err, result] = await to(this.dbfunc.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
				if (err) {
					throw err;
				}
				if (result.elem_id !== req.body.elem_id) {
					throw "elem_id lookup failed.";
				}
				let orig_data = JSON.parse(JSON.stringify(result));
				if (result.options === null) {
					result.options = {};
				}
				if (req.body.options && default_options.hasOwnProperty(req.body.options)) {
					default_options[req.body.options] = true;
				}
				if (req.body.priceAddOn !== 0) {
					default_options.priceAddOn = req.body.priceAddOn;
				}
				Object.assign(result.options,default_options);
				let fields = {
					price: req.body.price,
					options: JSON.stringify(result.options)
				};
				query = "UPDATE ?? SET ? WHERE subscriber_id = ? AND series_code = ? AND elem_id = ?";
				query = mysql.format(query,[objectTypeLookup[req.body.objectType].table,fields,req.session.subscriber_id,req.body.series_code,req.body.elem_id]);
				let [err2, result2] = await to(this.dbfunc.P_GetQueryData(query,null,this.MySQLActionResult));
				if (err2) {
					throw err2;
				}
				let [err3, result3] = await to(this.logAction({
					req: req,
					change_type: "price",
					category: req.body.objectType,
					series_code: req.body.series_code,
					product_id: req.body.elem_id,
					action: {
						class: "price_change",
						table: objectTypeLookup[req.body.objectType].table,
						description: "Price Update",
						previous_row: orig_data,
						new_row: result.options
					}
				}));
				return result2;
			}
			case "copy_siding_to_trim": {
				if ((["admin","sadmin"].includes(req.session.userdata.usertype)) && (req.body.source_subscriber_id !== req.session.subscriber_id)) {
					throw {name: "unauthorized", message: "Unauthorized request."};
				}
				let query = "SELECT * FROM subscriber_siding_categories WHERE subscriber_id = ? AND series_code = ? AND category_id = ?";
				query = mysql.format(query,[req.body.source_subscriber_id,req.body.source_series_code,req.body.source_category_id]);
				let [err, sidingInfo] = await to(this.dbfunc.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
				if (err) {
					throw err;
				}
				query = "SELECT subscriber_id, series_code, color_id FROM subscriber_siding_colors WHERE subscriber_id = ? AND series_code = ? AND category_id = ?";
				query = mysql.format(query,[req.body.source_subscriber_id,req.body.source_series_code,req.body.source_category_id]);
				let [err2, tabledata] = await to(this.dbfunc.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
				if (err2) {
					throw err2;
				}
				if (tabledata.length === 0) {
					throw("No colors found.");
				}
				switch (req.body.copy_type) {
					case "O": {
						query = "DELETE FROM subscriber_trim_colors WHERE subscriber_id = ? AND series_code = ? AND trim_set_id = ?";
						query = mysql.format(query,[req.body.source_subscriber_id,req.body.source_series_code, sidingInfo.trim_set_id]);
						let [err, result] = await to(this.dbfunc.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
						if (err) {
							throw err;
						}
					}
					case "A": {
						for (let color of tabledata) {
							color.trim_set_id = sidingInfo.trim_set_id;
						}
						break;
					}
					case "N": {
						for (let color of tabledata) {
							color.trim_set_id = req.body.trim_set;
						}
						break;
					}
					default: {
					throw("Invalid Action Type");
					}
				}
				query = "INSERT INTO subscriber_trim_colors (subscriber_id, series_code, color_id, trim_set_id) VALUES ?";
				query = mysql.format(query,[this.dbfunc.prepObjectArrayforMySQL(this.dbfunc.rowObjToArray(tabledata))]);
				{
					let [err, result] = await to(this.dbfunc.P_GetQueryData(query, null, this.MySQLActionResult));
					if (err) {
						throw err;
					}
				}
				return {success: true};
				//break;
			}
			case "setDesignAsDefaultForBuilding": {
				[err,result] = await to(this.setDesignAsDefaultForBuilding);
				break;
			}
			default: {
				throw {message: "invalid request"};
			}
		}
		if (err) {
			throw err;
		}
		return result;
	}

	async setDesignAsDefaultForBuilding(req) {
		this.logger.debug("/setDesignAsDefaultForBuilding");

		let subscriber = mysql.escape(await CleanSubscriberID(null, req));
		let building_id = mysql.escape(req.body.building_id);
		let width = mysql.escape(req.body.width);
		let design_id = mysql.escape(req.body.design_id);
		let series_code = "Standard";
		if (!(typeof req.body.series_code === "undefined")) {
			series_code = mysql.escape(req.body.series_code);
		} else {
			series_code = mysql.escape(series_code);
		}

		let query = "INSERT INTO subscriber_default_settings (subscriber_id, series_code, building_id, width, design_id) VALUES (" + subscriber + " ," + series_code + ", " + building_id + ", " + width + ", " + design_id + ")";

		this.logger.debug(query);

		let [err, result] = await to(this.P_GetQueryData(query, null, ParseSetDesignAsDefaultForBuilding));
		if (err) {
			throw err;
		}
		return result;
	}

	async addLocation(req) {
		logger.debug("app.js:fn:addLocation");
		if (["sadmin","master"].includes(req.session.userdata.usertype) === false) {
			throw {name: "unauthorized", message: "Unauthorized request."};
		}
		let query = "SELECT * FROM subscriber_locations WHERE subscriber_id = ? ORDER BY location_number DESC LIMIT 1";
		query = mysql.format(query,req.session.subscriber_id);
		let [err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		if (result.length > 0) {
			req.body.location_number = result[0].location_number + 1;
			req.body.display_prices = result[0].display_prices;
		}
		req.body.subscriber_id = req.session.subscriber_id;
		req.body.active = 0;

		query = "INSERT INTO subscriber_locations SET ?";
		delete req.body.request;
		query = mysql.format(query,[req.body]);

		[err,result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
		if (err) {
			throw err;
		}
		return req.body;
	}

	async updateLocation(req) {
		logger.debug("app.js:fn:updateLocation");
		let err, result, oldrow;
		if (["sadmin","master"].includes(req.session.userdata.usertype) === false) {
			throw {name: "unauthorized", message: "Unauthorized request."};
		}
		let updateRecord = JSON.parse(JSON.stringify(req.body));

		delete updateRecord.request;
		delete updateRecord.location_number;
		delete updateRecord.active;

		let query = "SELECT * FROM subscriber_locations WHERE subscriber_id = ? AND location_number = ?";
		query = mysql.format(query,[req.session.subscriber_id,req.body.location_number]);
		[err, oldrow] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
		if (err) {
			throw err;
		}
		query = "UPDATE subscriber_locations SET ? WHERE subscriber_id = ? AND location_number = ?";
		query = mysql.format(query,[updateRecord, req.session.subscriber_id,req.body.location_number]);
		logger.debug(query);
		[err,result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
		if (err) {
			throw err;
		}

		updateRecord.active = req.body.active;
		updateRecord.location_number = req.body.location_number;
		let dt = new Date();
		let t = dt.toISOString().substring(11, 19);
		let d = dt.toISOString().substring(0, 10);
		let change_log = {
			datetime: d + " " + t,
			subscriber_id: req.session.subscriber_id,
			userid: req.session.user,
			action: JSON.stringify({
				class: "record_change",
				type: "location",
				table: "subscriber_locations",
				details: {
					previous_row: oldrow,
					new_row: updateRecord
				}
			})
		};
		query = "INSERT INTO subscriber_change_log SET ?";
		query = mysql.format(query,change_log);
		[err,result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
		if (err) {
			throw err;
		}
		return updateRecord;
	}

	async activateLocation(req) {
		logger.debug("app.js:fn:activateLocation");
		// *** TODO: change to tranaction
		if (["sadmin","master"].includes(req.session.userdata.usertype) === false) {
			throw {name: "unauthorized", message: "Unauthorized request."};
		}
		let data = [];
		data.push(req.session.subscriber_id);
		data.push(req.body.location_number);
		let query = "UPDATE subscriber_locations SET active = 1 WHERE subscriber_id = ? AND location_number = ?";
		query = mysql.format(query,data);
		let [err,result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
		if (err) {
			throw err;
		}
		let dt = new Date();
		let t = dt.toISOString().substring(11, 19);
		let d = dt.toISOString().substring(0, 10);
		let change_log = {
			datetime: d + " " + t,
			subscriber_id: req.session.subscriber_id,
			userid: req.session.user,
			action: JSON.stringify({
				class: "service_change",
				type: "activatelocation",
				details: {
					location_number: req.body.location_number,
					name: req.body.name
				}
			})
		};
		query = "INSERT INTO subscriber_change_log SET ?";
		query = mysql.format(query,change_log);
		[err,result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
		if (err) {
			throw err;
		}

		return result;
	}

	async deactivateLocation(req) {
		logger.debug("app.js:fn:deactivateLocation");
		// *** TODO: change to tranaction
		if (["sadmin","master"].includes(req.session.userdata.usertype) === false) {
			throw {name: "unauthorized", message: "Unauthorized request."};
		}
		let data = [];
		data.push(req.session.subscriber_id);
		data.push(req.body.location_number);
		let query = "UPDATE subscriber_locations SET active = 0 WHERE subscriber_id = ? AND location_number = ?";
		query = mysql.format(query,data);
		let [err,result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
		if (err) {
			throw err;
		}
		let dt = new Date();
		let t = dt.toISOString().substring(11, 19);
		let d = dt.toISOString().substring(0, 10);
		let change_log = {
			datetime: d + " " + t,
			subscriber_id: req.session.subscriber_id,
			userid: req.session.user,
			action: JSON.stringify({
				class: "service_change",
				type: "deactivatelocation",
				details: {
					location_number: req.body.location_number,
					name: req.body.name
				}
			})
		};
		query = "INSERT INTO subscriber_change_log SET ?";
		query = mysql.format(query,change_log);
		[err,result] = await to(this.P_GetQueryData(query,null,this.MySQLActionResult));
		if (err) {
			throw err;
		}

		return result;
	}

	async getRegisteredUserCount(req) {
		logger.debug("fn:getRegisteredUserCount");
		if (["staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
			throw {name: "unauthorized", message: "Unauthorized request."};
		}
		let err, result, query;
		let subscriber_id = await CleanSubscriberID(null,req);
		if (req.session.subscriber_id.indexOf("MASTER")>-1 && req.session.userdata.usertype === "master") {
			query = `SELECT COUNT(*) AS registered_user_count FROM users`;
		} else {
			if (["sadmin","master"].includes(req.session.userdata.usertype)) {
				query = `SELECT COUNT(*) AS registered_user_count FROM users WHERE subscriber_id = ?`;
				query = mysql.format(query,subscriber_id);
			} else {
				query = `SELECT COUNT(*) AS registered_user_count FROM users WHERE subscriber_id = ? AND location_number = ?`;
				query = mysql.format(query,[subscriber_id,req.session.userdata.location_number]);
			}
		}
		[err,result] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
		if (err) {
			throw err;
		}
		return result;
	}

	async getSavedDesignCount(req) {
		logger.debug("fn:getSavedDesignCount");
		if (["staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
			throw {name: "unauthorized", message: "Unauthorized request."};
		}
		let err, result, query;
		let subscriber_id = await CleanSubscriberID(null,req);
		if (req.session.subscriber_id.indexOf("MASTER")>-1 && req.session.userdata.usertype === "master") {
			query = `SELECT COUNT(*) AS design_count FROM usersheds`;
		} else {
			if (["sadmin","master"].includes(req.session.userdata.usertype)) {
				query = `SELECT COUNT(*) AS design_count FROM usersheds WHERE subscriber_id = ?`;
				query = mysql.format(query,subscriber_id);
			} else {
				query = `SELECT COUNT(*) AS design_count FROM usersheds WHERE subscriber_id = ? AND location_number = ?`;
				query = mysql.format(query,[subscriber_id,req.session.userdata.location_number]);
			}
		}
		[err,result] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
		if (err) {
			throw err;
		}
		return result;
	}

	async getTotalContactRequestCount(req) {
		logger.debug("fn:getTotalOrderCount");
		if (["staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
			throw {name: "unauthorized", message: "Unauthorized request."};
		}
		let err, result, query;
		let subscriber_id = await CleanSubscriberID(null,req);
		if (req.session.subscriber_id.indexOf("MASTER")>-1 && req.session.userdata.usertype === "master") {
			query = `SELECT COUNT(*) AS contact_request_count FROM user_contact_requests`;
		} else {
			if (["sadmin","master"].includes(req.session.userdata.usertype)) {
				query = `SELECT COUNT(*) AS contact_request_count FROM user_contact_requests WHERE subscriber_id = ?`;
				query = mysql.format(query,subscriber_id);
			} else {
				query = `SELECT COUNT(*) AS contact_request_count FROM user_contact_requests WHERE subscriber_id = ? AND location_number = ?`;
				query = mysql.format(query,[subscriber_id,req.session.userdata.location_number]);
			}
		}
		[err,result] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
		if (err) {
			throw err;
		}
		return result;
	}

	async getTotalOrderCount(req) {
		logger.debug("fn:getTotalOrderCount");
		if (["staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
			throw {name: "unauthorized", message: "Unauthorized request."};
		}
		let err, result, query;
		let subscriber_id = await CleanSubscriberID(null,req);
		if (req.session.subscriber_id.indexOf("MASTER")>-1 && req.session.userdata.usertype === "master") {
			query = `SELECT COUNT(*) AS order_count FROM user_order_requests`;
		} else {
			if (["sadmin","master"].includes(req.session.userdata.usertype)) {
				query = `SELECT COUNT(*) AS order_count FROM user_order_requests WHERE subscriber_id = ?`;
				query = mysql.format(query,subscriber_id);
			} else {
				query = `SELECT COUNT(*) AS order_count FROM user_order_requests WHERE subscriber_id = ? AND location_number = ?`;
				query = mysql.format(query,[subscriber_id,req.session.userdata.location_number]);
			}
		}
		[err,result] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
		if (err) {
			throw err;
		}
		return result;
	}

/**
 * Returns a list of staff for the subscriber_id
 * @param {Object} req socket request or http request record
 */
async getStaff(req) {
	logger.debug("app.js:fn:getStaff");
	let query;
	if (["staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
		throw {name: "unauthorized", message: "Unauthorized request."};
	}
	if (req.session.subscriber_id.indexOf("MASTER")>-1) {
		query = "SELECT * FROM users WHERE subscriber_id = ? AND (usertype LIKE '%admin%' OR usertype = 'master' OR usertype = 'staff' OR usertype = 'driver')";
	} else {
		query = "SELECT * FROM users WHERE subscriber_id = ? AND (usertype LIKE '%admin%' OR usertype = 'staff' OR usertype = 'driver')";
	}
	query = mysql.format(query,req.session.subscriber_id);
	let [err,result] = await to(this.P_GetQueryData(query,ParseUsersRowDataObj,this.P_ParseMySqlRowsDataObj));
	if (err) {
		throw err;
	}
	return result;
}

/**
 * Returns a list of users for the subscriber_id
 * @param {Object} req socket request or http request record
 */
async getUsers(req) {
	logger.debug("app.js:fn:getUsers");
	if (["staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
		throw {name: "unauthorized", message: "Unauthorized request."};
	}
	let query;
	if (["sadmin","master"].includes(req.session.userdata.usertype)) {
		query = "SELECT * FROM users WHERE subscriber_id = ? AND (usertype = 'user' OR usertype='customer')";
		query = mysql.format(query,req.session.subscriber_id);
	} else {
		query = "SELECT * FROM users WHERE subscriber_id = ? AND location_number = ? AND (usertype = 'user' OR usertype='customer')";
		query = mysql.format(query,[req.session.subscriber_id,req.session.userdata.location_number]);
	}
	let [err,result] = await to(this.P_GetQueryData(query,ParseUsersRowDataObj,this.P_ParseMySqlRowsDataObj));
	if (err) {
		throw err;
	}
	return result;
}

/**
 * Returns a list of user designs for the subscriber_id
 * @param {Object} req socket request or http request record
 */
async getDesignsList(req) {
	logger.debug("app.js:fn:getDesignsList");
	if (["staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
		throw {name: "unauthorized", message: "Unauthorized request."};
	}
	//let query = "SELECT * FROM users WHERE subscriber_id = ? AND usertype = 'user'";
	let query;
	if (["sadmin","master"].includes(req.session.userdata.usertype) || (req.session.userdata.data && req.session.userdata.data.acl && req.session.userdata.data.acl.all_locations)) {
		query = `SET @sql = CONCAT('SELECT ', (SELECT GROUP_CONCAT(COLUMN_NAME) FROM information_schema.columns WHERE table_schema = 'tdfdesigner' AND table_name = 'usersheds' AND column_name NOT IN ('id', 'data')), ' FROM usersheds WHERE subscriber_id = "${req.session.subscriber_id}"');PREPARE stmt1 FROM @sql;EXECUTE stmt1;`
	} else {
		query = `SET @sql = CONCAT('SELECT ', (SELECT GROUP_CONCAT(COLUMN_NAME) FROM information_schema.columns WHERE table_schema = 'tdfdesigner' AND table_name = 'usersheds' AND column_name NOT IN ('id', 'data')), ' FROM usersheds WHERE subscriber_id = "${req.session.subscriber_id}" AND location_number = ${req.session.userdata.location_number}');PREPARE stmt1 FROM @sql;EXECUTE stmt1;`
	}
	//query = mysql.format(query,req.session.subscriber_id);
	let [err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
	if (err) {
		throw err;
	}
	let design_list = result[2];
	if (["sadmin","master"].includes(req.session.userdata.usertype) || (req.session.userdata.data && req.session.userdata.data.acl && req.session.userdata.data.acl.all_locations)) {
		query = `SELECT design_id, data FROM usersheds WHERE subscriber_id = "${req.session.subscriber_id}" AND in_file_bucket = 1`;
	} else {
		query = `SELECT design_id, data FROM usersheds WHERE subscriber_id = "${req.session.subscriber_id}" AND location_number = ${req.session.userdata.location_number} AND in_file_bucket = 1`;
	}
	let result2;
	[err, result2] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
	if (err) {
		throw err;
	}
	for (let row of result2) {
		let match = _.findIndex(design_list, ["design_id",row.design_id]);
		if (match) {
			design_list[match].data = typeof row.data === "string" ? JSON.parse(row.data) : row.data;
		}
	}
	return design_list;
}

/**
 * Returns a list of user designs for the subscriber_id
 * @param {Object} req socket request or http request record
 */
async getOrdersList(req) {
	logger.debug("app.js:fn:getOrdersList");
	if (["driver","staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
		throw {name: "unauthorized", message: "Unauthorized request."};
	}
	if (["driver","staff"].includes(req.session.userdata.usertype) === true) {
		// *** TODO: check for ACL permission list_orders
	}
	let query;
	if (["sadmin","master"].includes(req.session.userdata.usertype) || (req.session.userdata.data && req.session.userdata.data.acl && req.session.userdata.data.acl.all_locations)) {
		query = "SELECT * FROM user_order_requests WHERE subscriber_id = ?";
		query = mysql.format(query,req.session.subscriber_id);
	} else {
		if (req.session.userdata.data && req.session.userdata.data.acl && req.session.userdata.data.acl.locations) {
			query = "SELECT * FROM user_order_requests WHERE subscriber_id = ? AND location_number IN (?)";
			query = mysql.format(query,[req.session.subscriber_id,req.session.userdata.data.acl.locations]);
		} else {
			query = "SELECT * FROM user_order_requests WHERE subscriber_id = ? AND location_number = ?";
			query = mysql.format(query,[req.session.subscriber_id,req.session.userdata.location_number]);
		}
	}
	let [err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
	if (err) {
		throw err;
	}
	return result;
}

async getContactRequest(req) {
	// *** TODO: check location_number when admin
	logger.debug("app.js:fn:getContactRequest");
	if (req.session && req.session.userdata && ["admin", "sadmin", "master"].includes(req.session.userdata.usertype)) {
		if (req.body.id) {
			let query = "SELECT * FROM user_contact_requests WHERE subscriber_id = ? AND id = ?";
			query = mysql.format(query,[req.session.subscriber_id,req.body.id]);
			let [err,result] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
			if (err) {
				throw err;
			}
			return result;
		}
	} else {
		throw {message: "Unauthorized access."};
	}
}

/**
 * Returns a list of user designs for the subscriber_id
 * @param {Object} req socket request or http request record
 */
async getContactRequestsList(req) {
	logger.debug("app.js:fn:getContactRequestsList");
	if (["driver","staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
		throw {name: "unauthorized", message: "Unauthorized request."};
	}
	if (["driver","staff"].includes(req.session.userdata.usertype) === true) {
		// *** TODO: check for ACL permission list_contacts
	}
	let query;
	if (["sadmin","master"].includes(req.session.userdata.usertype) || (req.session.userdata.data && req.session.userdata.data.acl && req.session.userdata.data.acl.all_locations)) {
		query = "SELECT * FROM user_contact_requests WHERE subscriber_id = ?";
		query = mysql.format(query,req.session.subscriber_id);
	} else {
		if (req.session.userdata.data && req.session.userdata.data.acl && req.session.userdata.data.acl.locations) {
			query = "SELECT * FROM user_contact_requests WHERE subscriber_id = ? AND location_number IN (?)";
			query = mysql.format(query,[req.session.subscriber_id,req.session.userdata.data.acl.locations]);
		} else {
			query = "SELECT * FROM user_contact_requests WHERE subscriber_id = ? AND location_number = ?";
			query = mysql.format(query,[req.session.subscriber_id,req.session.userdata.location_number]);
		}
	}
	let [err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
	if (err) {
		throw err;
	}
	return result;
}

/**
 * Returns the last 10 entries from the update_log
 * @param {object} req socket request or http request record
 */
async getLast10Updates(req) {
	logger.debug("app.js:fn:getLast10Updates");
	if (["staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
		throw {name: "unauthorized", message: "Unauthorized request."};
	}
	let query = "SELECT * FROM update_log ORDER BY date DESC LIMIT 10";
	let [err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
	if (err) {
		throw err;
	}
	return result;
}

async getDesignData(req) {
	logger.debug("app.js:fn:getDesignData");
	if (["driver","staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
		throw {name: "unauthorized", message: "Unauthorized request."};
	}
	if (req.body.design_id) {
		let query = "DESCRIBE usersheds";
		let [err,result] = await to(this.P_GetQueryData(query,this.ParseMySqlRowDataObj,this.P_ParseMySqlRowsDataObj));
		if (err) {
			throw err;
		}
		let columns = "";
		for (let column of result) {
			if (column.Field !== "data") {
				columns += column.Field + ",";
			}
		}
		columns = columns.substring(0,columns.length-1);
		query = `SELECT ${columns} FROM usersheds WHERE subscriber_id = ? AND design_id = ?`;
		query = mysql.format(query,[req.session.subscriber_id,req.body.design_id]);
		[err, result] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
		if (err) {
			throw err;
		}
		let design_data = result;
		if (design_data.in_file_bucket !== 0) {
			query = "SELECT data FROM usersheds WHERE subscriber_id = ? AND design_id = ?";
			query = mysql.format(query,[req.session.subscriber_id,req.body.design_id]);
			[err, result] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
			if (err) {
				throw err;
			}
			design_data.data = JSON.parse(result.data);
		} else {
			design_data.data = null;
		}
		return design_data;
	} else {
		throw {name: "missing data", message: "No design id received in request."}
	}
}

async getOrderData(req) {
	logger.debug("app.js:fn:getOrderData");
	if (["driver","staff","admin","sadmin","master"].includes(req.session.userdata.usertype) === false) {
		throw {name: "unauthorized", message: "Unauthorized request."};
	}
	let query = "SELECT * FROM user_order_requests WHERE subscriber_id = ? AND id = ?";
	query = mysql.format(query,[req.session.subscriber_id,req.body.id]);
	let [err, result] = await to(this.P_GetQueryData(query,null,this.ReturnSingleMySQLRow));
	if (err) {
		throw err;
	}
	return result;
}
}
