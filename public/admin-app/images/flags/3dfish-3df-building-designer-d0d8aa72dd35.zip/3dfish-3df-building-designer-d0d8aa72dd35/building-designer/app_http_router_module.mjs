/*eslint-env node, es6*/
/*eslint-parserOptions ecmaVersion:2019*/
/*eslint no-unused-vars:1, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape, no-undef*/

const THIS_FILE = "app_http_router_module.mjs";

//import Dbfunctions from "./dbfunctions.cjs";
//import mysql from "mysql2/promise.js";
import to from "togo";
//import deepFind from "deep-find";
import _ from "lodash";
//import { getHostMap, setUserLastAccess } from "./app.mjs";

export class HTTPRouterModule {
	constructor(params) {
		this.io = params.io;
		this.designer = params.designerModule;
		this.admin = params.subscriberAdminModule;
		this.master = params.masterAdminModule;
		this.user = params.userModule;
		this.app = params.app;
		this.con = params.mysql_connection; // mysql_connection;
		this.tcon = params.mysql_transaction_connection; //mysql_transaction_connection;
		this.logger = params.logger;
		this.DEBUG = params.DEBUG;

		this.app.post('/userAction', async (req, res) => {
			let [err,result] = await to(this.user.action(req));
			if (err) {
				res.status(500).send("Internal Server Error: "+JSON.stringify(err));
				return;
			}
			res.send(result);
		});

		this.app.post('/userDataRequest', async (req, res) => {
			let [err,result] = await to(this.user.data(req));
			if (err) {
				res.status(500).send("Internal Server Error: "+JSON.stringify(err));
				return;
			}
			res.send(result);
		});

		this.app.post('/dataRequest', async (req, res) => {
			let [err,result] = await to(this.designer.data(req));
			if (err) {
				res.status(500).send("Internal Server Error: "+JSON.stringify(err));
				return;
			}
			res.send(result);
		});

		this.app.post('/adminDataRequest', async (req, res) => {
			let [err,result] = await to(this.admin.loadData(req));
			if (err) {
				res.status(500).send("Internal Server Error: "+JSON.stringify(err));
				return;
			}
			res.send(result);
		});

		this.app.post('/adminAction', async (req, res) => {
			let [err,result] = await to(this.admin.action(req));
			if (err) {
				res.status(500).send("Internal Server Error: "+JSON.stringify(err));
				return;
			}
			res.send(result);
		});

		this.app.post('/masterAction', async (req, res) => {
			let [err,result] = await to(this.master.action(req));
			if (err) {
				res.status(500).send("Internal Server Error: "+JSON.stringify(err));
				return;
			}
			res.send(result);
		});

		// Depricated use userAction instead
		this.app.post('/checkPostalCode', async (req, res) => {
			logger.debug("/checkPostalCode");

			[err, result] = await to(this.user.checkPostalCode(req));
			if (err) {
				this.logger.error("Error Location: app.js/checkPostalCode",{err:err});
				res.send({
					validzip: false,
					success: false,
					status: "fail",
					error: true,
					err: err
				});
				return;
			}
			res.send(result);
		});

		// Depricated use userAction instead
		this.app.post('/quoteRequest', async (req, res) => {
			this.logger.debug("/quoteRequest");

			let [err, result] = await to(this.user.quoteRequest(req));
			if (err) {
				this.logger.error(`app.js:/quoteRequest: Error: ${err}`);
				res.status(500).send("Internal Server Error: " + JSON.stringify(err));
				return;
			}
			res.send(result);
		});
		}
		}
