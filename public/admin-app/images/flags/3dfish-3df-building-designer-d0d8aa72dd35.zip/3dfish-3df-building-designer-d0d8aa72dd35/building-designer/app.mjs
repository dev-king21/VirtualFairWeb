/* 3D Fish Building Designer server app */
/* copyright 2014-2019 3D Fish, LLC, all rights reserved */
/*eslint-env node, es6*/
/*eslint-parserOptions ecmaVersion:2020*/
/*eslint no-unused-vars:0, no-trailing-spaces:2*/
/*eslint-disable no-console, quotes, no-useless-escape */

let codeBaseArrays = {};
const threejsVer = "119";

import { dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

const name = process.argv[2];
if ((!name) && (!process.env.NODE_ENV)) {
		console.error(
		"User not set and no NODE_ENV variable. Please pass in a user name: npm start your_user_name || or Set NODE_ENV"
		);
		process.exit(1);
} else {
	if (name) {
		process.env.NODE_ENV = name;
	}
	console.log("User environment set to:", process.env.NODE_ENV);
}

import tdfserver from "../package.json";
//console.log("tdfserver.version",tdfserver.version);
///const os = require("os");
import os from "os";
const processID = os.hostname();
//const deepFind = require("deep-find");
let debugLag = 100;
let warnLag = 500;
let resetLag = 2000;
let maxUptime = 21600; //6 hours
let sigterm = false;
let sigtermTime;
let killDelay = 120000;
let loadCheck = 60;
let loadWarn = 2;
let loadReset = 3;
let invalidZipCache = [];

import ip from "ip";
//const Promise = require("bluebird");
import Promise from "bluebird";
//const to = require("togo");
import to from "togo";
//const CSV = require("comma-separated-values");
import CSV from "comma-separated-values";
//const lz4 = require("lz4");

function deepFind(obj, path) {
	if (((typeof obj !== "object") && (typeof obj !== "function")) || (obj === null)) {
		return undefined;
	}
	let pathA = path.split('.');
	for (let i = 0; i < pathA.length; i++) {
		if ((obj === null) || (!obj.hasOwnProperty(pathA[i]))) {
			return undefined;
		}
		obj = obj[pathA[i]];
	}
	return obj;
}

process.on("SIGTERM", () => {
	http.close(() => {
		logger.warn('Process terminated');
	})
  })

// get server config
import config from "config";

const serverPort = config.get('Server.port');
const serverLocal = config.get('Server.localhost');

const dbLocal = config.get('Server.localdb');
const serverCfg = config.get('Server');

// check config
if (!(serverCfg.aws && serverCfg.s3)) {
	console.error("Required config sections missing: must have aws and s3 config sections.");
	process.exit(1);
}

import AWS from "aws-sdk";

	let aws_config = JSON.parse(JSON.stringify(serverCfg.aws));
	if (process.env.aws_accessKeyId) {
		Object.assign(aws_config,{accessKeyID: process.env.aws_accessKeyId});
	}
	if (process.env.aws_secretAccessKey) {
		Object.assign(aws_config,{secretAccessKey: process.env.aws_secretAccessKey});
	}
	AWS.config.update(aws_config);

const s3 = new AWS.S3();

import { nanoid } from "nanoid";
import fillTemplate from 'es6-dynamic-template';

let dblocalpw, dblocaluser;
if (config.has('Server.dblocalpw')) {
	dblocalpw = config.get('Server.dblocalpw');
} else {
	dblocalpw = "root";
}
if (config.has('Server.dblocaluser')) {
	dblocaluser = config.get('Server.dblocaluser');
} else {
	dblocaluser = "root";
}

let DEBUG;
let DEBUGQUERY;
let DEBUGCODE = false;

if (config.get('Client.debugcode'))
{
	DEBUGCODE = true;
}

if (!config.get('Server.debug'))
{
	DEBUG = false;
	DEBUGQUERY = false;
}
else
{
	DEBUG = true;
	//DEBUG=express-mysql-session;
	DEBUGQUERY = false;
}

if (DEBUG) {
	maxUptime = 43200; // 12 hours
	resetLag = 300000; // 5 minutes
}

if (config.has('Server.performance.lag.debug')) {
	debugLag = Number(config.get('Server.performance.lag.debug')) || debugLag;
}
if (process.env.lag_debug) {
	debugLag = Number(process.env.lag_debug) || debugLag;
}
if (config.has('Server.performance.lag.warn')) {
	warnLag = Number(config.get('Server.performance.lag.warn')) || warnLag;
}
if (process.env.lag_warn) {
	warnLag = Number(process.env.lag_warn) || warnLag;
}
if (config.has('Server.performance.lag.exit')) {
	resetLag = Number(config.get('Server.performance.lag.exit')) || resetLag;
}
if (process.env.lag_reset) {
	resetLag = Number(process.env.lag_reset) || resetLag;
}
if (config.has('Server.performance.uptime.max')) {
	maxUptime = Number(config.get('Server.performance.uptime.max')) || maxUptime;
}
if (process.env.max_uptime) {
	// this would be a great place for ?? -- should rework this when Node 14 is LTS
	if (Number(process.env.max_uptime) === 0) {
		maxUptime = 0;
	} else {
		maxUptime = Number(process.env.max_uptime) || maxUptime;
	}
}
if ((maxUptime > 0) && (maxUptime < 600)) {
	maxUptime = 600;
	console.warn(`maxUptime was set for less than 10 minutes - now set to 10 minutes.`);
}
// Add 1 to 10 minutes random to prevent all processes reseting at the same time
maxUptime = maxUptime + (Math.floor(Math.random() * 540)) + 60;

if (config.has('Server.performance.load.warn')) {
	loadWarn = Number(config.get('Server.performance.load.warn')) || loadWarn;
}
if (process.env.load_warn) {
	loadWarn = Number(process.env.load_warn) || loadWarn;
}
if (config.has('Server.performance.load.exit')) {
	loadReset = Number(config.get('Server.performance.load.exit')) || loadReset;
}
if (process.env.load_reset) {
	loadReset = Number(process.env.load_reset) || loadReset;
}
if (config.has('Server.performance.load.check')) {
	loadCheck = Number(config.get('Server.performance.load.check')) || loadCheck;
}
if (process.env.load_check) {
	loadCheck = Number(process.env.load_check) || loadCheck;
}

if (!DEBUG) {
	console.log = (...args) => logger.info(...args);
	console.info = (...args) => logger.info(...args);
	console.warn = (...args) => logger.warn(...args);
	console.error = (...args) => logger.error(...args);
	console.debug = (...args) => logger.debug(...args);
}

const serverRunmode = config.get('Server.runmode');
import logdnaWinston from 'logdna-winston';
import winston from 'winston';
winston.addColors({
	error: "white redBG",
	warn: "white yellowBG",
	info: "black whiteBG",
	verbose: "white magentaBG",
	debug: "white greenBG",
	silly: "white blackBG"
});
let createLoggerParams = {};
import tripleBeam from 'triple-beam';
const { LEVEL, MESSAGE } = tripleBeam;
if (DEBUG) {
	createLoggerParams = {
		transports: [
			new winston.transports.Console({
			//
			// Possible to override the log method of the
			// internal transports of winston@3.0.0.
			//
			format: winston.format.cli(),
			level: "debug",
			log(info, callback) {
				setImmediate(() => this.emit('logged', info));

				if (this.stderrLevels[info[LEVEL]]) {
					console.error(info[MESSAGE]);

					if (callback) {
						callback();
					}
					return;
				}

				console.log(info[MESSAGE]);

				if (callback) {
				  callback();
				}
			  }
			})
		  ]
		};
}

const logger = winston.createLogger(createLoggerParams);

const loggerOptions = {
	key: null,
	hostname: processID,
	ip: ip.address(),
	app: "BuildingDesignerServer",
	env: "node",
	level: "info", // Set default to info, medium level of log, doc: https://github.com/winstonjs/winston#logging-levels
	index_meta: true // Defaults to false, when true ensures meta object will be searchable
};

if (DEBUG) {
	loggerOptions.level = "debug";
}

// Only add this line in order to track exceptions
loggerOptions.handleExceptions = true;

if (deepFind(serverCfg,"logdna.apikey")) {
	loggerOptions.key = JSON.parse(JSON.stringify(serverCfg.logdna.apikey));
}
if (process.env.logdna_apikey) {
	loggerOptions.key = process.env.logdna_apikey;
}

if((serverRunmode === "production") && (!serverCfg.locallog) && (loggerOptions.key)) {
	logger.add(new logdnaWinston(loggerOptions));
	logger.add(new winston.transports.Console({
		format: winston.format.simple(),
		level: loggerOptions.level
	}));
} else {
	/* logger.add(new winston.transports.Console({
		format: winston.format.cli(),
		level: loggerOptions.level
	})); */
}

import moment from "moment";
import _ from "lodash";
import WebHooks from 'node-webhooks';

//const validateEmail = Promise.promisify(require('mailgun-validate-email')('key-a389aaf7feaf8f71d650f96b93fb23ad'));
import mailgunValidateEmailModule from 'mailgun-validate-email';
const validateEmail = Promise.promisify(mailgunValidateEmailModule('key-a389aaf7feaf8f71d650f96b93fb23ad'));

/*eslint-disable no-unused-vars*/
//const pkginfo = require('pkginfo')(module);  // The info is exposed via the module var not the pkginfo var
//debugger;
//import pkginfo from "pkginfo";
//pkginfo(module);
const module = {
	exports: {
		version: tdfserver.version || process.env.npm_package_version || "3.4.4",
		name: tdfserver.package_name || process.env.npm_package_name|| "building-designer"
	}
}
logger.info(`tdfserver.version: ${tdfserver.version}`);
/*eslint-enable no-unused-vars*/

import fs from "fs";

import mysql from "mysql2/promise.js";
// const mysql = require("mysql-connection-pool-manager");

const sharedSecretKey = '2C44-4D44-WppQ38S';
import express from 'express';
import cors from 'cors';
import session from 'express-session';
//const sharedsession = require("express-socket.io-session");
//const RedisStore = require('connect-redis')(session);
//const multiparty = Promise.promisifyAll(require('multiparty'), {multiArgs:true}); // May need mutliArgs in future
//const multiparty = Promise.promisifyAll(require('multiparty'));
//const busboyPromise = require('busboy-promise');
import formdata from '@coolgk/formdata';

import bodyParser from 'body-parser';
import path from "path";

import nodemailer from 'nodemailer';
import mg from 'nodemailer-mailgun-transport';

// at some point this will probably be set from the database dependent on the subscriber_id
// to allow for sending mail from the subscribers domain name
const mgauth = {
	auth: {
		api_key: 'key-a389aaf7feaf8f71d650f96b93fb23ad',
		domain: 'mg.3dfish.net'
	}
};

/*
const s3client = s3.createClient({
	maxAsyncS3: 20,     // this is the default
	s3RetryCount: 3,    // this is the default
	s3RetryDelay: 1000, // this is the default
	multipartUploadThreshold: 20971520, // this is the default (20 MB)
	multipartUploadSize: 15728640, // this is the default (15 MB)
	s3Options: {
	  accessKeyId: "AKIAQLBOLMGCIWNSF622",
	  secretAccessKey: "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",
	  // any other options are passed to new AWS.S3()
	  // See: http://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/Config.html#constructor-property
	},
  });
*/

const nodemailerMailgun = nodemailer.createTransport(mg(mgauth));

const app = express();
//const http = require('http').Server(app);
import httpModule from 'http';
const http = httpModule.Server(app);
//const io = require('socket.io')(http);
import ioModule from 'socket.io'
const io = ioModule(http);

let redisAdapterActive = false;
let mongoAdapterActive = false;
import mongoAdapter from '@mother/socket.io-adapter-mongo';

/*
if(serverRunmode === "production") {
	io.adapter(mongoAdapter( 'mongodb://a6e0075b91e7de4dc68308e8d087e0f7:tdfbd614MDB@30-2a.mongo.evennode.com:27017,30-2b.mongo.evennode.com:27017/a6e0075b91e7de4dc68308e8d087e0f7?replicaSet=rs0' ));
}
*/
//let defaultAdapter = "redis";
//let backupAdapter = "mongodb";
let backupAdapter = "redis";
let defaultAdapter = "mongodb";

let redisChannel;

if (serverCfg.socketCfg && serverCfg.socketCfg.defaultAdapter) {
	defaultAdapter = serverCfg.socketCfg.defaultAdapter;
}
if (serverCfg.socketCfg && serverCfg.socketCfg.defaultAdapter) {
	backupAdapter = serverCfg.socketCfg.backupAdapter;
}
if (process.env.socket_defaultAdapter) {
	defaultAdapter = process.env.socket_defaultAdapter;
}
if (process.env.socket_backupAdapter) {
	backupAdapter = process.env.socket_backupAdapter;
}

let mongodbKey;

if(serverRunmode === "production") {
	redisChannel = "socket.io";
	mongodbKey = "socket.io";
} else {
	redisChannel = "socket.io-dev";
	mongodbKey = "socket.io-dev";
}

let mongoUri = 'mongodb://a6e0075b91e7de4dc68308e8d087e0f7:tdfbd614MDB@30-2a.mongo.evennode.com:27017,30-2b.mongo.evennode.com:27017/a6e0075b91e7de4dc68308e8d087e0f7?replicaSet=rs0';
if (serverCfg.mongoDbCfg && serverCfg.mongoDbCfg.uri) {
	mongoUri = serverCfg.mongoDbCfg.uri;
}
if (process.env.mongoUri) {
	mongoUri = process.env.mongoUri;
}

/* The following requires a Redis server */
//const redis = require('redis').createClient;
import redisModule from 'redis'
const redis = redisModule.createClient;
import redisAdapter from 'socket.io-redis';

let redisHost = "reserver1.3dfish.net";
let redisPort = 6379;
let redisPass = "tdf614515RDS!";

if (serverCfg.redisCfg && serverCfg.redisCfg.host) {
	redisHost = serverCfg.redisCfg.host;
}
if (process.env.redisHost) {
	redisHost = process.env.redisHost;
}
if (serverCfg.redisCfg && serverCfg.redisCfg.port) {
	redisPort = serverCfg.redisCfg.port;
}
if (process.env.redisPort) {
	redisPort = process.env.redisPort;
}
if (serverCfg.redisCfg && serverCfg.redisCfg.password) {
	redisPass = serverCfg.redisCfg.password;
}
if (process.env.redisPass) {
	redisPass = process.env.redisPass;
}
let pub, sub;

if (serverCfg.redis && (!process.env.disableRedis)) {
	pub = redis(redisPort, redisHost,{ auth_pass: redisPass});
	sub = redis(redisPort, redisHost,{ auth_pass: redisPass});
}
// io.adapter(redisAdapter({host: 'rdserver1.3dfish.net', port: 6379}));
try {
	if ((defaultAdapter === "redis") && (serverCfg.redis && (!process.env.disableRedis))) {
		logger.debug("Setting Redis Adapter");
		io.adapter(redisAdapter({ pubClient: pub, subClient: sub, prefix: redisChannel, key: redisChannel, requestsTimeout: 10000 }));
		//redisAdapter.on('error',(err) => { logger.error(err)});
		redisAdapterActive = true;
	} else {
		logger.debug("Setting Mongo Adapter");
		io.adapter(mongoAdapter({uri: mongoUri, prefix: mongodbKey, key: mongodbKey, requestsTimeout: 20000, collectionSize: 1000000 } ));
		mongoAdapterActive = true;
		if (serverCfg.redis) {
			pub.on("error", function (err) {
				logger.warn("REDIS Error " + err);
			});
			pub.on("error", function (err) {
				logger.warn("REDIS Error " + err);
			});
		}
	}
	logger.info(`${defaultAdapter} adapter connected for process ${processID}`);
}
catch(err) {
	logger.error(`Error connecting to ${defaultAdapter} adapter: ${err} Trying backup`);
		try {
			if (backupAdapter === "mongodb") {
				io.adapter(mongoAdapter({ uri: mongoUri, prefix: mongodbKey, key: mongodbKey, requestsTimeout: 20000, collectionSize: 1000000 } ));
				mongoAdapterActive = true;
				if (config.get("Server.redis")) {
					pub.on("error", function (err) {
						logger.warn("REDIS Error " + err);
					});
					sub.on("error", function (err) {
						logger.warn("REDIS Error " + err);
					});
				}
			} else {
				if (config.get("Server.redis")) {
					io.adapter(redisAdapter({ pubClient: pub, subClient: sub, prefix: redisChannel, key: redisChannel, requestsTimeout: 10000 }));
					redisAdapterActive = true;
				}
			}
		}
		catch(err) {
			logger.error(`Error connecting to ${backupAdapter} Adapter: ${err}`);
		}
		logger.info(`${backupAdapter} adapter connected for process ${processID}`);
}

if (mongoAdapterActive) {
	io.of('/').adapter.on('error',(err) => { logger.error(`mongodb adapter.on error: ${err}`)});
	logger.info("Mongo Adapter Active");
	//io.of('/').adapter.prototype.on('error',(err) => { logger.error(`mongodb adapter.prototype.on error: ${err}`)});
}
if (redisAdapterActive) {
	io.of('/').adapter.on('error',(err) => { logger.error(`redis adapter.prototype.on error: ${err}`)});
	logger.info("Redis Adapter Active");
	//io.of('/').adapter.prototype.on('error',(err) => { logger.error(err)});
}

app.use(cors());

app.use(formdata.express());

app.set('view engine', 'ejs');

if (serverLocal) {
	app.set('views', __dirname + '/../views');
}

// const FileStore = require('session-file-store')(session);
//const MySQLStore = require('express-mysql-session')(session);
import MySQLStoreModule from 'express-mysql-session';
const MySQLStore = MySQLStoreModule(session);

/*  Moved this code to the end after app.get('/') otherwise '/' never gets processed

if (serverLocal)
{
	app.use(express.static('public'));
}
else
{
	app.use(express.static(path.join(__dirname, 'public')));
}
*/
app.enable('trust proxy');

app.use(function (req, response, next)
{
	response.setHeader('Access-Control-Allow-Origin', '*');

	// Pass to next layer of middleware
	next();
});

const sessionoptions = {
	checkExpirationInterval: 900000,// How frequently expired sessions will be cleared; milliseconds.
	expiration: 90 * 24 * 60 * 60 * 1000,  // 3 months
	createDatabaseTable: true,// Whether or not to create the sessions database table, if one does not already exist.
	connectionLimit: 1,// Number of connections when creating a connection pool
	schema: {
		tableName: 'sessions',
		columnNames: {
			session_id: 'session_id',
			expires: 'expires',
			data: 'data'
		}
	}
};

app.use(bodyParser.json());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));

app.use(bodyParser.urlencoded({ extended: true }));

// Create a connection to the db
let msconfig = {};
if ((!dbLocal) && (!serverCfg.devdb))
{
	/* msconfig = {
                host: "server.3dfish.net",
                user: "csdesignerbeta",
                password: "cs434SD!",
                database: "horsebarndesigner"
             }; */
	/* msconfig = {
		host: "rds-mysql-3df-useast.cdddmjaevdna.us-east-1.rds.amazonaws.com",
		user: "tdfaws",
		password: "td614RDS!",
		database: "tdfdesigner",
		ssl: "Amazon RDS",
		multipleStatements: true
	}; */
	if (serverCfg.productiondb) {
		msconfig = {
			...serverCfg.productiondbCfg,
			multipleStatements: true
		};
	} else {
		msconfig = {
			host: "tdfarorainstance2.cdddmjaevdna.us-east-1.rds.amazonaws.com",
			user: "tdfaws",
			password: "td614RDS!",
			database: "tdfdesigner",
			ssl: "Amazon RDS",
			multipleStatements: true
		};
	}
}
else
{
	if (serverCfg.localdb) {
		msconfig = {
			host: "localhost",
			user: dblocaluser,
			password: dblocalpw,
			database: "tdfdesigner",
			multipleStatements: true,
			connectionLimit: 10
		};
	}
	if (serverCfg.devdb) {
		logger.debug("setting msconfig");
		msconfig = {
			...serverCfg.devdbCfg,
			multipleStatements: true,
			connectionLimit: 10
		};
		logger.debug("after set");
	}
	if (DEBUG) {
		logger.debug(`msconfig: ${JSON.stringify(msconfig)}`);
	}
}

// db settings override with environment variables
if (process.env.tdf_dbhost) {
	Object.assign(msconfig,{host: process.env.tdf_dbhost});
}
if (process.env.tdf_dbport) {
	Object.assign(msconfig,{port: process.env.tdf_dbhost});
}
if (process.env.tdf_dbuser) {
	Object.assign(msconfig,{user: process.env.tdf_dbuser});
}
if (process.env.tdf_dbpass) {
	Object.assign(msconfig,{password: process.env.tdf_dbpass});
}

/*
const mysqlpoolconfig = {
	idleCheckInterval: 1000,
  maxConnextionTimeout: 30000,
  idlePoolTimeout: 3000,
  errorLimit: 5,
  preInitDelay: 50,
  sessionTimeout: 60000,
  onConnectionAcquire: () => { console.log("Acquire"); },
  onConnectionConnect: () => { console.log("Connect"); },
  onConnectionEnqueue: () => { console.log("Enqueue"); },
  onConnectionRelease: () => { console.log("Release"); },
	mySQLSettings: msconfig
}; */

// var con = mysql.createConnection(msconfig);
//var con = mysql(mysqlpoolconfig);
const con = mysql.createPool(msconfig);
// create seperate connection for session store to prevent it from interfering in transactions.
let msconfig2 = JSON.parse(JSON.stringify(msconfig));
const con2 = mysql.createPool(Object.assign(msconfig2,{connectionLimit: 1}));

import { ParseFeatureDataObj, InitDataParserModule, ParseSubscriberLocationData } from "./app_data_parser_module.mjs";
InitDataParserModule({
	logger: logger,
	DEBUG: DEBUG
});
import { MasterAdminModule } from './app_master_admin_module.mjs';
import { Designer as DesignerModule } from './app_designer_module.mjs';
import { HTTPRouterModule } from './app_http_router_module.mjs';
import { SocketRouterModule } from './app_socket_router_module.mjs';
import { SubscriberModule } from './app_subscriber_module.mjs';
import { User as UserModule } from './app_user_module.mjs';
import { Admin } from './app_subscriber_admin_module.mjs';
const admin = new Admin({mysql_connection:con,mysql_transaction_connection:con2,logger:logger,DEBUG:DEBUG});
import Dbfunc from './dbfunctions.cjs';
const dbfunc = new Dbfunc({mysql_connection:con,mysql_transaction_connection:con2,logger:logger,DEBUG:DEBUG});
const ReturnSingleMySQLRow = dbfunc.ReturnSingleMySQLRow.bind(dbfunc);
const MySQLActionResult = dbfunc.MySQLActionResult.bind(dbfunc);
const P_ParseMySqlRowsData = dbfunc.P_ParseMySqlRowsData.bind(dbfunc);
const P_ParseMySqlRowsDataObj = dbfunc.P_ParseMySqlRowsDataObj.bind(dbfunc);
const ParseMySqlRowData = dbfunc.ParseMySqlRowData.bind(dbfunc);
const ParseMySqlRowDataObj = dbfunc.ParseMySqlRowDataObj.bind(dbfunc);
const P_GetQueryData = dbfunc.P_GetQueryData.bind(dbfunc);

const sessionStore = new MySQLStore(sessionoptions,con2);

const sessionMiddleware = session({
	secret: sharedSecretKey,
	resave: false,
	saveUninitialized: false,
	cookie: {
		path: '/',
		httpOnly: true,
		maxAge: 30 * 24 * 60 * 60 * 1000  // 1 month
	},
	store: sessionStore
});

app.use(sessionMiddleware);

io.use(function(socket, next) {
	sessionMiddleware(socket.request, socket.request.res, next);
});
/*
app.use(session({
	secret: sharedSecretKey,
	resave: false,
	saveUninitialized: false,
	cookie: {
		path: '/',
		httpOnly: true,
		maxAge: 30 * 24 * 60 * 60 * 1000  // 1 month
	},
	store: sessionStore
}));
*/
/*
io.use(sharedsession(session, {
    autoSave:true
}));
*/
/*
con.connect(function (err)
{
	if (err)
	{
		console.log('Error connecting to Db');
		console.log("Location: app.js:193, App Error: ",err);
		return;
	}

	console.log('DB Connection established');

	setInterval(function ()
	{
		con.query('SELECT 1');
	}, 50000);
});
*/

//codeBaseArrays = require("./app_build_module.js")({threejsVer:threejsVer,buildVersion: module.exports.version, logger:logger,DEBUG:DEBUG});
import { build as codeBaseArraysModule } from "./app_build_module.mjs";
codeBaseArrays = codeBaseArraysModule({threejsVer:threejsVer,buildVersion: module.exports.version, logger:logger,DEBUG:DEBUG,buildDeactive:process.env.buildDeactive});

function measureLag(DEBUG, debugLag, warnLag, resetLag, loadCheckInt = 60, nextLoadCheck, loadWarn = 2, loadReset = 3) {
	const start = new Date();
	if (!loadCheckInt) {
		loadCheckInt = 60;
	}
	if (!nextLoadCheck) {
		nextLoadCheck = process.uptime() + loadCheckInt;
	}
	setTimeout(() => {
		const lag = new Date() - start;
		const uptime = process.uptime();
		if (DEBUG && (lag > debugLag)) {
			logger.warn(`Event loop took\t${lag} ms`);
		} else if (lag > warnLag) {
			logger.warn(`Event loop took\t${lag} ms`);
			//console.warn(`Console:Event loop took\t${lag} ms`)
		}
		if (lag > resetLag) {
			logger.error(`Event loop took\t${lag} ms -- resetting app`);
			sigterm = true;
			sigtermTime = new Date();
			process.kill(process.pid, 'SIGTERM');
		}
		if ((!sigterm) && (maxUptime > 0) && (uptime > maxUptime)) {
			logger.warn(`Max Uptime exceeded -- resetting app`);
			sigterm = true;
			sigtermTime = new Date();
			process.kill(process.pid, 'SIGTERM');
		}
		if (sigterm) {
			let sigtermDelay = new Date() - sigtermTime;
			if (sigtermDelay > killDelay) {
				logger.warn(`Max Kill delay exceeded -- resetting app by process.exit().`);
				process.exit(1);
			}
		}
		if ((uptime > 300) && (uptime > nextLoadCheck)) {
			let load = os.loadavg();
			if (load[0] > loadWarn) {
				logger.warn(`CPU Load ${load[0]}`);
			}
			if ((load[0] > loadReset) && (!sigterm)) {
				logger.warn(`Max CPU load exceeded -- resetting app`);
				sigterm = true;
				sigtermTime = new Date();
				process.kill(process.pid, 'SIGTERM');
			}
			nextLoadCheck = uptime + loadCheckInt;
		}

		measureLag(DEBUG, debugLag, warnLag, resetLag, loadCheckInt, nextLoadCheck, loadWarn, loadReset); // Recurse
	})
}

export function dateFormat(date, fstr, utc)
{
	utc = utc ? 'getUTC' : 'get';
	return fstr.replace(/%[YmdHMS]/g, function (m)
	{
		switch (m)
		{
		case '%Y':
			return date[utc + 'FullYear'](); // no leading zeros required
		case '%m':
			m = 1 + date[utc + 'Month']();
			break;
		case '%d':
			m = date[utc + 'Date']();
			break;
		case '%H':
			m = date[utc + 'Hours']();
			break;
		case '%M':
			m = date[utc + 'Minutes']();
			break;
		case '%S':
			m = date[utc + 'Seconds']();
			break;
		default:
			return m.slice(1); // unknown code, remove %
		}

		// add leading zero if required
		return ('0' + m).slice(-2);
	});
}

function sleep(ms) {
	return new Promise(resolve => setTimeout(resolve, ms));
}

async function broadcastPID() {
	await sleep(60000);
	io.emit('serverpid',process.pid);
	logger.info("NodeJS PID:",process.pid);
}

export async function setUserLastAccess(req) {
	let err, result, query;
	logger.debug("fn:setUserLastAccess");
	if (req.session && req.session.userdata) {
		req.session.userdata.last_access = dateFormat(new Date(), "%Y-%m-%d", true);
		let last_access_time = dateFormat(new Date(), "%Y-%m-%d %H:%M:%S", true);
		let fq_userid = req.session.userdata.userid;
		if (req.session.userdata.with_prefix) {
			if (fq_userid.indexOf(req.session.subscriber_data.design_prefix + "_") === -1) {
				fq_userid = req.session.subscriber_data.design_prefix + "_" + fq_userid;
			}
		}
		query = `UPDATE users SET last_access = '${last_access_time}' where userid = '${fq_userid}'`;
		[err, result] = await to(P_GetQueryData(query, null, MySQLActionResult));
		if (err) {
			logger.error(`Error updating last access for: ${fq_userid}`);
		}
		logger.debug("fq_userid:", fq_userid);
	}
}

export async function getSubscriberData(req, subscriber_id) {
	let err, result, query;
	subscriber_id = subscriber_id || req.body.subscriber_id;
	subscriber_id = subscriber_id || req.session.subscriber_id;
	if((!req.session.subscriber_data) || (!req.session.subscriber_data.design_prefix) || (!(req.session.subscriber_id == subscriber_id))) {
		query = `SELECT * FROM subscribers WHERE subscriber_id='${subscriber_id}'`;
		[err,result] = await to(P_GetQueryData(query,ParseMySqlRowDataObj,P_ParseMySqlRowsDataObj));
		if(err) {
			throw "Error retrieving subscriber data.";
		}
		if(result.length > 0) {
			req.session.subscriber_data = result[0];
			return result[0];
		} else {
			throw "subscriber id not found.";
		}
	}
}

export async function getHostMap(req) {
	let query = `SELECT * FROM admin_data WHERE datakey='hostmap'`;
	let [err, result] = await to(P_GetQueryData(query, null, ReturnSingleMySQLRow));
	if (err) {
		logger.error(`Error getting hostmap... retrying: host: ${req.headers.host} err: ${err}`);
		if (serverRunmode === "production") {
			if (deepFind(serverCfg, "notifications.error.webhook")) {
				let webHook = new WebHooks({
					db: {
						"errNotification": [deepFind(serverCfg, "notifications.error.webhook")]
					}
				});
				let defaultData = deepFind(serverCfg, "notifications.error.defaultData") || {};
				webHook.trigger('errNotification', {
					...defaultData,
					Message: "Error getting hostmap",
					Source: "app.js"
				});
			}
		}
		await sleep(2000);
		[err, result] = await to(P_GetQueryData(query, null, ReturnSingleMySQLRow));
		if (err) {
			logger.error(`Error getting hostmap, failed: host: ${req.headers.host} err: ${err}`);
			//res.send("The building designer failed to load, this is probably a temporary problem, please try again in a minute or two.");
			throw "The building designer failed to load, this is probably a temporary problem, please try again in a minute or two.";
			//return;
		}
	}
	//logger.debug("checking host map");
	if (result.data) {
		let hostmap;
		if (typeof result.data === "string") {
			hostmap = JSON.parse(result.data);
		} else {
			hostmap = result.data;
		}
		return hostmap;
		/*
		hostdata.customhost = true;
		let host = req.headers.host;
		if (host.indexOf(":")>-1) {
			host = host.substring(0,host.indexOf(":"));
		}
		if(hostmap.host.indexOf(host)>-1) {
			let hostindex = hostmap.host.indexOf(host);
			req.session.host = host;
			hostdata = {...hostdata, ...hostmap.data[hostindex]};
			ejsdata.hostdata = hostdata;
			req.query.sc = hostdata.subscriber_id;
		} */
	} else {
		return null;
	}
	}

/**
 * Resets the session subscriber_data to match the current subscriber in use
 * @function resetSubscriberDataFromDb
 * @param {Object} http request
 * @param {String} subscriber_id
 */
async function resetSubscriberDataFromDb(req, subscriber_id) {
	let err, result, query;
	query = `SELECT * FROM subscribers WHERE subscriber_id='${subscriber_id}'`;
	[err,result] = await to(P_GetQueryData(query,ParseMySqlRowDataObj,P_ParseMySqlRowsDataObj));
	if(err) {
		throw "Error retrieving subscriber data.";
	}
	if(result.length > 0) {
		req.session.subscriber_data = result[0];
	} else {
		throw "subscriber id not found.";
	}
}

const validateSeriesCode = async function (subscriber_id,req) {
	logger.debug('validateSeriesCode');
	let err, result, data;
	let query = "SELECT * FROM subscriber_series WHERE subscriber_id = '" + subscriber_id + "' AND series_code = ?";
	query = mysql.format(query, req.query.series);
	[err,result] = await to(P_GetQueryData(query, ParseMySqlRowData));
	if(err) {
		console.log("Location: app.js:const validateSeriesCode(fn), App Error",err);
		console.log("retrying...");
		await sleep(2000);
		[err,result] = await to(P_GetQueryData(query, ParseMySqlRowData));
		if (err) {
			throw err;
		}
	}
	data = JSON.parse(result)[0];
	if(typeof data !== "undefined") {
			//req.series_data = data;
			return {valid: true, active: data.active, seriesdata: data};
		}
	else {
		return {valid: false, active: false};
	}
};

const validateSubscriber = async function (subscriber_id,req) {
	logger.debug("validateSubscriber");
	let err, result, data;
	let query = "SELECT * FROM subscribers WHERE subscriber_id = '" + subscriber_id + "'";
	[err,result] = await to(P_GetQueryData(query, ParseMySqlRowData));
	if(err) {
		console.log("Location: app.js:const validateSubscriber(fn), App Error",err);
		console.log("retrying...");
		await sleep(2000);
		[err,result] = await to(P_GetQueryData(query, ParseMySqlRowData));
		if (err) {
			throw err;
		}
	}
	data = JSON.parse(result)[0];
	if(typeof data !== "undefined")
		if(((data.status > 0) && (data.status < 4)) || (data.status > 5))
		{
			req.subscriber_data = data;
			return {valid: true, active: true, subdata: data};
		}
		else {
			req.subscriber_data = data;
			return {valid: true, active: false, subdata: data};
		}
	else {
		return {valid: false, active: false};
	}
};

app.get('/healthcheck', async (req, res) => {
	res.send(os.loadavg());
});

app.post('/errorreport', async (req, res) =>
{
	logger.warn(`Error Report: ${req.body.errorcode} From IP: ${req.ip}`,
{StatusCode: req.body.statuscode});
	res.write("");
	res.end();
});

export async function CleanSubscriberID(subscriber_id, req) {
	let err, result;
	logger.debug("CleanSubscriberID");

	// req = req || request;
	if(typeof req==="undefined") req={};

	if (subscriber_id == undefined || subscriber_id == null)
		if(req.body.subscriber_id) {
			subscriber_id = req.body.subscriber_id;
		} else {
			if (req.session && req.session.subscriber_data && req.session.subscriber_data.subscriber_id) {
				subscriber_id = req.session.subscriber_data.subscriber_id;
			}
		}

	if(!subscriber_id) {
		console.log("fn:CleanSubscriberID - subscriber_id not set.");
		return null;
	}
	let subscriber = subscriber_id.replace(/([^a-z0-9\-]+)/gi,"");

	if (subscriber.substr(0,3) === "MT-")
	{
		// master_test = true;
		if(req.session !== "undefined") req.session.master_test = true;
		subscriber = subscriber.substr(3,subscriber.length - 3);
	}

	subscriber_id = subscriber.toUpperCase();
	if(typeof req.session !== "undefined") {
		if (!req.session.subscriber_data) {
			[err, result] = await to(getSubscriberData(req, subscriber_id));
		} else {
			if (req.session.subscriber_data.subscriber_id !== subscriber_id) {
				[err, result] = await to(resetSubscriberDataFromDb(req, subscriber_id));
			}
		}
	}

	return subscriber_id;
}

app.post('/validateEmail', async (req, res) =>
{
	logger.debug("/validateEmail");

	let err, result;

	let subscriber_id = await CleanSubscriberID(null,req);

	if (!subscriber_id) {
		res.send({is_valid: false, status: "error", err: "subscriber_id missing."});
		return;
	}

	if (req.body.email) {
		[err, result] = await to(validateEmail(req.body.email));
		if (err) {
			res.send({is_valid: false, status: "error", err: err});
			return;
		}
		res.send(result);
	} else {
		res.send({is_valid: false});
	}
});

export async function getSubscriberLocationData(req) {
	logger.debug("app.js:fn:getSubscriberLocationData");

	let subscriber_id = await CleanSubscriberID(null,req);

	logger.debug(`subscriber_id: ${subscriber_id}`);

	let query = "SELECT * FROM subscriber_locations WHERE subscriber_id=?";
	query = mysql.format(query,[subscriber_id]);
	let [err, result] = await to(P_GetQueryData(query, null, ParseSubscriberLocationData));
	if (err) {
		throw err;
	}
	return result;
}

app.post('/updateDesign', async (req, res) =>
{
	if(DEBUG) console.log("/updateDesign");
	let query, err, result;
	if(req.body.request) {
		switch(req.body.request) {
		case "archive": {
			query = "UPDATE usersheds SET design_archived = 1 WHERE design_id = ?";
			query = mysql.format(query,[req.body.design_id]);
			[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
			if(err) {
				res.send({status: "error", success: false, err: err});
				return;
			}
			query = "UPDATE usersheds2 SET design_archived = 1 WHERE design_id = ?";
			query = mysql.format(query,[req.body.design_id]);
			[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
			if(err) {
				res.send({status: "error", success: false, err: err});
				return;
			} else {
				res.send({status: "success", success: true});
				return;
			}
			// break; //unreachable code
		}
		case "activate": {
			query = "UPDATE usersheds SET design_archived = 0 WHERE design_id = ?";
			query = mysql.format(query,[req.body.design_id]);
			[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
			if(err) {
				res.send({status: "error", success: false, err: err});
				return;
			}
			query = "UPDATE usersheds2 SET design_archived = 0 WHERE design_id = ?";
			query = mysql.format(query,[req.body.design_id]);
			[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
			if(err) {
				res.send({status: "error", success: false, err: err});
				return;
			} else {
				res.send({status: "success", success: true});
				return;
			}
			// break; //unreachable code
		}
		case "rename": {
			if(req.body.design_id !== req.body.new_design_id) {
				let updatedata = {};
				updatedata.design_id = req.body.new_design_id;
				updatedata.shed_name = req.body.design_name;
				query = `UPDATE usersheds SET ? WHERE design_id = '${req.body.design_id}'`;
				query = mysql.format(query,updatedata);
				[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
				if(err) {
					res.send({status: "error", success: false, err: err});
					return;
				}
				query = `UPDATE usersheds2 SET ? WHERE design_id = '${req.body.design_id}'`;
				query = mysql.format(query,updatedata);
				[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
				if(err) {
					res.send({status: "error", success: false, err: err});
					return;
				} else {
					res.send({status: "success", success: true});
					return;
				}
			} else {
				query = `UPDATE usersheds SET shed_name = ? WHERE design_id = '${req.body.design_id}'`;
				query = mysql.format(query,[req.body.design_name]);
				[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
				if(err) {
					res.send({status: "error", success: false, err: err});
					return;
				}
				query = `UPDATE usersheds2 SET shed_name = ? WHERE design_id = '${req.body.design_id}'`;
				query = mysql.format(query,[req.body.design_name]);
				[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
				if(err) {
					res.send({status: "error", success: false, err: err});
					return;
				} else {
					res.send({status: "success", success: true});
					return;
				}
			}
			// break; //unreachable code
		}
		case "delete": {
			query = `INSERT INTO user_deleted_sheds (subscriber_id, series_code, location_number, userid, design_id, deleted_date, create_date, software_version, modified_date, design_locked, design_archived, design_ordered, invoice_number, order_date, design_built, build_date, design_delivered, delivery_date, shed_name, data_format, data, building_type) SELECT subscriber_id, series_code, location_number, userid, design_id, '${dateFormat(new Date(), "%Y-%m-%d", true)}', create_date, software_version, modified_date, design_locked, design_archived, design_ordered, invoice_number, order_date, design_built, build_date, design_delivered, delivery_date, shed_name, data_format, data, building_type FROM usersheds WHERE design_id = ?`;
			// query = `SELECT * FROM usersheds WHERE design_id = ?`;
			// [err, result] = await to(P_GetQueryData2(query,[req.body.design_id],ParseMySqlRowDataObj,P_ParseMySqlRowsDataObj));
			query = mysql.format(query,[req.body.design_id]);
			[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
			if(err) {
				res.send({status: "error", success: false, err: err});
				return;
			}
			query = `INSERT INTO user_deleted_sheds (subscriber_id, series_code, location_number, userid, design_id, deleted_date, create_date, software_version, modified_date, design_locked, design_archived, design_ordered, invoice_number, order_date, design_built, build_date, design_delivered, delivery_date, shed_name, data_format, data, building_type) SELECT subscriber_id, series_code, location_number, userid, design_id, '${dateFormat(new Date(), "%Y-%m-%d", true)}', create_date, software_version, modified_date, design_locked, design_archived, design_ordered, invoice_number, order_date, design_built, build_date, design_delivered, delivery_date, shed_name, data_format, data, building_type FROM usersheds2 WHERE design_id = ?`;
			query = mysql.format(query,[req.body.design_id]);
			[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
			if(err) {
				res.send({status: "error", success: false, err: err});
				return;
			} else {
				query = "DELETE FROM usersheds WHERE design_id = ?";
				query = mysql.format(query,[req.body.design_id]);
				[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
				if(err) {
					res.send({status: "error", success: false, err: err});
					return;
				}
				query = "DELETE FROM usersheds2 WHERE design_id = ?";
				query = mysql.format(query,[req.body.design_id]);
				[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
				if(err) {
					res.send({status: "error", success: false, err: err});
					return;
				}
				res.send({status: "success", success: true});
				return;
			}
			// not sure which way is better -- the below way has some advantages such as not having to change the fields if the database changes
			// however the top method keeps from using memory to store the data as the data is directly transfered within the database
			// and should keep the bandwidth lower also...
			/*
			if(_.size(result)==0) {
				res.send({status: "error", success: false, err: "Design_id not found."});
				return;
			}
			let newRow = result;
			delete newRow.id;
			newRow.deleted_date = dateFormat(new Date(), "%Y-%m-%d", true);
			query = `INSERT INTO user_deleted_sheds SET ?`;
			[err, result] = await to(P_GetQueryData2(query,newRow,null,MySQLActionResult));
			if(err) {
				res.send({status: "error", success: false, err: err});
				return;
			} else {
				res.send({status: "success", success: true});
			}
			break; */
		}
		default:
			res.send({status: "error", success: false, err: "unrecognized request type"});
			break;
		}
	} else {
		res.send({status: "error", success: false, err: "No request specified."});
	}
});

app.get('/config.js', async (req, res) =>
{
	if (DEBUG)
	{
		res.send('const DEBUG = true;');
	}
	else
	{
		res.send('const DEBUG = false;');
	}
});

app.post('/api/keygen', async(req, res) => {
	logger.debug("/api/keygen");
	let query, result, err;
	let subscriber = mysql.escape(await CleanSubscriberID(null,req));
	if (!subscriber) {
		res.status(400).send("Invalid Request - Missing data. Error Code: 3DF-KG1");
		return;
	}
	if (!req.body.userid) {
		res.status(400).send("Invalid Request - Missing data. Error Code: 3DF-KG2");
		return;
	}
	// *** TODO: check authorization
	let api_key = nanoid();
	query = `SELECT * FROM subscriber_api_keys WHERE api_key = '${api_key}'`;
	[err, result] = await to(P_GetQueryData(query, null, ReturnSingleMySQLRow));
	if (err) {
		res.status(500).send("Internal Server Error. Error Code: 3DF-KG3 Error Message:"+err);
		return;
	}
	if (result.length > 0) {
		// *** TODO: generate another key -- should be a while loop
	}
	let data = {};
	query = `INSERT INTO subscriber_api_keys SET subscriber_id = ${subscriber}, api_key = '${api_key}', data = ?`;
	query = mysql.format(query,JSON.stringify(data));
	[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
		if (err) {
			res.status(500).send("Internal Server Error. Error Code: 3DF-KG4 Error Message:"+err);
			return;
		}
	res.send({success: true, api_key: api_key});
});

app.post('/api', async (req, res) => {
	logger.debug("/api");
	let query, err, result;
	let subscriber_id = await CleanSubscriberID(null,req);
	let subscriber = mysql.escape(subscriber_id);
	if (!subscriber) {
		res.status(400).send("Invalid Request - Missing data. Error Code: 3DF-API1");
		return;
	}
	if (!req.body.api_key) {
		res.status(400).send("Invalid Request - Missing data. Error Code: 3DF-API2");
		return;
	}
	query = `SELECT * FROM subscriber_api_keys WHERE subscriber_id = ? AND api_key = ?`;
	query = mysql.format(query,[subscriber_id, req.body.api_key]);
	[err, result] = await to(P_GetQueryData(query, null, ReturnSingleMySQLRow));
	if (err) {
		logger.error(`/api: API Lookup Error: ${err}`);
		res.status(500).send("Server Error, Error Code: 3DF-API3");
		return;
	}
	if (result.length === 0) {
		logger.warn(`API request error: Invalid API key for ${subscriber_id}`);
		res.status(400).send("Invalid Request. Error Code: 3DF-API4");
		return;
	}
	if (!req.body.request) {
		logger.warn(`API request error: API Call with no request for ${subscriber_id}`);
		res.status(400).send("Invalid Request. Error Code: 3DF-API5");
		return;
	}
	switch (req.body.request) {
		case "buildings_sizes": {
			if (req.body.params) {
				query = `SELECT * FROM subscriber_buildings_sizes WHERE subscriber_id = ${subscriber} AND ${req.body.params}`;
			} else {
				query = `SELECT * FROM subscriber_buildings_sizes WHERE subscriber_id = ${subscriber}`;
			}
			[err, result] = await to(P_GetQueryData(query, ParseMySqlRowDataObj, P_ParseMySqlRowsDataObj));
			if (err) {
				logger.error(`/api: Subscriber id: ${subscriber} API Query Error: ${err}`);
				res.status(500).send("Server Error, Error Code: 3DF-API7");
				return;
			}
			res.send(result);
			return;
		}
		case "doors": {
			if (req.body.params) {
				query = `SELECT * FROM subscriber_doors WHERE subscriber_id = ${subscriber} AND ${req.body.params}`;
			} else {
				query = `SELECT * FROM subscriber_doors WHERE subscriber_id = ${subscriber}`;
			}
			[err, result] = await to(P_GetQueryData(query, ParseMySqlRowDataObj, P_ParseMySqlRowsDataObj));
			if (err) {
				logger.error(`/api: API Query Error ${err}`);
				res.status(500).send("Server Error, Error Code: 3DF-API8");
				return;
			}
			res.send(result);
			return;
		}
		case "windows": {
			if (req.body.params) {
				query = `SELECT * FROM subscriber_windows WHERE subscriber_id = ${subscriber} AND ${req.body.params}`;
			} else {
				query = `SELECT * FROM subscriber_windows WHERE subscriber_id = ${subscriber}`;
			}
			[err, result] = await to(P_GetQueryData(query, ParseMySqlRowDataObj, P_ParseMySqlRowsDataObj));
			if (err) {
				logger.error(`/api: API Query Error ${err}`);
				res.status(500).send("Server Error, Error Code: 3DF-API9");
				return;
			}
			res.send(result);
			return;
		}
		case "shelves": {
			if (req.body.params) {
				query = `SELECT * FROM subscriber_shelves WHERE subscriber_id = ${subscriber} AND ${req.body.params}`;
			} else {
				query = `SELECT * FROM subscriber_shelves WHERE subscriber_id = ${subscriber}`;
			}
			[err, result] = await to(P_GetQueryData(query, ParseMySqlRowDataObj, P_ParseMySqlRowsDataObj));
			if (err) {
				logger.error(`/api: API Query Error ${err}`);
				res.status(500).send("Server Error, Error Code: 3DF-API10");
				return;
			}
			res.send(result);
			return;
		}
		case "options": {
			if (req.body.params) {
				query = `SELECT * FROM subscriber_options WHERE subscriber_id = ${subscriber} AND ${req.body.params}`;
			} else {
				query = `SELECT * FROM subscriber_options WHERE subscriber_id = ${subscriber}`;
			}
			[err, result] = await to(P_GetQueryData(query, ParseMySqlRowDataObj, P_ParseMySqlRowsDataObj));
			if (err) {
				logger.error(`/api: API Query Error ${err}`);
				res.status(500).send("Server Error, Error Code: 3DF-API11");
				return;
			}
			res.send(result);
			return;
		}
		default: {
			logger.warn(`API request error: API Call with invalid request for ${subscriber_id} Request: ${request}`);
			res.status(400).send("Invalid Request. Error Code: 3DF-API6");
			return;
		}
	}
});

app.post('/wh/dt', async (req, res) => {
	// Daily Tasks
	logger.debug("/wh/dt");
	if (!req.body.apikey === "tdfdt") {
		res.send({success: false, err: "Unauthorized access."});
		return;
	}
	// TODO: Log run and prevent duplicate run on same day
	// Process subscriber charges
	let query = "SELECT * FROM subscriber_subscriptions WHERE active = 1 AND bill_day = ?";
	query = mysql.format(query,[new Date().getDate()]);
	let [err,result] = await to(P_GetQueryData(query,ParseMySqlRowDataObj,P_ParseMySqlRowsDataObj));
	if (err) {
		logger.error("Error at /wh/dt",err);
		res.send({success: false, err: err});
		return;
	}
	let txdate = new Date().toISOString().substr(0,10);
	for (transaction of result) {
		// TODO: Check start and end dates
		let memo = deepFind(transaction.data,"memo") || "Monthly Plan";
		query = "INSERT INTO subscriber_transactions (sbuscriber_id, txdate, debit, credit, memo) VALUES (?, ?, ?, ?, ?)";
		query = mysql.format(query,[transaction.subscriber_id,txdate,transaction.price,0,memo]);
		[err,result] = await to(P_GetQueryData(query,null,MySQLActionResult));
		if (err) {
			res.send({success: false, err: err});
			return;
		}
	}
	res.send({success: true, charges_processed: result.length});
});

app.post('/wh/bt', async (req, res) => {
	logger.debug("/wh/bt");
	let err, result;
	let subscriber;
	let dt = new Date();
	let t = dt.toISOString().substring(11, 19);
	let d = dt.toISOString().substring(0, 10);
	let dfdata = await req.formdata.getData(['data']);
	let data = JSON.parse(fs.readFileSync(dfdata.data.path));
	let data_string = JSON.stringify(data);
	//let data = JSON.stringify(req.body);
	let query = `INSERT INTO webhook_log (webhook, ip_address, date, time, data) VALUES ('/wh/bt', ?, ?, ?, ?)`;
	query = mysql.format(query,[req.ip,d,t,data_string]);
	[err,result] = await to(P_GetQueryData(query,null,MySQLActionResult));
	if (err) {
		res.send({success: false, err: err});
		return;
	}
	//if (data.kind && data.kind[0] && data.kind[0] === "subscription_charged_successfully") {
	switch (_.get(data,"kind[0]")) {
		case "subscription_charged_successfully": {
			let subscription_id = _.get(data,"subject[0].subscription[0].id[0]");
			//if (data.subject && data.subject[0] && data.subject[0].subscription && data.subscription[0] && etc {
			if (subscription_id) {
				if (subscription_id.indexOf("-") > -1) {
					result = {subscriber_id: subscription_id.substr(0,subscription_id.indexOf("-"))};
				} else {
					let query = `SELECT * FROM subscribers WHERE JSON_EXTRACT(data,"$.braintree.subscription_id") = "${subscription_id}"`;
					[err,result] = await to(P_GetQueryData(query,null,ReturnSingleMySQLRow));
					if (err) {
						res.send({success: false, err: err});
						return;
					}
				}
			if (result) {
				let subscriber_data = result;
				let memo = "Credit Card Payment";
				let query = `INSERT INTO subscriber_transactions SET subscriber_id = '${result.subscriber_id}', txdate = '${data.timestamp[0]._value.substring(0,10)}', debit = 0, credit = ${data.subject[0].subscription[0].price[0]}, memo = ?`;
				query = mysql.format(query,[memo]);
					[err,result] = await to(P_GetQueryData(query,null,MySQLActionResult));
					if (err) {
						res.send({success: false, err: err});
						return;
					}
					res.send({success: true, subscriber_data: subscriber_data});
					return;
				} else {
					res.send({success: false, err: "subscription_id not found"});
					return;
				}
			}
			break;
		} // case subscription charged
		case "disbursement": {
			//
			break;
		} // case disbursement
		res.send({success: false, err: "unknown transaction type."});
	}
	res.send({success:true});

});

app.post('/wh/pp', async (req, res) => {
	logger.debug("/wh/pp");
	let err, result;
	let subscriber;
	let dt = new Date();
	let t = dt.toISOString().substring(11, 19);
	let d = dt.toISOString().substring(0, 10);
	let data = JSON.stringify(req.body);
	let query = `INSERT INTO webhook_log (webhook, ip_address, date, time, data) VALUES ('/wh/pp', ?, ?, ?, ?)`;
	query = mysql.format(query,[req.ip,d,t,data]);
	[err,result] = await to(P_GetQueryData(query,null,MySQLActionResult));
	if (err) {
		res.send({success: false, err: err});
		return;
	}
	res.send({success:true});
});

app.post('/wh/ncsb-ebms', async (req, res) => {
	logger.debug("/wh/ncsb-ebms");
	let err, result;
	let subscriber;
	let dt = new Date();
	let t = dt.toISOString().substring(11, 19);
	let d = dt.toISOString().substring(0, 10);
	let data = JSON.stringify(req.body);
	let query = `INSERT INTO webhook_log (webhook, ip_address, date, time, data) VALUES ('/wh/ncsb-ebms', ?, ?, ?, ?)`;
	query = mysql.format(query,[req.ip,d,t,data]);
	[err,result] = await to(P_GetQueryData(query,null,MySQLActionResult));
	if (err) {
		res.send({success: false, err: err});
		return;
	}
	res.send({success:true});
});

app.get('/pwrst/*', async (req, res) => {
	logger.debug("/pwrst/*");
	let ejsdata = {};
	let query, err, result;
	let reset_code = req.params[0];
	query = `SELECT * FROM user_password_reset WHERE reset_code = ?`;
	query = mysql.format(query,[reset_code]);
	[err, result] = await to(P_GetQueryData(query,null,ReturnSingleMySQLRow));
	if (err) {
		res.status(500).send("Internal Server Error, please contact support. (Code /pwrst/*)");
		return;
	}
	if (!result) {
		res.status(404).send("Requested page not found.");
		return;
	}
	let minutesPassed = moment().diff(result.creation_time, 'minutes');
	if (minutesPassed > 60) {
		res.status(408).send("Requested link expired.");
		return;
	}
	ejsdata.minutesPassed = minutesPassed;
	ejsdata.resetData = result;
	res.render("passwordreset.html.ejs",{data:ejsdata});
	//res.send(`<html><head><title>Password Reset</title></head><body><p>Password Reset</p></body></html>`);
});

app.post('/spw', async (req, res) => {
	logger.debug("/spw");

	let query, err, result;
	if (!req.body.reset_code) {
		res.status(400).send("Invalid request.");
		return;
	}
	if (!req.body.password_hash) {
		res.status(400).send("Invalid request.");
		return;
	}
	query = `SELECT * FROM user_password_reset WHERE reset_code = ?`;
	query = mysql.format(query,[req.body.reset_code]);
	[err, result] = await to(P_GetQueryData(query,null,ReturnSingleMySQLRow));
	if (err) {
		res.status(500).send("Internal Server Error, please contact support. (Code /spw)");
		return;
	}
	if (!result) {
		res.status(401).send({success: false, err: "Authorization not found."});
		return;
	}
	query = `UPDATE users SET passwordhash = ? WHERE userid = '${result.userid}'`;
	query = mysql.format(query,[req.body.password_hash]);
	[err,result] = await to(P_GetQueryData(query,null,MySQLActionResult));
	if (err) {
		res.status(500).send("Internal Server Error, please contact support. (Code /spw)");
		return;
	}
	query = `DELETE FROM user_password_reset WHERE reset_code = ?`;
	query = mysql.format(query,[req.body.reset_code]);
	[err, result] = await to(P_GetQueryData(query,null,MySQLActionResult));
	if (err) {
		res.status(500).send("Internal Server Error, please contact support. (Code /spw)");
		return;
	}
	res.send({success: true, status: "success", designer_url: `https://${req.headers.host}`});
});

app.get('/resources/textures/*', async (req, res) => {
	logger.debug("/resources/textures/ground/");
	logger.debug(`req.path: ${req.path}`);
	let rootdir;
	if (serverLocal)
	{
		rootdir = __dirname + "/../public";
		await res.sendFile(path.join(rootdir, req.path));
	}
	else
	{
		rootdir = __dirname + "/../public";
		await res.sendFile(path.join(rootdir, req.path));
	}
});

/*
// Preliminary testing code for accessing resource files from Amazon S3 Bucket
app.get('/resources/*', async (req, res) => {
	// *** TODO:  add local bucket support
	if(DEBUG) console.log("/resources/*");
	if(DEBUG) console.log(req.path);

	//if(serverLocal)
	//{
		//
	//}
	//else {

	if(DEBUG) {
		let s3path = req.path.substr(11);
		s3path = s3path.replace(/\/\/+/g, '/');
		if(DEBUG) console.log(s3path);
		// let s3bucket = "http://3dfishdesigner.s3-website-us-east-1.amazonaws.com/";
		let s3bucket = "https://d3jasectrd3mt4.cloudfront.net/"
		res.redirect(s3bucket + s3path);
		// }  // End bracket for else (serverlocal)
		} else {
			// get file off of our server for now in production mode
			app.use(express.static(path.join(__dirname, 'public')));
		}
	});
*/
// app.get(['/','/carportdesigner.html','/sheddesigner.html','/horsebarndesigner.html'], async (req, res) =>
const rootHandler = async (req, res) =>
{
	if (req.headers['user-agent']) {
		if((req.headers['user-agent'].indexOf("MSIE") >= 0) || (req.headers['user-agent'].indexOf("Trident") >= 0)) {
			logger.warn(`Internet Explorer redirect - ${req.headers.host}`,req.headers);
			res.redirect("https://mybuilding.3dfish.net/msie.html");
			return;
		}
	} else {
		logger.warn("user-agent missing",{req: req});
	}
	if(req.baseUrl.indexOf("/sc=") === 0) {
		let redirectTo = req.protocol + "://" + req.headers.host + "/?" + req.baseUrl.substring(1);
		res.redirect(redirectTo);
		return;
	}
	req.session.ip = req.ip;
	if (req.session && req.session.bad_series_count && req.session.bad_series_count >= 5) {
		res.status(403).send("403: Your ip address has been blocked due to multiple hacking attempts. If you believe you have been blocked in error, please contact support. Error Code: 3DF-VS4");
		logger.warn(`IP ${req.ip} blocked.`);
		return;
	}
	let rootdir, subscriberStatus;
	let ejsdata = {};
	ejsdata.version = module.exports.version;
	let err, result;
	let hostdata = {};
	ejsdata.hostdata = {};
	try {
		ejsdata.client = JSON.parse(JSON.stringify(config.get("Client")));
	} catch (error) {
		ejsdata.client = false;
	}
	ejsdata.debug = DEBUG;
	ejsdata.debugcode = DEBUGCODE;
	ejsdata.resource_host = "";
	if (req.headers && req.headers.referer) {
		ejsdata.referer = req.headers.referer;
	}
	// ejsdata.interface = {};
	logger.debug("root route");
	if (serverLocal)
	{
		rootdir = __dirname + "/../public";
	}
	else
	{
		rootdir = __dirname + "/../public";
	}
	if(req.headers.host.indexOf("mybuilding.3dfish.net")==-1) {
		let [err, hostmap] = await to(getHostMap(req));
		if (err) {
			res.send(err);
			return;
		}
		logger.debug("checking host map");
		if(hostmap) {
			hostdata.customhost = true;
			let host = req.headers.host;
			if (host.indexOf(":")>-1) {
				host = host.substring(0,host.indexOf(":"));
			}
			if(hostmap.host.indexOf(host)>-1) {
				let hostindex = hostmap.host.indexOf(host);
				req.session.host = host;
				hostdata = {...hostdata, ...hostmap.data[hostindex]};
				ejsdata.hostdata = hostdata;
				req.query.sc = hostdata.subscriber_id;
			}
		}
	} else {
		req.session.host = "mybuilding.3dfish.net";
	}
	if (req.query.sc) {
		req.session.subscriber_id = mysql.escape(await CleanSubscriberID(req.query.sc,req));
		req.session.subscriber_id = req.session.subscriber_id.substr(1, req.session.subscriber_id.length-2);
		[err,subscriberStatus] = await to(validateSubscriber(req.session.subscriber_id, req));
		if (err) {
			logger.error(`app.js:fn:rootHandler: Error trying to validate subscriber id. Error: ${err}`);
			res.status(503).send("503: Service Temporarly Unavailable. Please try again. If problem persists, please contact support. Error Code: 3DF-VS1");
			return;
		}
		if(subscriberStatus.active) {
			if (req.query.series) {
				let [err,seriesStatus] = await to(validateSeriesCode(req.session.subscriber_id, req));
				if (err) {
					logger.error(`app.js:fn:rootHandler: Error trying to validate series code. Error: ${err}`);
					res.status(503).send("503: Service Temporarly Unavailable. Please try again. If problem persists, please contact support. Error Code: 3DF-VS2");
					return;
				}
				if (!seriesStatus.valid) {
					logger.warn(`Invalid series code requested. subscriber_id: ${req.session.subscriber_id} - Requested: ${req.query.series}`,{headers: req.headers, ip: req.ip});
					res.status(404).send("404: Series Requested not found. Please check your series code for typographical errors, if problem persists, try accessing without setting the series code. Error Code: 3DF-VS3");
					if (req.session) {
						if (req.session.bad_series_count) {
							req.session.bad_series_count++;
						} else {
							req.session.bad_series_count = 1;
						}
						logger.info(`Setting hacking count for ${req.ip} to ${req.session.bad_series_count}`);
					}
					return;
				}
			}
			if (hostdata.ifoverride) {
				subscriberStatus.subdata.interface_id = hostdata.ifoverride;
			}
			if (req.session && req.session.userdata) {
				if (!req.session.userdata.last_access) {req.session.userdata.last_access = null;}
				//if (req.session.userdata.last_access !== dateFormat(new Date (), "%Y-%m-%d", true)) {
					setUserLastAccess(req);
				//}
			}
			ejsdata.subscriber_data = req.subscriber_data;
			let query = `SELECT feature_id, feature_data FROM subscriber_feature_data WHERE subscriber_id='${req.session.subscriber_id}'`;
			[err, result] = await to(P_GetQueryData(query, null, ParseFeatureDataObj));
			if(err) {
				// TODO: Handle Error
			}
			if (result.resource_hosts) {
				if (DEBUG) {
					ejsdata.resource_host = result.resource_hosts.dev_host || "";
				} else {
					ejsdata.resource_host = result.resource_hosts.host || "";
				}
			}
			ejsdata = {...ejsdata, ...result};
			if (req.query.ifoverride && ejsdata.interface && ejsdata.interface.available_interfaces) {
				if (ejsdata.interface.available_interfaces.includes(req.query.ifoverride)) {
					subscriberStatus.subdata.interface_id = req.query.ifoverride;
				}
			}
			if (req.query.voverride) {
				ejsdata.version = req.query.voverride.replace(/[^\d.-]/g, '');
			}
			if (req.query.debugcode) {
				ejsdata.client.debugcode = true;
			}
			if (req.query.bg) {
				let inum = parseInt(req.query.bg);
				if (inum > 0) {
					query = `SELECT * FROM backgrounds WHERE id = ${inum}`;
					[err, result] = await to(P_GetQueryData(query, null, ReturnSingleMySQLRow));
					if (err) {
						logger.error(`app.js:fn:rootHandler: Error trying to load backgrounds. Error: ${err}`);
						// TODO: Handle Error
					}
					if (result.texture_name) {
						ejsdata.background = result.texture_name;
					}
				}
			}
			if (hostdata.dashboard_only || req.query.dashboard_only) {
				ejsdata.hostdata.dashboard_only = true;
				subscriberStatus.subdata.building_type = "DASHBOARD";
			}
			query = `SELECT * FROM interfaces WHERE interface_id = ${subscriberStatus.subdata.interface_id} AND building_type = '${subscriberStatus.subdata.building_type}' LIMIT 1`;
			[err, result] = await to(P_GetQueryData(query, null, ReturnSingleMySQLRow));
			if(err) {
				logger.error(`app.js:fn:rootHandler: Error trying to load interface data. Error: ${err}`);
				// TODO: Handle Error
			}
			let interfacedata = result;
			ejsdata.series_list = [];
			query = `SELECT * FROM subscriber_series WHERE subscriber_id='${req.session.subscriber_id}' AND active`;
			[err, result] = await to(P_GetQueryData(query, ParseMySqlRowDataObj, P_ParseMySqlRowsDataObj));
			if(err) {
				// TODO: Handle Error
				logger.error(`Error reading series list: ${err}`);
			}

			ejsdata.series_list = result;
			if(hostdata.customhost && hostdata.series_required && !req.query.series)
			{
				logger.debug("selector page");
				res.render("seriesselector.html.ejs",{data:ejsdata});
			} else {
				if(serverRunmode === "production") {
					// ejsdata.resource_host = "https://resources.3dfish.net/"; ** future implimentation
					// Push resources to browser
					if(interfacedata.production_link_header) {
						res.header('Link',fillTemplate(interfacedata.production_link_header,{version: module.exports.version}));
					}
				}
				if (req.query.family) {
					req.query.series = req.query.family;
				}
				if (!req.query.series) {
					req.query.series = "Standard";
				}
				ejsdata.series = req.query.series;
				if (hostdata.dashboard_only || req.query.dashboard_only) {
					if (!(req.session && req.session.userdata && req.session.userdata.usertype && ["admin","sadmin","master"].includes(req.session.userdata.usertype))) {
						ejsdata.codeToBeLoadedArray = codeBaseArrays["Login"];
						res.render("login.ejs",{data:ejsdata});
						return;
					}
					ejsdata.codeToBeLoadedArray = codeBaseArrays["Dashboard"];
					res.render("dashboard.html.ejs",{data:ejsdata});
					return;
				}
				ejsdata.codeToBeLoadedArray = codeBaseArrays[interfacedata.codebase_to_load];
				res.render(interfacedata.interface_file+".ejs",{data:ejsdata});
			}
		}
		else {
			//res.sendFile(path.join(rootdir + '/index.html'));
			ejsdata.subscriber_data = req.subscriber_data;
			res.render("index.html.ejs",{data:ejsdata});
		}
	}
	else {
		//res.sendFile(path.join(rootdir + '/index.html'));
		res.render("index.html.ejs",{data:{nodata: true}});
	}
//});
};


const subscriberModule = new SubscriberModule({app: app, con: con,con2:con2,logger:logger,DEBUG:DEBUG});

const userModule = new UserModule({
	serverCfg: serverCfg,
	s3: s3,
	subscriberModule:subscriberModule,
	nodemailerMailgun: nodemailerMailgun,
	app: app,
	mysql_connection: con,
	mysql_transaction_connection:con2,
	logger:logger,
	DEBUG:DEBUG
});

const masterAdminModule = new MasterAdminModule({
	app: app,
	mysql_connection: con,
	mysql_transaction_connection: con2,
	logger:logger,
	DEBUG:DEBUG
});

const designerModule = new DesignerModule(
	{app: app,
		mysql_connection: con,
		mysql_transaction_connection: con2,
		logger: logger,
		DEBUG: DEBUG
	});

const httpRouterModule = new HTTPRouterModule({
	designerModule:designerModule,
	subscriberAdminModule:admin,
	subscriberModule:subscriberModule,
	masterAdminModule:masterAdminModule,
	userModule:userModule,
	app: app,
	mysql_connection: con,
	mysql_transaction_connection:con2,
	logger:logger,
	DEBUG:DEBUG
});

const socketRouterModule = new SocketRouterModule({
	io:io,
	designerModule:designerModule,
	subscriberModule:subscriberModule,
	subscriberAdminModule:admin,
	masterAdminModule:masterAdminModule,
	userModule:userModule,
	serverAdapterActive: redisAdapterActive || mongoAdapterActive,
	redisAdapterActive: redisAdapterActive,
	mongoAdapterActive: mongoAdapterActive,
	serverAdapterType: redisAdapterActive ? "redis":"mongo",
	processID: processID,
	app: app,
	mysql_connection: con,
	mysql_transaction_connection:con2,
	logger:logger,
	DEBUG:DEBUG
});

app.get('/',rootHandler);
app.use('/carportdesigner.html',rootHandler);
app.use('/sheddesigner.html',rootHandler);
app.use('/horsebarndesigner.html',rootHandler);
app.use('/index.php',rootHandler);
app.use('/sc=*',rootHandler);

if (serverLocal)
{
	let spath = path.join(__dirname, '../public');
	if (DEBUG) {
		logger.info(`static path: ${spath}`);
	}
	app.use(express.static(spath,{index: false, fallthough: false}));
}
else
{
	app.use(express.static(path.join(__dirname, 'public'),{index: false}));
}

//app.listen(serverPort);
http.listen(serverPort);

logger.info(`${module.exports.name} version ${module.exports.version}`);
logger.info(`dirname: ${__dirname}`);
logger.info(`${module.exports.name} app listening on port ${serverPort} in ${serverRunmode} mode!`);

logger.debug('DEBUG mode ON');
logger.info(`Process ID: ${processID}`);

measureLag(DEBUG, debugLag, warnLag, resetLag, null, null, loadWarn, loadReset)

//broadcastPID();
